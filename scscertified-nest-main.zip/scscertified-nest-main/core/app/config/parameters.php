<?php

require_once __DIR__ . '/../../../web-root/nest/nest_config.php';

// Nest constants
$container->setParameter('NEST_DOMAIN', NEST_DOMAIN);
$container->setParameter('NEST_API_RELATIVE_URL', NEST_API_RELATIVE_URL);
$container->setParameter('NEST_HOME_URL', NEST_HOME_URL);
$container->setParameter('BASE_PROT', BASE_PROT);
$container->setParameter('BASE_HOST', BASE_HOST);
$container->setParameter('BASE_PORT', BASE_PORT);

// Other constants
$container->setParameter('SYMFONY_VERSION', \Symfony\Component\HttpKernel\Kernel::VERSION);
