#! /bin/bash

echo "Upload individual tables from 'pieces' directory..."
echo

i="0"
pieces="$(ls pieces)"

for i in $(ls pieces); do
    echo table: $i
    mysql -u root -p nest < pieces/$i
    echo
done
echo "Done."