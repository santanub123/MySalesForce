
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Address`
--
ALTER TABLE `Address`
  ADD CONSTRAINT `FK_C2F3561D217BBB47` FOREIGN KEY (`person_id`) REFERENCES `Person` (`id`),
  ADD CONSTRAINT `FK_C2F3561D5D83CC1` FOREIGN KEY (`state_id`) REFERENCES `State` (`id`),
  ADD CONSTRAINT `FK_C2F3561DF4837C1B` FOREIGN KEY (`org_id`) REFERENCES `Org` (`id`),
  ADD CONSTRAINT `FK_C2F3561DF92F3E70` FOREIGN KEY (`country_id`) REFERENCES `Country` (`id`);

--
-- Constraints for table `Assignedrole`
--
ALTER TABLE `Assignedrole`
  ADD CONSTRAINT `FK_196C846ED60322AC` FOREIGN KEY (`role_id`) REFERENCES `Role` (`id`),
  ADD CONSTRAINT `FK_196C846E217BBB47` FOREIGN KEY (`person_id`) REFERENCES `Person` (`id`),
  ADD CONSTRAINT `FK_196C846EF4837C1B` FOREIGN KEY (`org_id`) REFERENCES `Org` (`id`),
  ADD CONSTRAINT `FK_196C846EF8BD700D` FOREIGN KEY (`unit_id`) REFERENCES `Unit` (`id`);

--
-- Constraints for table `Org`
--
ALTER TABLE `Org`
  ADD CONSTRAINT `FK_4A58FC60727ACA70` FOREIGN KEY (`parent_id`) REFERENCES `Org` (`id`);

--
-- Constraints for table `org_orgtype`
--
ALTER TABLE `org_orgtype`
  ADD CONSTRAINT `FK_538F381E9F3D2697` FOREIGN KEY (`orgtype_id`) REFERENCES `Orgtype` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_538F381EF4837C1B` FOREIGN KEY (`org_id`) REFERENCES `Org` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `Person`
--
ALTER TABLE `Person`
  ADD CONSTRAINT `FK_3370D440A76ED395` FOREIGN KEY (`User_id`) REFERENCES `User` (`id`),
  ADD CONSTRAINT `FK_3370D440F4837C1B` FOREIGN KEY (`org_id`) REFERENCES `Org` (`id`);

--
-- Constraints for table `Unit`
--
ALTER TABLE `Unit`
  ADD CONSTRAINT `FK_7C89A36DAB2680E6` FOREIGN KEY (`unittype_id`) REFERENCES `Unittype` (`id`),
  ADD CONSTRAINT `FK_7C89A36DF08B48D3` FOREIGN KEY (`Parent_id`) REFERENCES `Unit` (`id`);

--
-- Constraints for table `User`
--
ALTER TABLE `User`
  ADD CONSTRAINT `FK_2DA17977217BBB47` FOREIGN KEY (`person_id`) REFERENCES `Person` (`id`);
