-- MySQL dump 10.13  Distrib 5.5.53, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: nest
-- ------------------------------------------------------
-- Server version	5.5.53-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Address`
--

DROP TABLE IF EXISTS `Address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT NULL,
  `person_id` int(11) DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stateIsoCode` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `countryIsoCode` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C2F3561DF4837C1B` (`org_id`),
  KEY `IDX_C2F3561D217BBB47` (`person_id`),
  KEY `IDX_C2F3561DF92F3E70` (`country_id`),
  KEY `IDX_C2F3561D5D83CC1` (`state_id`),
  CONSTRAINT `FK_C2F3561D217BBB47` FOREIGN KEY (`person_id`) REFERENCES `Person` (`id`),
  CONSTRAINT `FK_C2F3561D5D83CC1` FOREIGN KEY (`state_id`) REFERENCES `State` (`id`),
  CONSTRAINT `FK_C2F3561DF4837C1B` FOREIGN KEY (`org_id`) REFERENCES `Org` (`id`),
  CONSTRAINT `FK_C2F3561DF92F3E70` FOREIGN KEY (`country_id`) REFERENCES `Country` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Address`
--

LOCK TABLES `Address` WRITE;
/*!40000 ALTER TABLE `Address` DISABLE KEYS */;
INSERT INTO `Address` VALUES (1,NULL,24,'33026 Melody Alley','Beaumont','77713','TX','US',240,44),(2,NULL,18,'540 Ryan Hill','Norwalk','6854','CT','US',240,7),(3,4,NULL,'57 Brentwood Pass','Fort Lauderdale','33320','FL','US',240,10),(4,3,NULL,'910 Park Meadow Hill','Miami Beach','33141','FL','US',240,10),(5,NULL,1,'0 Badeau Avenue','Phoenix','85005','AZ','US',240,3),(6,NULL,49,'20726 Thierer Court','Bradenton','34282','FL','US',240,10),(7,6,NULL,'3 Myrtle Terrace','Johnstown','15906','PA','US',240,39),(8,13,NULL,'7 Dryden Park','Little Rock','72215','AR','US',240,4),(9,19,NULL,'10657 Veith Alley','Aurora','80044','CO','US',240,6),(10,5,NULL,'2525 Knutson Drive','Norfolk','23504','VA','US',240,49),(11,NULL,19,'7035 Dixon Place','El Paso','88525','TX','US',240,44),(12,NULL,9,'2164 Jackson Circle','Orlando','32891','FL','US',240,10),(13,20,NULL,'1 Waywood Circle','Dayton','45426','OH','US',240,36),(14,10,NULL,'6236 Rusk Place','Des Moines','50330','IA','US',240,16),(15,NULL,4,'98056 Oak Lane','Chicago','60604','IL','US',240,14),(16,1,NULL,'32 Lindbergh Place','Bethesda','20816','MD','US',240,21),(17,NULL,39,'6760 Schurz Park','San Diego','92132','CA','US',240,5),(18,7,NULL,'3095 Sunbrook Hill','Columbus','43284','OH','US',240,36),(19,NULL,12,'33 Hagan Pass','Charleston','29424','SC','US',240,41),(20,15,NULL,'612 Sycamore Way','Birmingham','35210','AL','US',240,1),(21,NULL,3,'566 Drewry Center','Fayetteville','28305','NC','US',240,34),(22,11,NULL,'900 Dovetail Point','Orlando','32891','FL','US',240,10),(23,NULL,9,'17827 Namekagon Hill','Washington','20409','DC','US',240,9),(24,NULL,27,'5989 Scofield Hill','Cincinnati','45249','OH','US',240,16),(25,15,NULL,'59221 Magdeline Court','New York City','10249','NY','US',240,33),(26,NULL,4,'0 Huxley Drive','Minneapolis','55487','MN','US',240,24),(27,NULL,25,'9373 Carioca Parkway','Largo','33777','FL','US',240,10),(28,NULL,19,'79 Hanover Junction','Dallas','75216','TX','US',240,44),(29,NULL,2,'17746 Tony Center','Amarillo','79176','TX','US',240,44),(30,NULL,39,'94 Saint Paul Street','Montgomery','36177','AL','US',240,1),(31,NULL,49,'42606 Hauk Place','Oakland','94660','CA','US',240,5),(32,23,NULL,'35 Nobel Crossing','New Castle','16107','PA','US',240,39),(33,17,NULL,'642 Kings Hill','Peoria','61640','IL','US',240,14),(34,NULL,29,'0317 Moland Point','Tacoma','98442','WA','US',240,48),(35,NULL,10,'08 Ryan Terrace','Boston','2114','MA','US',240,22),(36,NULL,2,'256 Kim Terrace','Cincinnati','45213','OH','US',240,36),(37,NULL,19,'4 Mitchell Trail','Lynn','1905','MA','US',240,22),(38,NULL,18,'3 Dovetail Trail','Cleveland','44191','OH','US',240,36),(39,NULL,12,'079 Schurz Plaza','Washington','20260','DC','US',240,9),(40,NULL,34,'0 Thierer Junction','Boston','2114','MA','US',240,22),(41,NULL,47,'0380 Clemons Terrace','Whittier','90610','CA','US',240,5),(42,8,NULL,'7 Milwaukee Place','Dallas','75367','TX','US',240,44),(43,NULL,32,'26 Hauk Terrace','Saint Petersburg','33737','FL','US',240,10),(44,NULL,29,'0 3rd Trail','Tulsa','74141','OK','US',240,37),(45,24,NULL,'17 Mayer Plaza','Inglewood','90310','CA','US',240,5),(46,16,NULL,'7 Maple Wood Way','Meridian','39305','MS','US',240,25),(47,NULL,25,'47 Sunfield Road','Saint Louis','63131','MO','US',240,26),(48,NULL,37,'99432 Reindahl Alley','Oklahoma City','73135','OK','US',240,37),(49,NULL,46,'43 Lukken Terrace','Washington','20238','DC','US',240,9),(50,NULL,2,'3535 Hermina Crossing','Duluth','30096','GA','US',240,11);
/*!40000 ALTER TABLE `Address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `App`
--

DROP TABLE IF EXISTS `App`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `App` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appkey` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `abbreviation` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `App`
--

LOCK TABLES `App` WRITE;
/*!40000 ALTER TABLE `App` DISABLE KEYS */;
INSERT INTO `App` VALUES (1,'','','User Admin',NULL,'user_admin','user_admin_icon.png'),(2,'','','GPG',NULL,'gpg','gpg_icon.png'),(3,'','','Food & Ag',NULL,'food_and_ag','food_ag_icon.png'),(4,'','','Client Badges',NULL,'client_badges','client_badges_icon.png'),(5,'','','Staff Suggestion Box',NULL,'staff_suggestion_box','user_admin.png'),(6,'','','Bugify',NULL,'request.scscertified.com','bugify_icon.png'),(7,'','','Auditor Resource System',NULL,'auditor_resource_system','ars_icon.png'),(8,'','','Eco Options',NULL,'eco_options','eco_options_icon.png'),(9,'','','Lot Label',NULL,'lot_label','lot_label_icon.png'),(10,'','','Internal Audit Portal',NULL,'internal_audit_portal','iap_icon.png');
/*!40000 ALTER TABLE `App` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `App_Role`
--

DROP TABLE IF EXISTS `App_Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `App_Role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `App_id` int(11) DEFAULT NULL,
  `Role_id` int(11) DEFAULT NULL,
  `Unit_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B0362A27987212D` (`App_id`),
  KEY `IDX_B0362A2D60322AC` (`Role_id`),
  KEY `IDX_B0362A2F8BD700D` (`Unit_id`),
  CONSTRAINT `FK_B0362A219BE1B30` FOREIGN KEY (`Role_id`) REFERENCES `Role` (`id`),
  CONSTRAINT `FK_B0362A237004991` FOREIGN KEY (`Unit_id`) REFERENCES `Unit` (`id`),
  CONSTRAINT `FK_B0362A27E2B241B` FOREIGN KEY (`App_id`) REFERENCES `App` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `App_Role`
--

LOCK TABLES `App_Role` WRITE;
/*!40000 ALTER TABLE `App_Role` DISABLE KEYS */;
INSERT INTO `App_Role` VALUES (1,1,1,3,'Admin','Can create and manage accounts for all types of users'),(2,1,1,5,'Admin','Can create and manage accounts for all types of users'),(3,1,1,1,'Admin','Can create and manage accounts for users who are clients or auditors'),(4,2,3,12,NULL,'Can view and edit products that belong to their company'),(5,2,1,12,NULL,'Can approve edits to products, can manage client accounts'),(6,3,3,15,NULL,'Can view confidential reports'),(7,3,1,15,NULL,'Can create information, can manage client accounts'),(8,3,4,15,NULL,'Can edit meta data (like commodity lists)'),(9,4,1,1,NULL,'Don\'t know'),(10,4,3,1,NULL,'Don\'t know'),(11,5,1,1,NULL,'Can make suggestions'),(12,5,1,3,NULL,'Can change the recipient addresses of complaints'),(13,6,1,1,NULL,'Assigned to \'user\' group in bugify (can make requests)'),(14,6,1,5,NULL,'Assigned to \'admin\' group in bugify (can respond to requests and change meta-data'),(15,7,2,1,NULL,'can view and \'read\' documents for their units'),(16,7,4,1,NULL,'can manage auditor accounts, and auditor compliance info. Can post documents.'),(17,8,5,1,NULL,'can upload reports'),(18,8,6,1,NULL,'can view reports'),(19,9,3,13,NULL,'view info specific to that client, create and print lot labels'),(20,9,1,12,NULL,'can view info for all clients, and create labels'),(21,9,2,13,NULL,'can view info for all clients, and create labels'),(22,9,NULL,NULL,'Lot Label User','(public access) can look up lot labels'),(23,10,1,1,NULL,'can view records, and edit records that they are associated with'),(24,10,1,4,NULL,'can create records, and view and edit them'),(25,10,7,1,NULL,'changes notifications received'),(26,10,8,1,NULL,'changes notifications received'),(27,1,1,10,NULL,'test 1'),(28,2,1,10,NULL,'test 1');
/*!40000 ALTER TABLE `App_Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Assigned_Role`
--

DROP TABLE IF EXISTS `Assigned_Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Assigned_Role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT NULL,
  `person_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AD5D9458F4837C1B` (`org_id`),
  KEY `IDX_AD5D9458217BBB47` (`person_id`),
  KEY `IDX_AD5D9458D60322AC` (`role_id`),
  KEY `IDX_AD5D9458F8BD700D` (`unit_id`),
  CONSTRAINT `FK_AD5D9458217BBB47` FOREIGN KEY (`person_id`) REFERENCES `Person` (`id`),
  CONSTRAINT `FK_AD5D9458D60322AC` FOREIGN KEY (`role_id`) REFERENCES `Role` (`id`),
  CONSTRAINT `FK_AD5D9458F4837C1B` FOREIGN KEY (`org_id`) REFERENCES `Org` (`id`),
  CONSTRAINT `FK_AD5D9458F8BD700D` FOREIGN KEY (`unit_id`) REFERENCES `Unit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Assigned_Role`
--

LOCK TABLES `Assigned_Role` WRITE;
/*!40000 ALTER TABLE `Assigned_Role` DISABLE KEYS */;
INSERT INTO `Assigned_Role` VALUES (1,1,NULL,1,NULL,''),(2,2,NULL,2,NULL,''),(3,3,NULL,NULL,8,''),(4,4,NULL,NULL,7,''),(5,5,NULL,NULL,6,''),(6,6,NULL,NULL,5,''),(7,7,NULL,7,NULL,''),(8,8,NULL,NULL,3,''),(9,9,NULL,NULL,2,''),(10,10,NULL,6,NULL,''),(11,NULL,11,5,NULL,''),(12,NULL,12,NULL,12,''),(13,NULL,13,NULL,14,''),(14,NULL,14,NULL,15,''),(15,NULL,15,1,NULL,''),(17,NULL,17,NULL,3,''),(18,NULL,18,7,NULL,''),(19,NULL,19,NULL,7,''),(20,7,NULL,NULL,8,''),(21,18,NULL,4,NULL,''),(22,24,NULL,6,NULL,''),(23,17,NULL,NULL,12,''),(24,18,NULL,NULL,13,''),(25,24,NULL,NULL,14,''),(27,NULL,27,NULL,1,''),(28,NULL,28,4,NULL,''),(29,18,NULL,2,NULL,''),(30,16,NULL,1,NULL,''),(31,14,NULL,NULL,7,''),(32,12,NULL,NULL,8,''),(33,NULL,33,4,9,''),(34,NULL,34,2,15,''),(35,NULL,35,1,6,''),(36,NULL,36,3,7,''),(37,NULL,37,4,10,''),(38,15,NULL,5,5,''),(39,13,NULL,6,8,''),(40,11,NULL,7,4,''),(41,9,NULL,8,11,''),(42,7,NULL,4,11,''),(43,5,NULL,3,11,''),(44,NULL,44,4,14,''),(45,NULL,45,2,7,''),(47,4,NULL,6,5,''),(48,NULL,48,4,8,''),(49,8,NULL,3,13,''),(50,NULL,50,1,2,'');
/*!40000 ALTER TABLE `Assigned_Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Country`
--

DROP TABLE IF EXISTS `Country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isoCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Country`
--

LOCK TABLES `Country` WRITE;
/*!40000 ALTER TABLE `Country` DISABLE KEYS */;
INSERT INTO `Country` VALUES (1,'AF','Afghanistan',0),(2,'AX','Åland Islands',1),(3,'AL','Albania',1),(4,'DZ','Algeria',1),(5,'AS','American Samoa',1),(6,'AD','Andorra',0),(7,'AO','Angola',1),(8,'AI','Anguilla',1),(9,'AQ','Antarctica',0),(10,'AG','Antigua and Barbuda',1),(11,'AR','Argentina',0),(12,'AM','Armenia',1),(13,'AW','Aruba',1),(14,'AU','Australia',1),(15,'AT','Austria',0),(16,'AZ','Azerbaijan',1),(17,'BS','Bahamas',1),(18,'BH','Bahrain',0),(19,'BD','Bangladesh',1),(20,'BB','Barbados',0),(21,'BY','Belarus',1),(22,'BE','Belgium',0),(23,'BZ','Belize',0),(24,'BJ','Benin',1),(25,'BM','Bermuda',0),(26,'BT','Bhutan',0),(27,'BO','Bolivia (Plurinational State of)',1),(28,'BQ','Bonaire, Sint Eustatius and Saba',0),(29,'BA','Bosnia and Herzegovina',0),(30,'BW','Botswana',1),(31,'BV','Bouvet Island',0),(32,'BR','Brazil',0),(33,'IO','British Indian Ocean Territory',0),(34,'BN','Brunei Darussalam',1),(35,'BG','Bulgaria',0),(36,'BF','Burkina Faso',1),(37,'BI','Burundi',1),(38,'CV','Cabo Verde',1),(39,'KH','Cambodia',0),(40,'CM','Cameroon',1),(41,'CA','Canada',0),(42,'KY','Cayman Islands',1),(43,'CF','Central African Republic',0),(44,'TD','Chad',1),(45,'CL','Chile',0),(46,'CN','China',1),(47,'CX','Christmas Island',1),(48,'CC','Cocos (Keeling) Islands',0),(49,'CO','Colombia',1),(50,'KM','Comoros',0),(51,'CG','Congo',0),(52,'CD','Congo (Democratic Republic of the)',0),(53,'CK','Cook Islands',1),(54,'CR','Costa Rica',1),(55,'CI','Côte d\'Ivoire',1),(56,'HR','Croatia',0),(57,'CU','Cuba',0),(58,'CW','Curaçao',0),(59,'CY','Cyprus',1),(60,'CZ','Czechia',0),(61,'DK','Denmark',1),(62,'DJ','Djibouti',0),(63,'DM','Dominica',1),(64,'DO','Dominican Republic',0),(65,'EC','Ecuador',1),(66,'EG','Egypt',1),(67,'SV','El Salvador',0),(68,'GQ','Equatorial Guinea',1),(69,'ER','Eritrea',0),(70,'EE','Estonia',1),(71,'ET','Ethiopia',1),(72,'FK','Falkland Islands (Malvinas)',0),(73,'FO','Faroe Islands',1),(74,'FJ','Fiji',0),(75,'FI','Finland',0),(76,'FR','France',0),(77,'GF','French Guiana',1),(78,'PF','French Polynesia',1),(79,'TF','French Southern Territories',0),(80,'GA','Gabon',1),(81,'GM','Gambia',0),(82,'GE','Georgia',1),(83,'DE','Germany',0),(84,'GH','Ghana',1),(85,'GI','Gibraltar',0),(86,'GR','Greece',0),(87,'GL','Greenland',0),(88,'GD','Grenada',1),(89,'GP','Guadeloupe',1),(90,'GU','Guam',0),(91,'GT','Guatemala',1),(92,'GG','Guernsey',1),(93,'GN','Guinea',1),(94,'GW','Guinea-Bissau',0),(95,'GY','Guyana',1),(96,'HT','Haiti',1),(97,'HM','Heard Island and McDonald Islands',1),(98,'VA','Holy See',0),(99,'HN','Honduras',1),(100,'HK','Hong Kong',0),(101,'HU','Hungary',1),(102,'IS','Iceland',0),(103,'IN','India',1),(104,'ID','Indonesia',0),(105,'IR','Iran (Islamic Republic of)',0),(106,'IQ','Iraq',0),(107,'IE','Ireland',1),(108,'IM','Isle of Man',1),(109,'IL','Israel',0),(110,'IT','Italy',1),(111,'JM','Jamaica',1),(112,'JP','Japan',1),(113,'JE','Jersey',0),(114,'JO','Jordan',1),(115,'KZ','Kazakhstan',0),(116,'KE','Kenya',1),(117,'KI','Kiribati',0),(118,'KP','Korea (Democratic People\'s Republic of)',0),(119,'KR','Korea (Republic of)',1),(120,'KW','Kuwait',0),(121,'KG','Kyrgyzstan',0),(122,'LA','Lao People\'s Democratic Republic',1),(123,'LV','Latvia',0),(124,'LB','Lebanon',0),(125,'LS','Lesotho',0),(126,'LR','Liberia',1),(127,'LY','Libya',0),(128,'LI','Liechtenstein',1),(129,'LT','Lithuania',1),(130,'LU','Luxembourg',1),(131,'MO','Macao',0),(132,'MK','Macedonia (the former Yugoslav Republic of)',1),(133,'MG','Madagascar',0),(134,'MW','Malawi',1),(135,'MY','Malaysia',0),(136,'MV','Maldives',1),(137,'ML','Mali',0),(138,'MT','Malta',1),(139,'MH','Marshall Islands',1),(140,'MQ','Martinique',0),(141,'MR','Mauritania',1),(142,'MU','Mauritius',0),(143,'YT','Mayotte',0),(144,'MX','Mexico',1),(145,'FM','Micronesia (Federated States of)',1),(146,'MD','Moldova (Republic of)',0),(147,'MC','Monaco',1),(148,'MN','Mongolia',0),(149,'ME','Montenegro',1),(150,'MS','Montserrat',0),(151,'MA','Morocco',1),(152,'MZ','Mozambique',0),(153,'MM','Myanmar',0),(154,'NA','Namibia',0),(155,'NR','Nauru',1),(156,'NP','Nepal',1),(157,'NL','Netherlands',0),(158,'NC','New Caledonia',1),(159,'NZ','New Zealand',1),(160,'NI','Nicaragua',1),(161,'NE','Niger',0),(162,'NG','Nigeria',1),(163,'NU','Niue',0),(164,'NF','Norfolk Island',1),(165,'MP','Northern Mariana Islands',0),(166,'NO','Norway',0),(167,'OM','Oman',1),(168,'PK','Pakistan',0),(169,'PW','Palau',0),(170,'PS','Palestine, State of',1),(171,'PA','Panama',1),(172,'PG','Papua New Guinea',0),(173,'PY','Paraguay',1),(174,'PE','Peru',1),(175,'PH','Philippines',0),(176,'PN','Pitcairn',1),(177,'PL','Poland',0),(178,'PT','Portugal',0),(179,'PR','Puerto Rico',1),(180,'QA','Qatar',1),(181,'RE','Réunion',1),(182,'RO','Romania',0),(183,'RU','Russian Federation',0),(184,'RW','Rwanda',1),(185,'BL','Saint Barthélemy',1),(186,'SH','Saint Helena, Ascension and Tristan da Cunha',0),(187,'KN','Saint Kitts and Nevis',1),(188,'LC','Saint Lucia',1),(189,'MF','Saint Martin (French part)',1),(190,'PM','Saint Pierre and Miquelon',0),(191,'VC','Saint Vincent and the Grenadines',0),(192,'WS','Samoa',1),(193,'SM','San Marino',1),(194,'ST','Sao Tome and Principe',0),(195,'SA','Saudi Arabia',1),(196,'SN','Senegal',0),(197,'RS','Serbia',0),(198,'SC','Seychelles',1),(199,'SL','Sierra Leone',0),(200,'SG','Singapore',0),(201,'SX','Sint Maarten (Dutch part)',0),(202,'SK','Slovakia',1),(203,'SI','Slovenia',0),(204,'SB','Solomon Islands',1),(205,'SO','Somalia',1),(206,'ZA','South Africa',1),(207,'GS','South Georgia and the South Sandwich Islands',0),(208,'SS','South Sudan',1),(209,'ES','Spain',0),(210,'LK','Sri Lanka',1),(211,'SD','Sudan',0),(212,'SR','Suriname',1),(213,'SJ','Svalbard and Jan Mayen',0),(214,'SZ','Swaziland',1),(215,'SE','Sweden',0),(216,'CH','Switzerland',0),(217,'SY','Syrian Arab Republic',1),(218,'TW','Taiwan, Province of China[a]',1),(219,'TJ','Tajikistan',0),(220,'TZ','Tanzania, United Republic of',1),(221,'TH','Thailand',1),(222,'TL','Timor-Leste',0),(223,'TG','Togo',1),(224,'TK','Tokelau',0),(225,'TO','Tonga',0),(226,'TT','Trinidad and Tobago',1),(227,'TN','Tunisia',1),(228,'TR','Turkey',1),(229,'TM','Turkmenistan',0),(230,'TC','Turks and Caicos Islands',0),(231,'TV','Tuvalu',1),(232,'UG','Uganda',1),(233,'UA','Ukraine',0),(234,'AE','United Arab Emirates',1),(235,'GB','United Kingdom of Great Britain and Northern Ireland',1),(236,'US','United States of America',1),(237,'UM','United States Minor Outlying Islands',0),(238,'UY','Uruguay',0),(239,'UZ','Uzbekistan',1),(240,'VU','Vanuatu',0),(241,'VE','Venezuela (Bolivarian Republic of)',1),(242,'VN','Viet Nam',1),(243,'VG','Virgin Islands (British)',1),(244,'VI','Virgin Islands (U.S.)',0),(245,'WF','Wallis and Futuna',0),(246,'EH','Western Sahara',1),(247,'YE','Yemen',0),(248,'ZM','Zambia',0),(249,'ZW','Zimbabwe',1);
/*!40000 ALTER TABLE `Country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Org`
--

DROP TABLE IF EXISTS `Org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Org` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4A58FC60727ACA70` (`parent_id`),
  CONSTRAINT `FK_4A58FC60727ACA70` FOREIGN KEY (`parent_id`) REFERENCES `Org` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Org`
--

LOCK TABLES `Org` WRITE;
/*!40000 ALTER TABLE `Org` DISABLE KEYS */;
INSERT INTO `Org` VALUES (1,NULL,'World Wildlife Fund','kbishop0@prnewswire.com','1-(312)704-2670'),(2,1,'Sierra Club','jjohnston1@drupal.org','1-(440)760-2466'),(3,2,'National Audubon Society','tcox2@cyberchimps.com','1-(724)509-1654'),(4,2,'EarthFirst!','aduncan3@nasa.gov','1-(303)150-4168'),(5,6,'Greenpeace','cmason4@abc.net.au','1-(410)440-2068'),(6,1,'National Wildlife Federation','jhunt5@bbb.org','1-(972)252-2076'),(7,9,'Natural Resources Defense Council (NRDC)','sscott6@purevolume.com','1-(423)380-1376'),(8,5,'1% For The Planet','esnyder7@diigo.com','1-(205)393-3365'),(9,10,'Co-Op America','scook8@ow.ly','1-(808)138-0853'),(10,1,'World Business Council for Sustainable Development','ecole9@example.com','1-(904)630-4576'),(11,8,'Forest Stewardship Council','esimsa@gnu.org','1-(727)974-1088'),(12,13,'Rainforest Action Network','erileyb@ca.gov','1-(281)976-9441'),(13,2,'The Nature Conservancy','bhudsonc@spotify.com','1-(304)600-6918'),(14,6,'Heal the Bay','eharveyd@google.it','1-(419)856-1728'),(15,16,'Surfrider','afowlere@smh.com.au','1-(757)369-5016'),(16,17,'Environmental Defense Fund','nmccoyf@google.ru','1-(256)222-9265'),(17,18,'Friends of Earth (FOE)','jrobinsong@shareasale.com','1-(360)797-4608'),(18,NULL,'Worldwatch Institute','rhunterh@istockphoto.com','1-(214)300-3359'),(19,16,'American Bird Conservancy','spiercei@whitehouse.gov','1-(360)242-2382'),(20,3,'Intergovernmental Panel on Climate Change','dreyesj@redcross.org','1-(512)275-7609'),(21,22,'United States Environmental Protection Agency','ewalkerk@wordpress.org','1-(512)496-5882'),(22,6,'Earth Liberation Front','mfreemanl@umn.edu','1-(303)690-4738'),(23,16,'Wildlife Conservation Society','rgutierrezm@blogger.com','1-(540)687-9525'),(24,20,'Association of Environmental Professionals','astonen@wikipedia.org','1-(606)736-8944'),(25,1,'National Geographic Society','jstewarto@ow.ly','1-(413)995-8888');
/*!40000 ALTER TABLE `Org` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrgType`
--

DROP TABLE IF EXISTS `OrgType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrgType` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrgType`
--

LOCK TABLES `OrgType` WRITE;
/*!40000 ALTER TABLE `OrgType` DISABLE KEYS */;
INSERT INTO `OrgType` VALUES (1,'SCS','Root Company'),(2,'Client','Certification client, etc.'),(3,'Contractor','Auditor or other vendor'),(4,'Partner','Collaboration organization');
/*!40000 ALTER TABLE `OrgType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Person`
--

DROP TABLE IF EXISTS `Person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT NULL,
  `nameHonorific` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `nameFirst` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nameMiddle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nameLast` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email1` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email2` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phoneCell` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `User_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3370D440A76ED395` (`User_id`),
  KEY `IDX_3370D440F4837C1B` (`org_id`),
  CONSTRAINT `FK_3370D44068D3EA09` FOREIGN KEY (`User_id`) REFERENCES `User` (`id`),
  CONSTRAINT `FK_3370D440F4837C1B` FOREIGN KEY (`org_id`) REFERENCES `Org` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Person`
--

LOCK TABLES `Person` WRITE;
/*!40000 ALTER TABLE `Person` DISABLE KEYS */;
INSERT INTO `Person` VALUES (1,2,'Ms','Katherine','Boyd','Richardson','Financial Analyst','krichardson0@scscertified.com','krichardson0@example.com','(702) 513-3990','(856) 905-4162',1),(2,8,'Honorable','Arthur','Hill','Gibson','Social Worker','agibson1@scscertified.com','agibson1@sciencedaily.com','(971) 143-1558','(512) 530-6347',2),(3,2,'Honorable','Wanda','Carter','Knight','Database Administrator I','wknight2@scscertified.com','wknight2@go.com','(419) 110-8210','(561) 171-9586',3),(4,9,'Mrs','Jacqueline','Harvey','Hunt','Technical Writer','jhunt3@scscertified.com','jhunt3@sfgate.com','(313) 721-6806','(732) 337-1729',4),(5,5,'Mr','Bobby','Boyd','Patterson','Chief Design Engineer','bpatterson4@scscertified.com','bpatterson4@flickr.com','(415) 322-4318','(937) 700-8037',5),(6,3,'Honorable','Shirley','Woods','Nguyen','Cost Accountant','snguyen5@scscertified.com','snguyen5@dell.com','(850) 376-9463','(602) 158-3430',6),(7,12,'Rev','Philip','Carter','Simpson','Data Coordiator','psimpson6@scscertified.com','psimpson6@cdbaby.com','(404) 289-5667','(832) 827-4671',7),(8,2,'Dr','Gloria','Austin','Rivera','Nuclear Power Engineer','grivera7@scscertified.com','grivera7@statcounter.com','(908) 568-8217','(209) 492-1862',8),(9,3,'Honorable','Jose','Bradley','Harrison','Statistician III','jharrison8@scscertified.com','jharrison8@java.com','(804) 321-3121','(646) 576-3420',9),(10,10,'Dr','Margaret','Welch','Richardson','Graphic Designer','mrichardson9@scscertified.com','mrichardson9@indiegogo.com','(903) 127-5875','(504) 225-6533',10),(11,8,'Honorable','Ashley','Nguyen','Adams','Legal Assistant','aadamsa@scscertified.com','aadamsa@cmu.edu','(806) 662-2201','(979) 299-2983',11),(12,11,'Dr','Jessica','Ferguson','Burke','Safety Technician IV','jburkeb@scscertified.com','jburkeb@163.com','(619) 656-2016','(501) 475-2612',12),(13,2,'Mr','Brian','Brown','Austin','Mechanical Systems Engineer','baustinc@scscertified.com','baustinc@howstuffworks.com','(407) 914-3831','(402) 244-5010',13),(14,2,'Ms','Louise','Gonzalez','Stone','Marketing Assistant','lstoned@scscertified.com','lstoned@google.nl','(614) 182-9528','(915) 940-0582',14),(15,11,'Mrs','Debra','Cooper','Stewart','Tax Accountant','dstewarte@scscertified.com','dstewarte@biglobe.ne.jp','(916) 862-5549','(862) 951-4344',15),(16,9,'Ms','Irene','Watkins','Crawford','Geological Engineer','icrawfordf@scscertified.com','icrawfordf@symantec.com','(214) 611-7642','(812) 272-9675',16),(17,1,'Rev','Arthur','Freeman','Murray','VP Product Management','amurrayg@scscertified.com','amurrayg@samsung.com','(612) 198-2111','(843) 784-8376',17),(18,7,'Ms','Norma','Roberts','Franklin','Payment Adjustment Coordinator','nfranklinh@scscertified.com','nfranklinh@sciencedaily.com','(901) 151-4375','(410) 453-9751',18),(19,11,'Mrs','Amy','Payne','Hanson','Compensation Analyst','ahansoni@scscertified.com','ahansoni@live.com','(951) 268-7149','(203) 966-3567',19),(20,11,'Rev','Donald','Gonzales','Fisher','Nurse Practicioner','dfisherj@scscertified.com','dfisherj@furl.net','(765) 558-2152','(314) 218-3971',20),(21,11,'Rev','Shawn','Chavez','Hamilton','Accounting Assistant IV','shamiltonk@scscertified.com','shamiltonk@dell.com','(610) 361-6002','(941) 938-7234',21),(22,5,'Honorable','Clarence','Duncan','Kennedy','Electrical Engineer','ckennedyl@scscertified.com','ckennedyl@clickbank.net','(202) 102-5653','(912) 285-9006',22),(23,9,'Dr','Katherine','Mason','Watkins','Structural Engineer','kwatkinsm@scscertified.com','kwatkinsm@bigcartel.com','(916) 978-7379','(304) 587-5028',23),(24,10,'Mr','Randy','Jones','Garrett','Associate Professor','rgarrettn@scscertified.com','rgarrettn@google.com.hk','(727) 466-6638','(914) 736-5696',24),(25,1,'Mr','Scott','Morris','Garrett','Help Desk Operator','sgarretto@scscertified.com','sgarretto@salon.com','(330) 490-7763','(614) 979-5411',25),(26,10,'Mr','Victor','Fox','Owens','General Manager','vowensp@scscertified.com','vowensp@samsung.com','(617) 345-5471','(954) 471-7618',26),(27,10,'Mr','Keith','Simmons','Ellis','Human Resources Manager','kellisq@scscertified.com','kellisq@illinois.edu','(517) 726-5104','(727) 491-6735',27),(28,10,'Dr','Phyllis','Richards','Bell','Professor','pbellr@scscertified.com','pbellr@de.vu','(804) 891-2982','(316) 808-4346',28),(29,9,'Honorable','Kimberly','Morris','Jones','Help Desk Operator','kjoness@scscertified.com','kjoness@cdbaby.com','(718) 723-4446','(253) 422-2096',29),(30,4,'Mr','Todd','Burke','Banks','Quality Engineer','tbankst@scscertified.com','tbankst@bing.com','(682) 360-6882','(614) 695-4724',30),(31,2,'Mrs','Rebecca','Brooks','Moreno','Quality Engineer','rmorenou@scscertified.com','rmorenou@usda.gov','(210) 265-9320','(406) 494-3280',31),(32,4,'Honorable','Tina','King','Snyder','Dental Hygienist','tsnyderv@scscertified.com','tsnyderv@dagondesign.com','(619) 287-6703','(304) 521-3370',32),(33,12,'Mrs','Michelle','Stanley','Collins','Human Resources Assistant III','mcollinsw@scscertified.com','mcollinsw@usa.gov','(423) 550-9462','(808) 321-3281',33),(34,8,'Rev','Gloria','Gomez','Rodriguez','Mechanical Systems Engineer','grodriguezx@scscertified.com','grodriguezx@redcross.org','(859) 185-7122','(410) 601-9519',34),(35,12,'Honorable','Daniel','Myers','Elliott','Health Coach II','delliotty@scscertified.com','delliotty@archive.org','(937) 674-3569','(786) 872-4751',35),(36,6,'Dr','Jerry','Welch','Montgomery','Account Executive','jmontgomeryz@scscertified.com','jmontgomeryz@loc.gov','(260) 809-7048','(601) 491-7954',36),(37,8,'Mr','Billy','Moreno','Riley','Librarian','briley10@scscertified.com','briley10@ebay.co.uk','(985) 638-8425','(262) 947-6769',37),(38,12,'Rev','Clarence','Banks','Palmer','Analog Circuit Design manager','cpalmer11@scscertified.com','cpalmer11@abc.net.au','(540) 125-9874','(773) 503-4063',38),(39,1,'Dr','Edward','Ross','Wallace','Statistician I','ewallace12@scscertified.com','ewallace12@dailymotion.com','(918) 396-7708','(312) 328-9400',39),(40,6,'Mr','Albert','Banks','Jones','Dental Hygienist','ajones13@scscertified.com','ajones13@mediafire.com','(606) 680-5274','(916) 854-4808',40),(41,12,'Rev','Jesse','Larson','Bell','Design Engineer','jbell14@scscertified.com','jbell14@taobao.com','(515) 214-0799','(513) 383-2042',41),(42,4,'Rev','Dorothy','Peters','Kelley','Recruiter','dkelley15@scscertified.com','dkelley15@technorati.com','(202) 867-9227','(812) 102-9549',42),(43,9,'Honorable','Gary','Boyd','Ramirez','Assistant Media Planner','gramirez16@scscertified.com','gramirez16@webmd.com','(816) 496-8874','(801) 266-5133',43),(44,7,'Mr','Johnny','Morrison','Russell','Nurse','jrussell17@scscertified.com','jrussell17@yandex.ru','(402) 663-5837','(323) 911-5782',44),(45,8,'Mrs','Pamela','Flores','Taylor','GIS Technical Architect','ptaylor18@scscertified.com','ptaylor18@tuttocitta.it','(240) 598-0056','(646) 714-6605',45),(46,6,'Honorable','Kathy','Richards','Tucker','Administrative Officer','ktucker19@scscertified.com','ktucker19@census.gov','(530) 791-4264','(302) 141-8986',46),(47,5,'Dr','Sean','Howell','Thomas','Accountant II','sthomas1a@scscertified.com','sthomas1a@elegantthemes.com','(213) 137-4514','(713) 452-2445',47),(48,10,'Dr','Clarence','Washington','Morales','Project Manager','cmorales1b@scscertified.com','cmorales1b@google.co.jp','(515) 975-3395','(361) 239-3287',48),(49,1,'Ms','Carol','Meyer','Welch','Product Engineer','cwelch1c@scscertified.com','cwelch1c@mediafire.com','(719) 482-2861','(916) 525-4514',49),(50,7,'Ms','Lois','Bradley','Ford','Librarian','lford1d@scscertified.com','lford1d@engadget.com','amendoza1d@ow.ly','(361) 588-9619',50);
/*!40000 ALTER TABLE `Person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES (1,'staff','will be a staff person'),(2,'auditor','will be a staff person'),(3,'client','will be a staff person'),(4,'Admin','will be a staff person'),(5,'Eco Options Admin','can be staff or client'),(6,'Eco Options User','can be staff or client'),(7,'IAP Upper Management','limited to upper management'),(8,'IAP Notification Exempt','limited to staff');
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `State`
--

DROP TABLE IF EXISTS `State`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `State` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isoCode` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_local` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `abbreviation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `countryCode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `State`
--

LOCK TABLES `State` WRITE;
/*!40000 ALTER TABLE `State` DISABLE KEYS */;
INSERT INTO `State` VALUES (1,'US-AL','Alabama','Alabama','AL','US'),(2,'US-AK','Alaska','Alaska','AK','US'),(3,'US-AZ','Arizona','Arizona','AZ','US'),(4,'US-AR','Arkansas','Arkansas','AR','US'),(5,'US-CA','California','California','CA','US'),(6,'US-CO','Colorado','Colorado','CO','US'),(7,'US-CT','Connecticut','Connecticut','CT','US'),(8,'US-DE','Delaware','Delaware','DE','US'),(9,'US-DC','District of Columbia','District of Columbia','DC','US'),(10,'US-FL','Florida','Florida','FL','US'),(11,'US-GA','Georgia','Georgia','GA','US'),(12,'US-HI','Hawaii','Hawaii','HI','US'),(13,'US-ID','Idaho','Idaho','ID','US'),(14,'US-IL','Illinois','Illinois','IL','US'),(15,'US-IN','Indiana','Indiana','IN','US'),(16,'US-IA','Iowa','Iowa','IA','US'),(17,'US-KS','Kansas','Kansas','KS','US'),(18,'US-KY','Kentucky','Kentucky','KY','US'),(19,'US-LA','Louisiana','Louisiana','LA','US'),(20,'US-ME','Maine','Maine','ME','US'),(21,'US-MD','Maryland','Maryland','MD','US'),(22,'US-MA','Massachusetts','Massachusetts','MA','US'),(23,'US-MI','Michigan','Michigan','MI','US'),(24,'US-MN','Minnesota','Minnesota','MN','US'),(25,'US-MS','Mississippi','Mississippi','MS','US'),(26,'US-MO','Missouri','Missouri','MO','US'),(27,'US-MT','Montana','Montana','MT','US'),(28,'US-NE','Nebraska','Nebraska','NE','US'),(29,'US-NV','Nevada','Nevada','NV','US'),(30,'US-NH','New Hampshire','New Hampshire','NH','US'),(31,'US-NJ','New Jersey','New Jersey','NJ','US'),(32,'US-NM','New Mexico','New Mexico','NM','US'),(33,'US-NY','New York','New York','NY','US'),(34,'US-NC','North Carolina','North Carolina','NC','US'),(35,'US-ND','North Dakota','North Dakota','ND','US'),(36,'US-OH','Ohio','Ohio','OH','US'),(37,'US-OK','Oklahoma','Oklahoma','OK','US'),(38,'US-OR','Oregon','Oregon','OR','US'),(39,'US-PA','Pennsylvania','Pennsylvania','PA','US'),(40,'US-RI','Rhode Island','Rhode Island','RI','US'),(41,'US-SC','South Carolina','South Carolina','SC','US'),(42,'US-SD','South Dakota','South Dakota','SD','US'),(43,'US-TN','Tennessee','Tennessee','TN','US'),(44,'US-TX','Texas','Texas','TX','US'),(45,'US-UT','Utah','Utah','UT','US'),(46,'US-VT','Vermont','Vermont','VT','US'),(47,'US-VA','Virginia','Virginia','VA','US'),(48,'US-WA','Washington','Washington','WA','US'),(49,'US-WV','West Virginia','West Virginia','WV','US'),(50,'US-WI','Wisconsin','Wisconsin','WI','US'),(51,'US-WY','Wyoming','Wyoming','WY','US');
/*!40000 ALTER TABLE `State` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Unit`
--

DROP TABLE IF EXISTS `Unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UnitType_id` int(11) DEFAULT NULL,
  `Parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_7C89A36DAB2680E6` (`UnitType_id`),
  KEY `IDX_7C89A36DF08B48D3` (`Parent_id`),
  CONSTRAINT `FK_7C89A36DE20736AD` FOREIGN KEY (`UnitType_id`) REFERENCES `UnitType` (`id`),
  CONSTRAINT `FK_7C89A36DF08B48D3` FOREIGN KEY (`Parent_id`) REFERENCES `Unit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Unit`
--

LOCK TABLES `Unit` WRITE;
/*!40000 ALTER TABLE `Unit` DISABLE KEYS */;
INSERT INTO `Unit` VALUES (1,'3','SCS','Root Company',1,NULL),(2,'960','Corporate','',2,1),(3,'2','HR','',3,2),(4,'2','Quality','',3,2),(5,'2','DevTech','',3,2),(6,'1','Natural Resources','',2,1),(7,'6','501','Forestry CoC',3,6),(8,'6','502','Forestry CoC',3,6),(9,'8','FSC Chain of Custody','not sure, this may be a program within a department',4,8),(10,'8','SFI Chain of Custody','not sure, this may be a program within a department',4,8),(11,'6','NR','a division',3,6),(12,'1','ECS','a division',2,1),(13,'12','Cal Compliant','not sure, this may be a program within a department',3,12),(14,'1','Food & Ag','a division',2,1),(15,'14','Non-GMO','not sure, this may be a program within a department',3,14);
/*!40000 ALTER TABLE `Unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UnitType`
--

DROP TABLE IF EXISTS `UnitType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UnitType` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UnitType`
--

LOCK TABLES `UnitType` WRITE;
/*!40000 ALTER TABLE `UnitType` DISABLE KEYS */;
INSERT INTO `UnitType` VALUES (1,'company','company'),(2,'division','division'),(3,'department','department'),(4,'program','program');
/*!40000 ALTER TABLE `UnitType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `locked` tinyint(1) NOT NULL,
  `expired` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `credentials_expired` tinyint(1) NOT NULL,
  `credentials_expire_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2DA1797792FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_2DA17977A0D96FBF` (`email_canonical`),
  UNIQUE KEY `UNIQ_2DA17977217BBB47` (`person_id`),
  CONSTRAINT `FK_2DA17977217BBB47` FOREIGN KEY (`person_id`) REFERENCES `Person` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,1,'krichardson0','krichardson0','krichardson0@scscertified.com','krichardson0@example.com',0,'4d5f5b6c2469ec29a7c0dc3d6ee100b237019b4651af8aa6ee286b3d5d38f782','1ad672a52d68cd3be919335f1ffd346e','2013-10-07 23:01:54',0,0,'2017-10-28 16:46:11','ba886aa8785b5e85bdac905da8181364275669b5','2016-09-30 12:57:17','a:0:{}',1,'2016-01-23 19:07:20'),(2,2,'agibson1','agibson1','agibson1@scscertified.com','agibson1@sciencedaily.com',0,'24fd2bddf20781184c23d71b3f013061a83551a6878580a84ef19cb6642e8f9b','a618c42ff6144dda8aed657fbd09af2d','2014-05-31 22:07:48',1,1,'2019-04-22 20:54:20','a88519f27a03eafb6fa8629dd83ab727b0874eff','2012-04-16 05:43:10','a:0:{}',1,'2016-09-30 02:24:31'),(3,3,'wknight2','wknight2','wknight2@scscertified.com','wknight2@go.com',1,'b5384a2c10a586b75b522619cea4ceb7b3f2f9c8048126d8c3baacecf7a4f870','97fd65d5b1a934af678be47adbb117e0','2014-08-03 08:48:58',1,1,'2018-08-07 18:20:44','c767b435164e459e24fefabddfc35fc48e4a2e97','2014-08-15 15:42:25','a:0:{}',1,'2014-05-23 13:40:20'),(4,4,'jhunt3','jhunt3','jhunt3@scscertified.com','jhunt3@sfgate.com',1,'aa62cbfb91e577b84edda0cdea5d2a0a03734258fbfc35f51f9efd77fd000b61','10b1f990ec16d8e5daa6ace4673b0d45','2015-11-12 12:39:02',1,1,'2018-11-24 11:24:07','2c54ecb26fc0993214b603ff6a4cb576ac05fbed','2013-10-15 19:32:46','a:0:{}',0,'2012-03-24 09:40:39'),(5,5,'bpatterson4','bpatterson4','bpatterson4@scscertified.com','bpatterson4@flickr.com',1,'4668b1bf7d82e3a30d82b9a17bd9ad61663c1fdbf19a8b51174c42622c4f3412','bf8ab49629735dcc9634c902d56c2516','2013-05-27 06:09:16',0,1,'2016-06-13 15:41:11','f831b8b3f0fac3209913052d2a3249853a6d3c9e','2014-01-21 10:48:57','a:0:{}',1,'2012-06-28 15:54:42'),(6,6,'snguyen5','snguyen5','snguyen5@scscertified.com','snguyen5@dell.com',1,'7acbd025ef3b1e06d07d9793887104c90a7c0cadacbb80824db1621469c040e7','91b73ad6f93a7e9ee44865ecc4a6585b','2016-04-12 23:38:51',0,1,'2017-03-01 14:23:58','5e5df23d7668ed4a7a1e7cd0af3d43e0a7180b22','2015-02-09 10:17:31','a:0:{}',1,'2014-03-14 07:27:36'),(7,7,'psimpson6','psimpson6','psimpson6@scscertified.com','psimpson6@cdbaby.com',0,'e87df5beca253ed491a6a25123c717fcfc10629ac5c91cc431dc20d98ff1b828','ef26b982be8e61ddccd8a3827d63da12','2016-05-26 18:59:56',0,1,'2016-11-23 12:50:41','c35c7af5e24f05724103f4579b75ff90dedf2c51','2014-11-12 08:17:36','a:0:{}',0,'2012-06-07 10:26:08'),(8,8,'grivera7','grivera7','grivera7@scscertified.com','grivera7@statcounter.com',0,'74edaaeef08ce61f4df08f89dd1f83144e58026e66aefdae6ae9081a6e6caf76','9374a366f8111cd974bddfa6a039064c','2014-03-09 10:14:48',0,0,'2017-11-25 19:27:51','6bdb88fe72c9facd3570f2dfb4726b9e80e73053','2015-06-25 09:54:41','a:0:{}',1,'2016-06-28 22:58:37'),(9,9,'jharrison8','jharrison8','jharrison8@scscertified.com','jharrison8@java.com',0,'b0ad855b5b6a43be082ea3d48453e98b4fa1952ff2d0df1974600646197d1312','3e1da487aecb65d43ebaac3c9f798151','2013-01-19 21:53:19',0,0,'2016-02-19 16:10:53','3c931e6e981f928bcb86e30402c622f8befae9b4','2016-05-29 09:48:13','a:0:{}',0,'2013-05-01 20:03:21'),(10,10,'mrichardson9','mrichardson9','mrichardson9@scscertified.com','mrichardson9@indiegogo.com',1,'eed8891a7adfc65c00b91e4eff1c7117ef94f2cfd235c9312875eadd3fa1adc1','abd89a82006e21d85abb53a92d855f06','2014-06-21 20:01:28',0,0,'2019-04-20 05:44:55','f8f447658643253a8e619f00782d38d19bc79a39','2014-03-27 02:22:43','a:0:{}',1,'2016-03-22 10:22:23'),(11,11,'aadamsa','aadamsa','aadamsa@scscertified.com','aadamsa@cmu.edu',1,'713fb2cb071638acefd80b4c6f5a388d0f3a739917d950ce12d4d50b8024aa29','e9a6b819518ca1ab46024da489492ea9','2016-10-02 09:53:20',1,0,'2018-03-29 20:45:57','1a530d8b41d2fce24c8dd8397c0e9658bc6b74f6','2013-01-04 00:19:33','a:0:{}',1,'2015-08-03 22:32:13'),(12,NULL,'jburkeb','jburkeb','jburkeb@scscertified.com','jburkeb@163.com',0,'6d487f08eaddbd10b12200b0eea39ee4daf3411c059106b7f8886e268c9d8316','772cee0f414c47669588e4dc697d98df','2014-04-22 08:27:47',0,0,'2017-09-17 14:34:34','02b843555838c0740af6ad1a2b2359be6a2ea882','2014-05-19 11:52:46','a:0:{}',0,'2012-07-22 23:39:31'),(13,13,'baustinc','baustinc','baustinc@scscertified.com','baustinc@howstuffworks.com',0,'bcc5d07954c47be05d0d0101f51d03baf5f6462a16c38f32f49984170dc9ce97','22283ca6a6e0eddf7645d6fd8e905ca2','2016-01-15 07:39:15',1,0,'2016-03-07 07:30:29','782ad78b8fdd8fc4d2080cd19cb9e1bcce94ca90','2016-07-25 06:46:32','a:0:{}',1,'2013-01-26 18:56:25'),(14,14,'lstoned','lstoned','lstoned@scscertified.com','lstoned@google.nl',0,'224f8f7b03841fcb7a47f43b493acdf71b700a1c364216341ac9e9c2b11e1372','1a0353f54f905fa5b33aa9f6ba8cbd1c','2014-12-07 03:42:35',1,1,'2018-05-03 13:02:33','c07226de33f55e67413f3d132baac80fd5822f62','2014-10-21 22:08:02','a:0:{}',1,'2012-01-18 00:47:33'),(15,15,'dstewarte','dstewarte','dstewarte@scscertified.com','dstewarte@biglobe.ne.jp',1,'08c4b46b0e3a7d7d76810451a1e6483db307224e62d3e2aca6b9bb96ee73e1ba','ec73a41b6abc8b03a841ea0469ddf8af','2015-05-15 08:21:20',0,1,'2016-09-15 22:54:14','9656dfa5881e322aee594d3e1d0c618fb1531dc1','2013-03-31 05:21:23','a:0:{}',0,'2015-11-15 07:59:35'),(16,16,'icrawfordf','icrawfordf','icrawfordf@scscertified.com','icrawfordf@symantec.com',1,'e1cfc9790257050a21f1b4d2866e715ff51b6e4a794d3987dd13d992223acaad','2d1ba34e66bdd5962207fe8b8e6f39ba','2014-07-03 21:03:57',1,1,'2019-03-18 23:50:18','042aca2a156c89ddab2085e8c9b91872d9b52af5','2016-10-07 13:03:33','a:0:{}',1,'2012-10-17 14:18:00'),(17,17,'amurrayg','amurrayg','amurrayg@scscertified.com','amurrayg@samsung.com',0,'477f426e4075796d08e30d5725a06280bfc66b2de302a768336f8c2a234253f4','d9b164c602b9374089b49b4a87745823','2012-06-05 16:52:51',1,1,'2017-04-30 06:14:53','696f1a340e56784d953d24816275a96ad89c15e9','2013-07-08 14:08:44','a:0:{}',1,'2012-04-28 05:39:08'),(18,18,'nfranklinh','nfranklinh','nfranklinh@scscertified.com','nfranklinh@sciencedaily.com',1,'6227f577b3e84b2e34a58b8687926782c28f281f88c5bf1975b8d22265bc6153','cf0aa939a33d4da9c62c0e624f3e11e8','2016-03-20 14:47:17',0,0,'2016-04-02 09:02:52','b2a3eb49700b444b2c90e4935999f61720abeecc','2012-09-19 20:14:54','a:0:{}',1,'2016-08-04 14:14:13'),(19,19,'ahansoni','ahansoni','ahansoni@scscertified.com','ahansoni@live.com',0,'dc257dbfb8d2bbe62f82642dda9a4fd353b68466946a2d87e1378e3e76ab2398','87c3b3cc30989d0a668c098979dd0b05','2013-08-16 17:04:08',1,1,'2016-01-04 18:08:52','f0e075974435b1d4691d871df0c9620b7bdb9864','2014-05-28 16:01:15','a:0:{}',0,'2015-08-04 22:11:54'),(20,20,'dfisherj','dfisherj','dfisherj@scscertified.com','dfisherj@furl.net',1,'3c7bfd065df999d00497c891473502d1488056bcd38e5d99e0b9febff744c0f9','a63068ce3ea7ffd14510ce6af8117aaa','2012-10-28 03:43:51',0,1,'2017-01-29 13:20:32','0897f437c08361f1cb298dba1e2a6b191d34fe35','2014-03-05 08:28:54','a:0:{}',0,'2016-02-19 17:54:22'),(21,21,'shamiltonk','shamiltonk','shamiltonk@scscertified.com','shamiltonk@dell.com',0,'4f1a2216a8993861939c3597efd466ea685da90f163a49cd7e629cec51c44a61','b1dc917b96cfa4d4b508ee7a3d22bff5','2015-05-13 03:34:53',0,1,'2019-11-03 01:50:21','e479846d72ae730221020d6275792d733073565c','2016-01-12 17:52:15','a:0:{}',0,'2012-10-23 11:21:45'),(22,22,'ckennedyl','ckennedyl','ckennedyl@scscertified.com','ckennedyl@clickbank.net',0,'96a676419c77ccd51a3a06586e35b5099d978219664d4b97c804ac85e86b1a09','fd7135e5168f01c2b1c99ee7ab0caab8','2014-12-10 00:21:02',1,1,'2016-06-08 03:57:14','e0440f3c435a89b7736153d1c100a35c9d8770ca','2014-03-07 02:28:45','a:0:{}',1,'2014-01-19 20:51:56'),(23,23,'kwatkinsm','kwatkinsm','kwatkinsm@scscertified.com','kwatkinsm@bigcartel.com',1,'43ec0bb826c2336b9fc3271d4ab4b11022a3492acd29aca5aa1713e724fccc1b','ab2b1c0948613a55dbd5c8efb9b01b8b','2015-05-24 18:10:30',1,0,'2019-08-29 09:56:43','ac668a2c2ae8671a86a475188c5edd46be99c6c5','2012-05-23 14:31:17','a:0:{}',0,'2015-08-02 06:14:36'),(24,24,'rgarrettn','rgarrettn','rgarrettn@scscertified.com','rgarrettn@google.com.hk',1,'1c3eb62ee892702ef848ad83c81ed5e884bd8f2f494d04e77d3e3437d14816b2','2a194b44f4cac3086e062386187eb4dc','2013-10-19 21:44:32',0,1,'2016-07-19 20:50:05','e3f1bbd4947762e0375a67d5a659dd78f9e55f5b','2016-01-31 22:58:46','a:0:{}',1,'2016-02-29 20:43:47'),(25,25,'sgarretto','sgarretto','sgarretto@scscertified.com','sgarretto@salon.com',1,'086372d8630ef6a4b2ad73bfbec2b1c05226f8a1967ab574e700002de9b562e1','164e57d684fe4b545a73c79e7ebffb32','2014-11-27 16:35:00',0,0,'2019-03-29 14:19:42','ec0d5d03d4ea8b4d37fc32a660bea4df29f57f54','2014-11-10 00:44:14','a:0:{}',1,'2014-04-03 07:18:20'),(26,26,'vowensp','vowensp','vowensp@scscertified.com','vowensp@samsung.com',0,'f453d6ef3d92c927dc1d5470c49ecc076f5590a054b5efadce2dce478d08032d','e0209037bc60c93a8ff3db14584bdb53','2012-03-13 03:56:00',0,0,'2016-12-25 17:50:46','80e595b0bc1a0b662b5feb13b28cdb062cdf5624','2016-01-30 05:00:32','a:0:{}',0,'2014-10-11 10:10:15'),(27,27,'kellisq','kellisq','kellisq@scscertified.com','kellisq@illinois.edu',0,'04e707f32733d433e06e87cb10978eb94839ebda6610c924e48f8b1f5881c80b','91f62a4c8fa192f0d0ca6078fc26e9c6','2016-08-30 16:45:09',0,1,'2019-03-28 16:19:38','54ecf73822d3f5915d294f5f8ef81b398a8f0971','2014-02-26 05:11:50','a:0:{}',1,'2016-10-01 01:08:11'),(28,28,'pbellr','pbellr','pbellr@scscertified.com','pbellr@de.vu',1,'20c5539179529fd6040ae6d209c4b28300bfabc604c7380ed9ecd1bfebec2efb','279240cbbb48322af2cc8650ef7d210c','2013-04-29 06:57:44',0,1,'2016-11-20 13:30:20','e27b613296a3e17bd12031ca7b9a9f5897570783','2014-11-20 08:04:01','a:0:{}',1,'2015-11-28 14:14:38'),(29,29,'kjoness','kjoness','kjoness@scscertified.com','kjoness@cdbaby.com',0,'333a6f7acff8a28c4f70f1c8e426296dbf52b133f6c5aa731cd61e5f64eff0d0','068018585598d43b5098973333d56d4d','2015-09-16 20:27:29',1,0,'2018-09-12 05:05:30','7e447b3953a14ee4af582d6e53f45236f5012416','2016-03-11 15:13:39','a:0:{}',0,'2014-03-03 06:42:55'),(30,30,'tbankst','tbankst','tbankst@scscertified.com','tbankst@bing.com',0,'b71148e7f279b7644b6ab92db0e52d4a0edefd76fe34a6271229b46496d46cbe','727ba72477ac39760e1348109cc4b0d9','2013-08-23 13:37:12',0,0,'2019-09-15 08:22:34','7a468ca4d59bbe983d00812a3ab3a00636e1a684','2016-07-06 16:37:17','a:0:{}',1,'2015-09-15 07:39:15'),(31,31,'rmorenou','rmorenou','rmorenou@scscertified.com','rmorenou@usda.gov',0,'3cbc3301595bac6f4f0c14566e09a7f385bbd24c04b1915fa2d024f40a14130c','08431480701d2c836d78b1a1ec9c9563','2014-10-13 14:03:24',1,1,'2018-05-18 02:42:54','8c66ebbf12150c35c7eaab897353a0f8cf127aa3','2013-01-31 14:48:05','a:0:{}',1,'2012-06-19 11:00:00'),(32,32,'tsnyderv','tsnyderv','tsnyderv@scscertified.com','tsnyderv@dagondesign.com',1,'d24194e88b4cf9977ce85fcda4166d615ecc7cea1733294ce5c392a8ed2894e5','3a7226b89b362df61e94ad1884ad9ab0','2013-01-21 03:18:15',0,0,'2016-10-08 02:17:37','799a095db38a1df9d04f4638f1cefe6d11169027','2014-10-14 07:42:15','a:0:{}',0,'2012-06-17 06:19:32'),(33,33,'mcollinsw','mcollinsw','mcollinsw@scscertified.com','mcollinsw@usa.gov',0,'c8963cb48b70bf15424945fc570cc6166f83b0e968d1d23d48ebda0e77f226bd','c231601974089bd32bf92bd1fc5a0982','2013-06-17 10:53:31',1,1,'2018-10-06 15:47:18','26ec0f89d56655121c387ede543d257f35fcc05a','2015-12-07 06:52:46','a:0:{}',1,'2014-05-01 10:54:41'),(34,34,'grodriguezx','grodriguezx','grodriguezx@scscertified.com','grodriguezx@redcross.org',0,'38ea18711bfe7b64cbd10b2c55fe3a0aa8d5333e2f1341877b40cbc8759df935','e76f3d616290891a5e9088050d4793f5','2012-06-12 06:35:01',0,0,'2017-06-05 12:15:34','08b3812ff948c77251c75001d3cc1ebcfe36bff6','2012-05-15 08:44:05','a:0:{}',1,'2015-07-07 04:18:44'),(35,35,'delliotty','delliotty','delliotty@scscertified.com','delliotty@archive.org',0,'3d6f1a39743fc27359658492ec568bef50ebe442ca75514f79c4a4011ae81d56','3c3ca46ea6a1f0b51e674ddfcf6d7f27','2013-06-11 13:23:17',1,1,'2019-12-31 18:15:04','d8d0753358b9337ed4afdbd7c9865940f721a32c','2012-05-26 22:29:16','a:0:{}',1,'2015-08-18 12:28:33'),(36,36,'jmontgomeryz','jmontgomeryz','jmontgomeryz@scscertified.com','jmontgomeryz@loc.gov',1,'7f6ae6bb511c2c81a75a799dbb5d6b36281328c7161196cd6b2af25d09e4162f','e485cf8571965ed6f656465fbd6b3793','2016-07-23 08:08:25',1,0,'2017-06-21 19:29:02','65df2aa3cf2e1c9c4ece0587c750fc7429033bd7','2012-02-17 16:52:48','a:0:{}',0,'2016-09-13 07:32:51'),(37,37,'briley10','briley10','briley10@scscertified.com','briley10@ebay.co.uk',0,'de77b3fd47b0c9483b42102a462d75a024a4f0e49d7412d9105548f34455a5cc','0128a50c9e842518533c0ace46bf98c0','2012-09-05 15:11:03',1,1,'2019-11-10 14:43:17','4f725b73086ce8fa296bfb69350f063520a15b29','2014-10-05 11:11:20','a:0:{}',0,'2015-05-02 19:53:20'),(38,38,'cpalmer11','cpalmer11','cpalmer11@scscertified.com','cpalmer11@abc.net.au',0,'d0fa1c31fc81e9e3b83fc4015c0ea1fe1e7905cc88f71020e8a87d3b936b5e36','d5a571e128ab3e791ea1af47dc3f7e50','2016-09-11 02:29:42',0,1,'2017-06-26 01:12:37','0565c6fb27d91fd66ae5a70f97142e7b3442e3c0','2013-03-20 16:18:17','a:0:{}',0,'2013-06-17 09:35:09'),(39,39,'ewallace12','ewallace12','ewallace12@scscertified.com','ewallace12@dailymotion.com',1,'c0da6facd1ba98c2310690d26b2a100b62f94acf4800b820131845b3a6642122','41a515d38df96958d565fd07916577b3','2013-10-19 09:47:08',0,0,'2019-07-11 04:13:41','8655e6ebbd78b19d11729ab61f68c13dcb7e5877','2014-02-24 04:08:17','a:0:{}',0,'2016-07-02 13:41:54'),(40,40,'ajones13','ajones13','ajones13@scscertified.com','ajones13@mediafire.com',0,'1dccb3f28b16812925d84ae1ca67cdaec4ea07ce289af1338fb6249a3786a6e6','e887fd235aac79ceb7f8a8808c441425','2013-02-18 07:48:53',0,0,'2019-01-16 00:31:48','b4811d213e6bf5a0aa72346c6b52fd75f41e3234','2012-05-06 19:38:31','a:0:{}',1,'2016-09-05 11:06:01'),(41,41,'jbell14','jbell14','jbell14@scscertified.com','jbell14@taobao.com',1,'f44f9b816b6045cee94e54e6351a17cb60e342fa9580ca2f93868e8f4aa1daa7','8febd0d10d0b578901fa0cc70b2181a7','2012-09-27 18:36:05',1,0,'2019-11-21 04:25:48','470f9d94fb3745dfe7c7765c4f24fc60d594a393','2016-01-27 15:50:33','a:0:{}',0,'2016-01-14 04:04:31'),(42,42,'dkelley15','dkelley15','dkelley15@scscertified.com','dkelley15@technorati.com',0,'8f03dea13485a5969b255fe5070f346c40065006a5b91752e190514f8fdeb606','1fa93ce676759e57ffdca45aa78ab473','2015-01-31 14:40:16',1,1,'2018-05-16 15:24:04','9d816a06832fb8f9f89823a72a2ec7d23e63d097','2016-09-10 12:03:00','a:0:{}',1,'2012-09-04 19:37:49'),(43,43,'gramirez16','gramirez16','gramirez16@scscertified.com','gramirez16@webmd.com',0,'63b4eed81576cdb1b954d1fd55bd6e945c15ca0bc3352a8ca86cc5e604e2021e','c7343bf450c3bf0361629165bb8374d6','2013-07-20 14:25:27',1,1,'2019-03-24 09:07:50','c86ea98ab0d8bc88f20f0538237bca1c0e122484','2012-08-26 19:46:56','a:0:{}',1,'2015-05-30 12:01:35'),(44,44,'jrussell17','jrussell17','jrussell17@scscertified.com','jrussell17@yandex.ru',1,'ecfd37a9b872e0dcf5e9205191bb3e836e932e1c4f18524e32f8592bb45765da','3b2d799bd982f527debb38bc4b468542','2014-03-27 21:37:27',1,0,'2019-01-06 15:04:52','62692e53a08d9026115156ce25e1795137d804ed','2013-11-28 00:32:39','a:0:{}',1,'2015-07-13 06:23:28'),(45,45,'ptaylor18','ptaylor18','ptaylor18@scscertified.com','ptaylor18@tuttocitta.it',1,'9744908e0e5c463dfe6da26310897fb82bd13ec62dbd15b483516c27f28fac51','9bcba46f2c3a9579fbc3876f57c35d97','2013-10-06 17:36:07',0,0,'2019-01-23 06:16:38','ffec39a4851017dc4faeff1bdc6c69a318cea3e7','2015-04-11 00:48:18','a:0:{}',1,'2014-07-16 14:07:17'),(46,46,'ktucker19','ktucker19','ktucker19@scscertified.com','ktucker19@census.gov',1,'4242185b5f9c0d35bfa516066cf79c26385c566aff09fe6754d79263b597be17','7ebcae11309aecab27b471649cb6b8d5','2013-03-03 13:30:08',1,0,'2016-12-18 06:28:36','bb197281870767e28d0aa0b8f65a0bfb7ef122dd','2014-02-16 08:34:54','a:0:{}',0,'2012-01-15 20:32:26'),(47,47,'sthomas1a','sthomas1a','sthomas1a@scscertified.com','sthomas1a@elegantthemes.com',0,'2cd7f33a807fc69639914fc5bb7c5a4332c09a982b241123d344f967ee26ddd8','159c9d3ebd41b179ed24f6d36db5394d','2013-06-25 16:38:01',0,1,'2017-04-25 15:24:29','036e1d0eb940029ce1dbf6897fc09bd5b68c61c9','2014-05-09 18:05:22','a:0:{}',1,'2013-05-03 19:38:00'),(48,48,'cmorales1b','cmorales1b','cmorales1b@scscertified.com','cmorales1b@google.co.jp',1,'490e72ab65ca93e694b36588c355805ed4b30f8ad927be34c01f2c9a3152f64f','0f28e2b43971278f5566142cb7d51c6b','2014-02-05 06:33:28',0,0,'2018-11-13 16:58:49','6c015292964c157ee3560d7a3ddac8e339deff10','2015-03-15 08:32:11','a:0:{}',1,'2012-09-22 23:06:08'),(49,49,'cwelch1c','cwelch1c','cwelch1c@scscertified.com','cwelch1c@mediafire.com',1,'1b75d26d00a3a8cbb7f1c32941e4187b4327e042a4222069bff86b0d6bf52a5d','7159efe76afa95f26d1c577e0a5e6e86','2013-03-25 15:52:55',0,0,'2018-03-12 08:03:07','47a07e92782557f59ed4cfdad793f55beed7b5bd','2012-12-07 17:54:30','a:0:{}',1,'2016-07-17 13:24:27'),(50,50,'lford1d','lford1d','lford1d@scscertified.com','lford1d@engadget.com',1,'74dd068c65c7e9c558f2ecf3f22b05972fe84bd3499e52eb4434c1c3a7221700','c83ef67b1b22e52bd776704de38d97ef','2013-01-15 09:46:55',0,1,'2018-05-19 11:44:34','221bf2d47ac75316227cb90262dfdefbf111504d','2015-04-18 19:10:52','a:0:{}',1,'2013-04-30 04:35:53'),(51,12,'apiuser','apiuser','apiuser@scsglobalservices.com','apiuser@scsglobalservices.com',1,'dak9qz125a80k408k88880480wc8w84','$2y$13$dak9qz125a80k408k8888uHHFAjNyjyPY7GDGYOrxDk9Pswe5mfnO','2016-10-26 15:05:21',0,0,NULL,NULL,NULL,'a:0:{}',0,NULL);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'IT','Morbi ut odio. Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim.'),(2,'Web','Ut at dolor quis odio consequat varius. Integer ac leo. Pellentesque ultrices mattis odio.'),(3,'ECS','Etiam vel augue.'),(4,'Executive','Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum. Curabitur in libero ut massa volutpat convallis.'),(5,'HR','Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.'),(6,'Marketing','Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.'),(7,'Natural Resources','Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien'),(8,'Agriculture','Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem. Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum'),(9,'Quality Assurance','In eleifend quam a odio. In hac habitasse platea dictumst.'),(10,'IT','In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus. Suspendisse potenti. In eleifend quam a odio. '),(11,'Web','In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem. Duis aliquam convallis nunc.'),(12,'ECS','Suspendisse potenti. Cras in purus eu magna vulputate luctus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus'),(13,'Executive','Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis. '),(14,'HR','Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui. Maecenas tristique, est et tempus semper, est quam pharetra '),(15,'Marketing','Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus. Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer '),(16,'Natural Resources','Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum'),(17,'Agriculture','Etiam justo. Etiam pretium iaculis justo. In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus. Nulla ut erat id '),(18,'Quality Assurance','Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam vel augue. Vestibulum rutrum rutrum'),(19,'IT','Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus. Suspendisse potenti. In eleifend quam a odio. In hac'),(20,'Web','Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus '),(21,'ECS','Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius. Integer ac leo.'),(22,'Executive','Proin risus. Praesent lectus. Vestibulum quam sapien, varius ut, blandit non, interdum in, ante.'),(23,'HR','Maecenas tincidunt lacus at velit.'),(24,'Marketing','Nulla facilisi. Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque. Quisque porta volutpat erat.'),(25,'Natural Resources','Nunc purus.'),(26,'Agriculture','Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam vel augue. Vestibulum rutrum rutrum neque. '),(27,'Quality Assurance','Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.'),(28,'IT','Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.'),(29,'Web','Nulla ut erat id mauris vulputate elementum. Nullam varius.'),(30,'ECS','Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. '),(31,'Executive','Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros. Vestibulum ac est lacinia nisi venenatis tristique.'),(32,'HR','Aliquam non mauris. Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet.'),(33,'Marketing','Duis mattis egestas metus. Aenean fermentum.'),(34,'Natural Resources','Aenean auctor gravida sem.'),(35,'Agriculture','In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus. Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.'),(36,'Quality Assurance','Mauris lacinia sapien quis libero. Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh. In quis justo. '),(37,'IT','Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti. '),(38,'Web','Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.'),(39,'ECS','Mauris ullamcorper purus sit amet nulla. Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam. Nam tristique tortor eu pede.'),(40,'Executive','Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis. Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.'),(41,'HR','Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam vel augue. '),(42,'Marketing','Nullam molestie nibh in lectus. Pellentesque at nulla. Suspendisse potenti.'),(43,'Natural Resources','Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.'),(44,'Agriculture','Vestibulum sed magna at nunc commodo placerat. Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede'),(45,'Quality Assurance','Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc.'),(46,'IT','Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede. Morbi porttitor lorem id ligula.'),(47,'Web','Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet. Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Tus et ultrices '),(48,'ECS','Etiam justo. Etiam pretium iaculis justo. In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus. Nulla ut erat id mauris vulputate '),(49,'Executive','Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem. Duis aliquam convallis '),(50,'HR','Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere ');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration_versions` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_versions`
--

LOCK TABLES `migration_versions` WRITE;
/*!40000 ALTER TABLE `migration_versions` DISABLE KEYS */;
INSERT INTO `migration_versions` VALUES (''),('1'),('2'),('3');
/*!40000 ALTER TABLE `migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `org_orgtype`
--

DROP TABLE IF EXISTS `org_orgtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `org_orgtype` (
  `org_id` int(11) NOT NULL,
  `orgtype_id` int(11) NOT NULL,
  PRIMARY KEY (`org_id`,`orgtype_id`),
  KEY `IDX_538F381EF4837C1B` (`org_id`),
  KEY `IDX_538F381E9F3D2697` (`orgtype_id`),
  CONSTRAINT `FK_538F381E9F3D2697` FOREIGN KEY (`orgtype_id`) REFERENCES `OrgType` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_538F381EF4837C1B` FOREIGN KEY (`org_id`) REFERENCES `Org` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `org_orgtype`
--

LOCK TABLES `org_orgtype` WRITE;
/*!40000 ALTER TABLE `org_orgtype` DISABLE KEYS */;
INSERT INTO `org_orgtype` VALUES (1,1),(2,2),(3,3),(4,4);
/*!40000 ALTER TABLE `org_orgtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_tokens`
--

DROP TABLE IF EXISTS `refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refresh_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refresh_token` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `valid` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_9BACE7E1C74F2195` (`refresh_token`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_tokens`
--

LOCK TABLES `refresh_tokens` WRITE;
/*!40000 ALTER TABLE `refresh_tokens` DISABLE KEYS */;
INSERT INTO `refresh_tokens` VALUES (1,'2f1af2a478c8b0574457f1ed758ce634f2613c7818fc9b5b822183f4296572c7f659ff46a92a8ed82d2625c6cdefd867436d61322a32308860e19452f60b4b95','apiuser','2016-11-16 16:38:27'),(2,'9b6b840dcda5e1518df85edc8d2dd056d5427aa8095bc4afca6d7be31145b8e5ee63d18f0178e4093baf1d0e367d3be02a2d7436323d64e7368e2caedce83130','apiuser','2016-11-16 16:39:45'),(3,'af99ce55cf1aa10088f7b3dbe1bd11c56eb0998cbb945b33fc29259f2b2a958b3b4bf7ffe95efe70aacdc64bce6496c513a916455845785cd0bd4d6f7edac514','apiuser','2016-10-19 17:49:19'),(4,'c2690557680928c36034bee249734eaf166f702347c224eb54b3d689b1561065723b0f6f6fa6ea2c419d5432b0bee243333ae15cbef4291e4c245eec64f80986','apiuser','2016-10-19 17:59:14'),(5,'82cffb1853d94925a64b95ff0a66899c019ccb3a0703b7713f7510b5f5dcc91396541997995c93dde25b3388d529b32d85c77cad0186bcfb5f1d6f0d3b65ffd2','apiuser','2016-10-19 18:02:40'),(6,'d65ad67d5632a420458dfd762c2974740524a42e36701847bf286ffb325414a4dbc3d48edce45a3d5da92cb5c47acf1b7cef93c25095996365fafef5839e4b45','apiuser','2016-10-19 18:07:11'),(7,'04eb35150589533361bc7fcc6365b31e10c70015fb8e7f403808abfe57f6e26b38676f3e0a7b5cf915f05a93b61842c518f1047247301e688bb4fd493da4d910','apiuser','2016-10-19 18:08:09'),(8,'bb410d5bc9f1eca9a6eb7c40a7395ca057b3367e06079a1a19b31c12b6ef1237aff44e1101549b66457c1087a3510b1e779b538e1544176bc99d0250c23c794a','apiuser','2016-10-19 18:09:36'),(9,'6ea966fde4451d08f7d0ee40d0d28abc3814a4f04d57becef37c9fa6a01cfc63a6331e0c2c65cd61b80efc29214e46dd6f48be09449af41723a4194eeb434251','apiuser','2016-10-19 18:09:41'),(10,'857ae6fedb1a9fa65655c599081ec20a810834b8f1c2b3f4bf96c53332eebeb39dd5d9df81fed5106cf2c9dce03dd7e3da51e44ae3ac69e7db5352b7a7d76c25','apiuser','2016-10-19 18:16:19'),(11,'557123b150dba588f9bf27825f757ddeb9f121f0e858b6f68675f0763b5cd0bfb1f5948510587e1a6cda16629a9390846b775a599cd8bd1aef1458d50b3be79d','apiuser','2016-10-19 18:18:53'),(12,'bfdf0fae982a25a5f5c3eb8e7093c5072eac4c50f51dd40ba9b3bc6597a12e063d0b133804de07775f18f73d3659e327bd3271e90cc2481955ee265c6aee9cf6','apiuser','2016-10-19 18:20:03'),(13,'7f3a6bd61e011f3b40fb9d52ab2b30e6de80b1905f96432461d47bc5a1ea2ddb5f932104c1393d1d11c9923dbb77d3577406ca18e86d7429484ddf892d43459e','apiuser','2016-10-19 18:23:23'),(14,'23aa33a8da2721b943f1f6b699ab7bbd194982e60b30e03a11a7b1403878f6daf9d5e37838a6f6bda26e317ba7309f54d78ede9713bc0e6143ba6300f181d483','apiuser','2016-10-20 10:15:09'),(15,'40c934111ecb41f076842df1718a1d6a9fb01f2133bc21eca4efb78731c60768d79cd3d15856029a031defc0d7379978b9c66002eafd7d9239ab23e91619a260','apiuser','2016-10-20 10:15:32'),(16,'b793c86f21d5129af0a51d99d4cd2c3c67727edc1373f902213fc40edc584b1760562cca8279dc39714c0e1a23b6880193937f201b5fc3c36fd2d45f438f581b','apiuser','2016-10-20 10:20:26'),(17,'536568f396e2a5d1fead689892adb465d4fc49c9b6a0628206a9e6fa8f2c5aef57943aa9d62fd0e4186fb5ee43b4d840938b17e4f58a93a0bdc5c98d52c4c5db','apiuser','2016-10-20 10:22:28'),(18,'8a058dc54dae7f80a842d9a30372790534e1db36ef498a90e310a53fde47c8b64b4958190de801dc13d5d9ad226a9ee0cfa8ccdef14862030854e8b17261aa10','apiuser','2016-10-20 10:28:25'),(19,'713d1bf8d005254cc5fb79306f6d4df87def6c7b8308d684261e5e4fe836bafe9ce1c18e24dac8638c6c63c7e3f8bb472baa4e37dc5032f161287803dddca38e','apiuser','2016-10-20 10:37:58'),(20,'0dae091d85e1eec187834a4d0004553e2aa65fe1104995d1b36c9f956884d9732a109b4e45b61e7245bcdc1404c7eeb891f52327f25e7124c928758d0afb1b95','apiuser','2016-10-20 10:39:14'),(21,'d98eae45565a8bf5439fc50f8f920972cccb866672f73a5d48936dd22f79363b47d3aff3cb084bd203e0184384632776c3c4cec4d1a272b73a247989e4366543','apiuser','2016-10-20 10:39:40'),(22,'73b98d1284d417a421d446b8f5f70022001d205f57aef10a82fad149b852d62d8348bcebceae7164432c170b74232ae174fb3249d4739abeec936fda638d846c','apiuser','2016-10-20 10:41:19'),(23,'6edd332d2aca8c4a9aaeab1f9ff764b8b88cdd7d67c98e095d446223ad8eb25b9cecffab23760c74080bbda3e89fdfa65dc057fff7ac1b94ede5c541f6dccadd','apiuser','2016-10-20 10:41:20'),(24,'6224df8ec20382819610d6e2683f4e2392ce3cfaa072ae76ef6d263db73988c128d9ba9d787e841ebe9e4b76a4acea071c7ca26f88c5c453b9e9af9fa8713685','apiuser','2016-10-20 10:42:40'),(25,'4f5c9cc08c4b882a17c42ebdfc704f3b209adf38626947e844fdb39de0ce0251e08fe560ab843336293143741a09da9fdc98a0392f07275403b21175c3c5e33b','apiuser','2016-10-20 11:30:39'),(26,'d1825becbf5e667081275d337cf9ca5135c20abe5e0677ba4cc087ac64b40e4f95f5946ec0fa0fb8bc149f2fc962c12f44913a7f9bd6c88a5d6b5e140484d8b9','apiuser','2016-10-20 11:33:20'),(27,'bbee5dce108a01dcfe539b6f639eb788ab46c83d1e5df481321c090fd19f225b366e2e398070a8e41930dbd651cb5a10ae50dbb1973cfe4c66db8d92a7cc5290','apiuser','2016-10-20 11:33:28'),(28,'54a11d2201826f4fafa1c47cfdb29eae94bcbdc363d5c110f6ffd5fd8ae0e99470e928567003461addaa1f9698e2089d6a649ac95ecbb1d2a90847518eeada88','apiuser','2016-10-20 11:34:10'),(29,'895f7ace85b7b27073101fc9a84c79ed8cb8e730cf1937631720f6c3670956130ed581b3efa7c37a731ad4ff5e9cb85f76c1a7d19382e61f6d2f53f58a691b66','apiuser','2016-10-20 11:36:29'),(30,'6c2644ea205744b0368a25150fd964d789949d654406416ea2bc4496ea19dbbefa71e06c517bcc3b65c5315c8f2825f24ff400e81c4191aa0e08ee00a08661e6','apiuser','2016-10-20 11:38:13'),(31,'0acc91114ad97be5b94fe8f775a6cec2c40225cc84e7f46fc0d2116df927f71e91f0ce979c5c7f67627276a580cc94a8a9f3ca88cad584b5d549f2e51bf58436','apiuser','2016-10-20 11:39:07'),(32,'780d9ae1fb578be92b270b5fe38d0e6fc31dbc1bc40016a9d8a1e83f0ef47ab4e4297887405299a914643228ba5524fc4959d4826c71198c2f52e360e86bf66d','apiuser','2016-10-20 11:39:20'),(33,'aff57f5e29587a1968e446da5a9738a14765dcb76ae583a9647194c057db510e007d27ec57243cb9a3b9ee3ee508c001fe1f7cbb05f05565e745521a66aff531','apiuser','2016-10-20 11:42:23'),(34,'17ba9647c13bbd93a2ca903f99e90e5c4cd31bd7f6401553bb87d32e8f56baecd5667a6cd648821b758965ff21383cdb4b3c20801e9c7cab4830b4d490ed02f1','apiuser','2016-10-20 11:51:39'),(35,'ea956a91d86453c81c1c12461597641c8bc5335b5adb154db4917979e446aa9b5ba4382874efc90572a3e63bb98a77128ebbcaba99be3a6f577ee0d4370f3f7b','apiuser','2016-10-20 11:54:04'),(36,'703a5975fbe5705ead241b04b5737de5c2de0c15c099c93e04faa93f843ca066207c8a161887b807e35387b7ea3464d093222e01da70c7787e3c857db468f021','apiuser','2016-10-20 11:59:30'),(37,'88284bd3c67a55d3c030bddf3627c4d4a0433dcaf6ef7ef37707855da442169b5a9b847852570dbda69903539baa42e15b366ebe0c10b82222ffc29865e0eba3','apiuser','2016-10-20 13:26:57'),(38,'fc2120b7c487d7eea05859a9edbdca6a91850f4743ca3b089c8c07af871012efe1d4d7abf47935aa76b7bdaaa658fff06ff0ec3503c32ac406dcba4aaf3e47e8','apiuser','2016-10-20 13:35:18'),(39,'874fdd2a92f952b6abfee7971d5725a720ebbbb0b76ac25a616846ddcf760aa1a0e82f72d9249ef91cccfc2875092702064b19868cea519f7584fc23c4bc433b','apiuser','2016-10-20 13:47:09'),(40,'9f4954e795d3cda75395d25da75fb0c0eb0662d88f90e517f84a4fd3129fa771fa5754a5765a65dc1160dc2af117711f5aa9e10e3ba8d33870ca251bce051169','apiuser','2016-10-20 13:48:05'),(41,'2989a5143fa75b120188c1767cb62a65da30de7531f9ba39eabd3385b2c44aebf163cdc0e58183a798c1c6097a2972186d058daccb54352d232ec7495a0e4782','apiuser','2016-10-20 13:48:09'),(42,'7ba4a88104c658d0f934c0a8a5d3960978dbed3cb1a4c633ba73a1c0b358948fb3fd0bc26058c7d230cc3a6fc8f889e6ce41d26faeb1e75a332953986ab2d73f','apiuser','2016-10-20 13:49:43'),(43,'8443ad42adbbb0d053740fb8231103fce3f9ba6cad472267d4e0f1d8d2a050209b0ba6f47091ebe55aa7d5d5eba53db7c33800e91b58dfa8a8f32809b61cb470','apiuser','2016-10-20 13:50:46'),(44,'d8bf881634b1e4fab4793924a8647dc5c38691d2059d6d8654dc0897192d5a6c3847ff4a588a4837f6f54d5eaf79d2c13b24f167d8f4d70f47c5f6eacfdd38f2','apiuser','2016-10-20 13:59:44'),(45,'289d901bf5b990f2de5529994988f769327139b7c967dfc8ab0c160d8233d53c63950dabd16604e48173b1d76e5154f555073e5f3ae0970c32a742083659da37','apiuser','2016-10-20 14:13:04'),(46,'3e8922e557f87f966346a046df41f6cd143dc8bb54a37f689da44a594e1c75a755d6636bcdfe87f4c95937a66d76847b90acecb5c99736b5d5b8122d9058533a','apiuser','2016-10-20 14:15:41'),(47,'20027f37ee63cd7d466e8285f25a00744546c20450a4f0a58d87258172339e3a0b1369abe5af3f93c12ab9f5ef447be14e9a3f2214d662fc7e92e618a5610512','apiuser','2016-10-20 14:33:58'),(48,'474ee211e997544359af0902a981bb42d947a9bf957fdbd0f2f8243129c9cd31ee39b90ff155e323f73f771845184c0ee54b33ccefde45df77f209f892dd1c75','apiuser','2016-10-20 14:42:11'),(49,'920bf371f2b43517a6f739c31688771bbe0091ea9e88c029aece126fc528f573bd587987dd8de692ead1e2ecb8e8410db40bd462875e83c3a4b78e7689a49c00','apiuser','2016-10-20 15:13:51'),(50,'40b075dacde044e6123d747c84709d8a327074975f29f855ec0222102d8dc17e4816e82ddaeb49bf9b2968cc356528944b6f47923f615ff4d9f0500adbd15b86','apiuser','2016-10-20 15:45:24'),(51,'d726ea73a713f2992ec38f734ea21a7bf29ec9ef7eb1e3c2c210403f5e284c37d91efba376e5e0591f2ee63876c40fbc55c5bd84ed55fe0186a46218004c401b','apiuser','2016-10-20 15:49:16'),(52,'57182fd9940a0c2d553c6e5cde2aaac618a4d94f4753d75ab54e9ca79a09e2150d5f2c39a8a59f9a43a567c0fed71e4c0cd87c2b1d15db48fbffe32d5fdfbac2','apiuser','2016-10-20 15:49:39'),(53,'a462fe0272c098e664abdfe7421f963959cd4b4ed518ddacf39dedb30b301dcd9a1eb3ce0347d75100c6b3eae978dfb91e8b684ddb4e352879faffa2d7c8a2ed','apiuser','2016-10-20 16:01:39'),(54,'abcb2ad13cb7d511f158536401dfdaf2e47b0ffc5cf17250b46bc3e9f2c9e41367558bf62c2c070202d76f3e970f19ac94aefa217fe17e8dcdb6ecce709b0610','apiuser','2016-10-20 16:02:32'),(55,'c914d335aa5ca4f61594a516b46a5f07ef9dae2d02fe7637091e4e510b15f1497c1acf6745b82457ed9e9d8f857bf4f8af89235e592012adc35eb91ac0f6676d','apiuser','2016-10-20 16:03:40'),(56,'bbd11d8aa113181aa045c84e6e462aa4e03966728dc2f84e8918639dddd3d2c5c27e5363dc809fda5dd85b47c2e9d0fb36b2dccef7b6891af15d406747339f53','apiuser','2016-10-20 16:12:01'),(57,'a6a309e75ead97ba74149d3f685bc6e4c7c041a45a27c1732de4840bd540a5d8d20af20a9070a6857ef1981659f0e26b3e42129e0578fbd2f788c7ad1b6d09d4','apiuser','2016-10-20 16:26:38'),(58,'3a87bf69e208b1c9fade8498f64d7859e6d13c84a361430e2e32e978eb8323911bcfcbb7c20ccd13a2f0e1d555b8983f9f21981d6ec0b4bbab1632b0c084a7b5','apiuser','2016-10-22 17:22:10'),(59,'24aacc7b5d49e7755cbecb7521d95b075dfa765773aa054868c88835389201effcb1d2d1f625de927ef609ebae925b5a7261e5b387ec17692cbe602d4d8989a9','apiuser','2016-10-22 17:37:02'),(60,'65c1ebf5fd4b4be7a1081580aaa7a76f527b65068cb8a0d6c1534c71a1a4569ef7cd2ae6808856433dbcdc787a778256b63adcdeb247b56c652df61359f97e97','apiuser','2016-10-22 17:52:18'),(61,'17e3be8fc9f982cc55359bbf95fabca1efa7c179889d5753f1037a444ea1c0cb231df24f14a74ab9a0cd6a95e127e6a9fbffb03ad901e8dcf3d8101005b41d0d','apiuser','2016-10-22 18:15:35'),(62,'70fc2b88d145b4347499bddcfe3751ba36f1ec827aa2313cba88a3beba8effade95529f5af4a1a47013c2bdb7cf66b12d5a45f1d98434e677e23012eab157a87','apiuser','2016-10-22 18:30:06'),(63,'80b1096dbe59960513ee904137d02409ae191a9acdcf5cdc6fc21b5c04cf1338c10267f4228869e9ca34c68c2ac00bb7de338ae9ba0c077f91117b02a6010d22','apiuser','2016-10-22 19:13:34'),(64,'4fe580398641627ff1a336ce8be0b109fdf1cd125405f878040bd2f6a4d702d6584a08bdc850845ca14fc2d23f22f45d3b5b410bdfdee3ada9b742ab7b63e260','apiuser','2016-10-23 01:39:14'),(65,'d24118ad3378aefb66ea2deae1f254406fbf47b1299c64c0745b49b9fa33743aacd5f92c47298f65d948187d4699806e544654fab579824496024c8fe81d0e6e','apiuser','2016-10-23 01:41:20'),(66,'dcbfca1e17a1a511a4bd9dce44dc8d6076e67ee28e5b46f1dc630a362c0fa577b338d5cca821fd73bde36df8bff4b64d5a40e9717f100bf2eb0926fec0e98bc9','apiuser','2016-10-23 01:42:17'),(67,'aef60a2d222be938aa547f21e8982f2577abc16bd30135c7f6379268fcd7c3ff4d291e76852effb583b6ee76c87df5de8f9f62847370c21f1eb103ae402daa68','apiuser','2016-10-23 02:08:16'),(68,'051e4252954edb1e742ab8f5506ca6497dbfdfcfbbfcdf7ff14d2175ebf878274be642bdd9d1f6573964f0f8b3563fa5ae74469da2e8cf948c9335a6f9d4eb4d','apiuser','2016-10-24 16:14:12'),(69,'417c4ad88aa1ed1a68bb581227b4ebc4db4acb06a1b6a269fdccbd6c3d99a14c3411d825d7d3bed76fe45260cfd88f4f3874570cd875eaf919d2dfceb45901c4','apiuser','2016-10-24 16:39:51'),(70,'6d70c257bd86ee5ee74ac0a0317c781c0e50fd6544d0298d0d2201c0b4fe65c6845584376608e5dd477f6acadaab5ed19914306cb884b9893eb1f1107d5768fa','apiuser','2016-10-24 19:02:15'),(71,'1e42cd07196b5dd6c6e3b6338a2eb649590cc65833de07d386ec9f58b759b780cc0453b681733d20086a997cd14450c65cd38f23540eb5dd11e34126b6b403fb','apiuser','2016-10-25 13:10:48'),(72,'7581a05087ea7e493539f3c811c33d3466d9c7b815137f33f9b1379c71ecaad1841a9c7bf5aff9390ae081d86e08d4a6dffff9cf1ac88fde6047cf146402dfd8','apiuser','2016-10-25 13:11:19'),(73,'0e8aa8ad60f7102d974c080906dda1b96e210a885271f632bc354012a745e13aad487dc1a55c134e2ab4cbca295f8ff81da3caf7d49e13c8812e4d8c536cc9b0','apiuser','2016-10-25 13:13:38'),(74,'942d42b0df75a16b7d5705ce5ff32872ed99bdd51b55197072ab73d5782609fa83e1d06201c0af6b7830d57ffba7e70b5548bc09fa65ef01498b2a6019668c93','apiuser','2016-10-25 19:01:01'),(75,'ab05be5c42c145b3e8e8abab1f5ecd1a863799409e5206ac0e7f928ffe3b20c144c1ab6c70aa3533a1a4c6a601d1165160e3119e6d8de1b43ed2e9b21a4293c8','apiuser','2016-10-25 19:24:17'),(76,'8adcb10badd9aafc4a98dad633824b7f0b74ed0d310ce5fa066d8830ef4bf61e3302b43ba3f40c70f4edc73c44d1597944d02632981dbdcf8c0539f1aede24d9','apiuser','2016-10-25 19:40:38'),(77,'c6a7bbd1c7ccf505d8dded674b2318589927322b33378a5b3a0880bb3db565a40e26eb0caf786e80eb6c853f67e99dde2e88b3b3d92fe61a2521326fc09be9a9','apiuser','2016-10-25 23:14:35'),(78,'9fcc5c14f2dcc1c03e596ac3318c8928e0c7412ee597c2df8da2d17cadec9603ba08855b906a76b99f2da1a9662c4c490a5b11b6e8bf501bd259bfe65ee6c2f5','apiuser','2016-10-26 00:19:27'),(79,'d84b7bcfa637c62347ee32e408c0f6a851f76e8b2d282599066df802cd18fbda5230b3bc9c17c861aa70b169b1cecafce9931f43c6f7129039139f760ef7ffea','apiuser','2016-10-26 17:35:28'),(80,'8f9f35e1ef509e1fff8e224c00c1e935974d5264061e8b9b3a4b6be1e07beb916e34d762f6ee6b7e0c1e17f870ee3d717cdc2c952d65904dcb6d549c97438ce4','apiuser','2016-10-26 19:06:44'),(81,'10806ea15facc521a1b063d1d0d260ef689b2d104c7a0ab5e33fb42188df5ff7866a442a54dd236c2b67b81175d5d757d174d7445e734c527c9d36ffb541ec8a','apiuser','2016-10-26 19:54:13'),(82,'38c3df0390b3b481c3e9eb85643db2ca84ca03dc0cd37ec7324db16c6701c54e4214d0265063f9c2783db33ec58b67dc6e5e93648c8b58704c79565f909bf9fd','apiuser','2016-10-27 10:45:57'),(83,'3706ab0b9c470a55a7c705ab40dd13c92350ec86be27405c35cec89685db78a3c252329177d2933ffe1185aa7c958351fa099c8e20342f732ed3917415fa1f48','apiuser','2016-10-27 10:47:01'),(84,'1d88795b6cac809bc44a4cda133a23665ae958aaedd958c0b7fb213965f036bbf33c901ae781380cb38531e655a726ab0e924fe71985739209857835ab2a52d8','apiuser','2016-10-27 10:48:23'),(85,'e5c36c2e62974c174fce7688aca58367f9deec1e40f8fb0a976ae5f6f04aa98a474415c53119aa8f2c59a86d7ba817f554d4ae00c7ff91a3264bb52fcf0278ff','apiuser','2016-10-27 10:50:32'),(86,'a94b3ae69d1704f5b0babfe8913b6993561b92b3879ef2e9332ac12e3f83c2404352648e8eba1e163c924004e15de13246a4205b6e61a564b4155c150ac2defa','apiuser','2016-10-27 10:50:41'),(87,'a6b93a97cb91302f1fbc628af6d24fe8fc83b17a5f597ef425cfc10c32ac1baa6fb003bd44c023873cf14ca70bea822981fa2ced51af6ea9b94a9936e3e6c356','apiuser','2016-10-27 10:50:46'),(88,'c25cd63273a7f4f2f9b3874f63f512e7410e2c90844b2df83b8f50c5282a85428a042242fc58604fd59342941718b4e6625e739892de86965b555705d40659c2','apiuser','2016-10-27 10:53:09'),(89,'acc1a4fa2573e4c2234f7aff731224c87fee57c8af9476dd995aab6e397b2400fe2551edbe99df12dd6ec8583204a67a41fc3e9ed77b0c625dd3351fe5bbc020','apiuser','2016-10-27 10:57:35'),(90,'7737ad44902c893b958faa774a19e30773eab776f80291ede549f77b64813f020dd6a853654dfeeef306f19368bfbe1e017237eee14b67da94cf5b3a87cba51e','apiuser','2016-10-27 10:58:09'),(91,'bbfb5c7a1cd419b85614c81ebd481d1b2b01673716e7f903dbc5872c0cd17594cb3a055359ded009588b9066778cdfe90794984c1fe7f4f53db94e4817bfd28e','apiuser','2016-10-27 10:58:57'),(92,'1fb9a9a92a4d51996ecb361f7faca2e37b9b97bfa9297b0188b540440079ff9f7b5877d389948d26a4093cf13c48df710bf071e31397ffa91443259b61774ee8','apiuser','2016-10-27 11:27:15'),(93,'90cfa82944ff8f6433f75f5c63913fe0aaece97c4e1de9bd006b3653b4b4687d86445573ff43c7ebe3efef1d88c4d17482b6446f60ee6f654d1dd7d9e432206d','apiuser','2016-10-27 11:29:12'),(94,'80412129aaf836db0483161bc1a13f232c97c133bb82321d227be56cb95118db69639513f649c3d615508e21a55c5593486389cf8a4fc83212ac28434c617888','apiuser','2016-10-27 11:29:53'),(95,'badf5c0d66563c017443c47acea5641b3f903e73479d5607c8a0a3fd5cdfc82a28837cd125a3112739579682298d5a44861c8af27a62203e17d98b3bbec73a20','apiuser','2016-10-27 11:31:21'),(96,'22d5e23e49438f215e11e8f57940053e794ad266e09a604773be0ca2f40c54e5a9cd88a83bd0adaca48f6611a76e33df9855fca79ecbed09b788a9504ccbf346','apiuser','2016-10-27 11:32:37'),(97,'11451b91927c6b1aa3a32265e0bf36d53704d1181cbbd5663dac29e051696f5624fa53f04148510d1f2081ecb7041843b576bc3c673223d9fda264dce57704b4','apiuser','2016-10-27 11:33:39'),(98,'c508a1800b444c62b0e84bebb3e63c2c345e86c709a4ab9bc0a659babc9c4820f6847255b13e24d64325175f132514aad265319dec3276c590dc2c2b5fab1858','apiuser','2016-10-27 11:34:51'),(99,'49bd48692b8a867d3f7bfc12d5b8dc94dff8562c54abc54d2e69475bfb100ee7bf679a63de935e35640a21413d7b7df303d347352629c99934404d3ed2c44eca','apiuser','2016-10-27 11:35:30'),(100,'47dec15bfaa68983d9d2024201abd1f7888af6a2f6a16488760c524e760db3cfe1f74e00271b20d845df91160b7705a80bb7e37905cfd1d9862774544cce6157','apiuser','2016-10-27 11:35:58'),(101,'122f6d1969ac93f469e1c0ea8f854840d83f6df19c4715284fb33682fd4c0ac88465a86c5e1e5f7a4e747808d91f948d5b70e1701cb5c15598af0d4d97b25d00','apiuser','2016-10-27 11:48:31'),(102,'020d93c57208bee21e4d5b54a9fe8b5fbf662c985244eaf2c99c8187dcd2b53cc04fc65c7bd567761fcbcb476e8f0189f797ff2ad549849b67a7248647e0088f','apiuser','2016-10-27 11:51:10'),(103,'2a7b778ede955719525ed27556b0f30e64e63e98b9f474a44f2e20ceb3f9890c5fff881876187a87a5ef8ae4fd3cf662c369a817d9be241c3c11476695511c2f','apiuser','2016-10-27 11:52:33'),(104,'11fc132bb0f400ff3a4f8f84c64398491cd7467aa01063b7ea7efad722c6050e11a0b585a33bc924ecf662b630654109a4a09ab92544809de31f4dcd8eb07bb8','apiuser','2016-10-27 12:45:20'),(105,'4fb815c225b7667a27ac92ec6344a63c257ed0ab8a14e9dcf8835fa6179fd142fee1358fd02d9747e138906980daed2f8d32af67578db5a8d2899eb44058b154','apiuser','2016-10-27 12:47:21'),(106,'8b334fd6e8fc9c10da6ae5206b9e881e1937e4ed65e62a735da40bf8c524132ef56091f898dd63730626d0b709757181a48247334b9dd478dbd0789a1804f56e','apiuser','2016-10-27 12:47:33'),(107,'081e9a44faf8e66b4c18694e3a3728c50e9865cb6c04e8d06be8b8de727ddf3d9cf0a7808f72de34bb8bfe127a12eaa127bf204163cbcb8da10ab1a83619a00d','apiuser','2016-10-27 12:47:49'),(108,'9406367d0a51516fb1960bbe962b51b366819358db3ebcf65a9b2fc377b6abb614e79802a128afd8368e9f13859cc94833b959d7e36cc4298b4b615859fa2f75','apiuser','2016-10-27 12:48:35'),(109,'5ae2a01d5aa7da28f3fc2cd706a0e9c514f1e82e03b55c2210d11a7fe68b9e56f06137d3f102ba6c59b540b95fa34cbce089b3284e502b0fb22223b1057f6041','apiuser','2016-10-27 12:49:09'),(110,'9045db56f12ff7adf8c08a7c26803d8aa6bcd32a37fee08c9b8355d176a1a7474fa63bb5b98811cb81718251ccd3810c696c331971ad2f4a6cb57a71431bf237','apiuser','2016-10-27 12:50:11'),(111,'e849ab738609cf707435099e724f50da61c1044d7b68c3fa429d632de47aaed3d0b162d01b2f4f2c1d65b0d9184b9b7392d215c53d4679cc652b662751962ba6','apiuser','2016-10-27 12:52:32'),(112,'0ab62e11154f05c782c6622a3844783e65070533bf3ec2872592afe5d83830835cb89dc296ceb7c482dc3b96f1adf0f9fea2405890bd935c5fe886b7f2a34032','apiuser','2016-10-27 12:53:09'),(113,'63de962f00d4c452bb561446f286783b13079faaf33a8db742ef40ce4572b5ea62143bdfa2a8576f0203e0d5ca24cddbcbbb85ec572c78b58daf4a83b2e4ef6b','apiuser','2016-10-27 12:55:06'),(114,'aecdd44fe1583ae8a02061d6259c932c84361d39c83cf08958c7f04e406a8c89da0331548c0cca35d1615f0b31cca0dd8c200e01543896caeb7bede526a876db','apiuser','2016-10-27 13:53:51'),(115,'1eb8a000ac0cef36655a653d55d2a9f41887812ed9d3267f16d0d3eed63da8077290aeace45d242adc2dedca32849efb036372d23349b7faa8d3b15553fc9e77','apiuser','2016-10-27 14:05:20'),(116,'052d4c848175f4b17c6d2de925df3967aa0b39718a24984fe46a5b4a576682e379a01ad8434df636af0b619f4d31c833d2e946c75fe958e1a4f2c2ac41c8bb57','apiuser','2016-10-27 14:05:28'),(117,'6852772fccfd20b886560c3491ac885480580291f9fdf0765cb0e30438dfc6fcdb8c7ee346b356f72dd0080115af50e3aed8b876bcfd15a64df9d131143a8cd1','apiuser','2016-10-27 14:05:57'),(118,'e677d0566687ca8ee43c4bf36b52183d849b67645326490784c5fcbf9254ee9def3c27306ff0e9ae7e5e005c25d9b216c89d63cccd043021494767abb53bcca7','apiuser','2016-10-27 14:08:38'),(119,'cb3b18d96227862f995977dc5b96cd85f0cc2a771d6f6ce97aa8eeb53625f28e41fb24b6edd2fa8921c685fefb84231d4804f2ace860fa549932b55da4256262','apiuser','2016-10-27 14:12:54'),(120,'1653c356ebf0987788eddf1933564fba9fad45d48fb279e0e4c1efb48010b0c77b8a81c48891e2312b72ccc06170d60cc94fc8e905b9454a8e7852ebd8ca2640','apiuser','2016-10-27 14:15:51'),(121,'04bc061a5087479b57593afa0c34055b680900edcbe2b55e65ca5ac8b89c9dd2e2ae86a8ac13941223c9ee9ffb8faf4bd19ae10bacc6dc724f77297eff1d9c36','apiuser','2016-10-27 14:17:10'),(122,'6a0042f9bfd096026f7f6b6383486581e72299b4e83d57afc4919ffb1f7fa11d676b113bc640ecefe31032e0d5e143f9b50c1307fa340f7c8b5dec1edb255e4d','apiuser','2016-10-27 14:22:44'),(123,'31311492ebf37ab0c89c24ac011c5c8cc15f50f3b4372fa840037e78f412eda95f47c4afee4ff7fe97bfac38f7ef186ddc0233ed8686365a5acaca3b144aa2e5','apiuser','2016-10-27 14:28:27'),(124,'bfeaf4b7ad9385a18d43423ad12832ff2f23d72136626f5a63f78a7fbd099532a41e1e141e5ab2386809c59115e7f48c28b0d8765980685b28d72fa360c6d067','apiuser','2016-10-27 14:29:48'),(125,'ab23088d32ace4e92fed1a6f397b8aca9908552993f8354b8eb314519ea333e83e247ac9374929039e9cc59f5f8fec3d9f972684b771c0ab7d5eda50ff7015a6','apiuser','2016-10-27 14:30:15'),(126,'26c6f173125bb2d6b161d12fb32616466b6efb7fa322c89c4d8a8141c612295b09598d21a8781ff74e9b42cb07f431e6a3b30fe4dab5b41f60215fd4c0bc11a2','apiuser','2016-10-27 14:30:27'),(127,'85dc7ccbcbc0d3afb064f0fe162365eb221e4979cf9d24106d96d664058955ce6c91c9e3cb4c00fb29fda7782ad46fb32b26ac1c9871aa1ad6a56c59eb9455ef','apiuser','2016-10-27 14:32:50'),(128,'3987ab95f14d58cf99cea416808410fb512d8ec362d32e72a881ff6570829999b8d1bff3860d3fdf1dfd2733210a6756df7c0bf5782da086d3f1020937d25651','apiuser','2016-10-27 14:46:26'),(129,'c0c50832e422f9a6f616edf11c09d4be846481e670808812c3e99850e33a1c9bab5fda4fd5bcf612c0ccb1c80b8c86718f432551f07aa8d8ce1d3c302e79fe7e','apiuser','2016-10-27 14:47:24'),(130,'3824f910adb2820695210686dc875893be587b13edb7df27f3d5bd6c6c2cc8a9abee1f85f1211d0b4c2fa6513c6f39b0cd5193b73fd747bd03e92d5b84ab64e9','apiuser','2016-10-27 14:48:24'),(131,'013f7bce7307afd5165542c215d2ce6289568e43e36fa75db9495db6be15900b89a6fe1f36f2e76388da4436d7a8b63198cdbba218bd656984c0b74b6225cc70','apiuser','2016-10-27 14:50:08'),(132,'3572231d86020b5cc2dff12380332daa92c2ae17e186b5fdcea7df7fbdbd5100797324e865a03c13669f0e0a6b79e843ab51662ca79bb3a9dc55b72500120574','apiuser','2016-10-27 15:05:21');
/*!40000 ALTER TABLE `refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-26 15:33:22
