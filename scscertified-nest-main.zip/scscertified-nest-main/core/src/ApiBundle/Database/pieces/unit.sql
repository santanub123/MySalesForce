-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nest
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;



--
-- Table structure for table `Unit`
--

DROP TABLE IF EXISTS `Unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UnitType_id` int(11) DEFAULT NULL,
  `Parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Unit_UnitType1_idx` (`UnitType_id`),
  KEY `fk_Unit_Unit1_idx` (`Parent_id`),
  CONSTRAINT `FK_7C89A36DE20736AD` FOREIGN KEY (`UnitType_id`) REFERENCES `UnitType` (`id`),
  CONSTRAINT `FK_7C89A36DF08B48D3` FOREIGN KEY (`Parent_id`) REFERENCES `Unit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Unit`
--

LOCK TABLES `Unit` WRITE;
/*!40000 ALTER TABLE `Unit` DISABLE KEYS */;
INSERT INTO `Unit` VALUES (1,'0','SCS','Root Company',1,0),(2,'1','Corporate','',2,1),(3,'2','HR','',3,2),(4,'2','Quality','',3,2),(5,'2','DevTech','',3,2),(6,'1','Natural Resources','',2,1),(7,'6','501','Forestry CoC',3,6),(8,'6','502','Forestry CoC',3,6),(9,'8','FSC Chain of Custody','not sure, this may be a program within a department',4,8),(10,'8','SFI Chain of Custody','not sure, this may be a program within a department',4,8),(11,'6','NR','a division',3,6),(12,'1','ECS','a division',2,1),(13,'12','Cal Compliant','not sure, this may be a program within a department',3,12),(14,'1','Food & Ag','a division',2,1),(15,'14','Non-GMO','not sure, this may be a program within a department',3,14);
/*!40000 ALTER TABLE `Unit` ENABLE KEYS */;
UNLOCK TABLES;



/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;