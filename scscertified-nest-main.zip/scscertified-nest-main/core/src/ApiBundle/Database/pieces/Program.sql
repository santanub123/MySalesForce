-- MySQL dump 10.13  Distrib 5.5.53, for debian-linux-gnu (i686)
--
-- Host: provision.scscertified.com    Database: nest
-- ------------------------------------------------------
-- Server version	5.5.52-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Program`
--

DROP TABLE IF EXISTS `Program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `department` varchar(100) DEFAULT NULL,
  `scs_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Program`
--

LOCK TABLES `Program` WRITE;
/*!40000 ALTER TABLE `Program` DISABLE KEYS */;
INSERT INTO `Program` VALUES (1,'Fair Labor Practices','703b',29,NULL),(2,'Organic','703c',30,NULL),(3,'Nutrition Rich',NULL,31,NULL),(4,'Antioxidant Rich','103',32,NULL),(5,'C.A.F.E Practices','703',36,NULL),(6,'Sensory Evaluation and Testing','307a',37,NULL),(7,'Greenhouse Gas Verification Program','503',39,NULL),(8,'Biodegradability','505',40,NULL),(9,'Recycling Program',NULL,41,NULL),(10,'Material Content & Indoor Air Quality',NULL,42,NULL),(11,'SCS 002-1 Climate Metrics',NULL,43,NULL),(12,'Environmentally Preferable Products & Life Cycle Services','503c',47,NULL),(13,'Import Testing Services','104',49,NULL),(14,'Export Testing Services',NULL,50,NULL),(15,'Indoor Advantage™','402a',53,NULL),(16,'Indoor Advantage™ Gold','402a',54,NULL),(17,'Indoor Air Quality + level™',NULL,56,NULL),(18,'Arctic Climate Footprinting','503c',58,NULL),(19,'Food & Agriculture and Latin America Divisions',NULL,59,NULL),(20,'Pesticide Residue Management','201',60,NULL),(21,'GHG Emissions Inventory and Reduction','503',61,NULL),(22,'Food & Agriculture Division',NULL,62,NULL),(23,'SCS Argentina SA',NULL,64,NULL),(24,'Natural Resources Division',NULL,65,NULL),(25,'Sensory Testing for Manufacturers','307a',66,NULL),(26,'Training Services','305',67,NULL),(27,'Sustainable Aquaculture Certification','603',68,NULL),(28,'Food & Agriculture Sustainability Services',NULL,69,NULL),(29,'Bonsucro Certification ','706',70,NULL),(30,'Responsible Biofuels','706',71,NULL),(31,'Certified Responsible Source',NULL,73,NULL),(32,'Carbon Neutral','503c',76,NULL),(33,'Fair Trade','703b',77,NULL),(34,'Produce Flavor & Nutrition','105',28,NULL),(35,'Lab Testing & Verification','105',48,NULL),(36,'Food and Agriculture Testing Services','200',27,NULL),(37,'NutriClean®','201',3,NULL),(38,'Food and Agriculture Auditing Services','300',4,NULL),(39,'Food Safety Audit - SQF','300',51,NULL),(40,'Environmental Certification Services','400',34,NULL),(41,'Indoor Air Quality','402a',5,NULL),(42,'FloorScore®','402b',6,NULL),(43,'Environmental Preferable Products','402c',7,NULL),(44,'Energy','403',8,NULL),(45,'Life Cycle Services','403b',9,NULL),(46,'Environmental Declarations','403c',10,NULL),(47,'calCOMPliant™','405',11,NULL),(48,'Forest Management','501',12,NULL),(49,'Carbon Offset Verification','501b',13,NULL),(50,'GHG Verification','501b',33,NULL),(51,'Chain of Custody','502',14,NULL),(52,'SCS LegalHarvest™ Verification Program','502',45,NULL),(53,'NWFA Responsible Procurement Program','502',46,NULL),(54,'Legal Harvest Verification Services','502b',63,NULL),(55,'Sustainable Seafood Certification','504',15,NULL),(56,'Recycled & Material Content','505',16,NULL),(57,'Green Squared℠','505',72,NULL),(58,'SVLK','508',74,NULL),(59,'MSC Chain of Custody','601',17,NULL),(60,'MSC Fisheries','601',35,NULL),(61,'Sustainable Agriculture','701',18,NULL),(62,'Veriflora®','702',19,NULL),(63,'Responsible Sourcing Strategies','703',20,NULL),(64,'Home Depot Eco Options','704',21,NULL),(65,'Sustainable Choice™','705',22,NULL),(66,'level™','705',44,NULL),(67,'SCS Mexico','801',57,NULL),(68,'SCS Corporate','900',1,NULL),(69,'Latin America','900',52,NULL),(70,'',NULL,NULL,NULL);
/*!40000 ALTER TABLE `Program` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-22 18:49:41
