-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nest
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;



--
-- Table structure for table `Person`
--

DROP TABLE IF EXISTS `Person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT NULL,
  `nameHonorific` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `nameFirst` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nameMiddle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nameLast` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email1` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email2` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phoneCell` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `User_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3370D440A76ED395` (`User_id`),
  KEY `fk_Person_Org1_idx` (`org_id`),
  KEY `fk_Person_User1_idx` (`User_id`),
  CONSTRAINT `FK_3370D44068D3EA09` FOREIGN KEY (`User_id`) REFERENCES `User` (`id`),
  CONSTRAINT `FK_3370D440F4837C1B` FOREIGN KEY (`org_id`) REFERENCES `Org` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Person`
--

LOCK TABLES `Person` WRITE;
/*!40000 ALTER TABLE `Person` DISABLE KEYS */;
INSERT INTO `Person` VALUES (1,2,'Ms','Katherine','Boyd','Richardson','Financial Analyst','krichardson0@scscertified.com','krichardson0@example.com','(702) 513-3990','(856) 905-4162',1),(2,8,'Honorable','Arthur','Hill','Gibson','Social Worker','agibson1@scscertified.com','agibson1@sciencedaily.com','(971) 143-1558','(512) 530-6347',2),(3,2,'Honorable','Wanda','Carter','Knight','Database Administrator I','wknight2@scscertified.com','wknight2@go.com','(419) 110-8210','(561) 171-9586',3),(4,9,'Mrs','Jacqueline','Harvey','Hunt','Technical Writer','jhunt3@scscertified.com','jhunt3@sfgate.com','(313) 721-6806','(732) 337-1729',4),(5,5,'Mr','Bobby','Boyd','Patterson','Chief Design Engineer','bpatterson4@scscertified.com','bpatterson4@flickr.com','(415) 322-4318','(937) 700-8037',5),(6,3,'Honorable','Shirley','Woods','Nguyen','Cost Accountant','snguyen5@scscertified.com','snguyen5@dell.com','(850) 376-9463','(602) 158-3430',6),(7,12,'Rev','Philip','Carter','Simpson','Data Coordiator','psimpson6@scscertified.com','psimpson6@cdbaby.com','(404) 289-5667','(832) 827-4671',7),(8,2,'Dr','Gloria','Austin','Rivera','Nuclear Power Engineer','grivera7@scscertified.com','grivera7@statcounter.com','(908) 568-8217','(209) 492-1862',8),(9,3,'Honorable','Jose','Bradley','Harrison','Statistician III','jharrison8@scscertified.com','jharrison8@java.com','(804) 321-3121','(646) 576-3420',9),(10,10,'Dr','Margaret','Welch','Richardson','Graphic Designer','mrichardson9@scscertified.com','mrichardson9@indiegogo.com','(903) 127-5875','(504) 225-6533',10),(11,8,'Honorable','Ashley','Nguyen','Adams','Legal Assistant','aadamsa@scscertified.com','aadamsa@cmu.edu','(806) 662-2201','(979) 299-2983',11),(12,11,'Dr','Jessica','Ferguson','Burke','Safety Technician IV','jburkeb@scscertified.com','jburkeb@163.com','(619) 656-2016','(501) 475-2612',12),(13,2,'Mr','Brian','Brown','Austin','Mechanical Systems Engineer','baustinc@scscertified.com','baustinc@howstuffworks.com','(407) 914-3831','(402) 244-5010',13),(14,2,'Ms','Louise','Gonzalez','Stone','Marketing Assistant','lstoned@scscertified.com','lstoned@google.nl','(614) 182-9528','(915) 940-0582',14),(15,11,'Mrs','Debra','Cooper','Stewart','Tax Accountant','dstewarte@scscertified.com','dstewarte@biglobe.ne.jp','(916) 862-5549','(862) 951-4344',15),(16,9,'Ms','Irene','Watkins','Crawford','Geological Engineer','icrawfordf@scscertified.com','icrawfordf@symantec.com','(214) 611-7642','(812) 272-9675',16),(17,1,'Rev','Arthur','Freeman','Murray','VP Product Management','amurrayg@scscertified.com','amurrayg@samsung.com','(612) 198-2111','(843) 784-8376',17),(18,7,'Ms','Norma','Roberts','Franklin','Payment Adjustment Coordinator','nfranklinh@scscertified.com','nfranklinh@sciencedaily.com','(901) 151-4375','(410) 453-9751',18),(19,11,'Mrs','Amy','Payne','Hanson','Compensation Analyst','ahansoni@scscertified.com','ahansoni@live.com','(951) 268-7149','(203) 966-3567',19),(20,11,'Rev','Donald','Gonzales','Fisher','Nurse Practicioner','dfisherj@scscertified.com','dfisherj@furl.net','(765) 558-2152','(314) 218-3971',20),(21,11,'Rev','Shawn','Chavez','Hamilton','Accounting Assistant IV','shamiltonk@scscertified.com','shamiltonk@dell.com','(610) 361-6002','(941) 938-7234',21),(22,5,'Honorable','Clarence','Duncan','Kennedy','Electrical Engineer','ckennedyl@scscertified.com','ckennedyl@clickbank.net','(202) 102-5653','(912) 285-9006',22),(23,9,'Dr','Katherine','Mason','Watkins','Structural Engineer','kwatkinsm@scscertified.com','kwatkinsm@bigcartel.com','(916) 978-7379','(304) 587-5028',23),(24,10,'Mr','Randy','Jones','Garrett','Associate Professor','rgarrettn@scscertified.com','rgarrettn@google.com.hk','(727) 466-6638','(914) 736-5696',24),(25,1,'Mr','Scott','Morris','Garrett','Help Desk Operator','sgarretto@scscertified.com','sgarretto@salon.com','(330) 490-7763','(614) 979-5411',25),(26,10,'Mr','Victor','Fox','Owens','General Manager','vowensp@scscertified.com','vowensp@samsung.com','(617) 345-5471','(954) 471-7618',26),(27,10,'Mr','Keith','Simmons','Ellis','Human Resources Manager','kellisq@scscertified.com','kellisq@illinois.edu','(517) 726-5104','(727) 491-6735',27),(28,10,'Dr','Phyllis','Richards','Bell','Professor','pbellr@scscertified.com','pbellr@de.vu','(804) 891-2982','(316) 808-4346',28),(29,9,'Honorable','Kimberly','Morris','Jones','Help Desk Operator','kjoness@scscertified.com','kjoness@cdbaby.com','(718) 723-4446','(253) 422-2096',29),(30,4,'Mr','Todd','Burke','Banks','Quality Engineer','tbankst@scscertified.com','tbankst@bing.com','(682) 360-6882','(614) 695-4724',30),(31,2,'Mrs','Rebecca','Brooks','Moreno','Quality Engineer','rmorenou@scscertified.com','rmorenou@usda.gov','(210) 265-9320','(406) 494-3280',31),(32,4,'Honorable','Tina','King','Snyder','Dental Hygienist','tsnyderv@scscertified.com','tsnyderv@dagondesign.com','(619) 287-6703','(304) 521-3370',32),(33,12,'Mrs','Michelle','Stanley','Collins','Human Resources Assistant III','mcollinsw@scscertified.com','mcollinsw@usa.gov','(423) 550-9462','(808) 321-3281',33),(34,8,'Rev','Gloria','Gomez','Rodriguez','Mechanical Systems Engineer','grodriguezx@scscertified.com','grodriguezx@redcross.org','(859) 185-7122','(410) 601-9519',34),(35,12,'Honorable','Daniel','Myers','Elliott','Health Coach II','delliotty@scscertified.com','delliotty@archive.org','(937) 674-3569','(786) 872-4751',35),(36,6,'Dr','Jerry','Welch','Montgomery','Account Executive','jmontgomeryz@scscertified.com','jmontgomeryz@loc.gov','(260) 809-7048','(601) 491-7954',36),(37,8,'Mr','Billy','Moreno','Riley','Librarian','briley10@scscertified.com','briley10@ebay.co.uk','(985) 638-8425','(262) 947-6769',37),(38,12,'Rev','Clarence','Banks','Palmer','Analog Circuit Design manager','cpalmer11@scscertified.com','cpalmer11@abc.net.au','(540) 125-9874','(773) 503-4063',38),(39,1,'Dr','Edward','Ross','Wallace','Statistician I','ewallace12@scscertified.com','ewallace12@dailymotion.com','(918) 396-7708','(312) 328-9400',39),(40,6,'Mr','Albert','Banks','Jones','Dental Hygienist','ajones13@scscertified.com','ajones13@mediafire.com','(606) 680-5274','(916) 854-4808',40),(41,12,'Rev','Jesse','Larson','Bell','Design Engineer','jbell14@scscertified.com','jbell14@taobao.com','(515) 214-0799','(513) 383-2042',41),(42,4,'Rev','Dorothy','Peters','Kelley','Recruiter','dkelley15@scscertified.com','dkelley15@technorati.com','(202) 867-9227','(812) 102-9549',42),(43,9,'Honorable','Gary','Boyd','Ramirez','Assistant Media Planner','gramirez16@scscertified.com','gramirez16@webmd.com','(816) 496-8874','(801) 266-5133',43),(44,7,'Mr','Johnny','Morrison','Russell','Nurse','jrussell17@scscertified.com','jrussell17@yandex.ru','(402) 663-5837','(323) 911-5782',44),(45,8,'Mrs','Pamela','Flores','Taylor','GIS Technical Architect','ptaylor18@scscertified.com','ptaylor18@tuttocitta.it','(240) 598-0056','(646) 714-6605',45),(46,6,'Honorable','Kathy','Richards','Tucker','Administrative Officer','ktucker19@scscertified.com','ktucker19@census.gov','(530) 791-4264','(302) 141-8986',46),(47,5,'Dr','Sean','Howell','Thomas','Accountant II','sthomas1a@scscertified.com','sthomas1a@elegantthemes.com','(213) 137-4514','(713) 452-2445',47),(48,10,'Dr','Clarence','Washington','Morales','Project Manager','cmorales1b@scscertified.com','cmorales1b@google.co.jp','(515) 975-3395','(361) 239-3287',48),(49,1,'Ms','Carol','Meyer','Welch','Product Engineer','cwelch1c@scscertified.com','cwelch1c@mediafire.com','(719) 482-2861','(916) 525-4514',49),(50,7,'Ms','Lois','Bradley','Ford','Librarian','lford1d@scscertified.com','lford1d@engadget.com','amendoza1d@ow.ly','(361) 588-9619',50);
/*!40000 ALTER TABLE `Person` ENABLE KEYS */;
UNLOCK TABLES;



/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;