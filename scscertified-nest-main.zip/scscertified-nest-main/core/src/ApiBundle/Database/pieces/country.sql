-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nest
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;



--
-- Table structure for table `Country`
--

DROP TABLE IF EXISTS `Country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isoCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Country`
--

LOCK TABLES `Country` WRITE;
/*!40000 ALTER TABLE `Country` DISABLE KEYS */;
INSERT INTO `Country` VALUES (1,'AFG','Afghanistan',0),(2,'ALA','�land Islands',1),(3,'ALB','Albania',1),(4,'DZA','Algeria',1),(5,'ASM','American Samoa',1),(6,'AND','Andorra',0),(7,'AGO','Angola',1),(8,'AIA','Anguilla',1),(9,'ATA','Antarctica',0),(10,'ATG','Antigua and Barbuda',1),(11,'ARG','Argentina',0),(12,'ARM','Armenia',1),(13,'ABW','Aruba',1),(14,'AUS','Australia',1),(15,'AUT','Austria',0),(16,'AZE','Azerbaijan',1),(17,'BHS','Bahamas',1),(18,'BHR','Bahrain',0),(19,'BGD','Bangladesh',1),(20,'BRB','Barbados',0),(21,'BLR','Belarus',1),(22,'BEL','Belgium',0),(23,'BLZ','Belize',0),(24,'BEN','Benin',1),(25,'BMU','Bermuda',0),(26,'BTN','Bhutan',0),(27,'BOL','Bolivia (Plurinational State of)',1),(28,'BES','Bonaire, Sint Eustatius and Saba',0),(29,'BIH','Bosnia and Herzegovina',0),(30,'BWA','Botswana',1),(31,'BVT','Bouvet Island',0),(32,'BRA','Brazil',0),(33,'IOT','British Indian Ocean Territory',0),(34,'BRN','Brunei Darussalam',1),(35,'BGR','Bulgaria',0),(36,'BFA','Burkina Faso',1),(37,'BDI','Burundi',1),(38,'CPV','Cabo Verde',1),(39,'KHM','Cambodia',0),(40,'CMR','Cameroon',1),(41,'CAN','Canada',0),(42,'CYM','Cayman Islands',1),(43,'CAF','Central African Republic',0),(44,'TCD','Chad',1),(45,'CHL','Chile',0),(46,'CHN','China',1),(47,'CXR','Christmas Island',1),(48,'CCK','Cocos (Keeling) Islands',0),(49,'COL','Colombia',1),(50,'COM','Comoros',0),(51,'COG','Congo',0),(52,'COD','Congo (Democratic Republic of the)',0),(53,'COK','Cook Islands',1),(54,'CRI','Costa Rica',1),(55,'CIV','C�te d\'Ivoire',1),(56,'HRV','Croatia',0),(57,'CUB','Cuba',0),(58,'CUW','Cura�ao',0),(59,'CYP','Cyprus',1),(60,'CZE','Czechia',0),(61,'DNK','Denmark',1),(62,'DJI','Djibouti',0),(63,'DMA','Dominica',1),(64,'DOM','Dominican Republic',0),(65,'ECU','Ecuador',1),(66,'EGY','Egypt',1),(67,'SLV','El Salvador',0),(68,'GNQ','Equatorial Guinea',1),(69,'ERI','Eritrea',0),(70,'EST','Estonia',1),(71,'ETH','Ethiopia',1),(72,'FLK','Falkland Islands (Malvinas)',0),(73,'FRO','Faroe Islands',1),(74,'FJI','Fiji',0),(75,'FIN','Finland',0),(76,'FRA','France',0),(77,'GUF','French Guiana',1),(78,'PYF','French Polynesia',1),(79,'ATF','French Southern Territories',0),(80,'GAB','Gabon',1),(81,'GMB','Gambia',0),(82,'GEO','Georgia',1),(83,'DEU','Germany',0),(84,'GHA','Ghana',1),(85,'GIB','Gibraltar',0),(86,'GRC','Greece',0),(87,'GRL','Greenland',0),(88,'GRD','Grenada',1),(89,'GLP','Guadeloupe',1),(90,'GUM','Guam',0),(91,'GTM','Guatemala',1),(92,'GGY','Guernsey',1),(93,'GIN','Guinea',1),(94,'GNB','Guinea-Bissau',0),(95,'GUY','Guyana',1),(96,'HTI','Haiti',1),(97,'HMD','Heard Island and McDonald Islands',1),(98,'VAT','Holy See',0),(99,'HND','Honduras',1),(100,'HKG','Hong Kong',0),(101,'HUN','Hungary',1),(102,'ISL','Iceland',0),(103,'IND','India',1),(104,'IDN','Indonesia',0),(105,'IRN','Iran (Islamic Republic of)',0),(106,'IRQ','Iraq',0),(107,'IRL','Ireland',1),(108,'IMN','Isle of Man',1),(109,'ISR','Israel',0),(110,'ITA','Italy',1),(111,'JAM','Jamaica',1),(112,'JPN','Japan',1),(113,'JEY','Jersey',0),(114,'JOR','Jordan',1),(115,'KAZ','Kazakhstan',0),(116,'KEN','Kenya',1),(117,'KIR','Kiribati',0),(118,'PRK','Korea (Democratic People\'s Republic of)',0),(119,'KOR','Korea (Republic of)',1),(120,'KWT','Kuwait',0),(121,'KGZ','Kyrgyzstan',0),(122,'LAO','Lao People\'s Democratic Republic',1),(123,'LVA','Latvia',0),(124,'LBN','Lebanon',0),(125,'LSO','Lesotho',0),(126,'LBR','Liberia',1),(127,'LBY','Libya',0),(128,'LIE','Liechtenstein',1),(129,'LTU','Lithuania',1),(130,'LUX','Luxembourg',1),(131,'MAC','Macao',0),(132,'MKD','Macedonia (the former Yugoslav Republic of)',1),(133,'MDG','Madagascar',0),(134,'MWI','Malawi',1),(135,'MYS','Malaysia',0),(136,'MDV','Maldives',1),(137,'MLI','Mali',0),(138,'MLT','Malta',1),(139,'MHL','Marshall Islands',1),(140,'MTQ','Martinique',0),(141,'MRT','Mauritania',1),(142,'MUS','Mauritius',0),(143,'MYT','Mayotte',0),(144,'MEX','Mexico',1),(145,'FSM','Micronesia (Federated States of)',1),(146,'MDA','Moldova (Republic of)',0),(147,'MCO','Monaco',1),(148,'MNG','Mongolia',0),(149,'MNE','Montenegro',1),(150,'MSR','Montserrat',0),(151,'MAR','Morocco',1),(152,'MOZ','Mozambique',0),(153,'MMR','Myanmar',0),(154,'NAM','Namibia',0),(155,'NRU','Nauru',1),(156,'NPL','Nepal',1),(157,'NLD','Netherlands',0),(158,'NCL','New Caledonia',1),(159,'NZL','New Zealand',1),(160,'NIC','Nicaragua',1),(161,'NER','Niger',0),(162,'NGA','Nigeria',1),(163,'NIU','Niue',0),(164,'NFK','Norfolk Island',1),(165,'MNP','Northern Mariana Islands',0),(166,'NOR','Norway',0),(167,'OMN','Oman',1),(168,'PAK','Pakistan',0),(169,'PLW','Palau',0),(170,'PSE','Palestine, State of',1),(171,'PAN','Panama',1),(172,'PNG','Papua New Guinea',0),(173,'PRY','Paraguay',1),(174,'PER','Peru',1),(175,'PHL','Philippines',0),(176,'PCN','Pitcairn',1),(177,'POL','Poland',0),(178,'PRT','Portugal',0),(179,'PRI','Puerto Rico',1),(180,'QAT','Qatar',1),(181,'REU','R�union',1),(182,'ROU','Romania',0),(183,'RUS','Russian Federation',0),(184,'RWA','Rwanda',1),(185,'BLM','Saint Barth�lemy',1),(186,'SHN','Saint Helena, Ascension and Tristan da Cunha',0),(187,'KNA','Saint Kitts and Nevis',1),(188,'LCA','Saint Lucia',1),(189,'MAF','Saint Martin (French part)',1),(190,'SPM','Saint Pierre and Miquelon',0),(191,'VCT','Saint Vincent and the Grenadines',0),(192,'WSM','Samoa',1),(193,'SMR','San Marino',1),(194,'STP','Sao Tome and Principe',0),(195,'SAU','Saudi Arabia',1),(196,'SEN','Senegal',0),(197,'SRB','Serbia',0),(198,'SYC','Seychelles',1),(199,'SLE','Sierra Leone',0),(200,'SGP','Singapore',0),(201,'SXM','Sint Maarten (Dutch part)',0),(202,'SVK','Slovakia',1),(203,'SVN','Slovenia',0),(204,'SLB','Solomon Islands',1),(205,'SOM','Somalia',1),(206,'ZAF','South Africa',1),(207,'SGS','South Georgia and the South Sandwich Islands',0),(208,'SSD','South Sudan',1),(209,'ESP','Spain',0),(210,'LKA','Sri Lanka',1),(211,'SDN','Sudan',0),(212,'SUR','Suriname',1),(213,'SJM','Svalbard and Jan Mayen',0),(214,'SWZ','Swaziland',1),(215,'SWE','Sweden',0),(216,'CHE','Switzerland',0),(217,'SYR','Syrian Arab Republic',1),(218,'TWN','Taiwan, Province of China[a]',1),(219,'TJK','Tajikistan',0),(220,'TZA','Tanzania, United Republic of',1),(221,'THA','Thailand',1),(222,'TLS','Timor-Leste',0),(223,'TGO','Togo',1),(224,'TKL','Tokelau',0),(225,'TON','Tonga',0),(226,'TTO','Trinidad and Tobago',1),(227,'TUN','Tunisia',1),(228,'TUR','Turkey',1),(229,'TKM','Turkmenistan',0),(230,'TCA','Turks and Caicos Islands',0),(231,'TUV','Tuvalu',1),(232,'UGA','Uganda',1),(233,'UKR','Ukraine',0),(234,'ARE','United Arab Emirates',1),(235,'GBR','United Kingdom of Great Britain and Northern Ireland',1),(236,'USA','United States of America',1),(237,'UMI','United States Minor Outlying Islands',0),(238,'URY','Uruguay',0),(239,'UZB','Uzbekistan',1),(240,'VUT','Vanuatu',0),(241,'VEN','Venezuela (Bolivarian Republic of)',1),(242,'VNM','Viet Nam',1),(243,'VGB','Virgin Islands (British)',1),(244,'VIR','Virgin Islands (U.S.)',0),(245,'WLF','Wallis and Futuna',0),(246,'ESH','Western Sahara',1),(247,'YEM','Yemen',0),(248,'ZMB','Zambia',0),(249,'ZWE','Zimbabwe',1);
/*!40000 ALTER TABLE `Country` ENABLE KEYS */;
UNLOCK TABLES;



/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;