-- MySQL dump 10.13  Distrib 5.5.53, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: nest
-- ------------------------------------------------------
-- Server version	5.5.53-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Address`
--

DROP TABLE IF EXISTS `Address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT NULL,
  `person_id` int(11) DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stateIsoCode` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `countryIsoCode` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C2F3561DF4837C1B` (`org_id`),
  KEY `IDX_C2F3561D217BBB47` (`person_id`),
  KEY `IDX_C2F3561DF92F3E70` (`country_id`),
  KEY `IDX_C2F3561D5D83CC1` (`state_id`),
  CONSTRAINT `FK_C2F3561D217BBB47` FOREIGN KEY (`person_id`) REFERENCES `Person` (`id`),
  CONSTRAINT `FK_C2F3561D5D83CC1` FOREIGN KEY (`state_id`) REFERENCES `State` (`id`),
  CONSTRAINT `FK_C2F3561DF4837C1B` FOREIGN KEY (`org_id`) REFERENCES `Org` (`id`),
  CONSTRAINT `FK_C2F3561DF92F3E70` FOREIGN KEY (`country_id`) REFERENCES `Country` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Address`
--

LOCK TABLES `Address` WRITE;
/*!40000 ALTER TABLE `Address` DISABLE KEYS */;
INSERT INTO `Address` VALUES (1,NULL,24,'33026 Melody Alley','Beaumont','77713','TX','US',240,44),(2,NULL,18,'540 Ryan Hill','Norwalk','6854','CT','US',240,7),(3,4,NULL,'57 Brentwood Pass','Fort Lauderdale','33320','FL','US',240,10),(4,3,NULL,'910 Park Meadow Hill','Miami Beach','33141','FL','US',240,10),(5,NULL,1,'0 Badeau Avenue','Phoenix','85005','AZ','US',240,3),(6,NULL,49,'20726 Thierer Court','Bradenton','34282','FL','US',240,10),(7,6,NULL,'3 Myrtle Terrace','Johnstown','15906','PA','US',240,39),(8,13,NULL,'7 Dryden Park','Little Rock','72215','AR','US',240,4),(9,19,NULL,'10657 Veith Alley','Aurora','80044','CO','US',240,6),(10,5,NULL,'2525 Knutson Drive','Norfolk','23504','VA','US',240,49),(11,NULL,19,'7035 Dixon Place','El Paso','88525','TX','US',240,44),(12,NULL,9,'2164 Jackson Circle','Orlando','32891','FL','US',240,10),(13,20,NULL,'1 Waywood Circle','Dayton','45426','OH','US',240,36),(14,10,NULL,'6236 Rusk Place','Des Moines','50330','IA','US',240,16),(15,NULL,4,'98056 Oak Lane','Chicago','60604','IL','US',240,14),(16,1,NULL,'32 Lindbergh Place','Bethesda','20816','MD','US',240,21),(17,NULL,39,'6760 Schurz Park','San Diego','92132','CA','US',240,5),(18,7,NULL,'3095 Sunbrook Hill','Columbus','43284','OH','US',240,36),(19,NULL,12,'33 Hagan Pass','Charleston','29424','SC','US',240,41),(20,15,NULL,'612 Sycamore Way','Birmingham','35210','AL','US',240,1),(21,NULL,3,'566 Drewry Center','Fayetteville','28305','NC','US',240,34),(22,11,NULL,'900 Dovetail Point','Orlando','32891','FL','US',240,10),(23,NULL,9,'17827 Namekagon Hill','Washington','20409','DC','US',240,9),(24,NULL,27,'5989 Scofield Hill','Cincinnati','45249','OH','US',240,16),(25,15,NULL,'59221 Magdeline Court','New York City','10249','NY','US',240,33),(26,NULL,4,'0 Huxley Drive','Minneapolis','55487','MN','US',240,24),(27,NULL,25,'9373 Carioca Parkway','Largo','33777','FL','US',240,10),(28,NULL,19,'79 Hanover Junction','Dallas','75216','TX','US',240,44),(29,NULL,2,'17746 Tony Center','Amarillo','79176','TX','US',240,44),(30,NULL,39,'94 Saint Paul Street','Montgomery','36177','AL','US',240,1),(31,NULL,49,'42606 Hauk Place','Oakland','94660','CA','US',240,5),(32,23,NULL,'35 Nobel Crossing','New Castle','16107','PA','US',240,39),(33,17,NULL,'642 Kings Hill','Peoria','61640','IL','US',240,14),(34,NULL,29,'0317 Moland Point','Tacoma','98442','WA','US',240,48),(35,NULL,10,'08 Ryan Terrace','Boston','2114','MA','US',240,22),(36,NULL,2,'256 Kim Terrace','Cincinnati','45213','OH','US',240,36),(37,NULL,19,'4 Mitchell Trail','Lynn','1905','MA','US',240,22),(38,NULL,18,'3 Dovetail Trail','Cleveland','44191','OH','US',240,36),(39,NULL,12,'079 Schurz Plaza','Washington','20260','DC','US',240,9),(40,NULL,34,'0 Thierer Junction','Boston','2114','MA','US',240,22),(41,NULL,47,'0380 Clemons Terrace','Whittier','90610','CA','US',240,5),(42,8,NULL,'7 Milwaukee Place','Dallas','75367','TX','US',240,44),(43,NULL,32,'26 Hauk Terrace','Saint Petersburg','33737','FL','US',240,10),(44,NULL,29,'0 3rd Trail','Tulsa','74141','OK','US',240,37),(45,24,NULL,'17 Mayer Plaza','Inglewood','90310','CA','US',240,5),(46,16,NULL,'7 Maple Wood Way','Meridian','39305','MS','US',240,25),(47,NULL,25,'47 Sunfield Road','Saint Louis','63131','MO','US',240,26),(48,NULL,37,'99432 Reindahl Alley','Oklahoma City','73135','OK','US',240,37),(49,NULL,46,'43 Lukken Terrace','Washington','20238','DC','US',240,9),(50,NULL,2,'3535 Hermina Crossing','Duluth','30096','GA','US',240,11);
/*!40000 ALTER TABLE `Address` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-22 19:16:54
