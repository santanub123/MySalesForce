-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nest
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;



--
-- Table structure for table `State`
--

DROP TABLE IF EXISTS `State`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `State` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isoCode` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_local` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `abbreviation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `countryCode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Dumping data for table `State`
--

LOCK TABLES `State` WRITE;
/*!40000 ALTER TABLE `State` DISABLE KEYS */;
INSERT INTO `State` VALUES (1,'US-AL','Alabama','Alabama','AL','US'),(2,'US-AK','Alaska','Alaska','AK','US'),(3,'US-AZ','Arizona','Arizona','AZ','US'),(4,'US-AR','Arkansas','Arkansas','AR','US'),(5,'US-CA','California','California','CA','US'),(6,'US-CO','Colorado','Colorado','CO','US'),(7,'US-CT','Connecticut','Connecticut','CT','US'),(8,'US-DE','Delaware','Delaware','DE','US'),(9,'US-DC','District of Columbia','District of Columbia','DC','US'),(10,'US-FL','Florida','Florida','FL','US'),(11,'US-GA','Georgia','Georgia','GA','US'),(12,'US-HI','Hawaii','Hawaii','HI','US'),(13,'US-ID','Idaho','Idaho','ID','US'),(14,'US-IL','Illinois','Illinois','IL','US'),(15,'US-IN','Indiana','Indiana','IN','US'),(16,'US-IA','Iowa','Iowa','IA','US'),(17,'US-KS','Kansas','Kansas','KS','US'),(18,'US-KY','Kentucky','Kentucky','KY','US'),(19,'US-LA','Louisiana','Louisiana','LA','US'),(20,'US-ME','Maine','Maine','ME','US'),(21,'US-MD','Maryland','Maryland','MD','US'),(22,'US-MA','Massachusetts','Massachusetts','MA','US'),(23,'US-MI','Michigan','Michigan','MI','US'),(24,'US-MN','Minnesota','Minnesota','MN','US'),(25,'US-MS','Mississippi','Mississippi','MS','US'),(26,'US-MO','Missouri','Missouri','MO','US'),(27,'US-MT','Montana','Montana','MT','US'),(28,'US-NE','Nebraska','Nebraska','NE','US'),(29,'US-NV','Nevada','Nevada','NV','US'),(30,'US-NH','New Hampshire','New Hampshire','NH','US'),(31,'US-NJ','New Jersey','New Jersey','NJ','US'),(32,'US-NM','New Mexico','New Mexico','NM','US'),(33,'US-NY','New York','New York','NY','US'),(34,'US-NC','North Carolina','North Carolina','NC','US'),(35,'US-ND','North Dakota','North Dakota','ND','US'),(36,'US-OH','Ohio','Ohio','OH','US'),(37,'US-OK','Oklahoma','Oklahoma','OK','US'),(38,'US-OR','Oregon','Oregon','OR','US'),(39,'US-PA','Pennsylvania','Pennsylvania','PA','US'),(40,'US-RI','Rhode Island','Rhode Island','RI','US'),(41,'US-SC','South Carolina','South Carolina','SC','US'),(42,'US-SD','South Dakota','South Dakota','SD','US'),(43,'US-TN','Tennessee','Tennessee','TN','US'),(44,'US-TX','Texas','Texas','TX','US'),(45,'US-UT','Utah','Utah','UT','US'),(46,'US-VT','Vermont','Vermont','VT','US'),(47,'US-VA','Virginia','Virginia','VA','US'),(48,'US-WA','Washington','Washington','WA','US'),(49,'US-WV','West Virginia','West Virginia','WV','US'),(50,'US-WI','Wisconsin','Wisconsin','WI','US'),(51,'US-WY','Wyoming','Wyoming','WY','US');
/*!40000 ALTER TABLE `State` ENABLE KEYS */;
UNLOCK TABLES;



/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;