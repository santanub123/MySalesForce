<?php
namespace ApiBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class DefaultControllerTest extends WebTestCase
{
  
    public function testGet()
    {
        $id = 1;
        $department = $this->getDepartment(); // create a Department object
        // I expect that the Department repository is called with find(1)
        $this->repository->expects($this->once())
            ->method('find')
            ->with($this->equalTo($id))
            ->will($this->returnValue($department));

        $this->departmentHandler->get($id); // call the get.
    }

}