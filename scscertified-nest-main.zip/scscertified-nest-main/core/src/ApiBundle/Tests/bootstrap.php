<?php

namespace ApiBundle\Tests;

$classLoader = require dirname(__DIR__).'../../../vendor/autoload.php';
$classLoader->register(true);

ini_set('error_reporting', E_ALL); // or error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');

class bootstrap{}