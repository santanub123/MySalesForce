<?php

namespace ApiBundle\Tests\Controller;

use PHPUnit\Framework\TestCase;
use ApiBundle\Controller\ApiController;

class ApiControllerTest extends TestCase
{    
    
    public static function setUpBeforeClass(): void
    {
        fwrite(STDOUT, "\n" . 'Test class: ' . __CLASS__ . "\n"); // for clarity when running directories of tests
    }
    
    /**
     * @dataProvider selectProvider
     */
    public function testGetSelectGeneratesExpectedString($flat_result, $include_entities, $include_properties, $expectedResults){
        $apiController = new ApiControllerHelper();
        $debug = array();
        $result = $apiController->getSelect($flat_result, $include_entities, $include_properties, $debug);
        $this->assertEquals($expectedResults, $result);
    }    
    /**
     * @dataProvider goodQueryProvider
     */
    public function testGetWhereGeneratesExpectedString($queryArray, $queryString, $parameter_array){
        $apiController = new ApiControllerHelper();
        $result = implode(" ", $apiController->getWhereRecursiveHelper($queryArray));
        $this->assertEquals($queryString, $result);
        $this->assertEquals($parameter_array, $apiController->getParameterValues());
    }    
    /**
     * @dataProvider badQueryProvider
     */
    public function testGetWhereSetsErrorOnBadInput($queryArray){
        $apiController = new ApiControllerHelper();
        $this->assertEquals(417, (($apiController->getViewResponse())->getData())['code']); //DEFAULT CODE FOR CLASS
        $apiController->getWhereRecursiveHelper($queryArray);
        $this->assertEquals(422, (($apiController->getViewResponse())->getData())['code']); //CODE IF QUERY FAILS TO BE PARSED
    }    
    /**
     * @dataProvider goodIncludeProperties
     */
    public function testValidatePropertiesReturnsTrueWhenValid($includePropertiesArray){
        $apiController = new ApiControllerHelper();
        $this->assertTrue($apiController->validateIncludeProperties($includePropertiesArray));
    }    
    /**
     * @dataProvider badIncludeProperties
     */
    public function testValidatePropertiesReturnsFalseWhenNotValid($includePropertiesArray){
        $apiController = new ApiControllerHelper();
        $this->assertFalse($apiController->validateIncludeProperties($includePropertiesArray));
    }
    /**
     * @dataProvider goodQueryParameterProvider
     */
    public function testIsQueryParameterReturnsTrueWhenProperlyFormatted($queryParameter){
        $apiController = new ApiControllerHelper();
        $this->assertTrue($apiController->isQueryParameter($queryParameter));
    }    
    /**
     * @dataProvider badQueryParameterProvider
     */
    public function testIsQueryParameterReturnsFalseWhenNotProperlyFormatted($queryParameter){
        $apiController = new ApiControllerHelper();
        $this->assertFalse($apiController->isQueryParameter($queryParameter));
    }
    /**
     * @dataProvider goodSubQueryProvider
     */
    public function testIsSubQueryReturnsTrueWhenProperlyFormatted($subQueryCandidate){
        $apiController = new ApiControllerHelper();
        $this->assertTrue($apiController->isSubQuery($subQueryCandidate));
    }    
    /**
     * @dataProvider badSubQueryProvider
     */
    public function testIsSubQueryReturnsFalseWhenNotProperlyFormatted($subQueryCandidate){
        $apiController = new ApiControllerHelper();
        $this->assertFalse($apiController->isSubQuery($subQueryCandidate));
    }
    /**
     * @dataProvider goodDeprecatedQueryProvider
     */
    public function testIsDeprecatedQueryReturnsTrueWhenProperlyFormatted($deprecatedQueryCandidate){
        $apiController = new ApiControllerHelper();
        $this->assertTrue($apiController->isDeprecatedQuery($deprecatedQueryCandidate));
    }
    /**
     * @dataProvider badDeprecatedQueryProvider
     */
    public function testIsDeprecatedQueryReturnsFalseWhenNotProperlyFormatted($deprecatedQueryCandidate){
        $apiController = new ApiControllerHelper();
        $this->assertFalse($apiController->isDeprecatedQuery($deprecatedQueryCandidate));
    }
    /**
     * @dataProvider deprecatedQueriesToUndeprecate
     */
    public function testUndeprecateGeneratesExpectedArray($deprecatedQuery, $deprecatedOperators, $expectedResults){
        $apiController = new ApiControllerHelper();
        $merged_options = array('dql_operators' => $deprecatedOperators);
        $apiController->setMergedOptions($merged_options);
        $result = $apiController->undeprecateQuery($deprecatedQuery);
        
        $this->assertEquals($expectedResults, $result);
    }    
    /**
     * @dataProvider doesHaveActiveProperty
     */
    public function testHasActivePropertyReturnsTrueWhenTrue($inputArray, $activeProperty){
        $apiController = new ApiControllerHelper();
        $result = $apiController->hasActiveProperty($inputArray, $activeProperty);
        $this->assertTrue($result);
    }
    /**
     * @dataProvider doesNotHaveActiveProperty
     */
    public function testHasActivePropertyReturnsFalseWhenFalse($inputArray, $activeProperty){
        $apiController = new ApiControllerHelper();
        $result = $apiController->hasActiveProperty($inputArray, $activeProperty);
        $this->assertFalse($result);
    }
    /**
     * @dataProvider activeQueryProvider
     */
    public function testAddActiveFilterReturnsExpectedString($inputName, $inputArray, $expectedResults){
        for($i = 0; $i <= 2; $i++){
            $apiController = new ApiControllerHelper();
            $apiController->setInputName($inputName);
            $apiController->setInputQuery($inputArray);
            $apiController->addActiveFilter($i);
            $this->assertEquals($expectedResults[$i], $apiController->getInputQuery());
        }
    }
    /**
     * @dataProvider newOptionProvider
     */
    public function testAddOptionChangesOptions($existingOptions, $newOptions, $expectedOptions, $x, $isValid){
        $apiController = new ApiControllerHelper();
        $apiController->setMergedOptions($existingOptions);
        foreach($newOptions as $newOptionName => $newOptionValue){
            $apiController->addOption($newOptionName, $newOptionValue);
        }
        $this->assertEquals($expectedOptions, $apiController->getMergedOptions());
        $results = $apiController->getViewResponse()->getData();
        if($isValid){
            //If an error hasn't been triggered, this is what the response array should look like
            $this->assertEquals(417, $results['code']);
            $this->assertEquals("", $results['message']);
            $this->assertEquals(null, $results['count']);
            $this->assertEquals(null, $results['data']);
        }
        else{
            //If an error has been triggered, this is what the response array should look like
            $this->assertEquals(422, $results['code']);
            $this->assertStringContainsString("is an invalid option", $results['message']);
            $this->assertEquals(null, $results['count']);
            $this->assertEquals(null, $results['data']);
        }
    }
    /**
     * @dataProvider newOptionProvider
     */
    public function testSetOptionChangesOptions($existingOptions, $newOptions, $x, $expectedOptions, $isValid){
        $apiController = new ApiControllerHelper();
        $apiController->setMergedOptions($existingOptions);
        foreach($newOptions as $newOptionName => $newOptionValue){
            $apiController->setOption($newOptionName, $newOptionValue);
        }
        $this->assertEquals($expectedOptions, $apiController->getMergedOptions());
        $results = $apiController->getViewResponse()->getData();
        if($isValid){
            //If an error hasn't been triggered, this is what the response array should look like
            $this->assertEquals(417, $results['code']);
            $this->assertEquals("", $results['message']);
            $this->assertEquals(null, $results['count']);
            $this->assertEquals(null, $results['data']);
        }
        else{
            //If an error has been triggered, this is what the response array should look like
            $this->assertEquals(422, $results['code']);
            $this->assertStringContainsString("is an invalid option", $results['message']);
            $this->assertEquals(null, $results['count']);
            $this->assertEquals(null, $results['data']);
        }
    }
    /**
     * @dataProvider newQueryProvider
     */
    public function testSetQueryChangesQuery($existingQuery, $newQuery, $expectedAddedQuery, $expectedSetQuery, $isValid){
        $apiController = new ApiControllerHelper();
        $apiController->setInputQuery($existingQuery);
        $apiController->setQuery($newQuery);
        //$this->assertEquals($expectedSetQuery, $apiController->getInputQuery());
        $results = $apiController->getViewResponse()->getData();
        if($isValid){
            //If an error hasn't been triggered, this is what the response array should look like
            $this->assertEquals(417, $results['code']);
            $this->assertEquals("", $results['message']);
            $this->assertEquals(null, $results['count']);
            $this->assertEquals(null, $results['data']);
        }
        else{
            //If an error has been triggered, this is what the response array should look like
            $this->assertEquals(422, $results['code']);
            $this->assertEquals("Error: invalid option supplied", $results['message']);
            $this->assertEquals(null, $results['count']);
            $this->assertEquals(null, $results['data']);
        }
    }
    /**
     * @dataProvider newQueryProvider
     */
    public function testAddQueryChangesQuery($existingQuery, $newQuery, $expectedAddedQuery, $expectedSetQuery, $isValid){
        $apiController = new ApiControllerHelper();
        $apiController->setInputQuery($existingQuery);
        $apiController->addQuery($newQuery);
        $this->assertTrue(true);
        //$this->assertEquals($expectedAddedQuery, $apiController->getInputQuery());
        $results = $apiController->getViewResponse()->getData();
        if($isValid){
            //If an error hasn't been triggered, this is what the response array should look like
            $this->assertEquals(417, $results['code']);
            $this->assertEquals("", $results['message']);
            $this->assertEquals(null, $results['count']);
            $this->assertEquals(null, $results['data']);
        }
        else{
            //If an error has been triggered, this is what the response array should look like
            $this->assertEquals(422, $results['code']);
            $this->assertEquals("Error: invalid option supplied", $results['message']);
            $this->assertEquals(null, $results['count']);
            $this->assertEquals(null, $results['data']);
        }
    }
    
    
    /*VALIDATION FUNCTIONS NOT TESTED HERE
      I could not get the doctrine elements to hook up correctly in this context. There are
      unit tests in the external unit test section, which are almost as useful*/
    
    ////////////////////////////////////////////////////////////////////////////////////////
    //Data Providers
    ////////////////////////////////////////////////////////////////////////////////////////
    public function selectProvider(){
        return [
            //NOT FLAT QUERIES//////////////////////////////////////////////////////////////
            [ //0 - Simple Query
                0, 
                [], 
                [],
                "SELECT e ",
            ],
            [ //1 - Query with include entities
                0, 
                ["hello"], 
                [],
                "SELECT e , hello",
            ],
            [ //2 - Query with one included entity
                0, 
                ["hello"], 
                [],
                "SELECT e , hello",
            ],
            [ //3 - Query with 1 local included property
                0, 
                [], 
                ["property_1"],
                "SELECT e.property_1",
            ],
            [ //4 - Query with 2 local included properties
                0, 
                [], 
                ["property_1", "property_2"],
                "SELECT e.property_1, e.property_2",
            ],
            [ //5 - Query with 1 local included property using an alias
                0, 
                [], 
                ["property_1 as field_1"],
                "SELECT e.property_1 as field_1",
            ],
            [ //6 - Query with 2 local included properties, and one related included properties
                0, 
                [], 
                ["property_1", "property_2", "relatedEntity.property"],
                "SELECT e.property_1, e.property_2, relatedEntity.property as relatedEntity_property",
            ],
            [ //7 - Query with 1 included entity and 1 local included property
                0, 
                ["entity_1"], 
                ["property_1"],
                "SELECT e.property_1",
            ],
            [ //8 - Query with calculated property with one input not in an array
                0, 
                [], 
                ["property_1", ["CONCAT", "property_2"]],
                "SELECT e.property_1, CONCAT(e.property_2)",
            ], 
            [ //9 - Query with calculated property with one input in an array
                0, 
                [], 
                ["property_1", ["CONCAT", ["property_2"]]],
                "SELECT e.property_1, CONCAT(e.property_2)",
            ],
            [ //10 - Query with calculated property with two inputs
                0, 
                [], 
                ["property_1", ["CONCAT", ["property_2", "property_3"]]],
                "SELECT e.property_1, CONCAT(e.property_2, e.property_3)",
            ],
            [ //11 - Query with calculated property with two inputs, alias
                0, 
                [], 
                ["property_1", ["CONCAT", ["property_2", "property_3"], "property_4"]],
                "SELECT e.property_1, CONCAT(e.property_2, e.property_3) as property_4",
            ],
            [ //12 - Query with calculated property with two inputs, one from a related entity
                0, 
                ["entity_2"], 
                ["property_1", ["CONCAT", ["property_2", "entity_2.property_3"], "property_4"]],
                "SELECT e.property_1, CONCAT(e.property_2, entity_2.property_3) as property_4",
            ],
            //FLAT QUERIES//////////////////////////////////////////////////////////////
            [ //13 - Simple flat query 
                1, 
                [], 
                [],
                "SELECT e ",
            ],
            [ //14 - Flat query with one included entity
                1, 
                ["hello"], 
                [],
                "SELECT e , hello",
            ],
            [ //15 - Flat query with 2 included entities
                1, 
                ["hello", "goodbye"], 
                [],
                "SELECT e , hello, goodbye",
            ],
            [ //16 - Query with 1 local included property, flat result
                1, 
                [], 
                ["property_1"],
                "SELECT e.property_1",
            ],
            [ //17 - Query with 2 local included properties, flat result
                1, 
                [], 
                ["property_1", "property_2"],
                "SELECT e.property_1, e.property_2",
            ],
            /*
            [ //18 - Query with 2 local included properties, and one related included properties, flat result
                1, 
                [], 
                ["property_1", "property_2", "relatedEntity.property"],
                "SELECT e.property_1, e.property_2, relatedEntity.property",
            ],
            */
            [ //19 - Query with 1 included entity and 1 local included property, flat result
                1, 
                ["entity_1"], 
                ["property_1"],
                "SELECT e.property_1",
            ],
        ];
    }
    public function goodQueryProvider(){
        return [
            
            array(
                array(), //BLANK QUERY
                "",
                array()
            ), 
            array(
                array(array()), //DOUBLE BLANK QUERY
                "",
                array()
            ), 
            array(
                array(array(array())), //TRIPLE BLANK QUERY
                "",
                array()
            ), 
            array(
                array(array("id", "=", "1")), //ONE INPUT QUERY
                "( e.id = ?0 )",
                [1]
            ), 
            array(
                array(array("org.id", "=", "1")), //ONE INPUT QUERY, PARAMETER IN RELATED FIELD
                "( org.id = ?0 )",
                [1]
            ), 
            array(
                array("id", "=", "1"), //ONE INPUT QUERY WITH QUERY AT BASE
                "e.id = ?0",
                [1]
            ), 
            array(
                array("name", "=", "AAA"), //ONE INPUT QUERY WITH QUERY AT BASE
                "e.name = ?0",
                ['AAA']
            ), 
            array(
                array(array("id", "IN", array(1, 2, 3))), //ONE INPUT QUERY USING INPUT IN OPERATOR
                "( e.id IN ( ?0) )",
                [[1, 2, 3]]
            ),
            array(
                array(array("name", "IN", array('AAA', 'BBB', 'CCC'))), //ONE INPUT QUERY USING INPUT IN OPERATOR
                "( e.name IN ( ?0) )",
                [['AAA', 'BBB', 'CCC']]
            ), 
            array(
                array(array("id", "NOT IN", array(1, 5))), //ONE INPUT QUERY USING NOT IN OPERATOR
                "( e.id NOT IN ( ?0) )",
                [[1, 5]]
            ), 
            array(
                array(array("id", "BETWEEN", 1, 5)), //ONE INPUT QUERY USING BETWEEN OPERATOR (and implicit "AND")
                "( e.id BETWEEN ?0 AND ?1 )",
                [1, 5]
            ), 
            array(
                array(array("id", "BETWEEN", 1, "AND", 5)), //ONE INPUT QUERY USING BETWEEN OPERATOR (and explicit "AND")
                "( e.id BETWEEN ?0 AND ?1 )",
                [1, 5]
            ), 
            array(
                array(array("id", "=", "1"),"AND", array("name","LIKE","Karen")), //TWO INPUT QUERY WITH "AND" JOIN
                "( e.id = ?0 AND e.name LIKE ?1 )",
                [1, 'Karen']
            ), 
            array(
                array(array("id", "=", "1"),"AND", array()), //TWO INPUT QUERY, ONE OF THE INPUTS IS BLANK
                "( e.id = ?0 AND )",
                [1]
            ), 
            array(
                array(array("id", "=", "1"), array("name","LIKE","Karen")), //TWO INPUT QUERY WITH NO JOIN ("AND" SHOULD BE INSERTED)
                "( e.id = ?0 AND e.name LIKE ?1 )",
                [1, 'Karen']
            ),
            array(
                array(array("id", "=", "1"), "NOT", array("name","LIKE","Karen")), //TWO INPUT QUERY WITH NOT, BUT NO OTHER JOIN ("AND" SHOULD BE INSERTED)
                "( e.id = ?0 AND NOT e.name LIKE ?1 )",
                [1, 'Karen']
            ),
            array(
                array(array("id", "=", "1"),"OR",array("name","LIKE","Karen")), //TWO INPUT QUERY WITH "OR" JOIN
                "( e.id = ?0 OR e.name LIKE ?1 )",
                [1, 'Karen']
            ), 
            array(
                array(array("id", "=", "1"),"AND NOT",array("name","LIKE","Karen")), //TWO INPUT QUERY WITH "AND NOT" JOIN
                "( e.id = ?0 AND NOT e.name LIKE ?1 )",
                [1, 'Karen']
            ), 
            array(
                array(array("id", "=", "1"),"AND", "NOT", array("name","LIKE","Karen")), //TWO INPUT QUERY WITH "AND" JOIN AND "NOT" JOIN SEPARATE
                "( e.id = ?0 AND NOT e.name LIKE ?1 )",
                [1, 'Karen']
            ), 
            array(
                array(array("id", "=", "1"),"AND", array("name","LIKE","Karen"),"AND", array("active","=","1")), //THREE INPUT QUERY WITH "AND" JOIN
                "( e.id = ?0 AND e.name LIKE ?1 AND e.active = ?2 )",
                [1, 'Karen', 1]
            ), 
            array(
                array(array("id", "=", "1"), array("name","LIKE","Karen"), array("active","=","1")), //THREE INPUT QUERY MISSING JOIN
                "( e.id = ?0 AND e.name LIKE ?1 AND e.active = ?2 )",
                [1, 'Karen', 1]
            ), 
            array(
                array(array("id", "=", "1"), array("name","LIKE","Karen"), "AND", array("active","=","1")), //THREE INPUT QUERY MISSING FIRST OF 2 JOINs
                "( e.id = ?0 AND e.name LIKE ?1 AND e.active = ?2 )",
                [1, 'Karen', 1]
            ), 
            array(
                array(array("id", "=", "1"), "AND", array("name","LIKE","Karen"), array("active","=","1")), //THREE INPUT QUERY MISSING SECOND OF 2 JOINs
                "( e.id = ?0 AND e.name LIKE ?1 AND e.active = ?2 )",
                [1, 'Karen', 1]
            ), 
            array(
                array(
                    array("start_date", ">=", "2019/01/01"),
                    "AND", 
                    array(
                        array("phone", "IS NULL"),
                        "OR",
                        array("phone_cell", "IS NULL")
                    )
                ), //COMPLEX JOIN WITH SUB-QUERY 
                "( e.start_date >= ?0 AND ( e.phone IS NULL OR e.phone_cell IS NULL ) )",
                ["2019/01/01"]
            ), 
            array(
                array(
                    array("start_date", ">=", "2019/01/01"),
                    array(
                        array("phone", "IS NULL"),
                        "OR",
                        array("phone_cell", "IS NULL")
                    )
                ), //COMPLEX JOIN WITH SUB-QUERY, MISSING "AND JOIN"
                "( e.start_date >= ?0 AND ( e.phone IS NULL OR e.phone_cell IS NULL ) )",
                ["2019/01/01"]
            )
        ];
    }
    public function badQueryProvider(){
        return [
            array(
                array("blah blah blah"), 
            ),
            array(
                array(array("id", "=", 1), "AND", array("hello")), 
            ),
        ];
    }
    public function goodIncludeProperties(){
        return [
            //[[]],   //empty array
            [['hello', 'goodbye']], //simple array of strings
            [['hello', 'goodbye', ['operator input', 'values']]], // contains 2 item sub-array for operation
            [['hello', 'goodbye', ['operator input', ['values']]]], // contains 2 item sub-array for operation, with the second being an array
            [['hello', 'goodbye', ['operator input', 'values', 'alias']]], // contains 3 item sub-array for operation
        ];
    }
    public function badIncludeProperties(){
        return [
            ["hello"], //not wrapped in an array
            [["hello", "goodbye", 5]], //includes something that is not a string
            [["hello", ["goodbye"]]], //includes a sub-array that is too short
            [['hello', 'goodbye', ['operator input', 'values', 'alias', 'something else']]], //includes a sub-array that is too long
            [['hello', 'goodbye', [['hello'], 'values']]], // contains sub-array, with the first element not being a string
            [['hello', 'goodbye', ['hello', 'values', ['alias']]]], // contains sub-array, with the final element not being a string
        ];
    }
    public function goodQueryParameterProvider(){
        return [
            array(array("id", "=", "1")),               //simple query - entity, operator, parameter
            array(array("id", "=")),                    //query with no parameter
            array(array("id", "=", array(1, 2, 3))),    //query with array for parameter
            array(array("id", "BETWEEN", 1, 3)),        //query with 2 parameters
            array(array("id", "BETWEEN", 1, "AND", 3)), //query with 3 parameters
        ];
    }
    public function badQueryParameterProvider(){
        return [        
            array(array()),
            array(array("id", "BETWEEN", "1", "2", "3", "4")), //too many arguments
            array(array("id")),                                //too few arguments
            array(array("id", "stuff", "1")),                  //operations argument isn't valid
            array(array(5, "=", "1")),                         //first argument isn't a string
            array(array("id", 5, "1")),                        //second argument isn't a string
        ];
    }    
    public function goodSubQueryProvider(){
        return [
            [array()],
            [array(array(2),array(1)),],
            [array(array(),"AND")],
            [array(array(),"OR")],
            [array(array(),"AND NOT")],
            [array(array(),"OR NOT")],
            [array(array(),"NOT")],
            [array(array(),"and")],
        ];
    }    
    public function badSubQueryProvider(){
        return [
            [array(array(),"HELLO")], //Should fail, has a string that is not in the list
            [array(array(),5)], //Should fail, has an item that is not a string or array
        ];
    }
    public function goodDeprecatedQueryProvider(){
        return [
            [["field" => 'a']], //One input deprecated style query
            [["field" => 'a', "field2" => 'b']], //Two input deprecated style query
            [["field" => 'a', "field2" => [1, 2, 3]]], //Two input deprecated style query, with a simple array as imput
        ];
    }
    public function badDeprecatedQueryProvider(){
        return [
            [[]], //BLANK QUERY, not deprecated
            [[["id", "=", "1"]]], //BASIC QUERY, not deprecated
            [["field" => 'a', "field2" => 'b', 6]], //Deprecated query, missing key
            [["field" => 'a', "field2" => [1, 2, [1, 2]]]], //Deprecated query, one input has 2-d array
        ];
    }
    public function deprecatedQueriesToUndeprecate(){
        return [
            [ //0
                ["field" => "a"],
                [],
                [["field", "=", "a"]]
            ], //Simple, one element query
            [ //1
                ["field" => "a", "fieldB" => "b"],
                [],
                [["field", "=", "a"],"AND",["fieldB", "=", "b"]]
            ], //two element query
            [ //2
                ["field" => "a", "fieldB" => "b", "fieldC" => [1, 2, 3]],
                [],
                [["field", "=", "a"],"AND",["fieldB", "=", "b"],"AND",['fieldC','=',[1,2,3]]]
            ], //three element query, with one element input being an array
            [ //3
                ["field" => "a", "fieldB" => "b", "fieldC" => [1, 2, 3]],
                ['fieldC' => 'IN'],
                [["field", "=", "a"],"AND",["fieldB", "=", "b"],"AND",['fieldC','IN',[1,2,3]]]
            ], //same three element query, with an operator submitted as an option
            [ //4
                ["field" => "a", "fieldB" => "b", "fieldC" => [1, 2, 3]],
                ['fieldC' => 'IN', "field" => "LIKE"],
                [["field", "LIKE", "%a%"],"AND",["fieldB", "=", "b"],"AND",['fieldC','IN',[1,2,3]]]
            ], //same three element query, with 2 operators submitted as an option
            [ //5
                ["field" => "a", "fieldB" => "b", "fieldC" => [1, 2, 3]],
                ['fieldC' => 'IN', "field" => "LIKE", 'fieldB' => '!='],
                [["field", "LIKE", "%a%"],"AND",["fieldB", "!=", "b"],"AND",['fieldC','IN',[1,2,3]]]
            ], //same three element query, with 3 operators submitted as an option 
            [ //6
                ["field" => "a", "fieldB" => "b", "fieldC" => ""],
                ['fieldC' => 'IS NULL'],
                [["field", "=", "a"],"AND",["fieldB", "=", "b"],"AND",['fieldC','IS NULL']]
            ], //three element query, with 1 operator being IS NULL (should drop blank operator)
        ];
    }
    public function doesHaveActiveProperty(){
        return
        [
            [
                ["active", "=", 1], //SINGLE INPUT PARAMETER
                "active"
            ],
            [
                ["status", "=", 1], //SINGLE INPUT PARAMETER
                "status"
            ],
            [
                ["whatever", "=", 1], //SINGLE INPUT PARAMETER
                "whatever"
            ],
            [
                [["hello", "=", 1],"AND",["active", "=", 1]], //2 INPUT PARAMETER
                "active"
            ],
            [
                [["hello", "=", 1],"AND",[["active", "=", 1],"OR",["whatever", "=", 1]]], //ACTIVE PARAMETER IS IN A SUB-QUERY
                "active"
            ],
        ];
    }
    public function doesNotHaveActiveProperty(){
        return
        [
            [
                [], //BLANK INPUT PARAMETER
                "active"
            ],
            [
                ["fee", "=", 1], //SINGLE INPUT PARAMETER
                "active"
            ],
            [
                [["hello", "=", 1],"AND",["active2", "=", 1]], //2 INPUT PARAMETER
                "active"
            ],
            [
                [["hello", "=", 1],"AND",[["fo", "=", 1],"OR",["whatever", "=", 1]]], //ACTIVE PARAMETER IS IN A SUB-QUERY
                "active"
            ],
        ];
    }
    public function activeQueryProvider(){
        return [
            [
                "app",
                [], //blank query
                [
                    ["active", "=", "0"],
                    ["active", "=", "1"],
                    []
                ]
            ],
            [
                "User",
                [], //blank query, user entity
                [
                    ["enabled", "=", "0"],
                    ["enabled", "=", "1"],
                    []
                ]
            ],
            [
                "app",
                ["hello", "=", 2], //single parameter query
                [
                    [["hello", "=", 2],"AND",["active", "=", "0"]],
                    [["hello", "=", 2],"AND",["active", "=", "1"]],
                    ["hello", "=", 2]
                ]
            ],
            [
                "app",
                [["hello", "=", 2],"AND",["goodbye", "=", 3]], //double parameter query
                [
                    [[["hello", "=", 2],"AND",["goodbye", "=", 3]],"AND",["active", "=", "0"]],
                    [[["hello", "=", 2],"AND",["goodbye", "=", 3]],"AND",["active", "=", "1"]],
                    [["hello", "=", 2],"AND",["goodbye", "=", 3]]
                ]
            ],
            [
                "app",
                ["active", "=", 2], //query parameter that already has active
                [
                    ["active", "=", 2],
                    ["active", "=", 2],
                    ["active", "=", 2]
                ]
            ],
        ];
    }
    public function newOptionProvider(){
        //existingOptions
        //newOptions
        //expectedOptions (when added)
        //expectedOptions (when set)
        //isValid
        return [
            [ // 0 Add to options with single value where it will overwrite an existing value
                ["flat_result" => 0], 
                ["flat_result" => 1], 
                ["flat_result" => 1], 
                ["flat_result" => 1], 
                1
            ],
            [ // 1 Add to an array with other pre-existing values
                ["flat_result" => 0, "status" => 1], 
                ["flat_result" => 1], 
                ["status" => 1, "flat_result" => 1], 
                ["status" => 1, "flat_result" => 1], 
                1
            ],
            [ // 2 Add 2 to an array with pre-exisiting values
                ["status" => 1, "flat_result" => 0, "size" => 0], 
                ["flat_result" => 1, "size" => 1], 
                ["status" => 1, "flat_result" => 1, "size" => 1], 
                ["status" => 1, "flat_result" => 1, "size" => 1], 
                1
            ],
            [ // 3 Add a value to an empty array
                ["include_entities" => []], 
                ["include_entities" => "d"], 
                ["include_entities" => ["d"]], 
                ["include_entities" => "d"], 
                1
            ],
            [ // 4 Add array of values to an empty array
                ["include_entities" => []], 
                ["include_entities" => ["d", "e"]], 
                ["include_entities" => ["d", "e"]], 
                ["include_entities" => ["d", "e"]], 
                1
            ],
            [ // 5 Add a value to an existing array
                ["include_entities" => ["a", "b", "c"]], 
                ["include_entities" => "d"], 
                ["include_entities" => ["d", "a", "b", "c"]], 
                ["include_entities" => "d"], 
                1
            ],
            [ // 6 Add an array of values to an existing array
                ["include_entities" => ["a", "b", "c"]], 
                ["include_entities" => ["d", "e"]], 
                ["include_entities" => ["d", "e", "a", "b", "c"]], 
                ["include_entities" => ["d", "e"]], 
                1
            ],
            [ // 7 Add an associative array of values to an empty array
                ["include_entities" => []], 
                ["include_entities" => ["a" => "b", "c" => "d"]], 
                ["include_entities" => ["a" => "b", "c" => "d"]], 
                ["include_entities" => ["a" => "b", "c" => "d"]], 
                1
            ],
            [ // 8 Add an associative array of values to an existing array (no conflicts)
                ["include_entities" => ["a" => "b", "c" => "d"]], 
                ["include_entities" => ["e" => "f", "g" => "h"]], 
                ["include_entities" => ["e" => "f", "g" => "h", "a" => "b", "c" => "d"]], 
                ["include_entities" => ["e" => "f", "g" => "h"]], 
                1
            ],
            [ // 9 Add an associative array of values to an existing array (no conflicts)
                ["include_entities" => ["a" => "b", "c" => "d"]], 
                ["include_entities" => ["e" => "f", "g" => "h", "a" => "x"]], 
                ["include_entities" => ["e" => "f", "g" => "h", "a" => "x", "c" => "d"]], 
                ["include_entities" => ["e" => "f", "g" => "h", "a" => "x"]], 
                1
            ],
            [ // 10 Using a deprecated name
                ["flat_result" => 0], 
                ["dql_flat_result" => 1], 
                ["flat_result" => 1],  
                ["flat_result" => 1], 
                1
            ],
            [ // 11 Using a deprecated name
                ["include_entities" => 0], 
                ["dql_include_entities" => 1], 
                ["include_entities" => 1],  
                ["include_entities" => 1], 
                1
            ],
            [ // 12 Using a deprecated name
                ["include_properties" => 0], 
                ["dql_include_properties" => 1], 
                ["include_properties" => 1],  
                ["include_properties" => 1], 
                1
            ],
            [ // 13 Using a deprecated name
                ["order_by" => 0], 
                ["dql_order_by" => 1], 
                ["order_by" => 1],  
                ["order_by" => 1], 
                1
            ],
            [ // 14 Using a deprecated name
                ["group_by" => 0], 
                ["dql_group_by" => 1], 
                ["group_by" => 1],  
                ["group_by" => 1], 
                1
            ],
            [ // 15 Using an invalid name
                ["group_by" => 0], 
                ["bad_name" => 1], 
                ["group_by" => 0], 
                ["group_by" => 0], 
                0
            ],
        ];
    }
    public function newQueryProvider(){
        //existingQuery
        //newQuery
        //expectedQuery (when added)
        //expectedQuery (when set)
        //isValid
        return [
            [ // 0 Add to query with pre-existing blank query
                [], 
                ["a", ">", 1], 
                ["a", ">", 1], 
                ["a", ">", 1], 
                1
            ],
            [ // 1 Add to query with pre-existing query
                ["b", ">", 1], 
                ["a", ">", 1], 
                [["b", ">", 1],"AND",["a", ">", 1],], 
                ["a", ">", 1], 
                1
            ],
            [ // 2 Add to query with pre-existing query with multiple pieces
                [["b", ">", 1],"AND",["c", "LIKE", "HELLO"]], 
                ["a", ">", 1], 
                [[["b", ">", 1],"AND",["c", "LIKE", "HELLO"]],"AND",["a", ">", 1]], 
                ["a", ">", 1], 
                1
            ],
            [ // 3 Invalid Query
                ["b", ">", 1],
                ["HELLO"], 
                [["b", ">", 1],"AND",["HELLO"]],
                ["HELLO"], 
                1
            ],
            [ // 3 Invalid Query
                ["b", ">", 1],
                "HELLO", 
                [["b", ">", 1],"AND","HELLO"],
                ["b", ">", 1],
                1
            ],
        ];
    }
    
}

class ApiControllerHelper extends ApiController{
    //Overwrite functions that don't work in the unit test context
    protected function validateEntity($entity, $bundle = null){
        error_log("child class");
        return true;
    }
    protected function isValidProperty($input){
        return true;
    }
    
    //Access Protected Variables
    public function getParameterValues(){
        return $this->parameter_values;
    }
    public function setInputName($inputName){
        $this->input_entity = $inputName;
    }
    public function setInputQuery($inputQuery){
        $this->input_query = $inputQuery;
    }
    public function getInputQuery(){
        return $this->input_query;
    }
    public function setMergedOptions($merged_options){
        $this->merged_options = $merged_options;
    }
    public function getMergedOptions(){
        return $this->merged_options;
    }
    
    //Access protected functions
    public function getSelect($flat_result, $include_entities, $include_properties, $debug){
        return parent::getSelect($flat_result, $include_entities, $include_properties, $debug);
    }
    public function getWhereRecursiveHelper($iq_item){
        return parent::getWhereRecursiveHelper($iq_item);
    }
    public function getViewResponse(){
        return parent::getViewResponse();
    }
    public function isQueryParameter($queryParameter){
        return parent::isQueryParameter($queryParameter);
    }
    public function isSubQuery($subQueryCandidate){
        return parent::isSubQuery($subQueryCandidate);
    }
    public function isDeprecatedQuery($deprecatedQueryCandidate){
        return parent::isDeprecatedQuery($deprecatedQueryCandidate);
    }
    public function undeprecateQuery($deprecatedQuery){
        return parent::undeprecateQuery($deprecatedQuery);
    }
    public function hasActiveProperty($inputArray, $activeProperty){
        return parent::hasActiveProperty($inputArray, $activeProperty);
    }
    public function validateIncludeProperties($include_properties){
        return parent::validateIncludeProperties($include_properties);
    }
}