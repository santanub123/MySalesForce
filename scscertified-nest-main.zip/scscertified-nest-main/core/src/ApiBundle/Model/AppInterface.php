<?php

namespace ApiBundle\Model;

Interface AppInterface
{
    /**
     * Set name
     *
     * @param string $name
     * @return AppInterface
     */
    public function setName($name);
    
    /**
     * Get name
     *
     * @return string 
     */
    public function getName();
    
    /**
     * Set description
     *
     * @param string $description
     * @return AppInterface
     */
    public function setDescription($description);
    
    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription();
}