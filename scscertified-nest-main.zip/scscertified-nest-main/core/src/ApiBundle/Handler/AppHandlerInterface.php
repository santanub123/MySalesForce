<?php

namespace ApiBundle\Handler;

use ApiBundle\Model\AppInterface;

interface AppHandlerInterface
{
    /**
     * Get a App given the identifier
     *
     * @api
     *
     * @param mixed $id
     *
     * @return AppInterface
     */
    public function get($id);
    
    /**
     * Get a list of Apps.
     *
     * @param int $limit  the limit of the result
     * @param int $offset starting from the offset
     *
     * @return array
     */
    public function all($limit = null, $offset = 0);
    
    /**
     * Post App, creates a new App.
     *
     * @api
     *
     * @param array $parameters
     *
     * @return AppInterface
     */
    public function post(array $parameters);
    
    /**
     * Edit a App.
     *
     * @api
     *
     * @param AppInterface   $app
     * @param array           $parameters
     *
     * @return AppInterface
     */
    public function put(AppInterface $app, array $parameters);
    
    /**
     * Partially update a App.
     *
     * @api
     *
     * @param AppInterface   $app
     * @param array           $parameters
     *
     * @return AppInterface
     */
    public function patch(AppInterface $app, array $parameters);
}