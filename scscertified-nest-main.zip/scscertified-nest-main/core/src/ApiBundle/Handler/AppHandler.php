<?php

namespace ApiBundle\Handler;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Form\FormFactoryInterface;

use ApiBundle\Model\AppInterface;
use ApiBundle\Form\AppType;
use ApiBundle\Exception\InvalidFormException;

class AppHandler implements AppHandlerInterface
{
    private $om;
    private $entityClass;
    private $repository;
    private $formFactory;
    
    public function __construct(ObjectManager $om, $entityClass, FormFactoryInterface $formFactory = null) // TODO: formFactory null default is a hack -- find out where this is being passed from and fix
    {
        $this->om = $om;
        $this->entityClass = $entityClass;
        $this->repository = $this->om->getRepository($this->entityClass);
        $this->formFactory = $formFactory;
    }

    /**
     * Get a App.
     *
     * @param mixed $id
     *
     * @return AppInterface
     */
    public function get($id)
    {
        return $this->repository->find($id);
    }
    
    /**
     * Get a list of Apps.
     *
     * @param int $limit  the limit of the result
     * @param int $offset starting from the offset
     *
     * @return array
     */
    public function all($limit = null, $offset = 0)
    {
        return $this->repository->findBy(array(), null, $limit, $offset);
    }
    
    /**
     * Create a new App.
     *
     * @param array $parameters
     *
     * @return AppInterface
     */
    public function post(array $parameters)
    {
        $app = $this->createApp();
        
        return $this->processForm($app, $parameters, 'POST');
    }
    
    /**
     * Edit a App.
     *
     * @param AppInterface $app
     * @param array         $parameters
     *
     * @return AppInterface
     */
    public function put(AppInterface $app, array $parameters)
    {
        return $this->processForm($app, $parameters, 'PUT');
    }
    
    /**
     * Partially update a App.
     *
     * @param AppInterface $app
     * @param array         $parameters
     *
     * @return AppInterface
     */
    public function patch(AppInterface $app, array $parameters)
    {
        return $this->processForm($app, $parameters, 'PATCH');
    }
    
    /**
     * Processes the form.
     *
     * @param AppInterface $app
     * @param array         $parameters
     * @param String        $method
     *
     * @return AppInterface
     *
     * @throws \ApiBundle\Exception\InvalidFormException
     */
    //private function processForm(AppInterface $app, array $parameters, $method = "PUT")
    private function processForm(AppInterface $app, array $parameters, $method = "PUT")
    {
        $form = $this->formFactory->create(new AppType(), $app, array('method' => $method));
        $form->submit($parameters, 'PATCH' !== $method);
        if ($form->isValid()) {
            $app = $form->getData();
            $this->om->persist($app);
            $this->om->flush($app);
            return $app;
        }
        throw new InvalidFormException('Invalid submitted data', $form);
    }
    
    private function createApp()
    {
        return new $this->entityClass();
    }

}