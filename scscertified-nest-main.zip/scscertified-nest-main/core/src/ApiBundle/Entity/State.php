<?php

namespace ApiBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
//use Doctrine\ORM\Mapping\UniqueConstraint;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * State (look up states here by ISO code)
 *
 * {@inheritdoc}
 * @ORM\Table(
 *     name="State",
 *     indexes={
 *         @ORM\Index(name="isoCode", columns={"isoCode"}),
 *         @ORM\Index(name="countryCode", columns={"countryCode"}),
 *         @ORM\Index(name="countryId", columns={"country_id"})
 *     }
 * )
 * @ORM\Entity
 *
 * @ExclusionPolicy("all")
 */
class State {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;

    /**
     * @var boolean
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var string
     *
     * @ORM\Column(name="isoCode", type="string", length=32, nullable=false)
     *
     * @Assert\NotBlank()
     * @Assert\Length(max = 32)
     *
     * @Expose
     */
    private $isoCode;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="nameLocal", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $nameLocal;

    /**
     * @var string
     *
     * @ORM\Column(name="abbreviation", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $abbreviation;

    /**
     * @var string
     *
     * @ORM\Column(name="countryCode", type="string", length=32, nullable=true)
     *
     * @Assert\Length(max = 32)
     * @Assert\Country()
     * # requires ISO-3166 alpha-2 code
     * # https://symfony.com/doc/3.4/reference/constraints/Country.html
     *
     * @Expose
     */
    private $countryCode;
    
    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     *
     * #Expose
     */
    private $countryId;
    
    /**
     * @var \ApiBundle\Entity\Country
     *
     * @ORM\ManyToOne(targetEntity="Country", inversedBy="states")
     * #ORM\JoinColumn(name="country_id", referencedColumnName="id")
     * #ORM\JoinColumn(name="countryCode", referencedColumnName="isoCode")
     *
     * @Expose
     */
    private $country;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Address", mappedBy="state")
     * @ORM\JoinColumn(name="id", referencedColumnName="state_id")
     * #ORM\JoinColumn(name="isoCode", referencedColumnName="stateCode")
     *
     * #Expose
     */
    private $addresses;
    
    
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->addresses = new ArrayCollection();
    }
    
    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        return $this->name;
    }
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set active
     *
     * @param string $active
     *
     * @return State
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return State
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }


    /**
     * Set nameLocal
     *
     * @param string $nameLocal
     *
     * @return State
     */
    public function setNameLocal($nameLocal)
    {
        $this->nameLocal = $nameLocal;

        return $this;
    }

    /**
     * Get nameLocal
     *
     * @return string
     */
    public function getNameLocal()
    {
        return $this->nameLocal;
    }

    /**
     * Set abbreviation
     *
     * @param string $abbreviation
     *
     * @return State
     */
    public function setAbbreviation($abbreviation)
    {
        $this->abbreviation = $abbreviation;

        return $this;
    }

    /**
     * Get abbreviation
     *
     * @return string
     */
    public function getAbbreviation()
    {
        return $this->abbreviation;
    }

    /**
     * Set countryCode
     *
     * @param string $countryCode
     *
     * @return State
     */
    public function setCountryCode($countryCode)
    {
        $this->countryCode = $countryCode;

        return $this;
    }

    /**
     * Get countryCode
     *
     * @return string
     */
    public function getCountryCode()
    {
        return $this->countryCode;
    }

    /**
     * Set isoCode
     *
     * @param string $isoCode
     *
     * @return State
     */
    public function setIsoCode($isoCode)
    {
        $this->isoCode = $isoCode;

        return $this;
    }

    /**
     * Get isoCode
     *
     * @return string
     */
    public function getIsoCode()
    {
        return $this->isoCode;
    }
    
    /**
     * Set countryId
     *
     * @param string $countryId
     *
     * @return State
     */
    public function setCountryId($countryId)
    {
        $this->countryId = $countryId;

        return $this;
    }

    /**
     * Get countryId
     *
     * @return integer
     */
    public function getCountryId()
    {
        return $this->countryId;
    }

    /**
     * Set country
     *
     * @param \ApiBundle\Entity\Country $country
     *
     * @return State
     */
    public function setCountry(\ApiBundle\Entity\Country $country = null)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return Country
     */
    public function getCountry()
    {
        return $this->country;
    }

}

?>
