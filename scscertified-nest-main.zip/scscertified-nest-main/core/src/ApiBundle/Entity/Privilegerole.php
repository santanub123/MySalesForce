<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

/**
 * Privilegerole
 *
 * @ORM\Table(name="Privilegerole")
 * @ORM\Entity(repositoryClass="ApiBundle\Repository\PrivilegeroleRepository")
 *
 * @ExclusionPolicy("all")
 */
class Privilegerole
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var integer
     *
     * @ORM\Column(name="privilege_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $privilegeId;

    /**
     * @var integer
     *
     * @ORM\Column(name="role_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $roleId;

    /**
     * @var integer
     *
     * @ORM\Column(name="unit_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $unitId;

    /**
     * @var \ApiBundle\Entity\Privilege
     *
     * @ORM\ManyToOne(targetEntity="Privilege", inversedBy="privilegeroles")
     *
     * @Assert\NotBlank()
     *
     * @Expose
     */
    private $privilege;

    /**
     * @var \ApiBundle\Entity\Role
     *
     * @ORM\ManyToOne(targetEntity="Role", inversedBy="privilegeroles")
     *
     * @Assert\NotBlank()
     *
     * @Expose
     */
    private $role;

    /**
     * @var \ApiBundle\Entity\Unit
     *
     * @ORM\ManyToOne(targetEntity="Unit", inversedBy="privilegeroles")
     *
     * @Assert\NotBlank()
     *
     * @Expose
     */
    private $unit;

    /**
     * Supports __toString()
     *
     * @var string
     *
     * @Expose
     */
    private $name;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Assignedrole", mappedBy="privilegeroles")
     *
     * #Expose
     */
    private $assignedroles;



    /**
     * Validation callback
     *
     * @Assert\Callback
     */
    public function validate(ExecutionContextInterface $context)
    {
    }



    /**
     * Constructor
     */
    public function __construct()
    {
        $this->setName();
        $this->assignedroles = new ArrayCollection();
    }



    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        $this->setName();

        return $this->getName(); // supports a useful return when listed as a related entity in EasyAdmin
    }

    /**
     * Set 'name'
     *
     * @return Privilegerole
     */
    public function setName()
    {
        // show a legible representation where a string is required
        $this->name = "r: $this->role | u: $this->unit | a#p: $this->privilege";

        return $this;
    }

    /**
     * Get 'name'
     *
     * @return string
     */
    public function getName()
    {
        return "$this->name";
    }


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set active
     *
     * @param string $active
     *
     * @return Privilegerole
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set privilege
     *
     * @param \ApiBundle\Entity\Privilege $privilege
     *
     * @return Privilegerole
     */
    public function setPrivilege(\ApiBundle\Entity\Privilege $privilege = null)
    {
        $this->privilege = $privilege;

        return $this;
    }

    /**
     * Get privilege
     *
     * @return \ApiBundle\Entity\Privilege
     */
    public function getPrivilege()
    {
        return $this->privilege;
    }

    /**
     * Get privilegeId
     *
     * @return integer
     */
    public function getPrivilegeId()
    {
        return $this->privilegeId;
    }

    /**
     * Set role
     *
     * @param \ApiBundle\Entity\Role $role
     *
     * @return Privilegerole
     */
    public function setRole(\ApiBundle\Entity\Role $role = null)
    {
        $this->role = $role;

        return $this;
    }

    /**
     * Get role
     *
     * @return \ApiBundle\Entity\Role
     */
    public function getRole()
    {
        return $this->role;
    }

    /**
     * Get roleId
     *
     * @return integer
     */
    public function getroleId()
    {
        return $this->roleId;
    }

    /**
     * Set unit
     *
     * @param \ApiBundle\Entity\Unit $unit
     *
     * @return Privilegerole
     */
    public function setUnit(\ApiBundle\Entity\Unit $unit = null)
    {
        $this->unit = $unit;

        return $this;
    }

    /**
     * Get unit
     *
     * @return \ApiBundle\Entity\Unit
     */
    public function getUnit()
    {
        return $this->unit;
    }

    /**
     * Get unitId
     *
     * @return integer
     */
    public function getUnitId()
    {
        return $this->unitId;
    }

    /**
     * Get privilege app
     *
     * @return \ApiBundle\Entity\App
     */
    public function getApp()
    {
        if (!empty($this->privilege)) {
            return $this->privilege->getApp();
        } else {
            return null;
        }
    }

    /**
     * Get assignedroles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAssignedroles()
    {
        return $this->assignedroles;
    }
}
