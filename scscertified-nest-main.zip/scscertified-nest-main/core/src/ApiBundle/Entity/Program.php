<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Program
 *
 * @ORM\Table(name="Program")
 * @ORM\Entity
 *
 * @ExclusionPolicy("all")
 */
class Program
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;
    
    /**
     * @var string
     *
     * @ORM\Column(name="scs_id", type="integer", nullable=true)
     *
     * @Expose
     */
    private $scsId;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=false)
     *
     * @Assert\NotBlank()
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $description;
    
    /**
     * @var string
     *
     * @ORM\Column(name="department", type="string", length=128, nullable=true)
     *
     * @Assert\Length(max = 128)
     *
     * @Expose
     */
    private $department;

    /**
     * #var string
     *
     * #ORM\Column(name="unit_id", type="integer", nullable=true)
     *
     * #Expose
     */
    //private $unitId; // placeholder for full Unit relationship, if we go in that direction; would need *-to-many


    
    /**
     * Constructor
     */
    public function __construct()
    {

    }
    
    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        return basename(__CLASS__);
    }
    
    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set department
     *
     * @param string $department
     * @return Program
     */
    public function setDepartment($department)
    {
        $this->department = $department;

        return $this;
    }

    /**
     * Get department
     *
     * @return string 
     */
    public function getDepartment()
    {
        return $this->number;
    }

    /**
     * Set active
     *
     * @param string $active
     *
     * @return Program
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }    

    /**
     * Set name
     *
     * @param string $name
     * @return Program
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Program
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

}
