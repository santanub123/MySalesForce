<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;

/**
 * AssignedrolePrivilegerole
 *
 * @ORM\Table(name="assignedrole_privilegerole")
 * @ORM\Entity(readOnly=true)
 *
 * @ExclusionPolicy("all")
 */
class AssignedrolePrivilegerole
{
    /**
     * @var integer
     *
     * @ORM\Column(name="assignedrole_id", type="integer", nullable=false)
     * @ORM\Id
     * @Expose
     */
    private $assignedroleId;

    /**
     * @var integer
     *
     * @ORM\Column(name="privilegerole_id", type="integer", nullable=false)
     * @ORM\Id
     * @Expose
     */
    private $privilegeroleId;

    /**
     * Get assignedroleId
     *
     * @return integer
     */
    public function getAssignedroleId()
    {
        return $this->assignedroleId;
    }

    /**
     * Get privilegeroleId
     *
     * @return integer
     */
    public function getPrivilegeroleId()
    {
        return $this->privilegeroleId;
    }
}
