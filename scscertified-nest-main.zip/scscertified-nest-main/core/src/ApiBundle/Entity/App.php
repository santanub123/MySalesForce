<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;


/**
 * App (individual application on the intranet)
 *
 * {@inheritdoc}
 * @ORM\Table(name="App")
 * @ORM\Entity
 *
 * @ExclusionPolicy("all")
 */
class App
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="appkey", type="string", length=8, nullable=false)
     *
     * @Expose
     */
    private $appkey;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="is_external", type="boolean", nullable=true)
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $isExternal;

    /**
     * @var integer
     *
     * @ORM\Column(name="has_display", type="boolean", nullable=true)
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $hasDisplay;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="sort", type="integer", nullable=true)
     *
     * @Assert\Type(type = "integer")
     *
     * @Expose
     */
    private $sort;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=128, nullable=false)
     *
     * @Assert\NotBlank()
     * @Assert\Length(max = 128)
     *
     * @Expose
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="abbreviation", type="string", length=8, nullable=false)
     *
     * @Assert\NotBlank()
     * @Assert\Length(max = 8)
     *
     * @Expose
     */
    private $abbreviation;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="path", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $path;

    /**
     * @var string
     *
     * @ORM\Column(name="icon", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $icon;
    
    /**
     * No getters or setters -- this is just to make association bidirectional, to try to help Listener issue
     * (Subsequently, added getter & setter for other purposes)
     *
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Privilege", mappedBy="app")
     * @ORM\OrderBy({"name" = "ASC"})
     *
     * #Expose
     */
    private $privileges;
    
    
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->privileges = new ArrayCollection();
    }
    
    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        return $this->name; // supports a useful return when listed as a related entity in EasyAdmin
    }
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set appkey
     *
     * @param string $appkey
     *
     * @return App
     */
    public function setAppkey($appkey)
    {
        $this->appkey = $appkey;

        return $this;
    }

    /**
     * Get appkey
     *
     * @return string
     */
    public function getAppkey()
    {
        return $this->appkey;
    }
    
    /**
     * Set active
     *
     * @param string $active
     *
     * @return App
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get isactive
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }
    
    /**
     * Set isexternal
     *
     * @param string $isexternal
     *
     * @return App
     */
    public function setIsExternal($isExternal)
    {
        $this->isExternal = $isExternal;

        return $this;
    }

    /**
     * Get isexternal
     *
     * @return boolean
     */
    public function getIsExternal()
    {
        return $this->isExternal;
    }

    /**
     * Set hasdisplay
     *
     * @param string $hasdisplay
     *
     * @return App
     */
    public function setHasDisplay($hasDisplay)
    {
        $this->hasDisplay = $hasDisplay;

        return $this;
    }

    /**
     * Get hasdisplay
     *
     * @return boolean
     */
    public function getHasDisplay()
    {
        return $this->hasDisplay;
    }
    
    /**
     * Set sort
     *
     * @param string $sort
     *
     * @return App
     */
    public function setSort($sort)
    {
        $this->sort = $sort;

        return $this;
    }

    /**
     * Get sort
     *
     * @return integer
     */
    public function getSort()
    {
        return $this->sort;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return App
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set abbreviation
     *
     * @param string $abbreviation
     *
     * @return App
     */
    public function setAbbreviation($abbreviation)
    {
        $this->abbreviation = $abbreviation;

        return $this;
    }

    /**
     * Get abbreviation
     *
     * @return string
     */
    public function getAbbreviation()
    {
        return $this->abbreviation;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return App
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set path
     *
     * @param string $path
     *
     * @return App
     */
    public function setPath($path)
    {
        $this->path = $path;

        return $this;
    }

    /**
     * Get path
     *
     * @return string
     */
    public function getPath()
    {
        return $this->path;
    }


    /**
     * Set icon
     *
     * @param string $icon
     *
     * @return App
     */
    public function setIcon($icon)
    {
        $this->icon = $icon;

        return $this;
    }

    /**
     * Get icon
     *
     * @return string
     */
    public function getIcon()
    {
        return $this->icon;
    }

    /**
     * Add privilege
     *
     * @param \ApiBundle\Entity\Privilege $privilege
     *
     * @return App
     */
    public function addPrivilege(\ApiBundle\Entity\Privilege $privilege)
    {
        $this->privileges[] = $privilege;

        return $this;
    }

    /**
     * Remove privilege
     *
     * @param \ApiBundle\Entity\Privilege $privilege
     */
    public function removePrivilege(\ApiBundle\Entity\Privilege $privilege)
    {
        $this->privileges->removeElement($privilege);
    }

    /**
     * Get privilege
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPrivileges()
    {
        return $this->privileges;
    }

}
