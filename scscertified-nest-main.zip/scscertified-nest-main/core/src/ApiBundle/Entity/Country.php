<?php 

namespace ApiBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Country (individual application on the intranet)
 *
 * {@inheritdoc}
 * @ORM\Table(
 *     name="Country",
 *     indexes={
 *         @ORM\Index(name="isoCode", columns={"isoCode"})
 *     }
 * )
 * @ORM\Entity
 *
 * @ExclusionPolicy("all")
 */
class Country {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;
    
    /**
     * @var boolean
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var string
     *
     * @ORM\Column(name="isoCode", type="string", length=32, nullable=false)
     *
     * @Assert\NotBlank()
     * @Assert\Country()
     * # requires ISO-3166 alpha-2 code
     * # https://symfony.com/doc/3.4/reference/constraints/Country.html
     *
     * @Expose
     */
    private $isoCode;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $name;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="State", mappedBy="country")
     * @ORM\JoinColumn(name="id", referencedColumnName="country_id")
     * #ORM\JoinColumn(name="isoCode", referencedColumnName="countryCode")
     *
     * #Expose
     */
    private $states;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Address", mappedBy="country")
     * @ORM\JoinColumn(name="id", referencedColumnName="country_id")
     * #ORM\JoinColumn(name="isoCode", referencedColumnName="countryCode")
     *
     * #Expose
     */
    private $addresses;
    
    
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->states    = new ArrayCollection();
        $this->addresses = new ArrayCollection();
    }
    
    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        return $this->name;
    }
    
    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set active
     *
     * @param string $active
     *
     * @return Country
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return string 
     */
    public function getActive()
    {
        return $this->active;
    }
    
    /**
     * Set name
     *
     * @param string $name
     *
     * @return Country
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }


    /**
     * Set isoCode
     *
     * @param string $isoCode
     *
     * @return Country
     */
    public function setIsoCode($isoCode)
    {
        $this->isoCode = $isoCode;

        return $this;
    }

    /**
     * Get isoCode
     *
     * @return integer
     */
    public function getIsoCode()
    {
        return $this->isoCode;
    }
    
    /**
     * Add state
     *
     * @param \ApiBundle\Entity\State $state
     *
     * @return Country
     */
    public function addState(\ApiBundle\Entity\State $state)
    {
        $this->states[] = $state;

        return $this;
    }

    /**
     * Remove state
     *
     * @param \ApiBundle\Entity\State $state
     */
    public function removeState(\ApiBundle\Entity\State $state)
    {
        $this->states->removeElement($state);
    }

    /**
     * Get states
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getStates()
    {
        return $this->states;
    }
    
    /**
     * Add address
     *
     * @param \ApiBundle\Entity\Address $address
     *
     * @return Country
     */
    public function addAddress(\ApiBundle\Entity\Address $address)
    {
        $this->addresss[] = $address;

        return $this;
    }

    /**
     * Remove address
     *
     * @param \ApiBundle\Entity\Address $address
     */
    public function removeAddress(\ApiBundle\Entity\Address $address)
    {
        $this->addresss->removeElement($address);
    }

    /**
     * Get addresses
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAddresses()
    {
        return $this->addresses;
    }

}

?>