<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;

/**
* Address
*
* TODO: add validation that either Person or Org is attached (and exists)?
*
* {@inheritdoc}
* @ORM\Table(name="Address")
* @ORM\Entity
*
* @ExclusionPolicy("all")
*/
class Address {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var string
     *
     * @ORM\Column(name="address", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $address;

    /**
     * @var string
     *
     * @ORM\Column(name="city", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $city;

    /**
     * @var string
     *
     * @ORM\Column(name="postal_code", type="string", length=64, nullable=true)
     *
     * @Assert\Length(max = 64)
     *
     * @Expose
     */
    private $postalCode;


    /**
     * @var string
     *
     * @ORM\Column(name="stateIsoCode", type="string", length=32, nullable=true)
     *
     * @Assert\Length(max = 32)
     *
     * @Expose
     */
    private $stateIsoCode;

    /**
     * @var string
     *
     * @ORM\Column(name="stateRaw", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $stateRaw;

    /**
     * @var string
     *
     * @ORM\Column(name="countryIsoCode", type="string", length=32, nullable=true)
     *
     * @Assert\Length(max = 32)
     * @Assert\Country()
     * # requires ISO-3166 alpha-2 code
     * # https://symfony.com/doc/3.4/reference/constraints/Country.html
     *
     * @Expose
     */
    private $countryIsoCode;

    /**
     * @var string
     *
     * @ORM\Column(name="countryRaw", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $countryRaw;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_primary", type="boolean", nullable=true)
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $isPrimary;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=128, nullable=true)
     *
     * @Assert\Length(max = 128)
     *
     * @Expose
     */
    private $type;

    /**
     * @var array
     *
     * Selection list (no ORM)
     *
     * #Expose
     */
    private $types;

    /**
     * @var string
     *
     * @ORM\Column(name="dms_id", type="string", length=64, nullable=true)
     *
     * @Assert\Length(max = 64)
     *
     * @Expose
     */
    private $dmsId;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="country_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $countryId;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="state_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $stateId;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="org_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $orgId;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="person_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $personId;

    /**
     * @var \ApiBundle\Entity\Country
     *
     * @ORM\ManyToOne(targetEntity="Country", inversedBy="addresses")
     *
     * @Expose
     */
    private $country;

    /**
     * @var \ApiBundle\Entity\State
     *
     * @ORM\ManyToOne(targetEntity="State", inversedBy="addresses")
     *
     * @Expose
     */
    private $state;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=true, options={"default": "CURRENT_TIMESTAMP"})
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=true, columnDefinition="DATETIME on update CURRENT_TIMESTAMP")
     */
    private $modified;

    /**
     * @var \ApiBundle\Entity\Country
     *
     * @ORM\ManyToOne(targetEntity="Org", inversedBy="addresses")
     *
     * #Expose
     */
    private $org;

    /**
     * @var \ApiBundle\Entity\Person
     *
     * @ORM\ManyToOne(targetEntity="Person", inversedBy="addresses")
     *
     * #Expose
     */
    private $person;
    
    /**
     * Supports __toString()
     *
     * @var string
     *
     * @Expose
     */
    private $name;



    /**
     * Constructor
     */
    public function __construct()
    {
        //$this->types = array('main','billing','shipping'); // for now, a reminder we want to require types to be members of this array
        $this->setName();
    }



    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        $this->setName();
        
        return $this->getName(); // supports a useful return when listed as a related entity in EasyAdmin
    }
    
    /**
     * Set 'name'
     *
     * @return Address
     */
    public function setName()
    {
        // set just the most local data, since completeness can vary
        $this->name = ($this->address ? $this->address :
                      ($this->city ? $this->city :
                      ($this->state ? $this->state :
                      ($this->postalCode ? $this->postalCode :
                      ($this->country ? $this->country :
                      ($this->id ? $this->id :
                      '(no data in record)'
                      ))))));

        return $this;
    }

    /**
     * Get 'name'
     *
     * @return string
     */
    public function getName()
    {
        return "$this->name";
    }

    public function getId()
    {
        return $this->id;
    }

    /**
     * Set address
     *
     * @param string $address
     *
     * @return Address
     */
    public function setAddress($address)
    {
        $this->address = $address;

        return $this;
    }

    /**
     * Get address
     *
     * @return string
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set city
     *
     * @param string $city
     *
     * @return Address
     */
    public function setCity($city)
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get city
     *
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set postalCode
     *
     * @param string $postalCode
     *
     * @return Address
     */
    public function setPostalCode($postalCode)
    {
        $this->postalCode = $postalCode;

        return $this;
    }

    /**
     * Get postalCode
     *
     * @return string
     */
    public function getPostalCode()
    {
        return $this->postalCode;
    }

    /**
     * Set isPrimary
     *
     * @param string $isPrimary
     *
     * @return Address
     */
    public function setIsPrimary($isPrimary)
    {
        $this->isPrimary = $isPrimary;

        return $this;
    }

    /**
     * Get isPrimary
     *
     * @return string
     */
    public function getIsPrimary()
    {
        return $this->isPrimary;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return Address
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set dmsId
     *
     * @param string $DmsId
     *
     * @return Address
     */
    public function setDmsId($DmsId)
    {
        $this->dmsId = $DmsId;

        return $this;
    }

    /**
     * Get dmsId
     *
     * @return string
     */
    public function getDmsId()
    {
        return $this->dmsId;
    }

    /**
     * Set stateIsoCode
     *
     * @param string $stateIsoCode
     *
     * @return Address
     */
    public function setStateIsoCode($stateIsoCode)
    {
        $this->stateIsoCode = $stateIsoCode;

        return $this;
    }

    /**
     * Set active
     *
     * @param string $active
     *
     * @return Address
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Get stateIsoCode
     *
     * @return string
     */
    public function getStateIsoCode()
    {
        return $this->stateIsoCode;
    }

    /**
     * Set state
     *
     * @param \ApiBundle\Entity\State $state
     *
     * @return Address
     */
    public function setState(\ApiBundle\Entity\State $state = null)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return \ApiBundle\Entity\State
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set countryIsoCode
     *
     * @param string $countryIsoCode
     *
     * @return Address
     */
    public function setCountryIsoCode($countryIsoCode)
    {
        $this->countryIsoCode = $countryIsoCode;

        return $this;
    }

    /**
     * Get countryIsoCode
     *
     * @return string
     */
    public function getCountryIsoCode()
    {
        return $this->countryIsoCode;
    }

    /**
     * Set country
     *
     * @param \ApiBundle\Entity\Country $country
     *
     * @return Address
     */
    public function setCountry(\ApiBundle\Entity\Country $country = null)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return \ApiBundle\Entity\Country
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Get created date
     *
     * @return boolean
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Get modified date
     *
     * @return boolean
     */
    public function getModified()
    {
        return $this->modified;
    }

    /**
     * Set org
     *
     * @param \ApiBundle\Entity\Org $org
     *
     * @return Address
     */
    public function setOrg(\ApiBundle\Entity\Org $org = null)
    {
        $this->org = $org;

        return $this;
    }

    /**
     * Get org
     *
     * @return \ApiBundle\Entity\Org
     */
    public function getOrg()
    {
        return $this->org;
    }

    /**
     * Set person
     *
     * @param \ApiBundle\Entity\Person $person
     *
     * @return Address
     */
    public function setPerson(\ApiBundle\Entity\Person $person = null)
    {
        $this->person = $person;

        return $this;
    }

    /**
     * Get person
     *
     * @return \ApiBundle\Entity\Person
     */
    public function getPerson()
    {
        return $this->person;
    }


    /**
     * Set stateRaw
     *
     * @param string $stateRaw
     *
     * @return Address
     */
    public function setStateRaw($stateRaw)
    {
        $this->stateRaw = $stateRaw;

        return $this;
    }

    /**
     * Get stateRaw
     *
     * @return string
     */
    public function getStateRaw()
    {
        return $this->stateRaw;
    }

    /**
     * Set countryRaw
     *
     * @param string $countryRaw
     *
     * @return Address
     */
    public function setCountryRaw($countryRaw)
    {
        $this->countryRaw = $countryRaw;

        return $this;
    }

    /**
     * Get countryRaw
     *
     * @return string
     */
    public function getCountryRaw()
    {
        return $this->countryRaw;
    }
}
