<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Role
 *
 * @ORM\Table(name="Role")
 * @ORM\Entity
 *
 * @ExclusionPolicy("all")
 */
class Role
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;

    /**
     * @var boolean
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=128, nullable=false)
     *
     * @Assert\Length(max = 128)
     *
     * @Expose
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $description;


    /**
     * @var \ApiBundle\Entity\Role
     * 
     * @ORM\ManyToOne(targetEntity="Role", inversedBy="children")
     * @ORM\JoinColumn(name="parent", referencedColumnName="id")
     *
     * @Expose
     */
    private $parent;

    /**
     * @var \ApiBundle\Entity\Privilegerole
     *
     * @ORM\OneToMany(targetEntity="Privilegerole", mappedBy="role")
     *  ORM\OrderBy({"unit" = "ASC", "privilege" = "ASC"})
     *
     * #Expose
     */
    private $privilegeroles;
    
    /**
     * @var \ApiBundle\Entity\Assignedrole
     *
     * @ORM\OneToMany(targetEntity="Assignedrole", mappedBy="role")
     *  ORM\OrderBy({"unit" = "ASC", "person" = "ASC"})
     *
     * #Expose
     */
    private $assignedroles;


    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->privilegeroles = new ArrayCollection();
        $this->assignedroles = new ArrayCollection();
    }
    
    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        return $this->name; // supports a useful return when listed as a related entity in EasyAdmin
    }
    
    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }
    
    /**
     * Set active
     *
     * @param string $active
     *
     * @return Role
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return string 
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Role
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Role
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add privilegerole
     *
     * @param \ApiBundle\Entity\Privilegerole $privilegerole
     *
     * @return Role
     */
    public function addPrivilegerole(\ApiBundle\Entity\Privilegerole $privilegerole)
    {
        $this->privilegeroles[] = $privilegerole;

        return $this;
    }

    /**
     * Remove privilegerole
     *
     * @param \ApiBundle\Entity\Privilegerole $privilegerole
     */
    public function removePrivilegerole(\ApiBundle\Entity\Privilegerole $privilegerole)
    {
        $this->privilegeroles->removeElement($privilegerole);
    }
    
    /**
     * Get privilegeroles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPrivilegeroles()
    {
        return $this->privilegeroles;
    }
    
    /**
     * Get assignedroles
     *
     * Note: providing getter only, since links should be managed from the Person or Org side
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAssignedroles()
    {
        return $this->assignedroles;
    }

    /**
     * Set Parent Role
     *
     * @return \ApiBundle\Entity\Role
     */
    public function setParent($parent)
    {
        $this->parent = $parent;
        return $this;
        
    }

    /**
     * Get Parent Role
     *
     * @return \ApiBundle\Entity\Role
     */
    public function getParent()
    {
        return $this->parent;
    }

}
