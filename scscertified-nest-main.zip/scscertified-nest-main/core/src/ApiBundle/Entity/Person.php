<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use JMS\Serializer\Annotation\VirtualProperty;
use JMS\Serializer\Annotation\PreSerialize;
use JMS\Serializer\Annotation\PostSerialize;;
use JMS\Serializer\Annotation\PostDeserialize;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;
use Misd\PhoneNumberBundle\Validator\Constraints\PhoneNumber as AssertPhoneNumber;

//use FOS\RestBundle\Controller\FOSRestController; // to allow $this->forward()
use Symfony\Bundle\FrameworkBundle\Controller\Controller; // to allow $this->forward()

/**
 * Person
 *
 * @ORM\Table(name="Person")
 * @ORM\Entity(repositoryClass="ApiBundle\Repository\PersonRepository")
 *
 * @ORM\HasLifecycleCallbacks
 *
 * @ExclusionPolicy("all")
 */
class Person
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;
    
    /**
     * @var string
     *
     * @ORM\Column(name="salesforce_id", type="string", nullable=true)
     *
     * @Expose
     */
    private $salesforceId;

    /**
     * @var integer
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var string
     *
     * @ORM\Column(name="nameHonorific", type="string", length=64, nullable=true)
     *
     * @Assert\Length(max = 64)
     *
     * @Expose
     */
    private $nameHonorific;

    /**
     * @var string
     *
     * @ORM\Column(name="nameFirst", type="string", length=255, nullable=false)
     *
     * @Assert\NotBlank()
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $nameFirst;

    /**
     * @var string
     *
     * @ORM\Column(name="nameMiddle", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $nameMiddle;

    /**
     * @var string
     *
     * @ORM\Column(name="nameLast", type="string", length=255, nullable=false)
     *
     * @Assert\NotBlank()
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $nameLast;
    
    /**
     * @var string
     * #ORM\Column(name="name", columnDefinition="VARCHAR(255) AS (CONCAT(nameFirst, ' ', nameLast))")
     *
     * #Expose
     */
    private $name;
    //public $name;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="email1", type="string", length=255, nullable=false)
     *
     * @Assert\NotBlank()
     * @Assert\Email(
     *     message = "'{{ value }}' is not a valid email.",
     *     checkHost = true
     * )
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $email1;

    /**
     * @var string
     *
     * @ORM\Column(name="phone", type="string", length=30, nullable=true)
     *
     * @AssertPhoneNumber(defaultRegion="US")
     * @Assert\Length(max = 30)
     *
     * @Expose
     */
    private $phone;

    /**
     * @var string
     *
     * @ORM\Column(name="phoneRaw", type="string", length=128, nullable=true)
     *
     * @Assert\Length(max = 128)
     *
     * @Expose
     */
    private $phoneRaw;

    /**
     * @var string
     *
     * @ORM\Column(name="phoneCell", type="string", length=30, nullable=true)
     *
     * @AssertPhoneNumber(defaultRegion="US")
     * @Assert\Length(max = 30)
     *
     * @Expose
     */
    private $phoneCell;

    /**
     * @var string
     *
     * @ORM\Column(name="phoneCellRaw", type="string", length=128, nullable=true)
     *
     * @Assert\Length(max = 128)
     *
     * @Expose
     */
    private $phoneCellRaw;

    /**
     * @var string
     *
     * @ORM\Column(name="imageFile", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $imageFile;

    /**
     * Support extension of FOSUserBundle /register process
     *
     * @var \Date
     *
     * @ORM\Column(name="start_date", type="date", nullable=true)
     *
     * @Assert\Date()
     *
     * @Expose
     */
    private $startDate;

    /**
     * Support extension of FOSUserBundle /register process
     *
     * @var \Date
     *
     * @ORM\Column(name="end_date", type="date", nullable=true)
     *
     * @Assert\GreaterThanOrEqual(
     *     "today",
     *     message = "End Date should not be in the past."
     * )
     * @Assert\Date()
     *
     * @Expose
     */
    private $endDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="ars_coc_team_id", type="integer", nullable=true)
     *
     * @Expose
     */
    private $arsCocTeamId;

    /**
     * @var string
     *
     * @ORM\Column(name="dms_id", type="string", length=64, nullable=true)
     *
     * @Assert\Length(max = 64)
     *
     * @Expose
     */
    private $dmsId;

    /**
     * @var integer
     *
     * @ORM\Column(name="scs_user_id", type="integer", nullable=true)
     *
     * @Expose
     */
    private $scsUserId;

    /**
     * Support extension of FOSUserBundle /register process
     *
     * @var string
     *
     * @ORM\Column(name="register_token", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $registerToken;

    /**
     * Support extension of FOSUserBundle /register process
     *
     * @var \DateTime
     *
     * @ORM\Column(name="register_token_start_date", type="datetime", nullable=true)
     *
     * @Assert\DateTime()
     *
     * @Expose
     */
    private $registerTokenStartDate;

    /**
     * Support extension of FOSUserBundle /register process
     *
     * @var integer
     *
     * @ORM\Column(name="register_token_duration", type="integer", nullable=true, options={"unsigned":true, "default":0})
     *
     * @Assert\GreaterThanOrEqual(0)
     *
     * @Expose
     */
    private $registerTokenDuration;

    /**
     * @var integer
     *
     * @ORM\Column(name="register_status", type="smallint", nullable=true, options={"default":0})
     *
     * @Expose
     */
    private $registerStatus;

    /**
     * @var integer
     *
     * @ORM\Column(name="user_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $userId;

    /**
     * @var integer
     *
     * @ORM\Column(name="org_id", type="integer", nullable=false)
     *
     * #Expose
     */
    private $orgId;

    /**
     * @var integer
     *
     * @ORM\Column(name="manager_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $managerId;

    /**
     * @var integer
     *
     * @ORM\Column(name="isManager", type="boolean", nullable=true)
     *
     * @Expose
     */
    private $isManager;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=true, options={"default": "CURRENT_TIMESTAMP"})
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=true, columnDefinition="DATETIME on update CURRENT_TIMESTAMP")
     */
    private $modified;

    /**
     * @var \ApiBundle\Entity\User
     *
     * @ORM\OneToOne(targetEntity="User")
     *
     * @Expose
     */
    private $user;

    /**
     * @var \ApiBundle\Entity\Org
     *
     * @ORM\ManyToOne(targetEntity="Org", inversedBy="persons", fetch="EAGER")
     *
     * @Assert\NotBlank()
     *
     * @Expose
     */
    private $org;

    /**
     * @var \ApiBundle\Entity\Person
     *
     * @ORM\ManyToOne(targetEntity="ApiBundle\Entity\Person", inversedBy="team")
     * @ORM\JoinColumn(name="manager_id", referencedColumnName="id", nullable=true)
     *
     * @Expose
     */
    private $manager;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="ApiBundle\Entity\Person", mappedBy="manager")
     *
     * #Expose
     */
    private $team;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Address", mappedBy="person", fetch="EAGER")
     *
     * @Expose
     */
    private $addresses;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Assignedrole", mappedBy="person", fetch="EAGER")
     *
     * (Assertion disabled but left as an example, for now)
     * #Assert\Count(
     *     min = 1,
     *     minMessage = "At least one permission should be assigned."
     * )
     *
     * #Expose
     */
    private $assignedroles;

    /**
     * Experimental -- would rely on DQL, query to Repository code, VirtualProperty, or some other mechanism
     *
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * #ORM\OneToMany(targetEntity="Privilegerole", mappedBy="person")
     *
     * #Expose
     */
    //private $privilegeroles;

    /**
     * @var string
     *
     * #Expose
     */
    //private $entityName;



    /**
     * Constructor
     */
    public function __construct()
    {
        $this->addresses      = new ArrayCollection();
        $this->assignedroles  = new ArrayCollection();
        $this->team           = new ArrayCollection();
        //$this->privilegeroles = new ArrayCollection();

        // to support dynamic form field population in ApiType.php
        //$this->entityName = basename(__CLASS__); // can we rely on __toString() instead?

        //$this->name = $this->getName(); // calculated result
    }

    /**
     * Validation callback
     *
     * @Assert\Callback
     */
    public function validate(ExecutionContextInterface $context, $payload)
    {
        // useful for more comlex logic
    }

    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        return $this->getName(); // supports a useful return when listed as a related entity in EasyAdmin
        //return $this->name;
    }

   /**
     * Get full Name
     *
     * @VirtualProperty()
     * @Expose
     *
     * @return string
     */
    public function getName()
    {
        $this->setName();
        
        return $this->name;
    }

   /**
     * Set full Name
     *
     * #PreSerialize()
     * #PostSerialize()
     * #PostDeserialize()
     *
     * #ORM\PostLoad
     *
     * @return Person
     */
    //public function SetName($name = '')
    public function SetName()
    {
        $this->name = $this->nameFirst . ' ' . $this->nameLast;

        return $this;
    }
    
    /**
     *
     * @ORM\PrePersist
     */
    public function removeName()
    {
        //$this->name = `DEFAULT`;
        unset($this->name);
        
        return $this;
    }
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
    
    /**
     * Set salesforceId
     *
     * @param boolean $salesforceId
     *
     * @return Unit
     */
    public function setSalesforceId($salesforceId)
    {
        $this->salesforceId = $salesforceId;

        return $this;
    }

    /**
     * Get salesforceId
     *
     * @return boolean
     */
    public function getSalesforceId()
    {
        return $this->salesforceId;
    }

    /**
     * Set active
     *
     * @param string $active
     *
     * @return Person
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set nameHonorific
     *
     * @param string $nameHonorific
     * @return Person
     */
    public function setNameHonorific($nameHonorific)
    {
        $this->nameHonorific = $nameHonorific;

        return $this;
    }

    /**
     * Get nameHonorific
     *
     * @return string
     */
    public function getNameHonorific()
    {
        return $this->nameHonorific;
    }

    /**
     * Get nameFirst
     *
     * @return string
     */
    public function getNameFirst()
    {
        return $this->nameFirst;
    }

    /**
     * Set nameFirst
     *
     * @param string $nameFirst
     * @return Person
     */
    public function setNameFirst($nameFirst)
    {
        $this->nameFirst = $nameFirst;

        return $this;
    }

    /**
     * Get nameMiddle
     *
     * @return string
     */
    public function getNameMiddle()
    {
        return $this->nameMiddle;
    }


    /**
     * Set nameMiddle
     *
     * @param string $nameMiddle
     * @return Person
     */
    public function setNameMiddle($nameMiddle)
    {
        $this->nameMiddle = $nameMiddle;

        return $this;
    }

   /**
     * Get nameLast
     *
     * @return string
     */
    public function getNameLast()
    {
        return $this->nameLast;
    }

    /**
     * Set nameLast
     *
     * @param string $nameLast
     * @return Person
     */
    public function setNameLast($nameLast)
    {
        $this->nameLast = $nameLast;

        return $this;
    }

//
//
//

    /**
     * Set title
     *
     * @param string $title
     * @return Person
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set email1
     *
     * @param string $email1
     * @return Person
     */
    public function setEmail1($email1)
    {
        $this->email1 = $email1;

        return $this;
    }

    /**
     * Get email1
     *
     * @return string
     */
    public function getEmail1()
    {
        return $this->email1;
    }

    /**
     * Set phone
     *
     * @param string $phone
     * @return Person
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set phoneCell
     *
     * @param string $phoneCell
     * @return Person
     */
    public function setPhoneCell($phoneCell)
    {
        $this->phoneCell = $phoneCell;

        return $this;
    }

    /**
     * Get phone cell
     *
     * @return string
     */
    public function getPhoneCell()
    {
        return $this->phoneCell;
    }

    /**
     * Set imageFile
     *
     * @param string $imageFile
     * @return Person
     */
    public function setImageFile($imageFile)
    {
        $this->imageFile = $imageFile;

        return $this;
    }

    /**
     * Get imageFile
     *
     * @return string
     */
    public function getImageFile()
    {
        return $this->imageFile;
    }

    /**
     * Set scsUserId
     *
     * @param string $scsUserId
     *
     * @return Person
     */
    public function setScsUserId($scsUserId)
    {
        $this->scsUserId = $scsUserId;

        return $this;
    }

    /**
     * Get scsUserId
     *
     * @return string
     */
    public function getScsUserId()
    {
        return $this->scsUserId;
    }

    /**
     * Set dmsId
     *
     * @param string $dmsId
     *
     * @return Person
     */
    public function setDmsId($dmsId)
    {
        $this->dmsId = $dmsId;

        return $this;
    }

    /**
     * Get dmsId
     *
     * @return string
     */
    public function getDmsId()
    {
        return $this->dmsId;
    }

    /**
     * Set arsCocTeamId
     *
     * @param string $arsCocTeamId
     *
     * @return Person
     */
    public function setArsCocTeamId($arsCocTeamId)
    {
        $this->arsCocTeamId = $arsCocTeamId;

        return $this;
    }

    /**
     * Get arsCocTeamId
     *
     * @return string
     */
    public function getArsCocTeamId()
    {
        return $this->arsCocTeamId;
    }

    /**
     * Set registerStatus
     *
     * @param string $registerStatus
     *
     * @return Person
     */
    public function setRegisterStatus($registerStatus)
    {
        $this->registerStatus = $registerStatus;

        return $this;
    }

    /**
     * Get registerStatus
     *
     * @return boolean
     */
    public function getRegisterStatus()
    {
        return $this->registerStatus;
    }

    /**
     * Set registerToken
     *
     * @param string $registerToken
     *
     * @return Person
     */
    public function setRegisterToken($registerToken)
    {
        $this->registerToken = $registerToken;

        return $this;
    }

    /**
     * Get registerToken
     *
     * @return boolean
     */
    public function getRegisterToken()
    {
        return $this->registerToken;
    }

    /**
     * Set registerTokenStartDate
     *
     * @param string $registerTokenStartDate
     *
     * @return Person
     */
    public function setRegisterTokenStartDate($registerTokenStartDate)
    {
        $this->registerTokenStartDate = $registerTokenStartDate;

        return $this;
    }

    /**
     * Get registerTokenStartDate
     *
     * @return boolean
     */
    public function getRegisterTokenStartDate()
    {
        return $this->registerTokenStartDate;
    }

    /**
     * Set registerTokenDuration
     *
     * @param integer $registerTokenDuration
     *
     * @return Person
     */
    public function setRegisterTokenDuration($registerTokenDuration)
    {
        $this->registerTokenDuration = $registerTokenDuration;

        return $this;
    }

    /**
     * Get registerTokenDuration
     *
     * @return boolean
     */
    public function getRegisterTokenDuration()
    {
        return $this->registerTokenDuration;
    }

    /**
     * Set startDate
     *
     * @param string $startDate
     *
     * @return Person
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return string
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set endDate
     *
     * @param string $endDate
     *
     * @return Person
     */
    public function setEndDate($endDate)
    {
        $this->endDate = $endDate;

        return $this;
    }

    /**
     * Get endDate
     *
     * @return string
     */
    public function getEndDate()
    {
        return $this->endDate;
    }

    /*** BEGIN Object getters & setters, as well as more complex functions ***/

    /**
     * Set org
     *
     * @param \ApiBundle\Entity\Org $org
     *
     * @return Person
     */
    public function setOrg(\ApiBundle\Entity\Org $org = null)
    {
        $this->org = $org;

        return $this;
    }

    /**
     * Get org
     *
     * @return \ApiBundle\Entity\Org
     */
    public function getOrg()
    {
        return $this->org;
    }

    /**
     * Set user
     *
     * @param \ApiBundle\Entity\User $user
     *
     * @return Person
     */
    public function setUser(\ApiBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \ApiBundle\Entity\User
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set isManager
     *
     * @param string $isManager
     *
     * @return Person
     */
    public function setIsManager($isManager)
    {
        $this->isManager = $isManager;

        return $this;
    }

    /**
     * Get isManager
     *
     * @return boolean
     */
    public function getIsManager()
    {
        return $this->isManager;
    }

    /**
     * Get manager
     *
     * @return \ApiBundle\Entity\Person
     */
    public function getManager()
    {
        return $this->manager;
    }

    /**
     * Get manager
     *
     * @return \ApiBundle\Entity\Person
     */
    public function setManager($person)
    {
        $this->manager = $person;
        return $this;
    }

    /**
     * Get created date
     *
     * @return boolean
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Get modified date
     *
     * @return boolean
     */
    public function getModified()
    {
        return $this->modified;
    }

    /**
     * Add team
     *
     * @param \ApiBundle\Entity\Person $person
     * @return Person
     */
    public function addTeamMember(\ApiBundle\Entity\Person $person)
    {
        $this->team[] = $person;
        return $this;
    }

    /**
     * Remove team
     *
     * @param \ApiBundle\Entity\Person $person
     */
    public function removeTeamMember(\ApiBundle\Entity\Person $person)
    {
        $this->team->removeElement($person);
        return $this;
    }

    /**
     * Get team
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTeam()
    {
        return $this->team;
    }

    /**
     * Add address
     *
     * @param \ApiBundle\Entity\Address $address
     *
     * @return Org
     */
    public function addAddress(\ApiBundle\Entity\Address $address)
    {
        $this->addresses[] = $address;

        return $this;
    }

    /**
     * Remove address
     *
     * @param \ApiBundle\Entity\Address $address
     */
    public function removeAddress(\ApiBundle\Entity\Address $address)
    {
        $this->addresses->removeElement($address);
    }

    /**
     * Get address
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAddresses()
    {
        return $this->addresses;
    }

    /**
     * Data Structure Files for October Model
     * Add assignedrole
     *
     * @param \ApiBundle\Entity\Assignedrole $assignedrole
     *
     * @return Person
     */
    public function addAssignedrole(\ApiBundle\Entity\Assignedrole $assignedrole)
    {
        $this->assignedroles[] = $assignedrole;

        return $this;
    }

    /**
     * Remove assignedrole
     *
     * @param \ApiBundle\Entity\Assignedrole $assignedrole
     */
    public function removeAssignedrole(\ApiBundle\Entity\Assignedrole $assignedrole)
    {
        $this->assignedroles->removeElement($assignedrole);
    }

    /**
     * Get assignedroles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAssignedroles($use_dql = FALSE)
    {
        /*
        // Doesn't seem possible to call a controller within an entity -- none of the below worked.
        if ($use_dql) {
            $id = $this->getId();
            $controller = new \Symfony\Bundle\FrameworkBundle\Controller\Controller;
            $assignedroles = $controller->forward('ApiBundle:Api:getEntityBy', array(
                'name'    => 'person',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2","dql_flat_result":"1","dql_include_entities":["assignedroles"]}',
            ));
        }
        else {
            $assignedroles = $this->assignedroles;
        }
        */

        $assignedroles = $this->assignedroles;

        return $assignedroles;
    }

    /*** further reaching relationships and evaluations; are these in use? are they working? are they optimized?  ***/

    /**
     * Get assignedroles from parent and ancestor orgs
     *
     * #return \Doctrine\Common\Collections\Collection
     * @return array
     */
    public function getOrgAncestors()
    {
        //KD 12/08/17 - Does this need to be here, since we can call the org function if we need this
        //VR 5/23/18  - Agreed, seems not a useful function, esp. since not used internally to this class
        $ancestors = null;
        if (!empty($this->org)) {
            $ancestors = $this->org->getAncestors();
        }

        return $ancestors;
    }

    /**
     * Get assignedroles from parent and ancestor orgs
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAssignedrolesOrg()
    {
        $assignedroles = null;
        if (!empty($this->org)) {
            $assignedroles = $this->org->getAssignedroles();
        }
        return $assignedroles;
    }

    /**
     * Get assignedroles from parent and ancestor orgs, and from direct assignedroles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAssignedrolesAll()
    {
        $assignedrolesSelf = [];
        if (count($this->getAssignedRoles())) {
            $assignedrolesSelf = $this->getAssignedRoles()->toArray();
        }

        $assignedrolesOrg = [];
        if (count($this->getAssignedRolesOrg())) {
            $assignedrolesOrg = $this->getAssignedRolesOrg()->toArray();
        }

        $results = new ArrayCollection(
                       array_merge(
                           $assignedrolesSelf,
                           $assignedrolesOrg
                       )
                   );
        return $results;
    }

    /**
     * *Was* used in AuthenticationSuccessListener (ASL), because controller methods are not accessible
     *     but ASL now uses getPrivileges(), so this could be converted back to Controller method,
     *     except getPrivileges() depends on this method
     *
     * Get privilegedroles from parent and ancestor orgs, and from direct assignedroles
     *
     * #return \Doctrine\Common\Collections\Collection
     * #return array
     * @return string
     */
    public function getPrivilegerolesAll()
    {

        $privilegeroles = ['Deprecated -- no useable entity relationships to span necessary objects/tables'];

        $assignedroles = $this->assignedroles;

        foreach ($assignedroles as $assignedrole) {

            $privilegeroles_ar = 'Can\'t get controller in entity (no Doctrine to get Repository)';

        }


        /*
        // can't (easily) get Doctrine in Entity context....
        $privilegeroles = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->findPrivilegeroles($this->getId());
        */

        /*
        // Doesn't yet consider Units or their ancestors
        // Nor permissions through person's Org, if any
        $privilegeroles = [];
        $assignedroles = $this->getAssignedrolesAll();

        foreach ($assignedroles as $assignedrole) {

            $privilegerole_set = $assignedrole->getRole()->getPrivilegeroles();

            foreach ($privilegerole_set as $privilegerole) {
                $privilegeroles[$privilegerole->getId()] = $privilegerole;
            }

        }
        */

        return $privilegeroles;
    }

    /**
     * For use in AuthenticationSuccessListener, because controller methods are not accessible there
     *
     * Get privileges from role & unit pathways
     *
     * #return \Doctrine\Common\Collections\Collection
     * @return array
     */
    public function getPrivileges()
    {
        $privileges = array(array('Under construction' => 'From Roles only, so far'));
        $privilegeroles = $this->getPrivilegerolesAll();

        foreach ($privilegeroles as $privilegerole) {
          if (is_object($privilegerole)) {
            $appkey = $privilegerole->getPrivilege()->getApp()->getAppkey();
            if(isset($privileges[$appkey])) {
              $privileges[$appkey] += array($privilegerole->getPrivilege()->getId() => $privilegerole->getPrivilege()->getName());
            } else {
              $privileges[$appkey] = array($privilegerole->getPrivilege()->getId() => $privilegerole->getPrivilege()->getName());
            }
          } else {
            $privileges['no-appkey'] = array(0 => 'no-privilegerole');
          }
        }

        return $privileges;
    }

    /**
     * Get self for occasions when proxy objects get in the way (AuthenticationSuccessListener.php)
     *
     * @return \ApiBundle\Entity\Person
     */
    public function getSelf()
    {
        $proxy = get_object_vars($this);
        //$proxy = json_decode(json_encode($this));
        //$proxy['assignedroles'] = $this->getAssignedroles();

        return $proxy;
    }


    /**
     * Set phoneRaw
     *
     * @param string $phoneRaw
     *
     * @return Person
     */
    public function setPhoneRaw($phoneRaw)
    {
        $this->phoneRaw = $phoneRaw;

        return $this;
    }

    /**
     * Get phoneRaw
     *
     * @return string
     */
    public function getPhoneRaw()
    {
        return $this->phoneRaw;
    }

    /**
     * Set phoneCellRaw
     *
     * @param string $phoneCellRaw
     *
     * @return Person
     */
    public function setPhoneCellRaw($phoneCellRaw)
    {
        $this->phoneCellRaw = $phoneCellRaw;

        return $this;
    }

    /**
     * Get phoneCellRaw
     *
     * @return string
     */
    public function getPhoneCellRaw()
    {
        return $this->phoneCellRaw;
    }

    /**
     * Add team
     *
     * @param \ApiBundle\Entity\Person $team
     *
     * @return Person
     */
    public function addTeam(\ApiBundle\Entity\Person $team)
    {
        $this->team[] = $team;

        return $this;
    }

    /**
     * Remove team
     *
     * @param \ApiBundle\Entity\Person $team
     */
    public function removeTeam(\ApiBundle\Entity\Person $team)
    {
        $this->team->removeElement($team);
    }
}
