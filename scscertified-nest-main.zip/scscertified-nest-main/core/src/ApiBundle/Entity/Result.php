<?php

namespace ApiBundle\Entity;

use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use JMS\Serializer\Annotation\Type;

/**
 * Roletype
 *
 * No database mapping - class to support auto-documentation, given standard data return format
 *
 * @ExclusionPolicy("none")
 */
class Result
{
  
    /**
     * @Type("ApiBundle\Entity\User")
     *
     * @var bool|object
     */
    private $data;
    
    /**
     * @Type("integer")
     *
     * @var int
     */
    private $count;
    
    /**
     * @Type("integer")
     *
     * @var int
     */
    private $code;
    
    /**
     * @Type("string")
     *
     * @var mixed
     */
    private $message;
    
    /**
     * Set data
     *
     * @param string|array $data
     *
     * @return Result
     */
    public function setData($data)
    {
        $this->data = $data;

        return $this;
    }

    /**
     * Get data
     *
     * @return string|array|Collection 
     */
    public function getData()
    {
        return $this->data;
    }
    
}

