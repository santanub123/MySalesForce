<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;

// repositoryClass="ApiBundle\Repository\UnittypeRepository"

/**
 * UnitType
 *
 * @ORM\Table(name="Unittype")
 * @ORM\Entity
 *
 * @ExclusionPolicy("all")
 */
class Unittype
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     *
     * @Expose
     */
    private $id;

    /**
     * @var boolean
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $description;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\ManyToMany(targetEntity="ApiBundle\Entity\Unit", mappedBy="unittypes")
     *
     * #Expose
     */
    private $units;



    /**
     * Constructor
     */
    public function __construct()
    {
        $this->units = new ArrayCollection();
    }



    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        return $this->name; // supports a useful return when listed as a related entity in EasyAdmin
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set active
     *
     * @param boolean $active
     *
     * @return Unittype
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Unittype
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Unittype
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add unit role
     *
     * @param \ApiBundle\Entity\Unit $unit
     * @return Unittype
     */
    public function addUnit(\ApiBundle\Entity\Unit $unit)
    {
        $this->units[] = $unit;

        return $this;
    }

    /**
     * Remove unit role
     *
     * @param \ApiBundle\Entity\Unit $unit
     */
    public function removeUnit(\ApiBundle\Entity\Unit $unit)
    {
        $this->units->removeElement($unit);
    }

    /**
     * Get unit role
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUnits()
    {
        return $this->units;
    }
}
