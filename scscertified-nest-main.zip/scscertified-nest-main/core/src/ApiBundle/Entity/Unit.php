<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use JMS\Serializer\Annotation\VirtualProperty;
use JMS\Serializer\Annotation\PreSerialize;
use JMS\Serializer\Annotation\PostSerialize;
use JMS\Serializer\Annotation\PostDeserialize;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;
use Misd\PhoneNumberBundle\Validator\Constraints\PhoneNumber as AssertPhoneNumber;


/**
 * Unit
 *
 * @ORM\Table(name="Unit")
 * @ORM\Entity(repositoryClass="ApiBundle\Repository\UnitRepository")
 *
 * @ExclusionPolicy("all")
 */
class Unit
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     *
     * @Expose
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="salesforce_id", type="string", nullable=true)
     *
     * @Expose
     */
    private $salesforceId;

    /**
     * @var boolean
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var string
     *
     * @ORM\Column(name="dept_code", type="string", length=10, nullable=true)
     *
     * @Expose
     */
    private $deptCode;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=100, nullable=false)
     *
     * @Expose
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="shortname", type="string", length=20, nullable=false)
     *
     * @Expose
     */
    private $shortname;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     *
     * @Expose
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="qb_class_listid", type="string", length=40, nullable=true)
     *
     * @Expose
     */
    private $qbClassListid;

    /**
     * @var boolean
     *
     * @ORM\Column(name="use_parent_dept", type="boolean", options={"default"=0})
     *
     * @Expose
     */
    private $useParentDept = false;

    /**
     * @var integer
     *
     * @ORM\Column(name="parent_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $parentId;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Unittype", inversedBy="units")
     *
     * @Expose
     */
    private $unittypes;

    /**
     * @var \ApiBundle\Entity\Unit
     *
     * @ORM\ManyToOne(targetEntity="Unit", inversedBy="children")
     *
     * @Expose
     */
    private $parent;

    /**
     * @var \ApiBundle\Entity\Unit
     *
     * @ORM\OneToMany(targetEntity="Unit", mappedBy="parent")
     * @ORM\OrderBy({"name" = "ASC"})
     *
     * #Expose
     */
    private $children;

    /**
     * Many Units have Many Units.
     * @ORM\ManyToMany(targetEntity="Unit", mappedBy="ancestors")
     *
     * #Expose
     */
    private $descendants;

    /**
     * Many Units have many Units.
     * @ORM\ManyToMany(targetEntity="Unit", inversedBy="descendants")
     * @ORM\JoinTable(name="Unittree",
     *      joinColumns={@ORM\JoinColumn(name="descendant_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="ancestor_id", referencedColumnName="id")}
     *      )
     *
     * #Expose
     */
    private $ancestors;

    /**
     * @var \ApiBundle\Entity\Unit
     *
     * @ORM\OneToMany(targetEntity="Privilegerole", mappedBy="unit")
     *  ORM\OrderBy({"role" = "ASC", "unit" = "ASC"})
     *
     * #Expose
     */
    private $privilegeroles;

    /**
     * @var \ApiBundle\Entity\Assignedrole
     *
     * @ORM\OneToMany(targetEntity="ApiBundle\Entity\Assignedrole", mappedBy="unit")
     *  ORM\OrderBy({"role" = "ASC", "unit" = "ASC"})
     *
     * #Expose
     */
    private $assignedroles;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->orgtypes      = new ArrayCollection();
        $this->children      = new ArrayCollection();
        $this->ancestors     = new ArrayCollection();
        $this->descendants   = new ArrayCollection();
        $this->persons       = new ArrayCollection();
        $this->assignedroles = new ArrayCollection();
    }




    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        return $this->name; // supports a useful return when listed as a related entity in EasyAdmin
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set salesforceId
     *
     * @param boolean $salesforceId
     *
     * @return Unit
     */
    public function setSalesforceId($salesforceId)
    {
        $this->salesforceId = $salesforceId;

        return $this;
    }

    /**
     * Get salesforceId
     *
     * @return boolean
     */
    public function getSalesforceId()
    {
        return $this->salesforceId;
    }

    /**
     * Set active
     *
     * @param boolean $active
     *
     * @return Unit
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set deptCode
     *
     * @param string $deptCode
     *
     * @return Unit
     */
    public function setDeptCode($deptCode)
    {
        $this->deptCode = $deptCode;

        return $this;
    }

    /**
     * Get deptCode
     *
     * @return string
     */
    public function getDeptCode()
    {
        return $this->deptCode;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Unit
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Unit
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set qbClassListid
     *
     * @param string $qbClassListid
     *
     * @return Unit
     */
    public function setQbClassListid($qbClassListid)
    {
        $this->qbClassListid = $qbClassListid;

        return $this;
    }

    /**
     * Get qbClassListid
     *
     * @return string
     */
    public function getQbClassListid()
    {
        return $this->qbClassListid;
    }

    /**
     * Set useParentDept
     *
     * @param boolean $useParentDept
     *
     * @return Unit
     */
    public function setUseParentDept($useParentDept)
    {
        $this->useParentDept = $useParentDept;

        return $this;
    }

    /**
     * Get useParentDept
     *
     * @return boolean
     */
    public function getUseParentDept()
    {
        return $this->useParentDept;
    }

    /**
     * Set parent
     *
     * @param \ApiBundle\Entity\Unit $parent
     *
     * @return Unit
     */
    public function setParent(\ApiBundle\Entity\Unit $new_parent = null)
    {
        $this->parent = $new_parent;
        $this->updateUnittree();

        return $this;
    }

    /**
     * @Assert\IsTrue(message="The parent unit is not valid for this unit. This unit is an ancestor of the parent unit, and this would create a circular relationship.")
     */
    public function isValidParent()
    {
        $valid = true;
        $childUnit = $this;
        while($valid && $childUnit->getParent() !== null){
            $childUnit = $childUnit->getParent();
            if($childUnit->getId() === $this->getId())
                $valid = false;
        }

        return $valid;
    }

    public function updateUnittree()
    {
        //Get the list of existing ancestors (which we need to update)
        if(is_null($this->getAncestors()))
            $old_ancestors = array();
        else{
            $old_ancestors = $this->getAncestors();
            $old_ancestors = $old_ancestors->toArray(); //Copying the array is a necessary step (so that it's a separate value from $this->ancestors, as opposed to a pointer to the same list)
        }

        //Get the list of ancestors as it should be
        if(is_null($this->parent))
            $new_ancestors = array();
        else{
            if(is_null($this->parent->getAncestors()))
                $new_ancestors = array();
            else{
                $new_ancestors = $this->parent->getAncestors();
                $new_ancestors = $new_ancestors->toArray(); //Copying the array is a necessary step, see above
            }
            $new_ancestors[] = $this->parent;
        }

        //Create lists of ancestors to remove and add (removing all and then adding all resulted mysql collisions, as all records are flushed to mysql at the same time)
        $diffFinder = function($a, $b){
          return $a->getId() - $b->getId();
        };
        $ancestors_to_add = array_udiff($new_ancestors, $old_ancestors, $diffFinder);
        $ancestors_to_remove = array_udiff($old_ancestors, $new_ancestors, $diffFinder);

        //Get the list of descendants (ancestor changes will need to be made to descendants)
        $descendants = $this->getDescendants();
        $descendants = $descendants->toArray();
        $descendants[] = $this;

        foreach($descendants as $descendant){
            foreach($ancestors_to_add as $ancestor){
                $descendant->addAncestor($ancestor);
            }
            foreach($ancestors_to_remove as $ancestor){
                $descendant->removeAncestor($ancestor);
            }
        }

        return array("removed" => $ancestors_to_remove, "added" => $ancestors_to_add);
    }

    /**
     * Get parent
     *
     * @return Unit
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Add child unit
     *
     * @param \ApiBundle\Entity\Unit $child
     *
     * @return Unit
     */
    public function addChild(\ApiBundle\Entity\Unit $child)
    {
        $this->children[] = $child;

        return $this;
    }

    /**
     * Remove person
     *
     * @param \ApiBundle\Entity\Person $child
     */
    public function removeChild(\ApiBundle\Entity\Person $child)
    {
        $this->children->removeElement($child);

        return $this;
    }

    /**
     * Get child units
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getChildren()
    {
        return $this->children;
    }

    /**
     * Get ancestor units
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAncestors()
    {
        return $this->ancestors;
    }

    /**
     * Add ancestor unit
     *
     * @param \ApiBundle\Entity\Unit $ancestor
     *
     * @return Unit
     */
    public function addAncestor(\ApiBundle\Entity\Unit $ancestor)
    {
        $this->ancestors[] = $ancestor;

        return $this;
    }

    /**
     * Remove ancestor unit
     *
     * @param \ApiBundle\Entity\Unit $child
     */
    public function removeAncestor(\ApiBundle\Entity\Unit $ancestor)
    {
        $results = $this->ancestors->removeElement($ancestor);

        return $this;
    }

    /**
     * Get descendant units
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getDescendants()
    {
        return $this->descendants;
    }

    /**
     * Add unittype
     *
     * @param \ApiBundle\Entity\Unittype $unittype
     *
     * @return Unit
     */
    public function addUnittype(\ApiBundle\Entity\Unittype $unittype)
    {
        $this->unittypes[] = $unittype;

        return $this;
    }

    /**
     * Remove unittype
     *
     * @param \ApiBundle\Entity\Unittype $unittype
     */
    public function removeUnittype(\ApiBundle\Entity\Unittype $unittype)
    {
        $this->unittypes->removeElement($unittype);
    }

    /**
     * Get unittypes
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUnittypes()
    {
        return $this->unittypes;
    }

    /**
     * Add assignedrole
     *
     * @param \ApiBundle\Entity\Assignedrole $assignedrole
     * @return Unit
     */
    public function addAssignedrole(\ApiBundle\Entity\Assignedrole $assignedrole)
    {
        $this->assignedroles[] = $assignedrole;

        return $this;
    }

    /**
     * Remove assignedrole
     *
     * @param \ApiBundle\Entity\Assignedrole $assignedrole
     */
    public function removeAssignedrole(\ApiBundle\Entity\Assignedrole $assignedrole)
    {
        $this->assignedroles->removeElement($assignedrole);

        return $this;
    }

    /**
     * Get assignedroles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAssignedroles()
    {
        return $this->assignedroles;
    }

    /**
     * Get privilegroles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPrivilegeroles()
    {
        $privilegeroles = $this->privilegeroles;
        if(!is_null($this->parent)){
          $privilegeroles = new ArrayCollection(array_merge($this->parent->getPrivilegeroles()->toArray(), $privilegeroles->toArray()));
        }
        return $privilegeroles;
    }

    /**
     * Get parentId
     *
     * @return integer
     */
    public function getParentId()
    {
        return $this->parentId;
    }

    /**
     * Set shortname
     *
     * @param string $shortname
     *
     * @return Unit
     */
    public function setShortname($shortname)
    {
        $this->shortname = $shortname;

        return $this;
    }

    /**
     * Get shortname
     *
     * @return string
     */
    public function getShortname()
    {
        return $this->shortname;
    }

    /**
     * Add privilegerole
     *
     * @param \ApiBundle\Entity\Privilegerole $privilegerole
     *
     * @return Unit
     */
    public function addPrivilegerole(\ApiBundle\Entity\Privilegerole $privilegerole)
    {
        $this->privilegeroles[] = $privilegerole;

        return $this;
    }

    /**
     * Remove privilegerole
     *
     * @param \ApiBundle\Entity\Privilegerole $privilegerole
     */
    public function removePrivilegerole(\ApiBundle\Entity\Privilegerole $privilegerole)
    {
        $this->privilegeroles->removeElement($privilegerole);
    }
}
