<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;


/**
 * Api (generic, bundle-wide services across entities)
 *
 * {@inheritdoc}
 * #ORM\Table(name="Api")
 * #ORM\Entity
 *
 * @ExclusionPolicy("all")
 */
class Api
{

    // placeholder class for now, but required for ApiDoc to show an entry (controller alone isn't sufficient);
    // also necessary for Repository methods to be available
    
    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        return basename(__CLASS__);
    }
    

}
