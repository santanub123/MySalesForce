<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AllowedOperations
 *
 * @ORM\Table(name="allowedoperations")
 * @ORM\Entity(repositoryClass="ApiBundle\Repository\AllowedOperationsRepository")
 */
class AllowedOperations
{

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }
    
     /**
     * @ORM\Column(type="string")
     */
    private $bundleId;

    /**
     * @ORM\Column(type="integer")
     */
    private $privilegeId;

    /**
     * @ORM\Column(type="integer")
     */
    private $roleId;

    /**
     * @ORM\Column(type="integer")
     */
    private $operationId;

    public function getBundleId() {
        return $this->$bundleId;
    }

    public function setBundleId($bundleId) {
        $this->bundleId = $bundleId;
    }

    public function getPrivilegeId() {
        return $this->$privilegeId;
    }

    public function setPrivilegeId($privilegeId) {
        $this->privilegeId = $privilegeId;
    }

    public function getRoleId() {
        return $this->roleId;
    }

    public function setRoleId($roleId) {
        $this->roleId = $roleId;
    }

    public function getOperationId() {
        return $this->$operationId;
    }

    public function setOperationId($operationId) {
        $this->operationId = $operationId;
    }
}

