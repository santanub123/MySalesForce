<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

/**
 * Assignedrole
 *
 * @ORM\Table(name="Assignedrole")
 * @ORM\Entity(repositoryClass="ApiBundle\Repository\AssignedroleRepository")
 *
 * @ExclusionPolicy("all")
 */
class Assignedrole
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var integer
     *
     * @ORM\Column(name="org_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $orgId;

    /**
     * @var integer
     *
     * @ORM\Column(name="person_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $personId;

    /**
     * @var integer
     *
     * @ORM\Column(name="role_id", type="integer", nullable=false)
     *
     * #Expose
     */
    private $roleId;

    /**
     * @var integer
     *
     * @ORM\Column(name="unit_id", type="integer", nullable=false)
     *
     * #Expose
     */
    private $unitId;

    /**
     * @var \ApiBundle\Entity\Org
     *
     * @ORM\ManyToOne(targetEntity="Org", inversedBy="assignedroles")
     *
     * @Expose
     */
    private $org;

    /**
     * @var \ApiBundle\Entity\Person
     *
     * see https://www.doctrine-project.org/api/orm/latest/Doctrine/ORM/Mapping/FetchMode.html
     *
     * @ORM\ManyToOne(targetEntity="Person", inversedBy="assignedroles", fetch="EAGER")
     * #ORM\ManyToOne(targetEntity="Person", inversedBy="assignedroles", fetch="LAZY")
     * #ORM\ManyToOne(targetEntity="Person", inversedBy="assignedroles", fetch="EXTRA_LAZY")
     *
     * @Expose
     */
    private $person;

    /**
     * @var \ApiBundle\Entity\Role
     *
     * @ORM\ManyToOne(targetEntity="Role", inversedBy="assignedroles")
     *
     * @Assert\NotBlank()
     *
     * @Expose
     */
    private $role;

    /**
     * @var \ApiBundle\Entity\Unit
     *
     * @ORM\ManyToOne(targetEntity="Unit", inversedBy="assignedroles")
     *
     * @Assert\NotBlank()
     *
     * @Expose
     */
    private $unit;

    /**
     * Supports __toString()
     *
     * @var string
     *
     * @Expose
     */
    private $name;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Privilegerole", inversedBy="assignedroles")
     *
     * #Expose
     */
    private $privilegeroles;


    /**
     * Validation callback
     *
     * @Assert\Callback
     */
    public function validate(ExecutionContextInterface $context, $payload)
    {
        // check assignments: not both person & org
        if ($this->person && $this->org) {
            $context->buildViolation('Either a Person or an Org should be associated, but not both.')
                ->atPath('person') // normally, propertyPath to field; 'person' indicates global
                ->addViolation();
        }

        // check assignments: at least person | org
        if (!$this->person && !$this->org) {
            $context->buildViolation('A Person or an Org should be associated.')
                ->atPath('person') // normally, propertyPath to field; 'person' indicates global
                ->addViolation();
        }

        // A 'not-blank' assertion can be written as below, but much easier to use @Assert on property annotation
        /*
        if (is_null($this->role)) {
            $context->buildViolation('A Role must be specified.')
                ->atPath('role')
                ->addViolation();
        }
        */

    }



    /**
     * Constructor
     */
    public function __construct()
    {
        $this->setName();
        $this->privilegeroles = new ArrayCollection();
    }



    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        $this->setName();

        return $this->getName(); // supports a useful return when listed as a related entity in EasyAdmin
    }

    /**
     * Set 'name'
     *
     * @return Assignedrole
     */
    public function setName()
    {
        // show a legible representation where a string is required
        $this->name = "r: $this->role | u: $this->unit | p: $this->person";

        return $this;
    }

    /**
     * Get 'name'
     *
     * @return string
     */
    public function getName()
    {
        return "$this->name";
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set active
     *
     * @param string $active
     *
     * @return Assignedrole
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set org
     *
     * @param \ApiBundle\Entity\Org $org
     * @return Assignedrole
     */
    public function setOrg(\ApiBundle\Entity\Org $org = null)
    {
        $this->org = $org;

        return $this;
    }

    /**
     * Get org
     *
     * @return \ApiBundle\Entity\Org
     */
    public function getOrg()
    {
        return $this->org;
    }

    /**
     * Set person
     *
     * @param \ApiBundle\Entity\Person $person
     * @return Assignedrole
     */
    public function setPerson(\ApiBundle\Entity\Person $person = null)
    {
        $this->person = $person;

        return $this;
    }

    /**
     * Get person
     *
     * @return \ApiBundle\Entity\Person
     */
    public function getPerson()
    {
        return $this->person;
    }

    /**
     * Get persons from related org
     *
     * return \Doctrine\Common\Collections\ArrayCollection
     */
    public function getPersonsAll()
    {
        if (is_null($this->person) && !is_null($this->org)) {
            $persons = $this->org->getPersons();
        } else {
            $persons = new ArrayCollection(array($this->person));
        }

        return $persons;
    }

    /**
     * Set unit
     *
     * @param \ApiBundle\Entity\Unit $unit
     *
     * @return Assignedrole
     */
    public function setUnit(\ApiBundle\Entity\Unit $unit = null)
    {
        $this->unit = $unit;

        return $this;
    }

    /**
     * Get unit
     *
     * @return \ApiBundle\Entity\Unit
     */
    public function getUnit()
    {
        return $this->unit;
    }

    /**
     * Set role
     *
     * @param \ApiBundle\Entity\Role $role
     *
     * @return Assignedrole
     */
    public function setRole(\ApiBundle\Entity\Role $role = null)
    {
        $this->role = $role;

        return $this;
    }

    /**
     * Get role
     *
     * @return \ApiBundle\Entity\Role
     */
    public function getRole()
    {
        return $this->role;
    }

    /**
     * Get self for occasions when proxy objects get in the way (AuthenticationSuccessListener.php)
     *
     * @return array
     */
    public function getSelf()
    {
        $proxy = get_object_vars($this);

        return $proxy;
    }

    /**
     * Get privilegroles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPrivilegeroles()
    {
        return $this->privilegeroles;
    }

}
