<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use FOS\UserBundle\Model\User as BaseUser;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * User
 *
 * BaseUser fields (w/sample data)
 *    "id": 12,
 *    "username": "jburkeb",
 *    "username_canonical": "jburkeb",
 *    "email": "jburkeb@scscertified.com",
 *    "email_canonical": "jburkeb@163.com",
 *    "enabled": false,
 *    "salt": "6d487f08eaddbd10b12200b0eea39ee4daf3411c059106b7f8886e268c9d8316",
 *    "password": "772cee0f414c47669588e4dc697d98df",
 *    "last_login": "2014-04-22T08:27:47-0700",
 *    "confirmation_token": "02b843555838c0740af6ad1a2b2359be6a2ea882",
 *    "password_requested_at": "2014-05-19T11:52:46-0700",
 *    "locked": false,
 *    "expired": false,
 *    "expires_at": "2017-09-17T14:34:34-0700",
 *    "roles": [],
 *    "credentials_expired": false,
 *    "credentials_expire_at": "2012-07-22T23:39:31-0700"
 *
 * @ORM\Table(name="User")
 * @ORM\Entity
 *
 * @ExclusionPolicy("all")
 */
class User extends BaseUser
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    protected $id; // *must* be protected, not private, since it extends the base property

    /**
     * This property exists solely to expose to API serialization
     * @Expose
     */
    protected $username; // *must* be protected, not private, since it extends the base property

    /**
     * This property exists solely to expose to API serialization
     * @Expose
     */
    protected $enabled; // *must* be protected, not private, since it extends the base property

    /**
     * Plain password. Used for model validation. Must not be persisted.
     *
     * *must* be protected, not private, since it extends the base property
     *
     * @var string
     *
     * @Assert\Length(
     *     min = 16,
     *     max = 250,
     *     minMessage = "Password must be at least 16 characters long"
     * )
     * @Assert\Expression(
     *     "this.passwordIncludesVariousCharClasses(value)",
     *     message="Password must contain one or more of each type: numeric digit, lowercase letter, uppercase letter, and non-alphanumeric character",
     *     groups={"Password"}
     * )
     * @Assert\Expression(
     *     "this.passwordDoesNotRepeatCharacters(value)",
     *     message="Password may not contain a character repeated 8 or more times",
     *     groups={"Password"}
     * )
     * @Assert\Expression(
     *     "this.passwordDoesNotIncludeCommonSequence(value)",
     *     message="Password may not contain a common sequence of characters",
     *     groups={"Password"}
     * )
     */
    protected $plainPassword;

    /**
     * Data in this field is a serialized array. Note that base getRoles inserts the
     * default role ("ROLE_USER," typically) if the array is otherwise empty
     *
     * This property exists solely to expose to API serialization
     * @Expose
     */
    protected $roles; // *must* be protected, not private, since it extends the base property

    /**
     * This property exists solely to expose to API serialization
     * @Expose
     */
    protected $email; // *must* be protected, not private, since it extends the base property

    /**
     * @var integer
     *
     * TODO: does #ORM annotation disturb our workflow (registration, etc.)? (VR)
     * @ORM\Column(name="person_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $personId;

    /**
     * @var \ApiBundle\Entity\Person
     *
     * @ORM\OneToOne(targetEntity="Person", fetch="EAGER")
     *
     * @Expose
     */
    private $person;

    /**
     * No ORM -- only for capturing input in the registration form
     *
     * @Expose
     */
    public $registerName;

    /**
     * No ORM -- only for capturing input in the registration form
     *
     * @Expose
     */
    public $registerOrganization;

    /**
     * No ORM -- only for capturing input in the registration form
     *
     * @Expose
     */
    public $registerProgram;

    /**
     * @var integer
     * @ORM\Column(name="failure_count", type="integer", nullable=true)
     *
     * @Expose
     */
    private $failureCount;

    /**
     * @var datetime
     * @ORM\Column(name="last_login_attempt", type="datetime", nullable=true)
     * 
     * @Expose
     */
    private $lastLoginAttempt;

    /**
     * @var datetime
     * @ORM\Column(name="lockout_expiration_time", type="datetime", nullable=true)
     * 
     * @Expose
     */
    private $lockoutExpirationTime;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=true, options={"default": "CURRENT_TIMESTAMP"})
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=true, columnDefinition="DATETIME on update CURRENT_TIMESTAMP")
     */
    private $modified;

    /**
     * No ORM -- only for aliasing 'enabled' to 'active' on read operations (including DQL)
     *
     * #Expose
     */
    //public $active;

    /**
     * This property exists solely to *suppress* API serialization -- but this has no effect in DQL
     * #Expose
     */
    //protected $salt; // *must* be protected, not private, since it extends the base property



    public function __construct()
    {
        parent::__construct(); // this class extends another, so this is important
        // our own logic
        //$this->active == $this->enabled;
    }



    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        return $this->email;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set enabled
     *
     * @param boolean $enabled
     *
     * @return User
     */
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;

        return $this;
    }

    /**
     * Get enabled
     *
     * @return boolean
     */
    public function getEnabled()
    {
        return $this->enabled;
    }

    /**
     * Set registerName
     *
     * @param string $name
     *
     * @return User
     */
    public function setRegisterName($name)
    {
        $this->registerName = $name;

        return $this;
    }

    /**
     * Get registerName
     *
     * @return string
     */
    public function getRegisterName()
    {
        return $this->registerName;
    }

    /**
     * Set registerOrganization (name, not id -- not a relationship)
     *
     * @param string $organization
     *
     * @return User
     */
    public function setRegisterOrganization($organization)
    {
        $this->registerOrganization = $organization;

        return $this;
    }

    /**
     * Get registerOrganization
     *
     * @return string
     */
    public function getRegisterOrganization()
    {
        return $this->registerOrganization;
    }

    /**
     * Set registerProgram
     *
     * @param string $program
     *
     * @return User
     */
    public function setRegisterProgram($program)
    {
        $this->registerProgram = $program;

        return $this;
    }

    /**
     * Get registerProgram
     *
     * @return string
     */
    public function getRegisterProgram()
    {
        return $this->registerProgram;
    }


    /**
     * Set failureCount
     * 
     * @param string failureCount
     * 
     * @return User
     */
    public function setFailureCount($failureCount) {
        $this->failureCount = $failureCount;
        return $this;
    }

    /**
     * Get failureCount
     *
     * @return string
     */
    public function getFailureCount()
    {
        return $this->failureCount;
    }

    /**
     * Set lastLoginAttempt
     * 
     * @param string lastLoginAttempt
     * 
     * @return User
     */
    public function setLastLoginAttempt($lastLoginAttempt) {
        $this->lastLoginAttempt = $lastLoginAttempt;
        return $this;
    }

    /**
     * Get lastLoginAttempt
     *
     * @return string
     */
    public function getLastLoginAttempt()
    {
        return $this->lastLoginAttempt;
    }
 
    /**
     * Set lockoutExpirationTime
     * 
     * @param string lockoutExpirationTime
     * 
     * @return User
     */
    public function setLockoutExpirationTime($lockoutExpirationTime) {
        $this->lockoutExpirationTime = $lockoutExpirationTime;
        return $this;
    }

    /**
     * Get lockoutExpirationTime
     *
     * @return string
     */
    public function getLockoutExpirationTime()
    {
        return $this->lockoutExpirationTime;
    }

    /**
     * Get created date
     *
     * @return boolean
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Get modified date
     *
     * @return boolean
     */
    public function getModified()
    {
        return $this->modified;
    }

    /**
     * Set personId
     *
     * @param integer $personId
     *
     * @return User
     */
    public function setPersonId($personId)
    {
        $this->personId = $personId;

        return $this;
    }

    /**
     * Get personId
     *
     * @return integer
     */
    public function getPersonId()
    {
        return $this->personId;
    }

    /**
     * Set person
     *
     * @param \ApiBundle\Entity\Person $person
     * @return User
     */
    public function setPerson(\ApiBundle\Entity\Person $person = null)
    {
        $this->person = $person;

        return $this;
    }

    /**
     * Get person
     *
     * @return \ApiBundle\Entity\Person
     */
    public function getPerson()
    {
        return $this->person;
    }

    /**
     * Test password for inclusion of various character classes
     *
     * @param string $password
     *     plain-text password to test
     *
     * @return boolean
     *     true if password is valid
     */
    public function passwordIncludesVariousCharClasses($password)
    {
        /* Tests for:
         *  at least one numeric digit
         *  at least one lowercase character
         *  at least one uppercase character
         *  at least one non-alphanumeric character
         */
        $pw_regex =
            '/^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^0-9a-zA-Z]).*$/';
        return (preg_match($pw_regex, $password) === 1);
    }

    /**
     * Test password for repeated characters
     *
     * @param string $password
     *     plain-text password to test
     *
     * @return boolean
     *     true if password is valid
     */
    public function passwordDoesNotRepeatCharacters($password)
    {
        /* Tests that a password does not include a character repeated 8 or
         * more times */
        $repeat_regex = '/(.)\\1{7,}/';
        return (preg_match($repeat_regex, $password) === 0);
    }

    /**
     * Test password for common sequences of characters
     *
     * @param string $password
     *     plain-text password to test
     *
     * @return boolean
     *     true if password is valid
     */
    public function passwordDoesNotIncludeCommonSequence($password)
    {
        $sequences = [
            'password',
            'scsglobal',
            'scs2000ca',
            '12345678',
            '23456789',
            'abcdefgh',
            'qwertyui',
            'asdfghjk',
            'zxcvbnm,',
            'qazwsxed',
        ];
        foreach ($sequences as $sequence) {
            // Test for existence of sequence.
            if (stripos($password, $sequence) !== false) {
                return false;
            }
            // Test for existence of reversed sequence.
            $rev_seq = strrev($sequence);
            if (stripos($password, $rev_seq) !== false) {
                return false;
            }
        }

        // None of the sequences were found.
        return true;
    }

    public function isAccountLocked() {
        $lockoutTimeStamp = is_null($this->getLockoutExpirationTime()) ? null : $this->getLockoutExpirationTime()->getTimestamp();
        return !is_null($this->getLockoutExpirationTime()) && !($lockoutTimeStamp < time());
    }

}
