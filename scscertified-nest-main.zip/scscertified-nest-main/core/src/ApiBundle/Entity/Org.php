<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Misd\PhoneNumberBundle\Validator\Constraints\PhoneNumber as AssertPhoneNumber;
use Symfony\Component\Validator\Constraints as Assert;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Org
 *
 * @ORM\Table(name="Org")
 * @ORM\Entity
 *
 * @ExclusionPolicy("all")
 */
class Org
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;
    
    /**
     * @var string
     *
     * @ORM\Column(name="salesforce_id", type="string", nullable=true)
     *
     * @Expose
     */
    private $salesforceId;

    /**
     * @var integer
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=false)
     *
     * @Assert\NotBlank()
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="alternate_name", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $alternateName;

    /**
     * @var string
     *
     * @ORM\Column(name="phone", type="string", length=30, nullable=true)
     *
     * @AssertPhoneNumber(defaultRegion="US")
     * @Assert\Length(max = 30)
     *
     * @Expose
     */
    private $phone;

    /**
     * @var string
     *
     * @ORM\Column(name="phoneRaw", type="string", length=125, nullable=true)
     *
     * @Assert\Length(max = 125)
     *
     * @Expose
     */
    private $phoneRaw;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="web", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $web;

    /**
     * @var string
     *
     * @ORM\Column(name="dms_id", type="string", length=64, nullable=true)
     *
     * @Assert\Length(max = 64)
     *
     * @Expose
     */
    private $dmsId;

    /**
     * @var string
     *
     * @ORM\Column(name="qb_id", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $qbId;

    /**
     * @var integer
     *
     * @ORM\Column(name="parent_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $parentId;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=true, options={"default": "CURRENT_TIMESTAMP"})
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="modified", type="datetime", nullable=true, columnDefinition="DATETIME on update CURRENT_TIMESTAMP")
     */
    private $modified;

    /**
     * @var \ApiBundle\Entity\Org
     *
     * @ORM\ManyToOne(targetEntity="Org", inversedBy="children")
     *
     * @Expose
     */
     private $parent;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Org", mappedBy="parent")
     */
    private $children;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Address", mappedBy="org") // TODO: make unidirectional?
     *
     * @Expose
     */
    private $addresses;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Person", mappedBy="org")
     * @ORM\OrderBy({"nameFirst" = "ASC", "nameLast" = "ASC"})
     *
     * #Expose
     */
    private $persons;
    
    /**
     * @var integer
     *
     * #Expose
     */
    private $personsCount;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Orgtype", inversedBy="orgs")
     *
     * @Expose
     */
    private $orgtypes;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Assignedrole", mappedBy="org")
     *  ORM\OrderBy({"role" = "ASC", "unit" = "ASC"})
     *
     * #Expose
     */
    private $assignedroles;



    /**
     * Constructor
     */
    public function __construct()
    {
        $this->addresses = new ArrayCollection();
        $this->children = new ArrayCollection();
        $this->persons = new ArrayCollection();
        $this->orgtypes = new ArrayCollection();
        $this->assignedroles = new ArrayCollection();
        $this->personsCount = $this->getPersonsCount();
    }

    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        return $this->name; // supports a useful return when listed as a related entity in EasyAdmin
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
    
    /**
     * Set salesforceId
     *
     * @param boolean $salesforceId
     *
     * @return Unit
     */
    public function setSalesforceId($salesforceId)
    {
        $this->salesforceId = $salesforceId;

        return $this;
    }

    /**
     * Get salesforceId
     *
     * @return boolean
     */
    public function getSalesforceId()
    {
        return $this->salesforceId;
    }
    
    /**
     * Set active
     *
     * @param string $active
     *
     * @return Org
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Org
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set alternate name
     *
     * @param string $name
     * @return Org
     */
    public function setAlternateName($alternateName)
    {
        $this->alternateName = $alternateName;

        return $this;
    }

    /**
     * Get alternate name
     *
     * @return string
     */
    public function getAlternateName()
    {
        return $this->alternateName;
    }

    /**
     * Set phone
     *
     * @param string $phone
     * @return Org
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return Org
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set web
     *
     * @param string $web
     * @return Org
     */
    public function setWeb($web)
    {
        $this->web = $web;

        return $this;
    }

    /**
     * Get web
     *
     * @return string
     */
    public function getWeb()
    {
        return $this->web;
    }

    /**
     * Set dmsId
     *
     * @param string $dmsId
     *
     * @return Org
     */
    public function setDmsId($dmsId)
    {
        $this->dmsId = $dmsId;

        return $this;
    }

    /**
     * Get dmsId
     *
     * @return string
     */
    public function getDmsId()
    {
        return $this->dmsId;
    }

    /**
     * Set qbId
     *
     * @param string $qbId
     *
     * @return Org
     */
    public function setQbId($qbId)
    {
        $this->qbId = $qbId;

        return $this;
    }

    /**
     * Get qbId
     *
     * @return string
     */
    public function getQbId()
    {
        return $this->qbId;
    }

    /**
     * Get created date
     *
     * @return boolean
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Get modified date
     *
     * @return boolean
     */
    public function getModified()
    {
        return $this->modified;
    }

    /**
     * Add address
     *
     * @param \ApiBundle\Entity\Address $address
     * @return Org
     */
    public function addAddress(\ApiBundle\Entity\Address $address)
    {
        $this->addresses[] = $address;

        return $this;
    }

    /**
     * Remove address
     *
     * @param \ApiBundle\Entity\Address $address
     */
    public function removeAddress(\ApiBundle\Entity\Address $address)
    {
        $this->addresses->removeElement($address);
    }

    /**
     * Get address
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAddresses()
    {
        return $this->addresses;
    }

    /**
     * Set parent org
     *
     * @param \ApiBundle\Entity\Org $parent
     *
     * @return Org
     */
    public function setParent(\ApiBundle\Entity\Org $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }
    
    /**
     * @Assert\IsTrue(message="The parent org is not valid for this org. This org is an ancestor of the parent org, and this would create a circular relationship.")
     */
    public function isValidParent()
    {
        $valid = true;
        $childOrg = $this;
        while($valid && $childOrg->getParent() !== null){
            $childOrg = $childOrg->getParent();
            if($childOrg->getId() === $this->getId())
                $valid = false;
        }
        
        return $valid;
    }

    /**
     * Get parent org
     *
     * @return Org
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Add child org
     *
     * @param \ApiBundle\Entity\Org $child
     *
     * @return Org
     */
    public function addChild(\ApiBundle\Entity\Org $child)
    {
        $this->children[] = $child;

        return $this;
    }

    /**
     * Remove child org
     *
     * @param \ApiBundle\Entity\Org $child
     */
    public function removeChild(\ApiBundle\Entity\Org $child)
    {
        $this->children->removeElement($child);
    }

    /**
     * Get child org
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getChildren()
    {
        return $this->children;
    }

    /**
     * Add person
     *
     * @param \ApiBundle\Entity\Person $person
     *
     * @return Org
     */
    public function addPerson(\ApiBundle\Entity\Person $person)
    {
        $this->persons[] = $person;

        return $this;
    }

    /**
     * Remove person
     *
     * @param \ApiBundle\Entity\Person $person
     */
    public function removePerson(\ApiBundle\Entity\Person $person)
    {
        $this->persons->removeElement($person);
    }

    /**
     * Get persons
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPersons()
    {
        return $this->persons;
    }
    
    /**
     * Get persons count
     *
     * @return integer
     */
    public function getPersonsCount()
    {
        return count($this->persons);
    }

    /**
     * Add orgtype
     *
     * @param \ApiBundle\Entity\Orgtype $orgtype
     *
     * @return Org
     */
    public function addOrgtype(\ApiBundle\Entity\Orgtype $orgtype)
    {
        $this->orgtypes[] = $orgtype;

        return $this;
    }

    /**
     * Remove orgtype
     *
     * @param \ApiBundle\Entity\Orgtype $orgtype
     */
    public function removeOrgtype(\ApiBundle\Entity\Orgtype $orgtype)
    {
        $this->orgtypes->removeElement($orgtype);
    }

    /**
     * Get orgtypes
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getOrgtypes()
    {
        return $this->orgtypes;
    }

    /**
     * Add assignedrole
     *
     * @param \ApiBundle\Entity\Assignedrole $assignedrole
     * @return Org
     */
    public function addAssignedrole(\ApiBundle\Entity\Assignedrole $assignedrole)
    {
        $this->assignedroles[] = $assignedrole;

        return $this;
    }

    /**
     * Remove assignedrole
     *
     * @param \ApiBundle\Entity\Assignedrole $assignedrole
     */
    public function removeAssignedrole(\ApiBundle\Entity\Assignedrole $assignedrole)
    {
        $this->assignedroles->removeElement($assignedrole);
    }

    /**
     * Get assignedroles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAssignedroles()
    {
        return $this->assignedroles;
    }

    /**
     * Get ancestors
     *
     * @return orgs[] // array of orgs
     */
    public function getAncestors()
    {
        $count = 0;
        $ancestors = [];
        $ancestor = $this->getParent();
        $ancestorIds = []; // bad data relationships were introducing circularity
        while ($ancestor && ($ancestor->getId() > 0) && (!in_array($ancestor->getId(), $ancestorIds)) && ($count < 100)) {
            $ancestorIds[] = $ancestor->getId();
            $ancestors[] = $ancestor;
            $ancestor = $ancestor->getParent();
            ++$count;
        }

        $ancestors = array_reverse($ancestors);
        return $ancestors;
    }

    /**
     * Get self for occasions when proxy objects get in the way (AuthenticationSuccessListener.php)
     *
     * @return Org
     */
    public function getSelf()
    {
        $proxy = get_object_vars($this);

        return $proxy;
    }


    /**
     * Set phoneRaw
     *
     * @param string $phoneRaw
     *
     * @return Org
     */
    public function setPhoneRaw($phoneRaw)
    {
        $this->phoneRaw = $phoneRaw;

        return $this;
    }

    /**
     * Get phoneRaw
     *
     * @return string
     */
    public function getPhoneRaw()
    {
        return $this->phoneRaw;
    }
}
