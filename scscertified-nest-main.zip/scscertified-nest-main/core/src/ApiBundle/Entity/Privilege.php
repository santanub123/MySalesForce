<?php

namespace ApiBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

/**
 * Privilege (description of what is allowed in an App)
 *
 * @ORM\Table(name="Privilege")
 * @ORM\Entity(repositoryClass="ApiBundle\Repository\PrivilegeRepository")
 *
 * @ExclusionPolicy("all")
 */
class Privilege
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="active", type="boolean", nullable=true, options={"default"=1})
     *
     * @Assert\Type(type = "bool")
     *
     * @Expose
     */
    private $active = TRUE;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     *
     * @Assert\Length(max = 255)
     *
     * @Expose
     */
    private $description;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="app_id", type="integer", nullable=true)
     *
     * #Expose
     */
    private $appId;

    /**
     * @var \ApiBundle\Entity\App
     *
     * @ORM\ManyToOne(targetEntity="App", inversedBy="privileges")
     *
     * @Expose
     */
    private $app;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Privilegerole", mappedBy="privilege")
     *  ORM\OrderBy({"role" = "ASC", "unit" = "ASC", "privilege" = "ASC"})
     *
     * #Expose
     */
    private $privilegeroles;



    public function __construct() {
        // $this->setAppId();
        $this->privilegeroles = new ArrayCollection();
    }

    /**
     * Get class name (for empty object)
     *
     * @return string
     */
    public function __toString()
    {
        //return basename(__CLASS__);
        return "{$this->app->getAbbreviation()}#{$this->name}"; // supports a useful return when listed as a related entity in EasyAdmin
    }

    /**
     * Validation callback
     *
     * @Assert\Callback
     */
    public function validate(ExecutionContextInterface $context)
    {
    }

    /**
     * Get appid
     *
     * @return integer
     */
    public function getAppId()
    {
        return $this->appId;
    }

    /**
     * Set appid
     *
     * #param integer $appid
     * @return Privilege
     */
    public function setAppId()
    {
        $this->appId = $this->getApp()->getId();

        return $this;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set active
     *
     * @param string $active
     *
     * @return Privilege
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Privilege
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Privilege
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set app
     *
     * @param \ApiBundle\Entity\App $app
     * @return Privilege
     */
    public function setApp(\ApiBundle\Entity\App $app = null)
    {
        $this->app = $app;

        return $this;
    }

    /**
     * Get app
     *
     * @return \ApiBundle\Entity\App
     */
    public function getApp()
    {
        return $this->app;
    }
    
    /**
     * Get app abbreviation
     *
     * @return \ApiBundle\Entity\App
     */
    public function getAppAbbreviation()
    {
        return $this->app->abbreviation;
    }

    /**
     * Add privilegerole
     *
     * @param \ApiBundle\Entity\Privilegerole $privilegerole
     * @return Privilege
     */
    public function addPrivilegerole(\ApiBundle\Entity\Privilege $privilegerole)
    {
        $this->privilegeroles[] = $privilegerole;

        return $this;
    }

    /**
     * Remove privilegerole
     *
     * @param \ApiBundle\Entity\Privilegerole $privilegerole
     */
    public function removePrivilegerole(\ApiBundle\Entity\Privilegerole $privilegerole)
    {
        $this->privilegeroles->removeElement($privilegerole);
    }

    /**
     * Get privilegerole
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPrivilegeroles()
    {
        return $this->privilegeroles;
    }

}
