<?php

namespace ApiBundle\EventListener;

use Lexik\Bundle\JWTAuthenticationBundle\Event\JWTDecodedEvent;
use Symfony\Component\HttpFoundation\RequestStack;

class JWTDecodedListener
{
    // Further custom validation of an incoming token
    
    /**
     * @var RequestStack
     */
    private $requestStack;
    private $hostIP;
    private $hostName;
    private $servers;

    /**
     * @param RequestStack $requestStack
     */
    public function __construct(RequestStack $requestStack)
    {
        $this->requestStack = $requestStack;
    }

    /**
     * @param JWTDecodedEvent $event
     *
     * @return void
     */
    public function onJWTDecoded(JWTDecodedEvent $event)
    {
        // Symfony < 2.4
        //$request = $event->getRequest();

        // Symfony 2.4+
        $request = $this->requestStack->getCurrentRequest();

        $payload = $event->getPayload();
        
        // ip set at the JWTCreated event listener
        if ($request->getClientIp() == $_SERVER['SERVER_ADDR']) {
            // IP match: get a pass (normal validation still applies
            // -- e.g., expiration, issuing server key, etc.)
            // Allows user-supplied token if submitted by the server to itself
        } elseif (!isset($payload['ip']) || $payload['ip'] !== $request->getClientIp()) {
            $event->markAsInvalid();
        }
    }
}
