<?php

namespace ApiBundle\EventListener;

use Lexik\Bundle\JWTAuthenticationBundle\Event\JWTEncodedEvent;

class JWTEncodedListener
{
    // This implementation doesn't yet have a net change over the default behavior
    
    /**
     * @param JWTEncodedEvent $event
     */
    public function onJWTEncoded(JWTEncodedEvent $event)
    {
        $token = $event->getJWTString();
    }

}