<?php

namespace ApiBundle\EventListener;

use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage;
use Symfony\Component\Stopwatch\Stopwatch;
use Symfony\Component\HttpKernel\Event\FilterControllerEvent;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class PerfmonListener
{
    // Properties.

    // Instance of Stopwatch.
    protected $stopwatch = null;

    // Instance of EntityManager for application_logs database.
    protected $perfmon_em = null;

    // Instance of TokenStorage.
    protected $token_storage = null;

    // Always log toggle.
    protected $always_log = null;


    // Methods.

    /**
     * Constructor
     *
     * @param EntityManagerInterface $perfmon_em
     *     injected entity manager to provide database access
     * @param TokenStorage $token_storage
     *     injected to access user name
     * @param string $log_perf_data
     *     determines for which requests to log performance data to database:
     *         "none" - no requests are logged
     *         "benchmark" - requests from the Perfmon Benchmark are logged
     *         "all" - all requests are logged
     */
    public function __construct(
        EntityManagerInterface $perfmon_em,
        TokenStorage $token_storage,
        string $log_perf_data
    ) {
        // Create instance of Stopwatch for time profiling.
        $this->stopwatch = new Stopwatch();

        // Store injected entity manager for storage of measurements.
        $this->perfmon_em = $perfmon_em;

        // Store injected token storage to obtain user name.
        $this->token_storage = $token_storage;

        // Store log perf data setting.
        $this->log_perf_data = $log_perf_data;
    }

    /**
     * Handler for kernel.controller event
     *
     * @param object $fc_event
     *     FilterControllerEvent object passed by the HTTP kernel
     */
    public function onKernelController(FilterControllerEvent $fc_event)
    {
        if (is_object($fc_event)) {
            $request = $fc_event->getRequest();

            // Determine if this request should be measured.
            $measure_request = false;
            if ($this->log_perf_data === 'all') {
                // Log performance data for all requests.
                $measure_request = true;
            } else {
                $perfmon_enable = $request->headers->get('Nest-Perfmon-Enable');
                if (!empty($perfmon_enable)) {
                    // Collect performance data for Perfmon Benchmark test.
                    $measure_request = true;
                }
            }

            if ($measure_request) {
                $nest_perfmon_request_id = mt_rand(100000, 999999);
                $this->stopwatch->start($nest_perfmon_request_id);
                $request->headers->set(
                    'Nest-Perfmon-Request-Id',
                    $nest_perfmon_request_id
                );
            }
        }
    }

    /**
     * Handler for kernel.response event
     *
     * @param object $fr_event
     *     FilterResponseEvent object passed by HTTP kernel
     */
    public function onKernelResponse(FilterResponseEvent $fr_event)
    {
        if (is_object($fr_event)) {
            $request = $fr_event->getRequest();
            $perfmon_id = $request->headers->get('Nest-Perfmon-Request-Id');
            if (
                !empty($perfmon_id) && $this->stopwatch->isStarted($perfmon_id)
            ) {
                // Stop timer.
                $sw_event = $this->stopwatch->stop($perfmon_id);
                $duration = $sw_event->getDuration();

                if (
                    ($this->log_perf_data === 'all') ||
                    ($this->log_perf_data === 'benchmark')
                ) {
                    // Log performance data.
                    $this->logPerformanceData($fr_event, $sw_event);
                }

                // Add duration to response header.
                $response = $fr_event->getResponse();
                $response->headers->set(
                    'Nest-Perfmon-Duration',
                    (string) $duration
                );
            }
        }
    }

    /**
     * Log performance data to database
     *
     * @param object $fr_event
     *     FilterResponseEvent object received by onKernelResponse
     * @param object $sw_event
     *     StopwatchEvent object returned from stopwatch->stop
     */
    protected function logPerformanceData($fr_event, $sw_event)
    {
        // Set up values for log entry.
        $timenow = new \DateTime(
            'now',
            new \DateTimeZone('America/Los_Angeles')
        );
        $timenow_str = $timenow->format('Y-m-d H:i:s');

        $request = $fr_event->getRequest();
        $host = $_SERVER['HTTP_HOST'];

        $token = $this->token_storage->getToken();
        if (!empty($token)) {
            $username = $token->getUsername();
        } else {
            $username = '';
        }

        $method = $request->getMethod();

        $pathInfo = \Scs\MysqlDatabase3::sqlEscapeString(
            urldecode($request->getPathInfo())
        );
        $controller = \Scs\MysqlDatabase3::sqlEscapeString(
            $request->attributes->get('_controller')
        );
        $forwarded_controller = '';
        $forwarded = $request->attributes->get('_forwarded');
        if (!empty($forwarded)) {
            $forwarded_controller = \Scs\MysqlDatabase3::sqlEscapeString(
                $forwarded->get('_controller')
            );
        }

        $query = \Scs\MysqlDatabase3::sqlEscapeString(
            $request->attributes->get('query')
        );
        $options = \Scs\MysqlDatabase3::sqlEscapeString(
            $request->attributes->get('options')
        );
        $response = $fr_event->getResponse();
        $statusCode = $response->getStatusCode();
        $contentLength = strlen($response->getContent());
        $duration = $sw_event->getDuration();

        // Construct the SQL statement.
        $sql = "
            INSERT INTO perf_data
            SET
              time = '$timenow_str',
              host = '$host',
              username = '$username',
              method = '$method',
              pathInfo = '$pathInfo',
              forwarded_controller = '$forwarded_controller',
              controller = '$controller',
              query = '$query',
              options = '$options',
              statusCode = $statusCode,
              contentLength = $contentLength,
              duration = $duration
        ";

        // Execute insertion.
        $stmt = $this->perfmon_em->getConnection()->prepare($sql);
        $stmt->execute();
    }
}
