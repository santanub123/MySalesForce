<?php

namespace ApiBundle\EventListener;

use ApiBundle\Controller\EmailController; // as EmailController;
use ApiBundle\Entity\Person;
//use FOS\UserBundle\Event\UserEvent;
use FOS\UserBundle\Event\GetResponseNullableUserEvent;
use FOS\UserBundle\FOSUserEvents;
//use Symfony\Bundle\FrameworkBundle\Templating\EngineInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Twig\Environment; // as Twig_Environment;

/**
 * Listener replaces Password Reset email with Registration email, if no User
 *
 * Note: PasswordResettingListener subscribes to same event
 */
class ResettingSendEmailInitializeSubscriber implements EventSubscriberInterface
{
  
    // TODO: set this into nest_config.php so it can be better shared
    private $role_staff_id = 1;
    
    private $entityManager;
    private $emailController;
    private $twig;
    private $mailer;
    private $router;
    
    /**
     * Constructor
     *
     * @param object $entityManager
     * @param object $emailController
     * @param object $twig
     * @param object $mailer
     * @param object $router
     *     passed from service container (defined in services.yml)
     */
    public function __construct( 
            \Doctrine\ORM\EntityManagerInterface $entityManager, 
            \ApiBundle\Controller\EmailController $emailController, 
            \Twig_Environment $twig, 
            \Swift_Mailer $mailer, 
            UrlGeneratorInterface $router
        )
    //public function __construct($entityManager)
    {
        $this->entityManager   = $entityManager;
        $this->emailController = $emailController;
        $this->twig            = $twig;
        $this->mailer          = $mailer;
        $this->router          = $router;
    }
    
    private function sendRegistrationEmail()
    {
        
    }
    
    /**
     * {@inheritdoc}
     *
     * Return array of event names this subscriber wants to listen to
     *
     * @return array
     *     array of event names => handlers
     */
    public static function getSubscribedEvents()
    {
        return array(
            FOSUserEvents::RESETTING_SEND_EMAIL_INITIALIZE  => 'onResettingSendEmailInitialize',
        );
    }
    
    /**
     * Check if the User exists and exit. If not, (re)send Registration email exit.
     * 
     * @param GetResponseNullableUserEvent $event
     */
    public function onResettingSendEmailInitialize(GetResponseNullableUserEvent $event) //, $eventName, $dispatcher)
    {
      
        if (NULL === $event->getUser()) {
            
            $username = $event->getRequest()->get('username');
            
            $entity = $this->entityManager->getRepository('ApiBundle:Person'); // deprecated bundle:entity format?
            $persons = $entity->findByEmail1("$username");
            
            $person = null;
            $registerTokenStartDate = null;
            $mailer = -1;
            
            if(count($persons)) {
            
                $person = $persons[0];
                
                // messageAction() expects this array -- see EmailController::setPersonDetailsAction()
                $personDetails = [
                    'id'            => $person->getId(),
                    'email'         => $person->getEmail1(),
                    'nameFirst'     => $person->getNameFirst(),
                    'nameLast'      => $person->getNameLast(),
                    'registerToken' => $person->getRegisterToken()
                ];
                
                //$today = new \DateTime();
                $today = time();
                $registerTokenStartDate = $person->getRegisterTokenStartDate()->getTimestamp();
                $registerTokenDuration = $person->getRegistertokenDuration();
                
                $remaining = $today - $registerTokenStartDate; // if negative, start date is in future
                $is_eligible = 0;
                
                if ($remaining > 0) {

                    $is_eligible = 1;
                    
                    // set is_staff to true if there's an assignedrole
                    $is_staff = false;
                    foreach($person->getAssignedroles() as $assignedrole) {
                        if($assignedrole->getRole()->getId() === $this->role_staff_id) {
                            $is_staff = true;
                            break; //Break out of the loop if the staff is set to true
                        }
                    }
                    
                    // get Registration email data: [$title, $sender, $user_email_address, Array $email_contents]
                    $message_data = $this->emailController->messageAction($personDetails, $is_staff, false); 
                    
                    // render items into vars
                    foreach ($message_data as $k => $v) {
                        $$k = $v;
                    }
                    
                    // send Registration message
                    //  - Same code as in EmailController, but twig doesn't work when invoked in that method from here.
                    //  - Also gives opportunity to amend body content here, though we don't do that yet.
                    $body = $this->twig->render('email/message.html.twig', $email_contents);
                    $message = new \Swift_Message($title);
                    $message->setFrom($sender);
                    $message->setTo($user_email_address);
                    $message->setBody($body,'text/html');
                    
                    $mailer = $this->mailer->send($message);
                    
                    // reset clock for registration token
                    $person->setRegisterTokenStartDate(new \DateTime());
                    $this->entityManager->persist($person);
                    $this->entityManager->flush();
                    
                    // TODO: (?) amend message in above email to say it's a resend due to Forgot Password attempt
                }
            }
            
            /*
            // Use this block to send back raw diagnostics during development (disable 'return true,' too)
            $registerTokenStartDate = $person->getRegisterTokenStartDate();
            
            $response = new JsonResponse([
                'success' => FALSE,
                'message' => 'You may need to complete your Registration first',
                //'username'      => $username,
                //'persons'       => $persons,
                //'person'        => $person,
                //'personDetails'     => $personDetails,
                'registerTokenStartDate' => $registerTokenStartDate,
                'mailer'        => $mailer,
                //'event'         => $event,
                //'eventName' => $eventName,
                //'emailController' => get_class_methods($this->emailController),
                //'dispatcher' => get_class($dispatcher),
                //'emailController' => get_class($this->emailController),
                //'var' => get_class($var),
                'staff_id' => $this->emailController->getStaffId(),
                //'twig' => get_class_methods($this->twig),
                //'twig' => $this->twig->render('email/message.html.twig', $message_data['email_contents'])
                //'today' => $today,
                'remaining' => $remaining,
            ]);
            
            $event->setResponse($response);
            
            // End diagnostic block
            
            */
            
            // we want actions following this listener to be the same regardless.
            //$event->setResponse(new RedirectResponse($this->router->generate('fos_user_resetting_check_email', array('username' => '$this->username'))));
            
            return true;
            
        }
      
    }
  
}