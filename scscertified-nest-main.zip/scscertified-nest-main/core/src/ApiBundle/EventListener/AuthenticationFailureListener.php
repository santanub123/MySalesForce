<?php

namespace ApiBundle\EventListener;

define('MAX_OF_ATTEMPTS', 100);

use ApiBundle\Entity\User;
use ApiBundle\Util\AccountManager;
use Doctrine\ORM\EntityManager;
use Lexik\Bundle\JWTAuthenticationBundle\Event\AuthenticationFailureEvent;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
// use Symfony\Component\HttpKernel\Event\FilterControllerEvent;

class AuthenticationFailureListener {

    protected $em;
    private $responseError;

    function __construct(EntityManager $em) {
        $this->em = $em;
    }

    /**
     * @param AuthenticationFailureEvent $event
     */
    public function onAuthenticationFailure(AuthenticationFailureEvent $event)
    {
        $em = $this->em;
        $request = new Request();
        // $entityManager = $container->get('doctrine.orm.entity_manager');
        $username = json_decode($request->getContent())->username;

        //check now for username or email WHERE u.username = :username OR u.email = :username
        $query = $em->createQuery(
            'SELECT u
            FROM ApiBundle:User u
            WHERE u.username = :username OR u.email = :email'
        )->setParameters(
            array(
                'username' => $username,
                'email'    => $username
            )
        );

        $user = $query->setMaxResults(1)->getOneOrNullResult();
        $am = new AccountManager($user);

        //If there is an existing User
        if ($user) {

            $minute_incremental = 6; // 6 mins

            if ($user->getFailureCount() % 10 === 0 && $user->getFailureCount() > 0) {
                //getFailureCount must be divisible by 10 and not 0

                $dateTobeUsed = empty($user->getLockoutExpirationTime()) || $am->isLockDateInPast($user) ? date("Y-m-d H:i:s") : $user->getLockoutExpirationTime()->format("Y-m-d H:i:s");
                $lockoutTime = new \DateTime($dateTobeUsed); //date
                $timeLocked = 'PT' . $minute_incremental . 'M'; // $user->getFailureCount() / 10  * minute_incremental
                $lockoutTime->add(new \DateInterval($timeLocked)); //adds 10 minutes

                $user->setLockoutExpirationTime($lockoutTime);
                $em->persist($user);
                // $em->flush();

            }

            if (!$am->isUserEnabled($user)) {

                $message = 'Your account is disabled. Please contact an SCS administrator to re-enable your account. info@scsglobalservices.com';

            } else if ($am->isAccountLocked($user)) {

                $failureCount = empty($user->getFailureCount()) ? 0 : $user->getFailureCount();
                $failureCount += 1;
                $user->setFailureCount($failureCount);
                $em->persist($user);
                // $em->flush();
                $message = 'Your account has been suspended until ' . $user->getLockoutExpirationTime()->format("Y-m-d / H:i:s") . ". Please try again later";

            } else {

                $failureCount = empty($user->getFailureCount()) ? 0 : $user->getFailureCount();
                $failureCount += 1;
                $user->setFailureCount($failureCount);
                $em->persist($user);
                // $em->flush();
                $message = 'Your username or password is incorrect. Please try again or click the forgot password link below to reset your password.';

            }

            if ($user->getFailureCount() >= MAX_OF_ATTEMPTS) {
                $user->setEnabled(0);
                $user->setLockoutExpirationTime(null);
                $em->persist($user);
                // $em->flush();
                $message = 'Your account has been disabled due to repeated login attempts. Please contact an SCS administrator to re-enable your account. info@scsglobalservices.com';
            }

            $em->flush();
            $this->setResponseErrorMessage('401 Unauthorized', $message);

        } else {
            // If log-in fails and they submitted invalid credentials
            $this->setResponseErrorMessage('401 Unauthorized', 'Your username or password is incorrect. Please try again or click the forgot password link below to reset your password.');
        }

        $response = new JsonResponse($this->getResponseErrorMessage(), 401);

        $event->setResponse($response);

    }

    // helper methods
    private function setResponseErrorMessage($status, $message) {
        $this->responseError = [ 'status'  => $status, 'message' => $message];
    }

    private function getResponseErrorMessage() {
        return $this->responseError;
    }

}
