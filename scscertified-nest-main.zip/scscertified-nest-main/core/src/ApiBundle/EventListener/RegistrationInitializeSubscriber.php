<?php

namespace ApiBundle\EventListener;

use ApiBundle\Entity\Person;
use FOS\UserBundle\FOSUserEvents;
use FOS\UserBundle\Event\UserEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Listener amends rendering of Registration form (before submission)
 */
class RegistrationInitializeSubscriber implements EventSubscriberInterface
{
  
    private $entityManager;
    
    /**
     * Constructor
     *
     * @param object $entityManager
     *     passed from service container (defined in services.yml)
     */
    public function __construct($entityManager)
    {
        $this->entityManager = $entityManager;
    }
    
    public function onRegistrationInitialize(UserEvent $event)
    {
        $user = $event->getUser();
        
        // this returns blank results, for some reason, but doesn't generate an error
        $token = $event->getRequest()->attributes->get('t');
        
        // alternative method
        parse_str($event->getRequest()->getQueryString(), $get);
        $token = (isset($get['t']) ? $get['t'] : '');
        
        $entity = $this->entityManager->getRepository('ApiBundle:Person');
        $persons = $entity->findBy(array('registerToken' => $token));
        
        // debug
        $status_info = '';
        
        if(count($persons)) {
            
            $person = $persons[0];
            
            $person_id                        = $person->getId();
            $person_start_date                = $person->getStartDate();
            $person_end_date                  = $person->getEndDate();
            $person_register_token_start_date = $person->getRegisterTokenStartDate();
            $person_register_token_duration   = $person->getRegisterTokenDuration();
            
            $now = time();
            
            // check start_date & token date validity
            $ts_psd   = null; // timestamp_person_start_date
            $ts_ped   = null; // timestamp_person_end_date
            $ts_prtsd = null; // timestamp_person_register_token_start_date
            if(is_object($person_start_date))                $ts_psd   = $person_start_date->getTimestamp();
            if(is_object($person_end_date))                  $ts_ped   = $person_end_date->getTimestamp();
            if(is_object($person_register_token_start_date)) $ts_prtsd = $person_register_token_start_date->getTimestamp();
                                                             // expiration datetime of token
                                                             $ts_prted = $ts_prtsd + $person_register_token_duration; 
            
            $status = '';
            if (
                    $ts_psd   < $now                    && 
                   ($ts_ped   > $now || empty($ts_ped)) && 
                    $ts_prtsd < $now                    &&
                    $ts_prted > $now
                ) {
                $status = 'OK';
            }
            
            // debug
            $status_info .= "\n\n" . 'Now: '          . $now . '';
            $status_info .= "\n\n" . 'Person Start: ' . $ts_psd . '';
            $status_info .= "\n\n" . 'Person End: '   . $ts_ped . '';
            $status_info .= "\n\n" . 'Token start: '  . $ts_prtsd . '';
            $status_info .= "\n\n" . 'Token end: '    . $ts_prted . '';
            $status_info .= "\n\n" . 'Date Status: '  . $status . '';
            
            if ($status) {
            
                $entity = $this->entityManager->getRepository('ApiBundle:User');
                $users = $entity->findBy(array('person' => $person_id)); // so far, Users have Persons, but Persons don't always have Users
                
                // if no matching users, try by email as well
                if(!count($users)) {
                     $users = $entity->findBy(array('email' => $person->getEmail1())); // so far, Users have Persons, but Persons don't always have Users
                }
                
                if(count($users)) {
                
                    // debug
                    // additional messages configured in twig: register_content.html.twig
                    $status_info = 'This account has been previously registered.<br />';  // prod;
                    $status_info .= 'You may be able to <a href="/">log in</a> with it.'; // prod;
                    //$status_info .= "\n\n" . 'User already exists (id or email).'; // dev
                    
                } else { // User not found: enable form, allowing new User to register
                        
                    $org_name = ((null !== $person->getOrg()) ? $person->getOrg()->getName() : '');
                    $name     = $person->getNameFirst() . ' ' . $person->getNameLast();
                    $email    = $person->getEmail1();
                    
                    $user = $event->getUser();
                    $user->setEmail($email);                   // enable form display in twig
                    $user->setPerson($person);                 // bind User to Person, as object
                    $user->setPersonId($person_id);            // bind User to Person, as id
                    $user->setRegisterName($name);             // for display on form
                    $user->setRegisterOrganization($org_name); // for display on form
                    
                    // debug
                    $status_info .= "\n\n" . 'User not found, so form enabled. '; // not displayed except as hover for 'Error' under this condition ('else')
                    
                }
            
            } else {
              
                // debug
                $status_info = 'Registration expired or not set up.';
                //$status_info .= "\n\n" . $status_info;
                
            }
            
        } else {
          
            // debug
            $status_info = 'Invalid Token';
            //$status_info = 'Person not found';
            
        }
        
        // debug
        // TODO: rename the function below to something like SetRegisterDebugError(), since we're not using programs
        $user->SetRegisterProgram($status_info);
        
        return $event;
    }
    
    /**
     * {@inheritdoc}
     *
     * Return array of event names this subscriber wants to listen to
     *
     * @return array
     *     array of event names => handlers
     */
    public static function getSubscribedEvents()
    {
        return array(
            FOSUserEvents::REGISTRATION_INITIALIZE => 'onRegistrationInitialize',
        );
    }

}