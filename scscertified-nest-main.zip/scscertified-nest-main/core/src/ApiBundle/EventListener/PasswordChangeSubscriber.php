<?php

namespace ApiBundle\EventListener;

use FOS\UserBundle\FOSUserEvents;
use FOS\UserBundle\Event\FormEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

/**
 * Event subscriber for password change event(s)
 */
class PasswordChangeSubscriber implements EventSubscriberInterface
{
    private $router;

    /**
     * Constructor
     *
     * @param object $router
     *     passed from service container (defined in services.yml)
     */
    public function __construct(UrlGeneratorInterface $router)
    {
        $this->router = $router;
    }

    /**
     * Return array of event names this subscriber wants to listen to
     *
     * @return array
     *     array of event names => handlers
     */
    public static function getSubscribedEvents()
    {
        return [
            FOSUserEvents::CHANGE_PASSWORD_SUCCESS => 'onPasswordChangeSuccess',
        ];
    }

    /**
     * Redirect to Nest home page after password change
     *
     * @param object $event
     *     the event object for the password change
     */
    public function onPasswordChangeSuccess(FormEvent $event)
    {
        $context = $this->router->getContext();
        $scheme    = $context->getScheme();
        $host      = $context->getHost();
        $http_port = $context->getHttpPort();
        $port = ($http_port == 80 ? '' : ':' . $http_port);
        $event->setResponse(new RedirectResponse("$scheme://$host$port/nest"));
        
        // Unfortunately, can't define a route that gets above or outside the Symfony web root,
        // which is always at /core. Nest home page is outside of that.
        //$url = $this->router->generate('homepage');
        //$event->setResponse(new RedirectResponse($url));
    }
}
