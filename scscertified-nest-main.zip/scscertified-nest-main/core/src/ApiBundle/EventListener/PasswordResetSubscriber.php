<?php

namespace ApiBundle\EventListener;

use FOS\UserBundle\FOSUserEvents;
use FOS\UserBundle\Event\FormEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Doctrine\ORM\EntityManager;

/**
 * Event subscriber for password change event(s)
 */
class PasswordResetSubscriber implements EventSubscriberInterface
{

    private $router;
    private $em;

    /**
     * Constructor
     *
     * @param object $router
     *     passed from service container (defined in services.yml)
     */
    public function __construct(UrlGeneratorInterface $router, EntityManager $em)
    {
        $this->router = $router;
        $this->em = $em;
    }

    /**
     * Return array of event names this subscriber wants to listen to
     *
     * @return array
     *     array of event names => handlers
     */
    public static function getSubscribedEvents()
    {
        return [
            FOSUserEvents::RESETTING_RESET_SUCCESS => 'onPasswordResetSuccess',
        ];
    }

    /**
     * Redirect to Nest home page after password change
     *
     * @param object $event
     *     the event object for the password change
     */
    public function onPasswordResetSuccess(FormEvent $event)
    {
        $context = $this->router->getContext();
        $scheme    = $context->getScheme();
        $host      = $context->getHost();
        $http_port = $context->getHttpPort();
        $port = ($http_port == 80 ? '' : ':' . $http_port);

        $path_info = explode("/", $context->getPathInfo()); //Split the path info
        $confirminationToken     = end($path_info);  // Get the last element which is the Token
        $em = $this->em;
        $query = $em->createQuery(
            "UPDATE ApiBundle:User u
             SET u.failureCount = 0,
                 u.lockoutExpirationTime = NULL
             WHERE u.confirmationToken = :confirminationToken"
        )->setParameter('confirminationToken', $confirminationToken);

        $user = $query->getResult();


        $event->setResponse(new RedirectResponse("$scheme://$host$port/nest"));
    }
}
