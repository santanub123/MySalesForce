<?php

namespace ApiBundle\EventListener;

use ApiBundle\Entity\Person;
use FOS\UserBundle\FOSUserEvents;
use FOS\UserBundle\Event\FormEvent;
use FOS\UserBundle\Event\FilterUserResponseEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

use Doctrine\ORM\EntityManagerInterface;


/**
 * Listener responsible to change the redirection at the end of the password resetting
 */
class RegistrationCompletedSubscriber implements EventSubscriberInterface
{
  
    private $entityManager;
    private $router;
    
    /**
     * Constructor
     *
     * @param object $router
     *     passed from service container (defined in services.yml)
     *
     * @param object $entityManager
     *     passed from service container
     */
    public function __construct(UrlGeneratorInterface $router, EntityManagerInterface $entityManager)
    {
        //$this->router = $router;
        $this->entityManager = $entityManager;
    }
    
    public function onRegistrationCompleted(FilterUserResponseEvent $event)
    {
        // propagate User to Person
        $em = $this->entityManager;
        $repo = $em->getRepository("ApiBundle:Person");
        $user = $event->getUser();
        $personEmail = $user->getEmail();
        $person = $repo->findOneBy(['email1' => $personEmail]);
        $user->setPerson($person);
        $person->setUser($user);
        $person->setActive(1);
        $person->setRegisterStatus(2);

    }
    
    /**
     * {@inheritdoc}
     *
     * Return array of event names this subscriber wants to listen to
     *
     * @return array
     *     array of event names => handlers
     */
    public static function getSubscribedEvents()
    {
        return array(
            FOSUserEvents::REGISTRATION_COMPLETED   => 'onRegistrationCompleted',
        );
    }

}