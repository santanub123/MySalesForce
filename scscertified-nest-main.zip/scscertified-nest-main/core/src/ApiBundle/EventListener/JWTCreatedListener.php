<?php

namespace ApiBundle\EventListener;

use Lexik\Bundle\JWTAuthenticationBundle\Event\JWTCreatedEvent;
use Symfony\Component\HttpFoundation\RequestStack;

    class JWTCreatedListener
    {
        /**
         * @var RequestStack
         */
        private $requestStack;

        /**
         * @param RequestStack $requestStack
         */
        public function __construct(RequestStack $requestStack)
        {
            $this->requestStack = $requestStack;
        }

        /**
         * @param JWTCreatedEvent $event
         *
         * @return void
         */
        public function onJWTCreated(JWTCreatedEvent $event)
        {
            // Symfony < 2.4
            //$request = $event->getRequest();

            // Symfony 2.4+
            $request = $this->requestStack->getCurrentRequest();

            $payload       = $event->getData();
            $payload['ip'] = $request->getClientIp(); // use for validation in JWTDecodedListener

            $event->setData($payload);
        }
    }