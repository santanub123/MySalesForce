<?php

namespace ApiBundle\EventListener;

use ApiBundle\Controller\PersonController;
use ApiBundle\Util\AccountManager;
use Doctrine\ORM\EntityManager;
use Lexik\Bundle\JWTAuthenticationBundle\Event\AuthenticationSuccessEvent;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;

class AuthenticationSuccessListener
{
    protected $em;

    function __construct($em) {
        $this->em = $em;
    }

    /**
     * @param AuthenticationSuccessEvent $event
     */
    public function onAuthenticationSuccess(AuthenticationSuccessEvent $event)
    {
        $code = null;
        $message = '';
        $count = null;
        $data = $event->getData(); // includes auth & refresh tokens
        
        $user = $event->getUser();
        if (!$user instanceof UserInterface) {
          
            // Currently, this test blocks this action even though our User class extends the FOSUB User class, 
            // which does implement UserInterface further back in its inheritance....So consider this a passing test for now. :<)
            
            //return;
        }
        
        $person = $user->getPerson();
        $person_id = null;
        $proxy_person = null;
        //$assignedroles = [];
        //$privileges = [];
        
        if (!empty($person)) { // this shouldn't fail -- a User, if found, should always have a Person
            $code = 200;
            $message = 'Authenticated';
            $count = 1;
            
            $person_id = $person->getId();
            $proxy_person = $person->getSelf();                  // a means of getting the instance hydrated, though doesn't yet pull in associations, and doesn't provide access to controller methods. Would FETCH_EAGER help this?
            $proxy_person['org'] = $person->getOrg()->getSelf(); // a means of getting the org instance hydrated
            
            // Experimental (see https://github.com/lexik/LexikJWTAuthenticationBundle/issues/424#issuecomment-352683341)
            //$serializer = new Serializer();
            //$assignedroles = $serializer->normalize($person->getAssignedroles(), \Symfony\Component\Serializer\Encoder\JsonEncoder::FORMAT);
            
            //$assignedroles = $person->getAssignedroles();
            
            // Experimental - call controller independently since no routing available in this context
            
            // Create new object out of whole cloth
            //$personController = new PersonController();
            //$privilegeroles = $personController->getPersonPrivilegerolesAllAction($person_id);
            
            // Or, use service to access Person controller
            //$privilegeroles = $person->('api.controller.person:getPrivilegerolesAll');
            
            // Or, use forwarding
            //$privilegeroles = $this->forward('ApiBundle.Person:getPrivilegerolesAll', array('id', $person_id));
            
            // remove unused bits
            unset($proxy_person['user']);
            unset($proxy_person['__initializer__']);
            unset($proxy_person['__cloner__']);
            unset($proxy_person['__isInitialized__']);
            unset($proxy_person['org']['__initializer__']);
            unset($proxy_person['org']['__cloner__']);
            unset($proxy_person['org']['__isInitialized__']);
            
        } else {
            $count = 0;
            $code = 402; // unprocessable entity (though there was no real HTTP error emitted)
            $message = 'Missing Person entity for User ' . $event->getUser()->getId() . '.';
        }
        
        $data['code']    = $code;
        $data['message'] = $message;
        $data['count']   = $count;
        $data['data'] = array(
            'person_id'     => $person_id,
            'person'        => $proxy_person,
            //'assignedroles' => $assignedroles,
            //'privileges' => $privileges,
        );
        
        // $data['token']   already contains the JWT
        // $data['refresh'] already contains the refresh token
        
        $am = new AccountManager($user);
        // This is where we prevent the token from having a value
        if ($am->isAccountLocked($user)) {
            // $data['isLocked'] = $am->isAccountLocked($user) ? "User is locked" : "User is not locked";
            $data['locked'] = true;
            $data['code']   = 418;
            $data['token'] = null;
            $data['message'] = 'Your account has been suspended until ' . $user->getLockoutExpirationTime()->format("Y-m-d / H:i:s") . ". Please try again later";
        } else {
            $user->setFailureCount(0); //it's a successful login and the user account isn't locked
            $user->setLockoutExpirationTime(NULL);
            $em = $this->em;
            $em->persist($user);
            $em->flush();
        }

        $event->setData($data);
    }
  
}