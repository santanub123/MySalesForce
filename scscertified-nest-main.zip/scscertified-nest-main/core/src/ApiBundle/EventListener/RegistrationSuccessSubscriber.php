<?php

namespace ApiBundle\EventListener;

use ApiBundle\Entity\Person;
use FOS\UserBundle\FOSUserEvents;
use FOS\UserBundle\Event\FormEvent;
use FOS\UserBundle\Event\FilterUserResponseEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

use Doctrine\ORM\EntityManagerInterface;

/**
 * Listener responsible to change the redirection at the end of the password resetting
 */
class RegistrationSuccessSubscriber implements EventSubscriberInterface
{
  
    private $entityManager;
    private $router;
    
    /**
     * Constructor
     *
     * @param object $router
     *     passed from service container (defined in services.yml)
     *
     * @param object $entityManager
     *     passed from service container
     */
    public function __construct(UrlGeneratorInterface $router, EntityManagerInterface $entityManager)
    {
        $this->router = $router;
        $this->entityManager = $entityManager;
    }
    
    public function onRegistrationSuccess(FormEvent $event)
    {
        // $person = $event->getForm()['person']->getData();
        // $person_id = $person->getId();
        // $user_id = '0';



        $form = $event->getForm();
        $person_id = $form->getData()->getPersonId();
        
        $em = $this->entityManager;
        $repo = $em->getRepository("ApiBundle:Person");
        $person = $repo->findOneById(['id' => $person_id]);
        
        $user_id = '0';
       
        /*
        if (empty($person_id)) {
          
            // this returns blank results, for some reason, but doesn't generate an error
            $token = $event->getRequest()->attributes->get('t');
            
            // manual method
            parse_str($event->getRequest()->getQueryString(), $get);
            $token = (isset($get['t']) ? $get['t'] : '');
            
            $entity_p = $this->entityManager->getRepository('ApiBundle:Person');
            $persons = $entity_p->findBy(array('registerToken' => $token));
            
            if(count($persons) === 1) {
            
                $person = $persons[0];
                $person_id = $person->getId() . '-';
                
            }
            
        }
                
        $entity_u = $this->entityManager->getRepository('ApiBundle:User');
        //$users = $entity_u->findBy(array('person' => $person));
        //$users = $entity_u->findByPerson($person_id);
        //$users = $entity_u->findBy(array('personId' => $person_id));
        
        // not finding any Users so far....
        
        if(count($users) === 1) {
          
            $user = $users[0];
            $user_id = $user->getId();
            
            $person->setUser($user);
        
        }
        
        //return $event;
        */
        
        // Redirect to Nest home/login (
        
        $context = $this->router->getContext();
        $scheme    = $context->getScheme();
        $host      = $context->getHost();
        $http_port = $context->getHttpPort();
        $port = ($http_port == 80 ? '' : ':' . $http_port);
        $event->setResponse(new RedirectResponse("$scheme://$host$port/nest"));
        //$event->setResponse(new RedirectResponse("$scheme://$host$port/nest/$person_id/$user_id"));
    }
    
    /**
     * {@inheritdoc}
     *
     * Return array of event names this subscriber wants to listen to
     *
     * @return array
     *     array of event names => handlers
     */
    public static function getSubscribedEvents()
    {
        return array(
            FOSUserEvents::REGISTRATION_SUCCESS  => 'onRegistrationSuccess',
        );
    }

}