<?php

/*
 *
 * This file overwrites the  onResettingResetSuccess to fix a bug enabling the user when they do a password reset
 *
 */

namespace ApiBundle\EventListener;

use FOS\UserBundle\EventListener\ResettingListener;
use FOS\UserBundle\Event\FormEvent;
use FOS\UserBundle\Event\GetResponseNullableUserEvent;
use FOS\UserBundle\FOSUserEvents;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class PasswordResettingListener extends ResettingListener
{
    private $router;
    private $request;
    private $username;

    /**
     * Constructor
     *
     * @param object $router
     *     passed from service container (defined in services.yml)
     */
    public function __construct(UrlGeneratorInterface $router)
    {
        $this->router = $router;
        $this->request = Request::createFromGlobals();
        $this->username = $this->request->get('username');
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return array(
            FOSUserEvents::RESETTING_SEND_EMAIL_INITIALIZE => 'onResettingSendEmailInitialize',
            FOSUserEvents::RESETTING_RESET_SUCCESS => 'onResettingResetSuccessful',
        );
    }

    /**
     * Check if the User is not enabled and exits; if so skip email by setting a new response
     * 
     * @param GetResponseNullableUserEvent $event
     */
    public function onResettingSendEmailInitialize(GetResponseNullableUserEvent $event)
    {
        if ($event->getUser() && !$event->getUser()->isEnabled()) {
            $event->setResponse(new RedirectResponse($this->router->generate('fos_user_resetting_check_email', array('username' => $this->username))));
        } else {
            return false;
        }
    }

    /**
     * Overrides onResettingResetSuccess from ResettingListener to not always set enabled = true
     * 
     * @param FormEvent $event
     */
    public function onResettingResetSuccessful(FormEvent $event)
    {
        /** @var $user \FOS\UserBundle\Model\UserInterface */
        $user = $event->getForm()->getData();

        $user->setConfirmationToken(null);
        $user->setPasswordRequestedAt(null);
    }
}