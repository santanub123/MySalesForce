These listeners respond to Events emitted by 3rd party bundles (LexikJWTBundle and FOSUserBundle so far) and add our own handling.

Custom listeners (that aren't overriding existing vendor/3rd party listeners) need to be registered in services.yml, too. (See https://symfony.com/doc/current/event_dispatcher.html)

They are not strictly necessary, out of the box, and most are simple copies of the existing vendor listeners. They will have to be reviewed on any significant upgrade to those bundles and/or the Symfony core.