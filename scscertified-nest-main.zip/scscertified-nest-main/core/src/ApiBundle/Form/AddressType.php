<?php

namespace ApiBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AddressType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id')
            ->add('active', null, ['empty_data' => 'Default value'])
            ->add('address')
            ->add('city')
            ->add('postalCode')
            ->add('isPrimary')
            ->add('stateIsoCode')
            ->add('stateRaw')
            ->add('state')
            ->add('countryIsoCode')
            ->add('countryRaw')
            ->add('country')
            ->add('dmsId')

            ->add('org')
            ->add('person')

            ->add('type', ChoiceType::class, array(
                      'choices' => array('main' => 'main', 'billing' => 'billing', 'shipping' => 'shipping'),
                      'choices_as_values' => true,
                      'placeholder' => 'Choose... (optional)',
                  ))
        ;
    }

    /**
     * #param OptionsResolverInterface $resolver
     * @param OptionsResolver $resolver
     */
    //public function setDefaultOptions(OptionsResolverInterface $resolver)
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'csrf_protection' => false,
                'data_class' => 'ApiBundle\Entity\Address',
            ]
        );
    }

    /**
     * @return string
     */
    //public function getName()
    public function getBlockPrefix()
    {
        // this is important in order to be able
        // to provide the entity directly in the json
        return '';
    }
}
