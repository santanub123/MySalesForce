<?php

namespace ApiBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;

// Symfony 2.8 dependencies
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

// symfony 3 dependencies
use Symfony\Component\OptionsResolver\OptionsResolver;

use ApiBundle\Entity\User;

class UserType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id')
            ->add('username')
            ->add('email')
            ->add('password')
            ->add('enabled')
            
            ->add('personId')
            ->add('person')
            
            // register_* are fields to support account request workflow -- not part of persisted entity
            ->add('registerName')
            ->add('registerOrganization')
            ->add('registerProgram')
            ->add('failureCount')
            ->add('lastLoginAttempt')
            ->add('lockoutExpirationTime')
        ;
    }
    
    // see http://symfony.com/doc/2.8/form/use_empty_data.html#option-2-provide-a-closure for reference

    /**
     * #param OptionsResolverInterface $resolver
     * @param OptionsResolver $resolver
     */
    //public function setDefaultOptions(OptionsResolverInterface $resolver)
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'csrf_protection' => false,
                'data_class' => 'ApiBundle\Entity\User',
            ]
        );
    }

    /**
     * @return string
     */
    //public function getName()
    public function getBlockPrefix()
    {
        // this is important in order to be able
        // to provide the entity directly in the json
        return '';
    }
}