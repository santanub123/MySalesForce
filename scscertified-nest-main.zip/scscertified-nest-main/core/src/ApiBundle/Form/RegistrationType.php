<?php

namespace ApiBundle\Form;

use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;


class RegistrationType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('registerName',         null, array('label' => 'Name'))
            ->add('registerOrganization', null, array('label' => 'Organization'))
            ->add('registerProgram',      TextareaType::class, array('label' => 'Program'))
            
            ->add('personId',               null, array('label' => 'Person'))
            ->add('person',               EntityType::class, array(
                            'class' => 'ApiBundle\Entity\Person',
                            'placeholder' => '',
                            'choice_label' => 'id',
                            //'extended' => false,
                            //'multiple' => false,
                            'query_builder' => function (\ApiBundle\Repository\PersonRepository $er) {
                                return $er->createQueryBuilder('p')
                                    ->orderBy('p.nameFirst', 'ASC');
                            },
                            
                            //'choices' => array(),
                            'attr'=> array('style'=>'display:none;visibility:hidden;'),
                            )
            )
            
        ;
        
        // from @Fabien Salles in https://stackoverflow.com/questions/35771945/choice-field-default-value
        /*
        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) {
            $form   = $event->getForm();
            $user   = $event->getData();
            //$person = $user->getPerson();
            $person = $user['person'];
            //$person = $form['person'];
            
            $form->add(
                'person', 
                EntityType::class,
                [
                    'class'    => 'ApiBundle\Entity\Person',
                    'expanded' => false,
                    'multiple' => false,
                    'choices'  => array($person),
                    'choices_as_values' => true,
                ]);
        });
        */
        
    }
    
    /**
     * #param OptionsResolverInterface $resolver
     * @param OptionsResolver $resolver
     */
    //public function setDefaultOptions(OptionsResolverInterface $resolver)
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            // some dev environments have trouble with the token, so disable locally if necessary (not in production!)
            // synchronize with disabling element 'form_widget(form._token)' in register_content.html.twig
            'csrf_protection' => false,
        ));
    }

    public function getParent()
    {
        //return 'fos_user_registration';
        return 'FOS\UserBundle\Form\Type\RegistrationFormType';
    }

    //public function getName()
    public function getBlockPrefix()
    {
        return 'api_user_registration';
    }
}