<?php

namespace ApiBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ApiType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            //->add('query') // enabling this adds to ApiDoc, even with no corresponding entity or entity property
            // Test fields for generic POST in Apidoc sandbox
            ->add('name')
            ->add('query')
            ->add('options')
            
            //->add('id')
            //->add('nameFirst')
            //->add('nameLast')
            //->add('notPartOfEntity')
            //->add('role') // might not be related to target entity
            ->addEventListener(FormEvents::PRE_SET_DATA, array($this, 'onPreSetData'))
        ;
        
        //$builder->addEventListener(FormEvents::PRE_SET_DATA, array($this, 'onPreSetData'));
        
        //$bundle = $options['bundle'];
        //$name = $options['name'];

    }
    
    public function onPreSetData(FormEvent $event)
    {
        $entity = $event->getData();
        $form = $event->getForm();

        // checks if the entity object is "new"
        // If no data is passed to the form, the data is "null".
        // This should be considered a new entity record (not an update or edit)
        //
        // This works for Apidoc sandbox, which is the purpose, and doesn't interfere with execution
        //
        // Now, how to load fields based on entity (name) itself?
        
        if (!$entity || null === $entity->getId()) { // should always be true on PRE_SET_DATA
            
            ////$form->add('org', OrgType::class); // this hard-coded action is obviously not what we want -- just shows the format
            
            //$class_name = get_class($entity);
            //$form_name = ucfirst($class_name) . '::class';
            ////$class_name = $entity->name;
            ////$form_name = ucfirst($name) . 'Type::class';
            ////$form->add($class_name, $form_name); // dynamic!
            
            //$entityName = $entity->__toString(); // not an object (see Person entity)
            //$entityType = $entityName . 'Type::class';
            //$form->add($entityName, $entityType); // $entity is null, so doesn't yet work
            
        }
    }

    /**
     * #param OptionsResolverInterface $resolver
     * @param OptionsResolver $resolver
     */
    //public function setDefaultOptions(OptionsResolverInterface $resolver)
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'csrf_protection' => false,
                'data_class' => 'ApiBundle\Entity\Api',
            ]
        );
    }

    /**
     * @return string
     */
    //public function getName()
    public function getBlockPrefix()
    {
        // this is important in order to be able
        // to provide the entity directly in the json
        return '';
    }
}