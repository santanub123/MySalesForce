<?php

namespace ApiBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ProgramType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id')
            ->add('scsId')
            ->add('name')
            ->add('description')
            ->add('department')
            ->add('active', null, ['empty_data' => 'Default value'])
        ;
    }

    /**
     * #param OptionsResolverInterface $resolver
     * @param OptionsResolver $resolver
     */
    //public function setDefaultOptions(OptionsResolverInterface $resolver)
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'csrf_protection' => false,
                'data_class' => 'ApiBundle\Entity\Program',
            ]
        );
    }

    /**
     * @return string
     */
    //public function getName()
    public function getBlockPrefix()
    {
        // this is important in order to be able
        // to provide the entity directly in the json
        return '';
    }
}
