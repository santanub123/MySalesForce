<?php

namespace ApiBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PersonType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id')
            ->add('scsUserId')
            ->add('active', null, ['empty_data' => 'Default value'])
            ->add('dmsId')
            ->add('nameHonorific')
            ->add('nameFirst',
                    TextType::class,
                    array('required' => true,))
            ->add('nameMiddle')
            ->add('nameLast',
                    TextType::class,
                    array('required' => true,))
            ->add('title')
            ->add('email1',
                    TextType::class,
                    array('required' => true,))
            ->add('phone')
            ->add('phoneRaw')
            ->add('phoneCell')
            ->add('phoneCellRaw')
            ->add('imageFile')
            ->add('isManager')
            ->add('arsCocTeamId')
            //->add('arsTeamId') // migrate to this, for better generality
            ->add('startDate',
                    DateType::class,
                    array(
                        'widget' => 'single_text',
                        'format' => 'yyyy-MM-dd'
                    )
                )
            ->add('endDate',
                    DateType::class,
                    array(
                        'widget' => 'single_text',
                        'format' => 'yyyy-MM-dd'
                    )
                )
            ->add('registerStatus')
            ->add('registerToken')
            ->add('registerTokenStartDate',
                    DateType::class,
                    array(
                        'widget' => 'single_text',
                        'format' => 'yyyy-MM-dd HH:mm:ss'
                    )
                )
            ->add('registerTokenDuration')

            ->add('org') // required, but enforced in Person entity by validation, and Doctrine FK constraint
            ->add('user')
            ->add('manager')
            ->add('team')

            ->add('addresses')
            ->add('assignedroles')
            
            //->add('name')
            ->addEventListener(FormEvents::POST_SET_DATA, function (FormEvent $event) {
                
                $person = $event->getData();
                $form = $event->getForm();
                
                ////unset($person->name); // 'name' is a generated column in MySQL, so we avoid including it in submission (esp. POST)
                //$form->get('name')->setData(`DEFAULT`); // allowed value for generated column in MySQL
                //$event->setData($person);
              
            })

        ;
    }

    /**
     * #param OptionsResolverInterface $resolver
     * @param OptionsResolver $resolver
     */
    //public function setDefaultOptions(OptionsResolverInterface $resolver)
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'csrf_protection' => false,
                'data_class' => 'ApiBundle\Entity\Person',
            ]
        );
    }

    /**
     * @return string
     */
    //public function getName()
    public function getBlockPrefix()
    {
        // this is important in order to be able
        // to provide the entity directly in the json
        return '';
    }
}
