<?php

namespace ApiBundle\Security;

use Doctrine\ORM\EntityManager;
use Lexik\Bundle\JWTAuthenticationBundle\Encoder\JWTEncoderInterface;
use Lexik\Bundle\JWTAuthenticationBundle\TokenExtractor\AuthorizationHeaderTokenExtractor;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Exception\CustomUserMessageAuthenticationException;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Guard\AbstractGuardAuthenticator;

class JwtTokenAuthenticator extends AbstractGuardAuthenticator
{

    private $jwtEncoder;
    private $em;
    
    public function __construct(JWTEncoderInterface $jwtEncoder=null, EntityManager $em=null)
    {
        $this->jwtEncoder = $jwtEncoder;
        $this->em = $em;
    }
    
    public function getCredentials(Request $request)
    {
        
        if(!$request->headers->has('Authorization')) {
            return;
        }
        
        $extractor = new AuthorizationHeaderTokenExtractor(
            'Bearer', // prefix
            'Authorization' // header
        );
        
        $token = $extractor->extract($request);
        
        if (!$token) {
            return;
        }
        
        return $token;
    }
    
    public function getUser($credentials, UserProviderInterface $userProvider)
    {
        
        $data = $this->jwtEncoder->decode($credentials);
        
        if ($data === false) {
            throw new CustomUserMessageAuthenticationException('Invalid Token');
        }
        
        $username = $data['username'];
        
        $username = $data['username'];

        $user = $this->em->getRepository('ApiBundle:User')
            ->findOneBy(['username' => $username]);

        if(!$user){
            return;
        }

        return $user;
            
    }
    
    public function checkCredentials($credentials, UserInterface $user)
    {
        return true;
    }
    
    public function onAuthenticationFailure(Request $request, AuthenticationException $exception)
    {
        return new JsonResponse([
            'message' => $exception->getMessage()
        ], 401);
    }
   
    public function onAuthenticationSuccess(Request $request, TokenInterface $token, $providerKey)
    {
        // do nothing - let the controller be called.
    }
    
    public function supportsRememberMe()
    {
        return false; // we're not supporting this for API access (we're stateless)
    }
    
    public function start(Request $request, AuthenticationException $authException = null)
    {
        // avoid the default redirect to the web login form by returning an http response instead
        return new JsonResponse([
            'error' => 'auth required'
        ], 401);
    }

}
