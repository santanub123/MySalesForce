<?php

/* KAREN's LIST OF WANTED CHANGES:
 *
 * - TO DO CLASS:
 *          Review class properties & remove unused ones
 * - TO DO CLASS:
 *          Clean up commented out code and unnecessary debugging code.
 * - TO DO CLASS:
 *          Remove all code that has knowledge of entity structure. Specifically, I'm thinking of:
 *          - special user status handling (could go in the user controller, which would call this)
 *          - phone number handling (could this go in entities?)
 * - TO DO CLASS:
 *          processOptions, mergeOptionsAction and setOptions do almost the same things, but to
 *          accommodate different paths (setOptions are for get calls, mergeOptionsAction are for
 *          change. processOptions is used in places where a static function is desired, but I
 *          think we want to eliminate that capability).
 * - TO DO CHANGE FUNCTIONS:
 *          Put does not normalize phone numbers (post and patch do)
 * - TO DO CLASS:
 *          Standardize how defaults are set. Either have them in the constructor OR special functions.
 * - TO DO CHANGE FUNCTIONS:
 *          Post/Put/Patch/Delete are 90% identical. Standardize them. There is some limitation to
 *          this. (Vincent says: POST is slightly different because the entity instance is derived
 *          from the formType rather than from a found record. DELETE starts similarly to POST
 *          (though gets the $id from a parameter rather than the found record), but difference in
 *          its action thereafter. So...there's a little consolidation that could happen, but it's
 *          not obvious to me it's worth the effort.) *
 * - TO DO CHANGE FUNCTIONS:
 *          Post/Put/Patch each have a code block for handling boolean inputs. Can that be a function?
 * - TO DO CHANGE FUNCTIONS:
 *          Post/Put/Patch/Delete should be standardized with GET functions.
 * - TO DO QUERY FUNCTION:
 *          Can we provide "info" functions that return field or relationships of an entity?
 *
 * - Q. What are the static functions for? Are they properly integrated with the rest of the class?
 * - Q. Delete takes the id as part of the url, but put and patch as part of the query parameter.
 *      This is not intuitive to me.
 * - Q. The use of private/public/protected categories is inconsistent. Some things need to be
 *      public, some things need to be protected for unit testing (unless we find a better method).
 *      But some properties and function designations as public seem to be random.
 * - Q. The use of class properties vs. variables passed to function is inconsistent, and perhaps not ideal.
 */


namespace ApiBundle\Controller;

use \Doctrine\ORM\Query\QueryException;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
use FOS\RestBundle\Controller\Annotations\Post; // to amend route for a particular method
use FOS\RestBundle\Controller\Annotations\Put; // to amend route for a particular method
use FOS\RestBundle\Controller\Annotations\Patch; // to amend route for a particular method
use FOS\RestBundle\Controller\Annotations\Delete; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

// line below is only for experimental bypassing of JMSSerializer
//use Symfony\Component\HttpFoundation\JsonResponse;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;
//use Symfony\Component\Validator\ConstraintViolationList;
//use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Misd\PhoneNumberBundle\Validator\Constraints\PhoneNumber as AssertPhoneNumber;

//class ApiController extends Controller
class ApiController extends FOSRestController
{

    // Constants
    const ENTITY_STATUS_INACTIVE_ONLY = 0;
    const ENTITY_STATUS_ACTIVE_ONLY   = 1;
    const ENTITY_STATUS_ALL           = 2;

    // Query properties, SET BY CONSTRUCTOR (in use)
    private   $changeDefaults            = array(); // see constructor
    private   $default_options           = array(); // see constructor
    private   $allowed_operators         = array(); // see constructor
    private   $allowed_logical_operators = array(); // see constructor

    // static properties (for static methods, used externally without instantiating class)
    private static $defaults = array();

    // Supports filtering by related entity field (non-DQL only)
    private $r_record = null;
    private $r_entity = '';
    private $r_field  = '';
    private $r_value  = '';
    private $r_error  = '';

    // Error capture
    private $errors = array(); //SHOULD BE REMOVED WITH REFACTORING
    private $debug = array();

    // Query Properties - derived directly from input (set either at the beginning of unpackInput() or performQuery() or both)
    protected $input_bundle;
    protected $input_entity;
    protected $input_query;
    protected $input_options;

    // Query Properties - derived indirectly from input
    protected $merged_options;
    protected $parameter_values = array();

    // Response properties
    protected $error_found = false;
    protected $response_data = null;
    protected $response_count = null;
    protected $response_code = Response::HTTP_EXPECTATION_FAILED;
    protected $response_message = array();
    protected $response_validations = array();
    protected $response_debug_message = array();

    // Privilege ids with write access (PUT, PATCH, POST).
    private $privileges_with_write_access = [];

    // Privilege ids with DELETE access.
    private $privileges_with_delete_access = [];

    public function __construct()
    {

        $this->changeDefaults = array(
                'bundle' => 'ApiBundle',
            );
        $this->default_options = array(
                'debug'  => [],                                    // first to avoid undeclared var errors; normally empty
                // enable line below and individual elements as needed
                //'debug'  => [0,'','',0,0,0,0,0,'dql',0,0,0,0,0,0,'','','params','validateQuery'], // strings usually are var or function name

                // core
                'bundle' => 'ApiBundle',
                'status' => self::ENTITY_STATUS_ACTIVE_ONLY, // 0,1,2:
                                                             //   0 = inactive only,
                                                             //   1 = active only,
                                                             //   2 = both / all,

                // Flatter variation of DQL options (replaces deprecated version)
                'flat_result'        => 0,  // return simple array vs. full object graph
                'include_entities'   => [], // return related entities (non-associative array)
                'include_properties' => [], // return only properties specified (non-associative array)
                'order_by'           => [], // order results by entity.property; defaults are in entity property annotations; associative array (JSON object on input)
                'group_by'           => [], // group results by entity.property; defaults are in entity property annotations; associative array (JSON object on input)
                'dql_operators'      => [], // use various operators; associative array (JSON object on input)

                // Pagination (requires DQL)
                'start' => '0', // 0-indexed
                'size'  => '0', // 0 = unlimited
            );

        // List derived from https://dev.mysql.com/doc/refman/5.7/en/comparison-operators.html
        // Not included (but could be in future updates):
        //     [not] between,
        //     coalesce(),
        //     greatest(),
        //     interval(),
        //     isnull(), (different from IS NULL)
        //     least(),
        //     strcmp()
        $this->allowed_operators = array( // default is first member ('[0]')
                '='                    => 1,
                '<'                    => 1,
                '<='                   => 1,
                '>'                    => 1,
                '>='                   => 1,
                '!='                   => 1,
                '<>'                   => 1,
                'LIKE'                 => 1,
                'NOT LIKE'             => 1,
                'IS NULL'              => 1,
                'IS NOT NULL'          => 1,
                'IN'                   => 1,
                'NOT IN'               => 1,
                'BETWEEN'              => 1,
            );

        $this->allowed_logical_operators = array( // default is first member ('[0]')
                'AND'     => 1,
                'OR'      => 1,
                'NOT'     => 1,
                'AND NOT' => 1,
                'OR NOT'  => 1,
            );

        /* Set lists of privileges with write and delete access (may eventually
         * want to put this into database).
         */

        $this->privileges_with_write_access = [
            1,        // UMS Super Admin
            2,        // UMS Auditor Admin
            41,       // UMS Staff Admin
            51,       // Manage Auditors
            59,       // Manage Partner Staff'
            61,       // Manage Clients'
        ];

        $this->privileges_with_delete_access = [
            1,        // UMS Super Admin
            2,        // UMS Auditor Admin
            41,       // UMS Staff Admin
            51,       // Manage Auditors
            59,       // Manage Partner Staff'
            61,       // Manage Clients'
        ];
    }



    /*** BEGIN Helper methods ***/



    /*** BEGIN Static Functions ***/

    /**
     *
     */
    public static function getDefaults()
    {
        return self::$defaults;
    }

    /**
     * For use in static processOptions($options), as external invocation
     */
    public static function setDefaults()
    {
        // TODO: merge this static array with array from constructor (to avoid maintaining 2 copies of defaults), until constants can be arrays in PHP 7
        self::$defaults = [
            'bundle'               => 'ApiBundle',
            'status'               => self::ENTITY_STATUS_ACTIVE_ONLY,


            // DQL
            'flat_result'      => 0,

            // not yet used in any referencing functions
            'include_entities' => [], // return related entities (non-associative array)
            'order_by'         => [], // order results by entity.property; defaults are in entity property annotations; associative array (JSON object on input)
            'group_by'         => [], // group results by entity.property; defaults are in entity property annotations; associative array (JSON object on input)
            'operators'        => [], // use various operators; associative array (JSON object on input)

            // debug
            'debug'  => false,

        ];
    }

    /**
     * Process options parameter and merge with defaults
     * (Accessed from outside this class (e.g.
     *     as 'ApiController::processOptions($options)'
     *     in PersonController))
     *
     * @param string $options
     *     JSON-encoded options
     *
     * @return array
     *     associative array of option name-value pairs
     */
    public static function processOptions($options)
    {
        /*
        $defaults = [
            'bundle'         => 'ApiBundle',
            'status'         => self::ENTITY_STATUS_ACTIVE_ONLY,
            'flat_result'    => 0,
            'debug'          => false,
        ];
        */

        self::setDefaults(); // allowed keys
        $merged_options = self::$defaults;
        if (is_string($options)) {
            $options = str_ireplace('{options}','{}',$options); // handle default from doc/sandbox page
            $options_arr = json_decode($options, true);
            if (is_array($options_arr)) {
                $options_arr = self::undeprecateOptions($options_arr);

                // Force certain options to integer type.
                array_walk(
                    $options_arr,
                    function (&$value, $key) {
                        if (in_array(
                            $key,
                            ['status', 'flat_result']
                        )) {
                            $value = (int) $value;
                        }
                    }
                );

                $merged_options = array_merge(
                    $merged_options,
                    $options_arr
                );
                // NOTE: this allows unkeyed values to creep into $option, rather than being restricted to keys in $defaults
            } else {
                error_log(
                    __FILE__ . ':' . __LINE__ . ': ' . __METHOD__ .
                    ": Invalid JSON:'$options'"
                );
            }
        }
        return $merged_options;
    }

    /*** END Static Functions ***/



    /*** BEGIN Class Variable Helpers ***/

    public function getAllowedOperators()
    {
        return $this->allowedOperators;
    }

    /*
     * At some point, it will be good if these functions can handle both entity names (as used by
     * the bundles) and entity aliases (as used in the dql call). Right now, only the input_entity
     * uses an alias (e), so it's not worth the effort.
     *
     */

    /**
     * Takes a string that represents either a property or an entity.property name, and returns
     * the entity.property name. If the entity is not included, it adds 'e.property' which is the
     * alias of the primary entity.
     *
     * @param $inputProperty Expect string
     *
     * @return string
     */
    public function getEntityPropertyName($inputProperty)
    {
        if(strpos($inputProperty, ".") === false)
            return "e." . $inputProperty;
        else
            return $inputProperty;
    }

    /**
     * Takes a string which includes a property name, possibly proceeded by an entity name,
     * possibly succeeded by an alias name, and returns the entity name and property name. Also,
     * if the string included an alias, that is included. If the string needs an alias (because it
     * is from a related entity), it creates one and adds it.
     *
     * @param $inputProperty Expect string
     *
     * @return string
     */
    public function getEntityPropertyAliasName($inputProperty)
    {
        if(strpos($inputProperty, ".") === false)
            return "e." . $inputProperty;
        else{
            if(strpos($inputProperty, " as ") === false)
                return $inputProperty . " as " . str_replace(".", "_", $inputProperty);
            else
                return $inputProperty;
        }
    }

    /**
     * Takes a string that represents either a property or an entity.property name, and returns
     * the property name. It does this by determining whether the entity name is included, and
     * removing it if it is.
     *
     * @param $inputProperty Expect string
     *
     * @return string
     */
    public function getPropertyName($inputProperty)
    {
        if(strpos($inputProperty, ".") === false)
            return $inputProperty;
        else
            return substr($inputProperty, strrpos($inputProperty, ".") + 1);
    }

    /**
     * Takes a string that represents either a property or an entity.property name, plus an
     * optional default entity. It returns the entity name of the property. If the given string
     * includes the entity, it returns that. If the given string does not include the entity, it
     * uses the supplied default entity. If no default entity is specified, it uses the
     * input_entity of the object.
     *
     * @param $inputProperty Expect string
     *
     * @return string
     */
    public function getEntityName($inputProperty, $defaultEntity = null)
    {
        if($defaultEntity === null)
            $defaultEntity = $this->input_entity;

        if(strpos($inputProperty, ".") === false)
            return $defaultEntity;
        else
            return substr($inputProperty, 0, strrpos($inputProperty, "."));
    }

    /**
     * Takes a string that represents an included entity. It should be in the form of:
     *      {relatedEntity.}Entity {as aliasEntity}
     * RelatedEntity is optional and is the name of the entity that this entity is related to.
     *
     * Returns the name of the entity alias (if used) or the entity, without the anchor entity.
     *
     * @param $inputProperty Expect string
     *
     * @return string
     */
    public function getAliasOfEntityName($inputEntity){
        $entityAlias = $inputEntity;
        if(strpos($inputEntity, " as ") !== false){
            $entityAlias = substr($inputEntity, strpos($inputEntity, " as ") + 4);
        }
        elseif(strpos($inputEntity, ".") !== false){
            $entityAlias = substr($inputEntity, strpos($inputEntity, ".") + 1);
        }

        return $entityAlias;
    }

    /**
     * Takes a string that represents an included entity. It should be in the form of:
     *      {relatedEntity.}Entity {as aliasEntity}
     * RelatedEntity is optional and is the name of the entity that this entity is related to.
     * When omitted, it's assumed it is directly related to the primary entity of the query.
     *
     * Entity is the entity that should be included in the query.
     *
     * AliasEntity is an alias that the entity will be referred to as, and should be returned as.
     *
     * This script returns the string anchorEntity.Entity entityAlias.
     *
     * If no anchor entity is input, 'e' will be returned as the anchor.
     * If no alias is input, the name of entity will be used.
     *
     * @param $inputProperty Expect string
     *
     * @return string
     */
    public function getAnchorEntityAlias($inputEntity){
        $entity = $inputEntity;
        $anchorEntity = 'e';
        if(strpos($entity, ".") !== false){
            $anchorEntity = substr($entity, 0, strpos($entity, "."));
            $entity = substr($entity, strpos($entity, ".") + 1);
        }
        $entityAlias = $entity;
        if(strpos($entity, " as ") !== false){
            $entityAlias = substr($entity, strpos($entity, " as ") + 4);
            $entity = substr($entity, 0, strpos($entity, " as "));
        }

        return $anchorEntity . "." . $entity . " " . $entityAlias;
    }

    /*** END Class Variable Helpers ***/



    /*** BEGIN Deprecation Handling Functions ***/

    /**
     * If options includes deprecated elements, change them to the up-to-date style
     * (I'm moving this to a separate function as I suspect it may change and be added to, and this
     * keeps the calling code cleaner)
     *
     * @param $options Expect array
     *
     * @return array $options
     */
    protected static function undeprecateOptions($options)
    {
        if(isset($options['dql'])) { //This was changed from an embedded array to separate elements of the main options array
            foreach($options['dql'] as $k => $v){
                $options['dql_' . $k] = $v;
            }
            unset($options['dql']);
        }
        if(isset($options['dql_use'])) //Non-dql queries are not part of the main query function anymore, so this is obsolete (but still in calling code)
            unset($options['dql_use']);
        foreach($options as $optionName => $optionValue){ //Some options have been renamed
            $newOptionName = self::undeprecateOptionName($optionName);
            if($optionName !== $newOptionName){
                $options[$newOptionName] = $options[$optionName];
                unset($options[$optionName]);
            }
        }

        return $options;
    }

    /**
     * Review an option name and, if it has been replaced by a new name, return that name
     *
     * @param $optionName Expect String
     *
     * @return string $optionName
     */
    protected static function undeprecateOptionName($optionName){
        $renamed_dql_options = array('dql_flat_result', 'dql_include_entities', 'dql_include_properties', 'dql_order_by', 'dql_group_by');
        if(in_array($optionName, $renamed_dql_options))
            $optionName = substr($optionName, 4);
        return $optionName;
    }

    /**
     * Convert deprecated style of query parameters to the new style
     *     OLD STYLE: {"propertyName" => "propertyValue"} (with special operators in stored in options)
     *     NEW STYLE: [[propertyName, operator, propertyValue], "logicalJoinOperator", ["sub query array"]]
     *
     * @param array $queryArray
     *     original query to be converted
     *
     * @param array $dql_operators
     *     original set of special operators
     *
     * @return array
     *     indexed multi-dimensional array of the query in the new style
     */
    protected function undeprecateQuery($queryArray)
    {
        $dql_operators = $this->merged_options['dql_operators'];

        $operator_helpers = array(
            'LIKE'        => ['wildcard' => true],
            'NOT LIKE'    => ['wildcard' => true],
            'IN'          => ['array'    => true],
            'NOT IN'      => ['array'    => true],
            'BETWEEN'     => ['array'    => true],
            'IS NULL'     => ['solo'     => true],
            'IS NOT NULL' => ['solo'     => true],
        );

        $newArray = array();

        foreach($queryArray as $paramField => $paramValue){
            if(count($newArray) >= 1)
                $newArray[] = "AND";
            $paramOperator = "=";
            $includeValue = true;
            if(array_key_exists($paramField, $dql_operators)){
                $paramOperator = strtoupper($dql_operators[$paramField]);
                //APPLY OLD STYLE CONVENTIONS OF MASSAGING INPUT
                /*Remove parameter if operator is not expecting it. (Old structure queries required a parameter, even when it wasn't used.  New style do not want it included).*/
                if(isset($operator_helpers[$paramOperator]['solo']))
                    $includeValue = false;
                /*If the operators is expecting an array, and the parameter is not, make it an array.*/
                if(isset($operator_helpers[$paramOperator]['array']) && !is_array($paramValue))
                    $paramValue = array($paramValue);
                /*If the operators used to insert wildcards, reinsert them*/
                if(isset($operator_helpers[$paramOperator]['wildcard'])){
                    $paramValue = '%' . $paramValue . '%';
                }
            }
            if($includeValue)
                $newParam = array($paramField, $paramOperator, $paramValue);
            else
                $newParam = array($paramField, $paramOperator);
            $newArray[] = $newParam;
        }

        return $newArray;
    }

    /**
     * Checks input query to see if it's in the deprecated style or the new style
     *     OLD STYLE: {"propertyName" => "propertyValue"} (with special operators in stored in options)
     *     NEW STYLE: [[propertyName, operator, propertyValue], "logicalJoinOperator", ["sub query array"]]
     * This errs on the side of strict. If a query does not meet the standards for the deprecated
     * style AND the new style, it will fail with an error message later in the script.
     *
     * @param array $queryArray
     *     original query to be evaluated
     *
     * @return bool
     *     true if the deprecated style, false otherwise
     */
    protected function isDeprecatedQuery($queryArray)
    {
        $isDeprecatedQuery = true;

        if(!is_array($queryArray))
            $isDeprecatedQuery = false; //Input is not an array
        else{
            if(count($queryArray) < 1)
                $isDeprecatedQuery = false; //Input array is empty
            foreach($queryArray as $k => $v){
                if(!is_string($k))
                    $isDeprecatedQuery = false; //Key is not a string (array is not an associative array)
                if(is_array($v)){ //If the value is an array, the array is not more than 1 dimensional (used for IN clauses for example)
                    foreach($v as $i){
                        if(is_array($i))
                            $isDeprecatedQuery = false;
                    }
                }
            }
        }

        return $isDeprecatedQuery;
    }

    /*** END Deprecation Handling Functions ***/



    /*** BEGIN Validation and Input Process Functions ***/

    /**
     * Clears all class properties that may be modified as part of query process. This should be
     * run at the start of public query functions prior to unpacking the input. The goal is to
     * prevent variables leaking between multiple queries on a single ApiController object.
     *
     */
    private function clearProperties()
    {
        // Error capture
        $this->errors = array();
        $this->debug = array();

        // Query Properties - derived directly from input (set either at the beginning of performQuery() or unpackInput() or both)
        $this->input_entity = "";
        $this->input_query = array();
        $this->input_options = array();

        // Query Properties - derived indirectly from input
        $this->merged_options = array();
        $this->parameter_values = array();

        // Response properties
        $this->error_found = false;
        $this->response_data = null;
        $this->response_count = null;
        $this->response_code = Response::HTTP_EXPECTATION_FAILED;
        $this->response_message = array();
        $this->response_validations = array();
        $this->response_debug_message = array();
    }

    /**
     * Take input strings, decode json strings, and validate
     *
     * @param $name Expect string
     * @param $query Expect string (json encoded array)
     * @param $options Expect string (json encoded array)
     *
     */
    public function unpackInput($entityName, $query, $options)
    {
        //REMOVE SANDBOX INPUT
        $entityName = $this->accommodateSandboxInput($entityName, '{name}',    '');
        $options    = $this->accommodateSandboxInput($options,    '{options}', '{}');
        $query      = $this->accommodateSandboxInput($query,      '{query}',   '{}');

        //DECODE & VALIDATE JSON
        $options = $this->validateJsonInput('options', $options);
        $query = $this->validateJsonInput('query', $query);

        //SET CLASS VARIABLES
        $this->setEntity($entityName);
        $this->setOptions($options);
        $this->setQuery($query);
    }

    /**
     * The sandbox may input a field name instead of a field value. If that is the case, replace
     * with an appropriate blank value.
     *
     * @param $value The value that is input
     * @param $expectedSandboxInput What the sandbox will input if it uses the field name instead of value
     * @param $defaultValue The appropriate blank value for the field if the field name is input (a blank string or an empty array for example)
     *
     * @return mixed
     *     a value that can be used in the query (either the original value or a blank value)
     */
    public function accommodateSandboxInput($value, $expectedSandboxInput, $defaultValue){
        if($value === $expectedSandboxInput)
            $vaule = $defaultValue;
        return $value;
    }

    /**
     * Validate and decode supplied query parameters
     *
     * @param $name Expect string
     * @param $test Expect string
     *
     * @return array $parameter
     */
    public function validateJsonInput($inputName = "blank", $inputValue = null)
    {
        $error = false;

        if (is_string($inputValue)) {
            if ($inputValue) { // non-empty; should be JSON

                $decoded_test = json_decode($inputValue, true); // return array

                // protect against bad JSON
                if (is_array($decoded_test)) {
                    $inputValue = $decoded_test;
                }
                else {
                    $error = true;
                }

            } // else, let it go (leave $error == false). This can happen if no $options were submitted, which happens when they're not included in the referring endpoint
        }
        else {
            $error = true;
        }

        if ($error) {
            $this->setError("Invalid \$$inputName supplied. \$$inputName: " . $inputValue);
            $inputValue = false;
        }

        return $inputValue;
    }

    /**
     * Validate and decode supplied query parameters
     *
     * @param $name Expect string
     * @param $test Expect string
     *
     * @return array $parameter
     */
    public function validateJsonInput_2($name = "blank", $test = null)
    {

        $error = false;
        $code  = 0;

        if (is_string($test)) {

            if ($test) { // non-empty; should be JSON

                if ($test == '{' . $name . '}') { // accommodate sandbox defaults (.e.g, '{options}')
                    $test = '{}';
                }

                $decoded_test = json_decode($test, true); // return array

                // protect against bad JSON
                if (is_array($decoded_test)) {
                    $test = $decoded_test;
                }
                else {
                    $error = true;
                    $code  = 1;
                }

            } // else, let it go (leave $error == false). This can happen if no $options were submitted, which happens when they're not included in the referring endpoint
        }
        else {
            $error = true;
            $code  = 2;
        }

        if ($error) {
            $this->errors[] = "($code) Invalid \$$name supplied. \$$name: " . $test;
            $test = false;
        }

        return $test;
    }

    /**
     * Sets the class input_entity value after correcting the capitalization
     *
     * @param $entityName the entity name that has been supplied
     */
    public function setEntity($entityName){
        // make input case-insensitive (controller name matching)
        $this->input_entity = ucfirst(strtolower($entityName));
    }

    /**
     * Merge default options with submitted options
     *
     * @param $options the options supplied to the class
     *
     */
    public function setOptions($options)
    {
        $this->input_options = $options; //Only used to supply error and debugging messages
        $this->merged_options = $this->default_options;

        if(!$this->error_found){
            if(is_array($options)) {
                $options = self::undeprecateOptions($options);
                foreach($options as $optionName => $optionValue){
                    $this->setOption($optionName, $optionValue);
                }
            }
        }
    }

    /**
     * Merge default options with submitted options
     *
     * @return array $defaults
     * #return array($defaults, $options, $error)
     */
    public function mergeOptionsAction($defaults=array(), $options=null)
    {
        // Requires 'Action' suffix so references to 'ApiBundle:Api:mergeOptions' work outside this controller

        // Default defaults
        if(empty($defaults)) {
            //$defaults = $this->defaults;
            self::setDefaults();
            $defaults = self::defaults;
        }
        else {
            // TODO: merge with private $defaults so no keys are missing
        }

        $errors = array();
        if($options == '{options}') $options = '{}'; // accommodate input from ApiDoc sandbox when 'options' field is blank

        // sanitize options
        $options = $this->validateJsonInput_2("options", $options);
        if($options !== false){
            $options = self::undeprecateOptions($options);
            if(is_array($options)) {  //TO DO - this shouldn't be necessary since validateJsonInput also checks that options are an array, but I'm not sure what the consequence of a blank options is
                foreach($options as $k => $v){
                    if(isset($defaults["$k"])) {
                        $defaults["$k"] = $options["$k"];
                    }
                    else{
                        $errors[] = "ERROR WITH OPTIONS: Supplied option '" . $k . "' is not an allowed option.";
                    }
                }
            }
            if(count($errors) === 0){
                return $defaults;
            }
            else{
                $errorMessage = implode(". ", $errors);
                $this->setError($errorMessage);
                $this->errors[] = $errorMessage;
                return false;
            }
        }
        else{
            return false;
        }
    }

    /**
     * Validate and then set the input option in the merged options list. If the optionName
     * doesn't represent a valid option, return false.
     *
     * @param $optionName Expect string
     * @param $optionValue
     *
     * @return bool $results
     */
    public function setOption($optionName, $optionValue)
    {
        $results = true;

        $optionName = self::undeprecateOptionName($optionName);
        if(!isset($this->merged_options[$optionName])){
            $this->setError("Error: $optionName is an invalid option.");
            $results = false;
        }
        else{
            $this->merged_options[$optionName] = $optionValue;
        }

        return $results;
    }

    /**
     * Validate and then add an option to the existing merged options list. If the optionName
     * doesn't represent a valid option, return false. If the option in question is a single value,
     * set that option to the new value. If the option is an array, add the new value(s) to the
     * array, putting the new values first. If the new option and old option are associative arrays
     * with conflicting keys (as could be the case with order_by), use the values from the new array.
     *
     * @param $optionName Expect string
     * @param $optionValue
     *
     * @return bool $results
     */
    public function addOption($optionName, $optionValue)
    {
        $optionName = self::undeprecateOptionName($optionName);

        if(isset($this->merged_options[$optionName])){
            if(is_array($this->merged_options[$optionName])){
                if(!is_array($optionValue)){
                    $optionValue = array($optionValue); //If a single value is submitted to an array option, turn it into an array
                }
                /* Merge the old option array and the new option
                 *     Why is this custom steps instead of an array_merge?
                 *     The option's new array needs to list the added values first, the pre-existing values
                 *     second. Also, if they are associative arrays, and a key is shared by each array,
                 *     the added option's value needs to be used. */
                $oldOptionValue = $this->merged_options[$optionName];
                foreach($oldOptionValue as $optionItemKey => $optionItemValue){
                    if(is_int($optionItemKey))
                        $optionItemKey = count($optionValue);
                    if(!isset($optionValue[$optionItemKey]))
                        $optionValue[$optionItemKey] = $optionItemValue;
                }
            }
        }
        $results = $this->setOption($optionName, $optionValue);

        return $results;
    }

    /**
     * Un-deprecates and sets the class query variable based on the input query
     *
     * @param $query the input query
     */
    public function setQuery($query){
        if($query === "")
            $query = array();
        if(!$this->error_found && $this->isDeprecatedQuery($query))
            $query = $this->undeprecateQuery($query);
        $this->input_query = $query;
    }

    /**
     * Adds additional elements to the class query parameter
     *
     * @param $query the new input query element
     */
    public function addQuery($query){
        if(count($this->input_query) > 0){
            $this->input_query = array($this->input_query, "AND", $query);
        }
        else{
            $this->input_query = $query;
        }
    }

    /**
     * Tests whether a given entity is part of a given bundle. If no bundle is specified, it tests
     * against the class variable input_bundle.
     *
     * @param $entity Expect string
     * @param $bundle Expect string or blank
     *
     * @return bool $isValid
     */
    private function validateEntity($entity, $bundle = null)
    {
        $isValid = true;
        if($bundle === null)
            $bundle = $this->input_bundle;
        try{
            $this->getDoctrine()->getRepository($bundle . ":" . $entity);
        }
        catch(\Exception $e){
            $isValid = false;
        }
        return $isValid;
    }

    /**
     * Tests a set of include_entities to make sure it's an array of strings without a period in
     * the strings. This ensures that the code can process the array without creating an error.
     *
     * @param $include_entities Expect array
     *
     * @return bool $valid
     */
    private function validateIncludeEntities($include_entities)
    {
        $valid = true;

        if(!is_array($include_entities)){
          $valid = false;
          $this->setError("include_entities is not an array: " . json_encode($include_entities));
        }
        else{
            $include_entities_error = array();
            foreach($include_entities as $entity) {
                if( !( gettype($entity) === "string" ||
                       ( gettype($entity) === "array" &&
                         gettype($entity[0]) === "string" &&
                         gettype($entity[1]) === "array" &&
                         count($entity) === 2
                       )
                     )
                  )
                    $include_entities_error[] = $entity;
            }
            if(count($include_entities_error)){
                $valid = false;
                $this->setError("One or more include_entities are not valid. : " . json_encode($include_entities_error));
            }
        }

        return $valid;
    }

    /**
     * Tests whether a given include_properties array meets the structural requirements, so that
     * it can be processed by code without throwing an error.
     *
     * @param $include_properties Expect array
     *
     * @return bool $valid
     */
    protected function validateIncludeProperties($include_properties)
    {
        $valid = true;

        if(gettype($include_properties) !== "array"){
            $valid = false;
            $this->setError("include_properties is not an array: " . json_encode($include_properties));
        }
        else{
            foreach($include_properties as $included_property){
                //Each element in $include_properties is either a property (string), or operation (array)
                //If it's an operation, the 0 element is the name of the operation (string),
                //                      the 1 element is either a parameter or set of parameters (any data type)
                //                      the 2 element is either unset, or is an alias
                //                      there are no additional elements
                if(!(
                    gettype($included_property) === "string" ||
                    ( gettype($included_property) === "array" &&
                      count($included_property) > 1 &&
                      gettype($included_property[0]) === "string" &&
                      (!isset($included_property[2]) || gettype($included_property[2]) === "string") &&
                      count($included_property) < 4
                    )
                )){
                    $valid = false;
                    $this->setError("Included property is not valid: " . json_encode($included_property));
                }
            }
        }

        return $valid;
    }

    /**
     * Tests whether a given property is a valid property for the specified entity.
     *
     * @param $input Expect string
     *
     * @return bool $isProperty
     */
    protected function isValidProperty($input)
    {

        $isProperty = false;
        $propertyName = $this->getPropertyName($input);
        $entityName = $this->getEntityName($input);

        if($this->validateEntity($entityName)){
            $entity_properties = $this->getEntityProperties($entityName);
            if(in_array($propertyName, $entity_properties)){
                $isProperty = true;
            }
        }

        return $isProperty;
    }

    private function getEntityProperties($name)
    {
        $entity_fields = $this
                ->getDoctrine()
                ->getManager()
                ->getClassMetadata($this->input_bundle . ":" . $name)
                ->getFieldNames();

        // get list of related entities
        $entity_associations = $this
                ->getDoctrine()
                ->getManager()
                ->getClassMetadata($this->input_bundle . ":" . $name)
                ->getAssociationNames();

        // combine lists
        $entity_properties = array_merge($entity_fields,$entity_associations);

        return $entity_properties;
    }

    /**
     * Tests an input array to see if it's a query parameter (combination of entity, operator and possibly parameter value)
     * Returns true if it is, false otherwise
     *
     * @param $queryArray Expect array
     *
     * @return boolean
     */
    protected function isQueryParameter($queryArray)
    {
        $isQueryParameter = false;

        if(
            count($queryArray) >= 2
            && count($queryArray) <= 5
            && gettype($queryArray[0]) === "string"
            && gettype($queryArray[1]) === "string"
            && array_key_exists(strtoupper($queryArray[1]), $this->allowed_operators)
          )
        {
            $isQueryParameter = true;
        }

        return $isQueryParameter;
    }

    /**
     * Tests an input array to see if it's a sub-query (an array that is comprised of arrays and strings-which are operators)
     * A valid query parameter may also pass as a subquery, so that function should be run first
     * Returns true if it is, false otherwise
     *
     * @param $queryArray Expect array
     *
     * @return boolean
     */
    protected function isSubQuery($queryArray)
    {
        $isSubQuery = true;

        foreach($queryArray as $item){
            if(!(
                    gettype($item) === "array" ||
                    (
                        gettype($item) === "string" &&
                        array_key_exists(strtoupper($item), $this->allowed_logical_operators)
                    )
                )
            ){
                $isSubQuery = false;
            }
        }


        return $isSubQuery;
    }

    /**
     * Tests an input array to see if it's a logical join operator ("AND", "OR", "NOT", or a combo)
     * Returns true if it is, false otherwise
     *
     * @param $iq_item
     *
     * @return boolean
     */
    protected function isLogicalJoinOperator($iq_item)
    {
        $isLogicalJoinOperator = false;
        if(gettype($iq_item) === "string"
           && array_key_exists(strtoupper($iq_item), $this->allowed_logical_operators))
           $isLogicalJoinOperator = true;

        return $isLogicalJoinOperator;
    }

    private function validateOrderBy($order_by)
    {
        $valid = true;

        if(!is_array($order_by)){
            $valid = false;
            $this->setError("order_by is not an array: " . json_encode($order_by));
        }
        else{
            foreach($order_by as $order_field => $order_type){
                if(!gettype($order_field) === "string" || !gettype($order_type) === "string"){
                    $valid = false;
                    $this->setError("The order_by element is not correct. The key must be a string representing a property, and the value must be a string representing ASC or DESC. Element: " . json_encode(array($order_field => $order_type)));
                }
            }
        }

        return $valid;
    }

    private function validateGroupBy($group_by)
    {
        $valid = true;

        if(!is_array($group_by)){
            $valid = false;
            $this->setError("group_by is not an array: " . json_encode($group_by));
        }
        else{
            foreach($group_by as $group_by_element){
                if(gettype($group_by_element) !== "string"){
                    $valid = false;
                    $this->setError("Each element in the group_by array must be a string representing a property" . json_encode($group_by_element));
                }
            }
        }

        return $valid;
    }

    private function validateIntInputs($input, $name)
    {
        $valid = true;

        if(gettype($input) !== "integer" && gettype($input) !== "string"){
            $valid = false;
            $this->setError("$name is not valid. It should be an integer or a string. $name input:" . json_encode($input));
        }

        return $valid;
    }

    private function validateStatus($input)
    {
        return $this->validateIntInputs($input, "Status");
    }

    private function validateFlatFlag($input)
    {
        return $this->validateIntInputs($input, "Flat_Result");
    }

    private function validateSize($input)
    {
        return $this->validateIntInputs($input, "Size");
    }

    private function validateStart($input)
    {
        return $this->validateIntInputs($input, "Start");
    }

    /*** END Validation and Input Process Functions ***/



    /*** BEGIN Filter Functions (Run after the Query?) ***/

    /**
     * Filter results based on status
     *
     * @param array $records
     *     array of Nest entity objects (have active property)
     * @param integer $status
     *     status value to filter by, must match one of the ENTITY_STATUS_*
     *     constants
     *
     * @return array
     *     the filtered array of entities
     */
    public static function filterByStatus($records, $status)
    {
        if (is_object($records)) {
            if(method_exists($records, 'getValues')) {
                $records = $records->getValues();
            }
            else {
                $records = json_decode($records->getContent(), true)['data']; // when it's a Response object; decode to array
            }
        }

        // TODO: accommodate User class, which uses 'enabled' rather than 'active'?
        switch ($status) {
            case self::ENTITY_STATUS_INACTIVE_ONLY:
                $filtered_data = array_filter($records, function ($elem) {

                    $elem = (object) $elem; // not recursive, but sufficient for this case (compare json_decode(json_encode($elem)))

                    if (
                        !is_object($elem) ||
                        (!method_exists($elem, 'getActive') &&
                        !isset($elem->active))

                    ) {
                        return false;
                    }

                    if (method_exists($elem, 'getActive')) {
                        $active = (bool) $elem->getActive(); // object from traditional non-DQL query, and is a whole Enitity object
                    } else {
                        $active = (bool) $elem->active;      // object cast from array, from DQL (flat), and has no methods
                    }

                    return !$active;
                });
                $filtered_data = array_values($filtered_data);
                break;

            case self::ENTITY_STATUS_ACTIVE_ONLY:
                $filtered_data = array_filter($records, function ($elem) {

                    $elem = (object) $elem; // not recursive, but sufficient for this case (compare json_decode(json_encode($elem)))

                    if (
                        !is_object($elem) ||
                        (!method_exists($elem, 'getActive') &&
                        !isset($elem->active))

                    ) {
                        return false;
                    }

                    if (method_exists($elem, 'getActive')) {
                        $active = (bool) $elem->getActive(); // object from traditional non-DQL query, and is a whole Entity object
                    } else {
                        $active = (bool) $elem->active;      // object cast from array, from DQL (flat), and has no methods
                    }

                    return $active;
                });
                $filtered_data = array_values($filtered_data);
                break;

            case self::ENTITY_STATUS_ALL:
                $filtered_data = $records;
                break;

            default:
                error_log(
                    __FILE__ . ':' . __LINE__ . ': ' . __METHOD__ .
                    ": Invalid status value:$status"
                );
                $filtered_data = [];
        }
        return $filtered_data;
    }

    /**
     * Tests an input array to see if it's a query array that contains the status field.
     * This is a recursive function. If the given array contains subqueries, it will test thouse
     * Returns true if it does, false otherwise
     *
     * @param $iq_item
     * @param $activeProperty The name of the active property for the given entity. Expect string
     *
     * @return boolean
     */
    protected function hasActiveProperty($iq_item, $activeProperty)
    {
        $hasActiveProperty = false;

        if(is_array($iq_item)){
            if($this->isQueryParameter($iq_item)){
                if($iq_item[0] === $activeProperty){
                    $hasActiveProperty = true;
                }
            }
            else{
                for($i = 0; !$hasActiveProperty && $i < count($iq_item); $i++){
                    $hasActiveProperty = $this->hasActiveProperty($iq_item[$i], $activeProperty);
                }
            }
        }

        return $hasActiveProperty;
    }

    /**
     * Tests whether the input_query needs to query for active property, and adds it if it does.
     * The active property needs to be added if there is not yet an active property queried for,
     * and the options for active filter are not set to 2 (or all). The name of the property added
     * depends on the entity.
     *
     *
     * @param $status int The status that should be added (should be 0, 1, or 2)
     *
     * @return boolean
     */
    public function addActiveFilter($status)
    {
        $activeProperty = ($this->input_entity === 'User' ? 'enabled' : 'active');
        $hasActiveProperty = $this->hasActiveProperty($this->input_query, $activeProperty);

        // Add status filter if it wasn't already in the query, and it wasn't set to 2 in the options
        if(!$hasActiveProperty && 0 <= $status && $status <= 1){
            $activeFilter = array($activeProperty, "=", $status);
            if(count($this->input_query) > 0){
                $this->input_query = array($this->input_query, "AND", $activeFilter);
            }
            else
                $this->input_query = $activeFilter;
        }
    }

    /*** END Filter Functions ***/



    /*** BEGIN DQL Query Functions ***/

    protected function getSelect($flat_result, $include_entities, $include_properties, $debug)
    {
        if(count($include_properties) < 1){ //If no properties are specified, all should be included
            $select = "SELECT e ";

            //Add included entities
            foreach($include_entities as $entity) {
                if(gettype($entity) === "array"){
                    $entity = $entity[0];
                }
                $select .= ", " . $this->getAliasOfEntityName($entity);
                $this->setDebugMessage($debug, isset($debug[6]), '$entity: ' . $entity);
            }
        }
        else{ //Properties are limited to those specified
            $selectArray = [];
            foreach($include_properties as $dql_include_property){
                if(gettype($dql_include_property) !== "array") //Property is a simple property name
                    $selectArray[] = $this->getEntityPropertyAliasName($dql_include_property);
                else{ //Property is an operation, and needs to be unpacked
                    $operator = $dql_include_property[0];
                    $operands = $dql_include_property[1];
                    if(gettype($operands) !== "array")
                        $operands = array($operands);
                    $alias = '';
                    if(isset($dql_include_property[2]))
                        $alias = ' as ' . $dql_include_property[2];

                    foreach($operands as &$operand){ //If this is a property, add as property. If this is not a property, add quote marks so it gets treated as a string.
                        if($this->isValidProperty($operand))
                            $operand = $this->getEntityPropertyName($operand);
                        else
                            $operand = '\'' . $operand . '\'';
                    }
                    $operation = $operator . "(" . implode(", ", $operands) . ")" . $alias;
                    $selectArray[] = $operation;
                }
            }
            $select = "SELECT " . implode(", ", $selectArray);
        }

        return $select;
    }

    private function getJoin($flat_result, $include_entities)
    {
        $join = "";

        foreach($include_entities as $entity) {
            $entityQueryString = "";
            if(gettype($entity) === "array"){
                $entityQueryString = " WITH " . implode(" ", $this->getWhereRecursiveHelper($entity[1]));
                $entity = $entity[0];
            }

            $join .= " LEFT JOIN " . $this->getAnchorEntityAlias($entity) . $entityQueryString;
        }

        return $join;
    }

    protected function getWhereRecursiveHelper($iq_item)
    {
        $results = array();

        if($this->isLogicalJoinOperator($iq_item)){
            $results[] = $iq_item;
        }
        elseif(gettype($iq_item) === "array" && $this->isQueryParameter($iq_item)){
            //Set the property element
            $property = $this->getEntityPropertyName($iq_item[0]);
            $results[] = $property;

            //Set the operator element
            $operator = $iq_item[1];
            $results[] = $operator;

            //Set the parameters
            //Some operators ("IS NULL") will have 0 parameters, some ("LIKE") will have 1, some ("BETWEEN") will have 2, possibly separated by "AND", some ("IN") will have an array
            if(isset($iq_item[2])){
                //Loop through remaining elements, they will all populate the parameters elements
                for($i = 2; $i < count($iq_item); $i++){
                    if(!(gettype($iq_item[$i]) === 'string' && strcasecmp($iq_item[$i], "AND") === 0)){ //Skip "AND" parameters, we'll just automatically add them when needed
                        $parameter = $iq_item[$i];
                        $this->parameter_values[] = $parameter; //Save parameter to a separate array (they will be injected later)
                        $placeHolder = "?" . (count($this->parameter_values) - 1); //Generate a placeholder, which will be used to match to the array later
                        if(is_array($parameter))
                            $results[] = "( " . $placeHolder . ")"; //an array parameter needs to be surrounded by parenthesis
                        else
                            $results[] = $placeHolder;
                        if($i + 1 < count($iq_item))
                            $results[] = "AND"; //If this is not the last parameter, add an "AND"
                    }
                }
            }
        }
        elseif(gettype($iq_item) === "array" && $this->isSubQuery($iq_item)){
            $subQuery = array();
            $requires_trailing_join = false;

            foreach($iq_item as $iq_item2){
                //If a logical operator is needed to join the last and current element, add it
                if($requires_trailing_join && (!$this->isLogicalJoinOperator($iq_item2) || strtoupper($iq_item2) === "NOT" ))
                    $subQuery[] = "AND";
                //Get next element of the query
                $subQuery = array_merge($subQuery, $this->getWhereRecursiveHelper($iq_item2));
                $requires_trailing_join = (gettype($iq_item2) === "array" ? true : false);
            }

            if(count($subQuery) > 0){
                $results[] = "(";
                $results = array_merge($results, $subQuery);
                $results[] = ")";
            }
        }
        else{
            $message = "Unprocessable Query Input: see specifically " . json_encode($iq_item) . "Full query: " . json_encode($this->input_query);
            $this->setError($message);
        }

        return $results;
    }

    protected function getWhere()
    {
        $parameter_array = $this->getWhereRecursiveHelper($this->input_query);
        if(count($parameter_array) > 0)
            $results = "WHERE " . implode(" ", $parameter_array);
        else
            $results = "";

        if($this->response_code === Response::HTTP_UNPROCESSABLE_ENTITY){
            $results = false;
        }

        return $results;
    }

    private function getOrderBy($order_by)
    {
        // NOTE: default ordering should be in entity annotation
        $ORDER_BY = '';

        if (!empty($order_by)) { // e.g., ['org.name' => 'ASC', 'nameLast' => 'ASC', 'nameFirst' => 'ASC', etc.]
            foreach ($order_by as $k => $v) {
                if(gettype($k) === "integer"){
                    $field = $v;
                    $direction = "";
                }
                else{
                    $field = $k;
                    $direction = $v;
                }
                    $entity = $this->getEntityName($field, 'e');
                    $property = $this->getPropertyName($field);

                    $orderByArray[] = "$entity.$property $direction";
            }
            $ORDER_BY = "ORDER BY " . implode(", ", $orderByArray);
        }

        return $ORDER_BY;
    }

    private function getGroupBy($group_by)
    {
        $group_by_statement = '';
        $group_by_array = array();

        if (!empty($group_by)) {
            foreach ($group_by as $group_by_element) {
                $entity = $this->getEntityName($group_by_element, 'e');
                $property = $this->getPropertyName($group_by_element);

                $group_by_array[] = "$entity.$property";
            }
            $group_by_statement = "GROUP BY " . implode(", ", $group_by_array);
        }

        return $group_by_statement;
    }

    private function setSize($dql_query, $start, $size)
    {
        if($size) {
            $dql_query
                ->setFirstResult($start)
                ->setMaxResults($size);
        }
    }

    public function performQuery()
    {
        $successfulResults = false;

        $debug = $this->default_options['debug']; //This will be replaced by options if there is a valid debug options
        if(!$this->error_found){

            // set options vars based on default keys
            foreach($this->merged_options as $k => $v){
                $$k = $v;
            }
            $this->input_bundle = $bundle;

            $this->setDebugMessage($debug, isset($debug[1]), json_encode($this->input_options));

            // translate $status option value to 'active' query value (or enabled if this is user), if no 'active' value
            $this->addActiveFilter($status);

            $this->setDebugMessage($debug, isset($debug[2]), '$this->merged_options: ' . print_r($this->merged_options, true));

            if(!$this->input_entity){
                $this->setError('entity name cannot be empty');
            }
            else{
                if (!$this->validateEntity($this->input_entity)){
                    $this->setError('$this->input_entity must be a valid entity in ' . $this->input_bundle);
                }
                else{

                    $this->setDebugMessage($debug, isset($debug[3]), ', $include_entities: ' . (is_array($include_entities) ? '(is array) ' . json_encode($include_entities): '(not array) ' . json_encode($include_entities)));

                    // TODO: move DQL to Repository?
                    // When not using array result, an empty related property is returned as a null

                    $this->setDebugMessage($debug, isset($debug[4]),
                          '. $flat_result: '      . json_encode($flat_result)
                        . '. $include_entities: ' . json_encode($include_entities)
                        . '. $order_by: '         . json_encode($order_by)
                        . '. $dql_operators: '        . json_encode($dql_operators)
                    );
                    //$this->setDebugMessage($debug, isset($debug[5]), 'include_entities: ' . json_encode($include_entities));

                    $this->validateIncludeEntities($include_entities);
                    $this->validateIncludeProperties($include_properties);
                    $this->validateOrderBy($order_by);
                    $this->validateGroupBy($group_by);
                    $this->validateStatus($status);
                    $this->validateFlatFlag($flat_result);
                    $this->validateSize($size);
                    $this->validateStart($start);
                    //STRUCTURE of $input_query is validated during the getWhere() function
                    if (!$this->error_found){

                        $this->setDebugMessage($debug, isset($debug[7]), '$this->input_query: ' . json_encode($this->input_query));

                        $SELECT = $this->getSelect($flat_result, $include_entities, $include_properties, $debug);
                        $JOIN = $this->getJoin($flat_result, $include_entities);
                        $FROM = "FROM $this->input_bundle:$this->input_entity e ";
                        $WHERE = $this->getWhere();
                        $GROUP_BY = $this->getGroupBy($group_by);
                        $ORDER_BY = $this->getOrderBy($order_by);
                        $dql = " $SELECT $FROM $JOIN $WHERE $GROUP_BY $ORDER_BY ";

                        // TODO: confirm this try/catch is useful
                        try {
                        $dql_query = $this
                            ->getDoctrine()
                            ->getManager()
                            ->createQuery($dql);
                        }
                        catch (\Exception $e) {
                            $this->setError($e->getMessage() . $this->input_options ? '; Likely problem with properties in \$this->input_options: ' . print_r($this->input_options, true) : '');
                        }

                        if (!$this->error_found) { // 422

                            /* NOTE: using createQueryBuilder() allows access to easier programmatic functions such as andWhere(), etc.
                             *       (but I find that style harder to read (VR))
                             */

                            $dql_query->setParameters($this->parameter_values);

                            if ($this->response_code != Response::HTTP_UNPROCESSABLE_ENTITY) {
                                $this->setSize($dql_query, $start, $size);

                                try {
                                    if($flat_result) {
                                        $this->response_data = $dql_query->getArrayResult(); // get just scalar properties AND those specified in $dql_data['included_entities']
                                    } else {
                                        $this->response_data = $dql_query->getResult();      // get all properties, including all related entities
                                    }
                                    $successfulResults = true;
                                    $this->response_code = Response::HTTP_OK;
                                }
                                catch (\Exception $e) {
                                    $message = $e->getMessage() . ($dql  ? "; \$dql: $dql"   : ''). ($this->input_entity ? "; \$this->input_entity: $this->input_entity" : '');
                                    $this->setError($message, Response::HTTP_BAD_REQUEST);
                                }
                            }
                        }

                        $this->setDebugMessage($debug, isset($debug[8]),  'DQL: ' . $dql_query->getDQL());
                        //$this->setDebugMessage($debug, isset($debug[16]), 'SQL: ' . $dql_query->getSQL());
                        /*THIS DEBUG MESSAGE THROWS IT'S OWN BUG - which causes the server to not return
                         * anything, causing helpful error messages to be overwritten. I tried putting on a
                         * try/catch, but it didn't catch for whatever reason. The solution is either to
                         * figure out why try/catch is not working, or to place this code so it only runs in
                         * the context where $dql->query has been correctly created*/
                        $this->setDebugMessage($debug, isset($debug[16]), 'Karen says: getSQL() not working, please see code.');
                        $this->setDebugMessage($debug, isset($debug[17]), 'Parameters: ' . print_r($dql_query->getParameters()->toArray(), true));
                    }

                    $this->response_message[] = 'Filtered records by $this->input_query (DQL)';

                }
            }
        }

        $this->setDebugMessage($debug, isset($debug[14]), '[$this->input_query: ' . print_r($this->input_query, true) . ', $this->input_options: ' . print_r($this->input_options, true) . ']');

        return $successfulResults;

        /*
        Caching experiments: (integrate with app_cache.php)

        $result = new View(array('data' => $this->response_data, 'count' => $this->response_count, 'code' => $this->response_code, 'message' => $this->response_message), $this->response_code);
        $result->setHeader('s-maxage', 60);                                 // 1m
        $result->setHeader('must-revalidate', true);                        // confirm this would be useful and effective
        //$result->setHeader('public', true);                                 // doesn't make result cacheable
        //$result->setHeader('vary', array('Accept-Encoding', 'User-Agent')); // already seems to be set

        return $result;
        */
    }

    /*** END DQL Query Functions ***/



    /*** BEGIN Response Preparation Functions ***/

    private function setError($message, $code = Response::HTTP_UNPROCESSABLE_ENTITY)
    {
        $this->error_found = true;
        $this->response_message[] = $message;
        $this->response_code = $code;
    }

    private function setDebugMessage($recordDebugs, $recordSpecificDebug, $message)
    {
        if($recordDebugs && $recordSpecificDebug)
            $this->response_debug_message[] = $message;
    }

    protected function getViewResponse()
    {
        if(gettype($this->response_data) === "array")
            $this->response_count = count($this->response_data);
        $responseArray = array(
            'code'    => $this->response_code,
            'message' => $this->response_message,
            'count'   => $this->response_count,
            'data'    => $this->response_data,
        );
        if(is_array($responseArray['message']))
            $responseArray['message'] = implode(". ", $responseArray['message']);
        if(count($this->response_validations))
            $responseArray['validations'] = $this->response_validations;
        if(count($this->response_debug_message))
            $responseArray['message'] .= ". " . implode(". ", $this->response_debug_message);

        if (
            ($this->response_code < Response::HTTP_OK) ||
            ($this->response_code > Response::HTTP_ACCEPTED)
        ) {
            error_log(
                __FILE__ . ' line ' . __LINE__ . ': ' . __METHOD__ .
                'Nest API ERROR: ' . self::varShow($responseArray)
            );
        }
        return new View($responseArray, $this->response_code);
    }

    /*** END Response Preparation Functions ***/



    /*** BEGIN Special Data Handling Functions ***/

    /**
     * Normalize an entity's phone numbers to standard format
     *
     * @param object $entity
     *     Symfony entity possibly containing phone numbers
     */
    protected function normalizeEntityPhoneNumbers(&$entity)
    {
        $phone_property_names = ['Phone', 'PhoneCell'];
        foreach ($phone_property_names as $phone_property_name) {
            $get_method = 'get' . $phone_property_name;
            $set_method = 'set' . $phone_property_name;
            $set_raw_method = 'set' . $phone_property_name . 'Raw';

            if (method_exists($entity, $get_method)) {
                $input_phone = $entity->$get_method();
                if (!empty($input_phone)) {
                    $normalized_phone = $this->normalizePhoneNumber($input_phone);
                    if (!empty($normalized_phone)) {
                        $entity->$set_method($normalized_phone);
                    } else {
                        // Invalid phone number, or couldn't be parsed.
                        error_log(
                            __FILE__ . ' line ' . __LINE__ . ': ' . __METHOD__ .
                            ': Invalid phone number ' . $input_phone
                        );
                        $entity->$set_raw_method($input_phone);
                        $entity->$set_method('');
                    }
                }
            }
        }
    }

    /**
     * Normalize a phone number to libphonenumber international format
     *
     * @param string $input_number
     *     phone number to be normalized
     *
     * @return string
     *     normalized phone number, or '' if invalid
     */
    protected function normalizePhoneNumber($input_number)
    {
        $phoneNumberUtil = \libphonenumber\PhoneNumberUtil::getInstance();
        try {
            // Parse phone number.
            $phoneNumberObject = $phoneNumberUtil->parse(
                $input_number,
                'US'
            );
        } catch (\libphonenumber\NumberParseException $e) {
            error_log(
                __FILE__ . ' line ' . __LINE__ . ': ' . __METHOD__ .
                ': Exception parsing phone number \'' . $input_number .
                '\': ' . $e->getMessage()
            );
            return '';
        }

        // Test if it's a possible number.
        if (!$phoneNumberUtil->isPossibleNumber($phoneNumberObject)) {
            error_log(
                __FILE__ . ' - ' . __METHOD__ . ' line ' . __LINE__ .
                ': Not a possible phone number: ' . $input_number
            );
            return '';
        }

        // Test if it's a valid number.
        if (!$phoneNumberUtil->isValidNumber($phoneNumberObject)) {
            error_log(
                __FILE__ . ' - ' . __METHOD__ . ' line ' . __LINE__ .
                ': Not a valid phone number: ' . $input_number
            );
            return '';
        }

        return $phoneNumberUtil->format(
            $phoneNumberObject,
            \libphonenumber\PhoneNumberFormat::INTERNATIONAL
        );
    }

    /*** END Special Data Handling Functions ***/



    /*** BEGIN Special Security Functions ***/

    /**
     * Determine if caller has write permission for Nest database
     *
     * @return boolean
     *     true if user associated with current token has write permission
     */
    protected function callerHasWritePermission()
    {
        // Fetch the current user's active privilege ids.
        $current_user_privileges = $this->currentUserPrivileges();

        // Determine if this user has write privileges.
        $user_write_privileges = array_intersect(
            $this->privileges_with_write_access,
            $current_user_privileges
        );
        return (count($user_write_privileges) > 0);
    }

    /**
     * Determine if caller has delete permission for Nest database
     *
     * @return boolean
     *     true if user associated with current token has delete permission
     */
    private function callerHasDeletePermission()
    {
        // Fetch the current user's active privilege ids.
        $current_user_privileges = $this->currentUserPrivileges();

        // Determine if this user has delete privileges.
        $user_delete_privileges = array_intersect(
            $this->privileges_with_delete_access,
            $current_user_privileges
        );
        return (count($user_delete_privileges) > 0);
    }

    /**
     * Construct a list of the current user's active privilege ids
     *
     * @return array
     *     array of integer ids
     */
    private function currentUserPrivileges()
    {
        $user_privileges = [];

        // Get the current user's assigned roles.
        $person         = $this->getUser()->getPerson();
        $assigned_roles = $person->getAssignedrolesAll();


        // For each assigned role, collect the active privilege ids.
        foreach ($assigned_roles as $assigned_role) {
            $ar_pr_response = $this->forward(
                '\ApiBundle\Controller\AssignedroleController::getAssignedrolePrivilegerolesQuery',
                ['id' => $assigned_role->getId()]
            ); // View object with the 4 keys ('data', etc.)
            $ar_pr_content_obj = json_decode($ar_pr_response->getContent());
            if (isset($ar_pr_content_obj->data)) {
                foreach ($ar_pr_content_obj->data as $privilegerole) {
                    $privilege_id     = $privilegerole->privilege->id;
                    $privilege_active = $privilegerole->privilege->active;
                    if ($privilege_active === true) {
                        $user_privileges[] = (int) $privilege_id;
                    }
                }
            }
            // log error (can't easily return it)
            else {
                // Blank out the privileges in order to draw attention to failure?
                // (Alternative is to pass them back unevaluated, no?)
                $user_privileges = [];
                error_log(
                    __FILE__ . ': ' . __LINE__ . ': ' . __METHOD__ .
                    ': $ar_pr_content_obj missing "data" property: ' .
                    var_export($apps, true)
                );
            }
        }

        // Eliminate duplicate or zero privilege ids.
        $user_privileges_filtered = array_unique(
            array_filter($user_privileges)
        );

        return $user_privileges_filtered;
    }

    /*** END Special Security Functions ***/

    /**
     * Show value of a variable safely for log output
     *
     * @param mixed $value
     *      value to represent as string
     * @param integer $max_depth
     *      optional, depth to recurse
     * @param integer $level
     *      just for internal use, do not set
     *
     * $return string
     *      representation of value
     */
    public static function varShow($value, $max_depth=3, $level=0)
    {
        $indent = str_repeat('  ', $level);

        if (is_string($value) || is_numeric($value)) {
            return strval($value);
        }

        if (is_array($value) || is_object($value)) {
            if ($level === $max_depth) {
                return '';
            }
            $retval = $indent;
            if (is_object($value)) {
                $retval .= get_class($value) . "\n";
            }
            $retval .= $indent . "[\n";
            foreach ($value as $key => $val) {
                $retval .= $indent . $indent . $key . ' => ' . self::varShow($val, $max_depth, $level + 1) . "\n";
            }
            $retval .= $indent . ']';
            return $retval;
        }

        return '<' . gettype($value) . ">\n";
    }

    /*** END Helper methods ***/



    /*** BEGIN Primary methods (must have routable path) ***/

    /**
     * Generic POST method for any entity<br />
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "~Global",
     *   resource = true,
     *   description = "Create an Entity",
     *   input = {
     *       "class" = "ApiBundle\Form\ApiType",
     *     },
     *   parameters = {
     *     {
     *       "name" = "name",
     *       "dataType" = "string",
     *       "required" = 1,
     *       "format" = "string",
     *       "description" = "Entity name",
     *     },
     *     {
     *       "name" = "options",
     *       "dataType" = "string",
     *       "required" = 0,
     *       "format" = "JSON",
     *       "description" = "{""bundle"":""ApiBundle"",""status"":1, etc.}",
     *     },
     *   },
     *   output = "ApiBundle\Entity\$entity",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   },
     * )
     *
     * @POST("/entity/{name}/{options}", name="api_api_entity_post", defaults={"options"=""}, options={"method_prefix" = false})
     *
     * @param string $name    Entity name
     * @param JSON   $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     */
    public function postEntityAction(Request $request, $name=null, $options='{}')
    {


        /*** Example of generalized POST method ***/

        /*
         * A challenge is the form, at least in the Apidoc sandbox rendering: since we can't name the path to the form(type) dynamically
         * in the annotations, the sandbox can't render the necessary input fields based on entity name. (Submission still works,
         * just without any data, which is a problem if some fields are not nullable (among other reasons!).
         *
         * The formType can be dynamically loaded in this method, though, so it's not a problem for actual usage. The $request just
         * has to have the correct fields in the body. Fields that don't match properties in the target entity appear to be ignored.
         *
         * For that reason, it does work to put arbitrary field names in the ApiType.php file. Crudely, it could just be the union of
         * all field names of all entities. (They could be organized with comments to indicate the originating entity.)
         * It might also be possible to add them dynamically in the ApiType.php page (and thus be read by the Apidoc page).
         */

        $defaults = $this->changeDefaults;

        if ($this->callerHasWritePermission()) {
            // set vars based on default keys and received options
            $merged = $this->mergeOptionsAction($defaults, $options);
            if (!$merged) {
                $this->setError( "invalid options: " . json_encode($options));
            }
            else{
                foreach ($merged as $k => $v) {
                    $$k = $v;
                }
                $this->input_bundle = $bundle;

                // sanitize required arguments
                $name = str_ireplace('{name}', '', $name); // accommodate default input from api-docs-sandbox page
                $name = ucfirst(strtolower($name));        // make input case-insensitive
                if (!$name) {
                    $this->setError('$name cannot be empty');
                }
                else{
                    if (!$this->validateEntity($name)){
                        $this->setError('$name must be a valid entity in ' . $this->input_bundle);
                    }
                    else{
                        // including 'use' statements at top didn't seem to allow us to avoid FQCN's, alas.
                        $entityType = $this->input_bundle . '\\Form\\'   . $name . 'Type';
                        $entity = $this->input_bundle . '\\Entity\\' . $name;

                        // toward dynamically determining fields for Apidoc display...
                        $formBuilderOptions = array('bundle' => $this->input_bundle, 'entity' => $name);

                        // note this block is slightly different from PATCH & PUT, since entity object comes from 'new'
                        $entity = new $entity(); // re-use var
                        $form = $this->createForm(
                            $entityType,
                            $entity,
                            array('method' => 'POST') // POST is default
                        );

                        $form->handleRequest($request);

                        // use this instead of usual $form->isValid() because resulting json is
                        // much more readable than that generated by serializing $form->getErrors()
                        $errors = $this->get('validator')->validate($entity);
                        if (count($errors) > 0) {
                            $this->setError('Validation errors found.');
                            $this->response_data = $entity;
                            // Validation errors; will be a Symfony\Component\Validator\ConstraintViolationList object
                            $validations = [];
                            foreach($errors as $error) { // each 'violation'
                                $property = $error->getPropertyPath();
                                $msg      = $error->getMessage();
                                $this->response_validations["$property"] = $msg;
                            }
                        }
                        else {
                            try{
                                $this->normalizeEntityPhoneNumbers($entity);
                                $manager = $this->getDoctrine()->getManager();

                                // BEGIN temporary workaround to boolean-setting issue [INTR-1128]

                                // set the boolean fields on the entity because handleRequest can't update these fields for some reason
                                // Derived from: https://github.com/symfony/symfony/issues/17026
                                // Get list of local scalar fields & types; if boolean, use entity setter to impose value
                                $metadata = $manager->getClassMetadata($this->input_bundle . ":" . $name);
                                $entity_fields = $metadata->getFieldNames();
                                foreach ($entity_fields as $field) {
                                    $type = $metadata->getTypeOfField($field);
                                    if ($request->request->has("$field") && $type == 'boolean') {
                                        $setter = 'set' . ucfirst($field);
                                        $entity->$setter(!!$request->request->get("$field"));
                                    }
                                }

                                // END temporary workaround

                                $manager->persist($entity);
                                $manager->flush();

                                $this->response_data    = $entity;
                                $this->response_count   = 1;
                                $this->response_code    = Response::HTTP_CREATED; // 201
                            }
                            catch (\Exception $e) {
                                $this->setError('Unable to save to database. Details: ( ' . $e . ')');
                            }
                        }
                    }
                }
            }
        } else {
            $this->setError('Permission denied', Response::HTTP_FORBIDDEN);
        }

        return $this->getViewResponse();
    }

    /**
     * Generic PUT method for any entity<br />
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "~Global",
     *   resource = true,
     *   description = "Modify an Entity (Replace)",
     *   input = {
     *       "class" = "ApiBundle\Form\ApiType",
     *     },
     *   parameters = {
     *     {
     *       "name" = "name",
     *       "dataType" = "string",
     *       "required" = 1,
     *       "format" = "string",
     *       "description" = "Entity name",
     *     },
     *     {
     *       "name" = "options",
     *       "dataType" = "string",
     *       "required" = 0,
     *       "format" = "JSON",
     *       "description" = "{""bundle"":""ApiBundle"",""status"":1, etc.}",
     *     },
     *   },
     *   output = "ApiBundle\Entity\$entity",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   },
     * )
     *
     * @PUT("/entity/{name}/{options}", name="api_api_entity_put", defaults={"options"=""}, options={"method_prefix"=false})
     *
     * @param string $name    Entity name
     * @param JSON   $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     */
    public function putEntityAction(Request $request, $name=null, $options=null)
    {

        /*** Example of generalized PUT method ***/

        /*
         * A challenge is the form, at least in the Apidoc sandbox rendering: since we can't name the path to the form(type) dynamically
         * in the annotations, the sandbox can't render the necessary input fields based on entity name. (Submission still works,
         * just without any data, which is a problem if some fields are not nullable (among other reasons!).
         *
         * The formType can be dynamically loaded in this method, though, so it's not a problem for actual usage. The $request just
         * has to have the correct fields in the body. Fields that don't match properties in the target entity appear to be ignored.
         *
         * For that reason, it does work to put arbitrary field names in the ApiType.php file. Crudely, it could just be the union of
         * all field names of all entities. (They could be organized with comments to indicate the originating entity.)
         * It might also be possible to add them dynamically in the ApiType.php page (and thus be read by the Apidoc page).
         */

        $defaults = $this->changeDefaults;

        if ($this->callerHasWritePermission()) {
            // set vars based on default keys and received options
            $merged = $this->mergeOptionsAction($defaults, $options);
            if(!$merged){
                $this->setError( "invalid options: " . json_encode($options));
            }
            else{
                foreach ($merged as $k => $v) {
                    $$k = $v;
                }
                $this->input_bundle = $bundle;

                // sanitize required arguments
                $name = str_ireplace('{name}', '', $name); // accommodate default input from api-docs-sandbox page
                $name = ucfirst(strtolower($name));        // make input case-insensitive
                if (!$name){
                    $this->setError('$name cannot be empty');
                }
                else{
                    $bundle_entity = $this->input_bundle . ':' . $name;
                    if (!$this->validateEntity($name)){
                        $this->setError('$name must be a valid entity in ' . $this->input_bundle);
                    }
                    else{

                        $id = $request->get('id');

                        if($id == null){ // no id number supplied
                            $this->setError('No id number supplied');
                        }
                        else{
                            $entity = $this
                                ->getDoctrine()
                                ->getRepository("$bundle_entity")
                                ->find($id);

                            if ($entity == null){
                                $this->setError("No $name with id of $id found to edit");
                            }
                            else {
                                // including 'use' statements at top didn't seem to allow us to avoid FQCN's, alas.
                                $entityType = $this->input_bundle . '\\Form\\'   . $name . 'Type';

                                // toward dynamically determining fields for Apidoc display...
                                $formBuilderOptions = array('bundle' => $this->input_bundle, 'entity' => $name);

                                $form = $this->createForm(
                                    $entityType,
                                    $entity,
                                    array('method' => 'PUT') // POST is default
                                );

                                $form->handleRequest($request);

                                // use this instead of usual $form->isValid() because resulting json is
                                // much more readable than that generated by serializing $form->getErrors()
                                $errors = $this->get('validator')->validate($entity);
                                if (count($errors) > 0) {
                                    $this->setError('Validation errors found: ' . $errors);
                                    $this->response_data = $entity;
                                    // Validation errors; will be a Symfony\Component\Validator\ConstraintViolationList object
                                    $validations = [];
                                    foreach($errors as $error) { // each 'violation'
                                        $property = $error->getPropertyPath();
                                        $msg      = $error->getMessage();
                                        $this->response_validations["$property"] = $msg;
                                    }
                                }
                                else {
                                    try{
                                        $manager = $this->getDoctrine()->getManager();

                                        // BEGIN temporary workaround to boolean-setting issue [INTR-1128]

                                        // set the boolean fields on the entity because handleRequest can't update these fields for some reason
                                        // Derived from: https://github.com/symfony/symfony/issues/17026
                                        // Get list of local scalar fields & types; if boolean, use entity setter to impose value
                                        $metadata = $manager->getClassMetadata($bundle_entity);
                                        $entity_fields = $metadata->getFieldNames();
                                        foreach ($entity_fields as $field) {
                                            $type = $metadata->getTypeOfField($field);
                                            if ($request->request->has("$field") && $type == 'boolean') {
                                                $setter = 'set' . ucfirst($field);
                                                $entity->$setter(!!$request->request->get("$field"));
                                            }
                                        }

                                        // END temporary workaround

                                        $manager->persist($entity);
                                        $manager->flush();

                                        $this->response_data    = $entity;
                                        $this->response_count   = 1;
                                        $this->response_code    = Response::HTTP_ACCEPTED; // 202
                                    }
                                    catch(\Exception $e){
                                        $this->setError('Unable to save to database. Details: ( ' . $e . ')');
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            $this->setError('Permission denied', Response::HTTP_FORBIDDEN);
        }

        return $this->getViewResponse();
    }

    /**
     * Generic PATCH method for any entity<br />
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "~Global",
     *   resource = true,
     *   description = "Modify an Entity (Update)",
     *   input = {
     *       "class" = "ApiBundle\Form\ApiType",
     *     },
     *   parameters = {
     *     {
     *       "name" = "name",
     *       "dataType" = "string",
     *       "required" = 1,
     *       "format" = "string",
     *       "description" = "Entity name",
     *     },
     *     {
     *       "name" = "options",
     *       "dataType" = "string",
     *       "required" = 0,
     *       "format" = "JSON",
     *       "description" = "{""bundle"":""ApiBundle"",""status"":1, etc.}",
     *     },
     *   },
     *   output = "ApiBundle\Entity\$entity",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   },
     * )
     *
     * @PATCH("/entity/{name}/{options}", name="api_api_entity_patch", defaults={"options"=""}, options={"method_prefix"=false})
     *
     * @param string $name    Entity name
     * @param JSON   $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     */
    public function patchEntityAction(Request $request, $name=null, $options=null)
    {

        /*** Example of generalized PATCH method ***/

        /*
         * A challenge is the form, at least in the Apidoc sandbox rendering: since we can't name the path to the form(type) dynamically
         * in the annotations, the sandbox can't render the necessary inpatch fields based on entity name. (Submission still works,
         * just without any data, which is a problem if some fields are not nullable (among other reasons!).
         *
         * The formType can be dynamically loaded in this method, though, so it's not a problem for actual usage. The $request just
         * has to have the correct fields in the body. Fields that don't match properties in the target entity appear to be ignored.
         *
         * For that reason, it does work to patch arbitrary field names in the ApiType.php file. Crudely, it could just be the union of
         * all field names of all entities. (They could be organized with comments to indicate the originating entity.)
         * It might also be possible to add them dynamically in the ApiType.php page (and thus be read by the Apidoc page).
         */

        $defaults = $this->changeDefaults;

        if ($this->callerHasWritePermission()) {
            // set vars based on default keys and received options
            $merged = $this->mergeOptionsAction($defaults, $options);
            if(!$merged){
                $this->setError( "invalid options: " . json_encode($options));
            }
            else{
                foreach ($merged as $k => $v) {
                    $$k = $v;
                }
                $this->input_bundle = $bundle;

                // sanitize required arguments
                $name = str_ireplace('{name}', '', $name); // accommodate default input from api-docs-sandbox page
                $name = ucfirst(strtolower($name));        // make input case-insensitive
                if (!$name){
                    $this->setError('$name cannot be empty');
                }
                else{
                    $bundle_entity = $this->input_bundle . ':' . $name;
                    if (!$this->validateEntity($name)){
                        $this->setError('$name must be a valid entity in ' . $this->input_bundle);
                    }
                    else{

                        $id = $request->get('id');

                        if($id == null){
                            $this->setError('No id number supplied');
                        }
                        else{
                            $entity = $this
                                ->getDoctrine()
                                ->getRepository("$bundle_entity")
                                ->find($id);

                            if ($entity == null){
                                $this->setError("No $name with id of $id found to edit");
                            }
                            else{
                                // including 'use' statements at top didn't seem to allow us to avoid FQCN's, alas.
                                $entityType = $this->input_bundle . '\\Form\\'   . $name . 'Type';

                                // toward dynamically determining fields for Apidoc display...
                                $formBuilderOptions = array('bundle' => $this->input_bundle, 'entity' => $name);

                                $form = $this->createForm(
                                    $entityType,
                                    $entity,
                                    array('method' => 'PATCH') // POST is default
                                );

                                $form->handleRequest($request);

                                // use this instead of usual $form->isValid() because resulting json is
                                // much more readable than that generated by serializing $form->getErrors()
                                $errors = $this->get('validator')->validate($entity);

                                if (count($errors) > 0) {
                                    $this->setError('Validation errors found: ' . $errors);
                                    $this->response_data = $entity;
                                    // Validation errors; will be a Symfony\Component\Validator\ConstraintViolationList object
                                    $validations = [];
                                    foreach($errors as $error) { // each 'violation'
                                        $property = $error->getPropertyPath();
                                        $msg      = $error->getMessage();
                                        $this->response_validations["$property"] = $msg;
                                    }
                                }
                                else { // no validation errors
                                    try{
                                        $this->normalizeEntityPhoneNumbers($entity);
                                        $manager = $this->getDoctrine()->getManager();

                                        // BEGIN temporary workaround to boolean-setting issue [INTR-1128]

                                        // set the boolean fields on the entity because handleRequest can't update these fields for some reason
                                        // Derived from: https://github.com/symfony/symfony/issues/17026
                                        // Get list of local scalar fields & types; if boolean, use entity setter to impose value
                                        $metadata = $manager->getClassMetadata($bundle_entity);
                                        $entity_fields = $metadata->getFieldNames();
                                        foreach ($entity_fields as $field) {
                                            $type = $metadata->getTypeOfField($field);
                                            if ($request->request->has("$field") && $type == 'boolean') {
                                                $setter = 'set' . ucfirst($field);
                                                $entity->$setter(!!$request->request->get("$field"));
                                            }
                                        }

                                        // END temporary workaround

                                        $manager->persist($entity);
                                        $manager->flush();

                                        $this->response_data    = $entity;
                                        $this->response_count   = 1;
                                        $this->response_code    = Response::HTTP_ACCEPTED; // 202
                                    }
                                    catch(\Exception $e){
                                        $this->setError('Unable to save to database. Details: ( ' . $e . ')');
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            $this->setError('Permission denied', Response::HTTP_FORBIDDEN);
        }

        return $this->getViewResponse();
    }

    /**
     * Delete an entity
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "~Global",
     *   resource = true,
     *   description = "Delete Entity",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @DELETE("/entity/{name}/{id}/{options}", name="api_api_entity_delete", defaults={"options":""}, requirements={"id":"\d+"}, options={"method_prefix" = false})
     *
     * @param integer $id the entity id
     * @param string $name    Entity name
     * @param JSON   $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     */
    public function deleteEntityAction($name=null, $id=null, $options=null)
    {
        $defaults = $this->changeDefaults;

        if ($this->callerHasDeletePermission()) {
            // set vars based on default keys and received options
            $merged = $this->mergeOptionsAction($defaults, $options);
            if(!$merged){
                $this->setError( "invalid options: " . json_encode($options));
            }
            else{
                foreach ($merged as $k => $v) {
                    $$k = $v;
                }
                $this->input_bundle = $bundle;

                // sanitize required arguments
                $id   = str_ireplace('{id}',   '', $id);   // accommodate default input from api-docs-sandbox page
                $name = str_ireplace('{name}', '', $name); // accommodate default input from api-docs-sandbox page
                $name = ucfirst(strtolower($name));        // make input case-insensitive

                if (!$name){
                    $this->setError('$name cannot be empty');
                }
                else{
                    $bundle_entity = $this->input_bundle . ':' . $name;
                    if (!$this->validateEntity($name)){
                        $this->setError('$name must be a valid entity in ' . $this->input_bundle);
                    }
                    else{
                        $entity = $this
                            ->getDoctrine()
                            ->getRepository("$bundle_entity")
                            ->find($id);

                        if ($entity == null){
                            $this->setError("No $name with id of $id found to edit");
                        }
                        else{

                            $manager = $this->getDoctrine()->getManager();
                            $manager->remove($entity);
                            $manager->flush();

                            $this->response_data    = true;
                            $this->response_count   = 0;
                            $this->response_code    = Response::HTTP_ACCEPTED; // 202
                            $this->response_message[] = "$name removed";

                        }
                    }
                }
            }
        } else {
            $this->setError('Permission denied', Response::HTTP_FORBIDDEN);
        }

        return $this->getViewResponse();
    }

    /**
     * Get records for any entity by any field/value<br />
     * Now supports related field names, e.g., as {"app.appkey":"xYZa1230"} in $query
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "~Global",
     *   resource = true,
     *   description = "Get records for any entity by any field, e.g., ""Person"", {""scsUserId"":""358""}",
     *   todo = "Add pagination support",
     *   input = {
     *       "class" = "ApiBundle\Form\ApiType",
     *     },
     *   parameters = {
     *     {
     *       "name" = "name",
     *       "dataType" = "string",
     *       "required" = 1,
     *       "format" = "string",
     *       "description" = "Entity name",
     *     },
     *     {
     *       "name" = "query",
     *       "dataType" = "string",
     *       "required" = 1,
     *       "format" = "JSON",
     *       "description" = "{""field_name"":""field_value"",""status"":1, etc}",
     *     },
     *     {
     *       "name" = "options",
     *       "dataType" = "string",
     *       "required" = 0,
     *       "format" = "JSON",
     *       "description" = "{""bundle"":""ApiBundle"",""status"":1, etc.}",
     *     },
     *   },
     *   output = "ApiBundle\Entity\$entity",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *     422 = "Returned when entity bad or unspecified",
     *   },
     * )
     *
     * @Get("/entity/{name}/by/{query}/{options}", defaults={"query"="","options"=""}, name="api_api_get_entity_by_query", options={"method_prefix"=false})
     *
     * @param string $name  Entity name
     * @param JSON $query   {''field_name'':''field_value'', ''status'':1, etc.}
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string JSON
     */
    public function getEntityByAction($name, $query, $options)
    {
        $this->clearProperties();

        $this->unpackInput($name, $query, $options);
        $this->performQuery();
        return $this->getViewResponse();
    }

    /**
     * Retrieve all records of entity<br />
     * (Convenience wrapper for /by/{query} where there is no query
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "~Global",
     *   resource = true,
     *   description = "Get all records of an Entity (Note {options} not yet in use)",
     *   todo = "Add pagination support",
     *   parameters = {
     *     {
     *       "name" = "name",
     *       "dataType" = "string",
     *       "required" = 1,
     *       "format" = "string",
     *       "description" = "Entity name",
     *     },
     *     {
     *       "name" = "options",
     *       "dataType" = "string",
     *       "required" = 0,
     *       "format" = "JSON",
     *       "description" = "{""bundle"":""ApiBundle"",""status"":1, etc.}",
     *     },
     *   },
     *   output = "ApiBundle\Entity\$entity",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *     422 = "Returned when entity bad or unspecified",
     *   },
     * )
     *
     * @Get("/entity/{name}/list/{options}", name="api_api_get_entity_list", options={"method_prefix" = false})
     *
     * @param string $name  Entity name
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     */
    public function getEntityListAction($name=null, $options=null)
    {
        // Wrapper for /by/{query}, where there is no query
        $this->input_query = '{}';
        return $this->getEntityByAction($name, $this->input_query, $options);
    }

    /*** END Primary methods ***/



    /*** BEGIN Deprecated Functions ***/

    /**
     * Filter array by key of related entity, as callback in array_map() or array_filter()
     * Supports traditional Symfony object level queries. Not designed for DQL (flattened or 'array-result' query style)
     */
    private function filterByRelatedField($record=null, $entity='', $field='', $value='')
    {
        $record = ($record ? $record : $this->r_record);
        $entity = ($entity ? $entity : $this->r_entity);
        $field  = ($field  ? $field  : $this->r_field);
        $value  = ($value  ? $value  : $this->r_value);

        $getEntity = 'get' . $entity;
        $getField  = 'get' . $field;
        $this->r_error = '';
        $result = null;
        // property is defined, has a record associated, and value matches
        if(method_exists($record, "$getEntity") && is_object($record->$getEntity())) {
            if($record->$getEntity() && $record->$getEntity()->$getField() == $value) {
                $result = $record;
            }
        } else {
            $this->r_error = "Entity '$entity' is not related to $record";
        }

        return $result;
    }

    /**
     * DEPRECATED
     * KD 12/03/18 - THIS FUNCTION IS HERE IN CASE IT NEEDS TO BE RESTORED. DO NOT MAINTAIN. DELETE AT SOME POINT.
     * Get records for any entity by any field, using non-dql query /value<br />
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "~Global",
     *   resource = true,
     *   description = "Get records for any entity by any field, e.g., ""Person"", {""scsUserId"":""358""}",
     *   todo = "Add pagination support",
     *   input = {
     *       "class" = "ApiBundle\Form\ApiType",
     *     },
     *   parameters = {
     *     {
     *       "name" = "name",
     *       "dataType" = "string",
     *       "required" = 1,
     *       "format" = "string",
     *       "description" = "Entity name",
     *     },
     *     {
     *       "name" = "query",
     *       "dataType" = "string",
     *       "required" = 1,
     *       "format" = "JSON",
     *       "description" = "{""field_name"":""field_value"",""status"":1, etc}",
     *     },
     *     {
     *       "name" = "options",
     *       "dataType" = "string",
     *       "required" = 0,
     *       "format" = "JSON",
     *       "description" = "{""bundle"":""ApiBundle"",""status"":1, etc.}",
     *     },
     *   },
     *   output = "ApiBundle\Entity\$entity",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *     422 = "Returned when entity bad or unspecified",
     *   },
     * )
     *
     * @Get("/deprecated/entity/{name}/by/{query}/{options}", defaults={"query"="","options"=""}, name="api_api_deprecated_get_entity_by_query", options={"method_prefix"=false})
     *
     * @param string $name  Entity name
     * @param JSON $query   {''field_name'':''field_value'', ''status'':1, etc.}
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string JSON
     */
    public function getEntityByNonDQLAction($name, $query, $options)
    {
        // TODO: pull out various blocks into helper/sub methods
        // TODO: pull out legacy traditional/non-DQL handling into separate method

        // Extensible options handling
        $defaults = $this->default_options;

        // confirm incoming arguments are proper JSON and each represents an array
        $query = $this->validateJsonInput_2('query', $query);

        //if (empty($this->errors)) {
        if($query === false){
            $this->setError(implode(", ", $this->errors));
            $debug = $this->default_options['debug'];
        }
        else{

            // set options vars based on default keys
            $merged = $this->mergeOptionsAction($defaults, $options);
            if ($merged === false){
                $this->setError(implode(", ", $this->errors));
                $debug = $this->default_options['debug'];
            }
            else{
                foreach($merged as $k => $v){
                    $$k = $v;
                }

                $this->setDebugMessage($debug, isset($debug[1]), json_encode($options));

                // translate $status option value to 'active' query value, if no 'active' value
                if (is_array($query) && !isset($query['active']) && 0 <= $status && $status <= 1) {
                    $query['active'] = $status;
                }
                // Else: Do nothing -- 'active' was set in $query, or $status is an unusable value, so ignore.
                // (Note this means setting 'active' in $query overrides both $defaults and/or $options values for 'status')

                $this->setDebugMessage($debug, isset($debug[2]), '$merged: ' . print_r($merged, true));

                if(!$name){
                    $this->setError('$name cannot be empty');
                }
                else{

                    // accommodate default input from api-docs-sandbox page

                    $name = str_ireplace('{name}', '', $name); // accommodate default input from api-docs-sandbox page
                    $name = ucfirst(strtolower($name));        // make input case-insensitive (controller name matching)

                    $bundle_entity = $bundle . ':' . $name;

                    if (!$this->validateEntity($name, $bundle)){
                        $this->setError('$name must be a valid entity in ' . $bundle);
                    }
                    else{

                        $this->setDebugMessage($debug, isset($debug[3]), ', $include_entities: ' . (is_array($include_entities) ? '(is array) ' . implode(', ', $include_entities): '(not array) ' . $include_entities));

                        /* cases: 3 outcomes
                         * - status = 2,         $query = empty  => findAll()
                         * - status = 2,         $query = !empty => findBy() (use $query as is)
                         * - status in (0,1),    $query = empty  => findBy() (add 'active' key)
                         * - status in (0,1),    $query = !empty => findBy() (add 'active' key, if not defined)
                         * - status !in (0,1,2), $query = empty  => findBy() (add 'active' key)
                         * - status !in (0,1,2), $query = !empty => findBy() (add 'active' key, if not defined)
                         */

                        if ($status == 2) { // from $options; no restriction on status/active unless in $query

                            if(count($query)) { // $query is decoded JSON of the original $query argument

                                $em = $this->getDoctrine()->getManager();

                                // test that queried field/relationship is valid before proceeding -- avoids 500 errors
                                // TODO: this properly detects scalar properties, but not associated properties (like person.org)
                                $invalid_properties = [];
                                $columns = $em->getClassMetadata("$bundle_entity")->getColumnNames();
                                foreach($query as $k => $v) {
                                    if (!in_array($k, $columns)) {
                                        $invalid_properties[] = $k;
                                    }
                                }

                                $this->setDebugMessage($debug, isset($debug[9]), '$columns: ' . implode(', ', $columns));

                                if ('empty($invalid_properties)') { // non-test, for now

                                    $this->response_data = $this
                                        ->getDoctrine()
                                        ->getRepository("$bundle_entity")
                                        ->findBy($query);

                                    $this->setDebugMessage($debug, isset($debug[10]), (is_array($query) ? implode(', ', $query) : '$query is not an array;'));

                                }
                                else {
                                    $this->setError('Query filter parameters were invalid for ' . $name . ': ' . implode(', ', $invalid_properties));
                                }
                            }
                            else {

                                $this->response_data = $this
                                    ->getDoctrine()
                                    ->getRepository("$bundle_entity")
                                    ->findAll();

                                $this->setDebugMessage($debug, isset($debug[11]), (is_array($query) ? implode(', ', $query) : '$query is not an array;'));

                            }
                        }
                        else {
                            // add 'active' according to $options or $defaults
                            if (!isset($query['active']) && 0 <= $status && $status <= 1) {
                                $query['active'] = $status;
                            }
                            // do nothing -- 'active' is set in $query or $status is an unusable value, so ignore
                            else {
                                // (Note this means setting 'active' in $query overrides both $defaults and $options value(s) for status ('active'))
                            }

                            // segregate fields from related entities vs. root entity into array (e.g., 'app.appkey' vs. 'name')
                            //     - '0' index holds fields associated with root entity
                            //     - '<name>' holds field associated with related entity <name>
                            $expanded_query = array(array());
                            $has_related = false;
                            // TODO: handle call to unrelated entity gracefully?                              (done)
                            //       should we modify the error?                                              (not yet)
                            // TODO: handle more than one related entity?                                     (done)
                            // TODO: handle entities more than one relation distant?                          (not yet) (doctrine relations only)
                            // TODO: handle related entities that are OneToMany?                              (not yet)
                            // TODO: decide how 'active' should be propagated to related entities             (done)
                            //       Apply same value?                                                        (no)
                            //       handle separate value, if supplied?                                      (done)    (overrides/is used)
                            //       handle original 'status':'2'?                                            (deprecated)
                            // TODO: String searches currently require exact match.
                            //       add param for wildcard?                                                  (not yet) (not via findBy())
                            foreach($query as $k => $v) {
                                // e.g., if root entity were 'Privilegerole,' then $k might be 'privilege.name'
                                //       (or in further-reaching form, 'privilege.app.appkey')
                                $k_exp = explode('.', $k);
                                // 'privilege'  -> [0 => 'privilege']
                                // 'app.appkey' -> [0 => 'app', 1 => 'appkey']
                                // etc.
                                if (count($k_exp) > 1) { // field name has more than one part, split on at least one '.'
                                    $has_related = true;
                                    //$i = 0;
                                    //foreach($k_exp as $k_x => $v_x) { // for multiple relationship levels -- not yet handled
                                        $r_entity = $k_exp[0];
                                        $r_field  = $k_exp[1];
                                        $r_value  = $v;
                                        $expanded_query["$r_entity"]["$r_field"] = $r_value; // allows one level (e.g., 'app.appkey' => 'JaY8EwSv')
                                    //}

                                    /* Deprecated -- apply $status only to root entity records

                                    // Propagate original $status value, unless previously set from $query
                                    if (0 <= $status && $status <= 1 && !isset($expanded_query["$r_entity"]['active'])) {
                                        $expanded_query["$r_entity"]['active'] = $status;
                                    }

                                    */

                                }
                                else {
                                    $expanded_query[0]["$k"] = $v; // these field names apply to root entity
                                }
                            }

                            $this->response_data = $this
                                ->getDoctrine()
                                ->getRepository("$bundle_entity")
                                //->findBy($query);
                                ->findBy($expanded_query[0]);
                            $this->response_message[] = 'Filtered records by $query';

                            $this->setDebugMessage($debug, isset($debug[12]), print_r($expanded_query[0], true));

                            // further filter by related field values
                            if ($has_related) {
                                // these private vars used by filterByRelatedField()
                                // TODO: convert to arrays, to accommodate multiple related parameters in $expanded_query?
                                foreach ($expanded_query as $related_e => $related_v) {
                                    if ($related_e) { // only if not '0' (which signifies the root entity, not a related one)
                                        $this->r_entity = $related_e;
                                        foreach ($related_v as $r_field => $r_value) {
                                            $this->r_field = $r_field;
                                            $this->r_value = $r_value;

                                            $this->response_data = array_filter($this->response_data, array($this, 'filterByRelatedField'));
                                            $this->response_data = array_values($this->response_data); // otherwise, indexes are string values of original integers, and in indeterminate order
                                        }
                                    }
                                }

                                $this->setDebugMessage($debug, isset($debug[13]), 'further filtered by related field(s)');
                            }
                        }

                        if ($this->r_error) {
                            $this->setError("Error: '$this->r_error'");
                        }
                        else {

                            if (is_null($this->response_data)) {
                                $this->response_message = $this->response_message . ", No records found in $name";
                            } else {
                                $this->response_count   = count($this->response_data);
                                $this->response_code    = Response::HTTP_OK;
                                //$this->response_message = ''; // normally, we'll return blank $this->response_message on successful result
                            }
                        }
                    }
                }
            }
        }

        if(null === $this->response_data) {
            $this->response_count = null;
        }
        else {
            $this->response_count = count($this->response_data);
            $this->response_code = Response::HTTP_OK;
        }

        $this->setDebugMessage($debug, isset($debug[14]), '[$query: ' . print_r($query, true) . ', $options: ' . print_r($options, true) . ']');

        // reordered for convenience in Workbench results (esp. for repetitive testing
        return $this->getViewResponse();

        /*
        Caching experiments: (integrate with app_cache.php)

        $result = new View(array('data' => $this->response_data, 'count' => $this->response_count, 'code' => $this->response_code, 'message' => $this->response_message), $this->response_code);
        $result->setHeader('s-maxage', 60);                                 // 1m
        $result->setHeader('must-revalidate', true);                        // confirm this would be useful and effective
        //$result->setHeader('public', true);                                 // doesn't make result cacheable
        //$result->setHeader('vary', array('Accept-Encoding', 'User-Agent')); // already seems to be set

        return $result;
        */
    }

    /*** END Deprecated Functions ***/

}
