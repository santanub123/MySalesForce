<?php 

namespace ApiBundle\Controller;

use ApiBundle\Entity\Person;
use FOS\RestBundle\Controller\FOSRestController;
//use FOS\RestBundle\View\View;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class CronController extends FOSRestController {

    /**
     * @Route("/person/cron/deactivateUserOnEndDate")
     */
    public function deactiveUserOnEndDate() {
 
      //should run via curl (through API.php)
      $repositoryPerson = $this->getDoctrine()->getRepository(Person::class);
      $current_date = date('Y-m-d');
      $entityManager = $this->getDoctrine()->getManager();
      $query = $entityManager->createQuery(
          "SELECT p
          FROM ApiBundle:Person p 
          WHERE p.endDate <= :end_date 
          AND p.active = :active"
      )->setParameters(
        array(
          'end_date' => $current_date,
          'active' => 1
          )
      );
      $persons = $query->getResult();
      
      $deactivatedUsers = [];

      // loop won't run if there are no users (which is OK)
      foreach($persons as $person) {
        array_push($deactivatedUsers, [
            "id"        => $person->getId(),
            "nameFirst" => $person->getNameFirst(),
            "nameLast"  => $person->getNameLast(),
            "email1"    => $person->getEmail1(),
            "startDate" => $person->getStartDate(),
            "endDate"   => $person->getEndDate()
          ]);
        // $person->setActive(0);
      
        // use PersonController->getPersonDeactivate($id) to deactivate Person and disable User.
        // (use forward() as alternate to curl)
        $this->forward('ApiBundle:Person:getPersonDeactivate', [
            'id' => $person->getId()
        ]);
        
      }
      // $entityManager->flush();
      
      // format expected by Api.php and our general convention
      $response = (object) [
          'count'   => count($deactivatedUsers),
          'data'    => $deactivatedUsers,
          'code'    => Response::HTTP_OK, // 200
          'message' => ''
        ];
        
      return new Response(json_encode($response));
  }
}
