<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\User;
use ApiBundle\Form\UserType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;

use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class UserController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "User",
     *   resource = true,
     *   description = "Get User with id",
     *   output = "ApiBundle\Entity\Result",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the User id
     *
     * @return Array
     *     JSON array of 1 User object
     */
    public function getUserAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'User',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all users<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "User",
     *   resource = true,
     *   description = "Get all Users (array of objects)",
     *   output = "ApiBundle\Entity\User",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)"
     *   }
     * )
     *
     * @Get("/users/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_users", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of User objects
     */
    public function getUsersQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'User',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create User
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "User",
     *   resource = true,
     *   description = "Create User",
     *   input = "ApiBundle\Form\UserType",
     *   output = "ApiBundle\Entity\User",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postUserAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'User',
                'options' => '{}',
            ]
        );
    }

    /**
     * Create user, with option to register ($option=1), and to notify ($option=2)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "User",
     *   resource = true,
     *   description = "Create User",
     *   input = "ApiBundle\Form\UserType",
     *   output = "ApiBundle\Entity\User",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @Get("/user/register/{option}", name="api_post_user_register", options={"method_prefix" = false})
     *
     * @return user
     */
    public function postUserRegister(Request $request, $option=false)
    {
        $user = new User();
        $form = $this->createForm(
            UserType::class,
            $user
        );

        $form->handleRequest($request);

        $errors = $this->get('validator')->validate($user);
        if (count($errors) > 0) {
            $data          = $user;
            $count         = 0;
            $message       = $errors;
            $http_response = Response::HTTP_UNPROCESSABLE_ENTITY;
        } else {
            $manager = $this->getDoctrine()->getManager();
            $manager->persist($user);
            $manager->flush();

            $data          = $user;
            $count         = 1;
            $message       = '';
            $http_response = Response::HTTP_CREATED;

            if ($option) {

                // TODO: get email, id
                $user_email = '';
                $user_id = '';
                $succesfullyRegistered = $this->register("demo@example.com", 27, true);

                if ($succesfullyRegistered && $option == 2) { // the user is now registered -- send mail?

                    /*
                    $message = (new \Swift_Message('Welcome to SCS'))
                                    ->setFrom('nestadmin@scscertified.com')
                                    ->setTo('someuser@example.com') // in Dev config.yml, this can be set to always send to a fixed email address, for testing
                                    ->setBody(
                                        $this->renderView(
                                            // app/Resources/views/Emails/registration.html.twig
                                            'Emails/registration.html.twig',
                                            array('name' => $name)
                                        ),
                                        'text/html'
                                    )

                                    // include a plaintext version of the message
                                    ->addPart(
                                        $this->renderView(
                                            'Emails/registration.txt.twig',
                                            array('name' => $name)
                                        ),
                                        'text/plain'
                                    );

                    $this->get('mailer')->send($message);
                    */

                    $message = 'User created, registered, and notified';

                } elseif ($succesfullyRegistered) {

                    $message = 'User created and registered';

                } else { // the user exists

                    $message = 'User created but not registered';

                }

            }

        }

        return new View(array('data' => $data, 'count' => $count, 'code' => $http_response, 'message' => $message), $http_response);
    }

   /**
    * Registers a user in the database manually.
    *
    * @return boolean User registered / not registered
    **/
   private function register($email, $person_id, $update=false)
   {
        // derived from: https://ourcodeworld.com/articles/read/91/how-to-register-an-user-in-a-custom-controller-with-fosuserbundle-in-symfony

        $userManager = $this->get('fos_user.user_manager');
        $user = $userManager->findUserByEmail($email);

        // You can also use the doctrine entity manager in the traditional way:
        //
        // $em = $this->getDoctrine()->getManager();
        //
        // ...then use shorthand:
        // $usersRepository = $em->getRepository("mybundleuserBundle:User");
        //
        // ...or use namespace and name of the class:
        // $usersRepository = $em->getRepository("mybundle\userBundle\Entity\User");
        //
        // Then check uniqueness of email:
        // $user = $usersRepository->findOneBy(array('email' => $email));

        $proceed = 0;

        if ($update && $user) { // expected to exist and does
            $proceed = 1;
        } elseif (!$update && $user) { // expected empty, but isn't
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_ACCEPTED; // 202
            $message       = 'Email not unique';
        } elseif ($update && !$user) { // expected to exist, but doesn't
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_ACCEPTED; // 202
            $message       = 'User not found';
        } elseif (!$update && !$user) { // expect empty and is
            $proceed = 2;
            $user = $userManager->createUser();
            // TODO: adjust username if SCS vs. not (left side of email, or full email for username)
            $user->setUsername($email);
            $user->setEmail($email);
            $user->setEmailCanonical($email);
        }

        if ($proceed) {
            $user->setPersonId($person_id); // TODO: confirm this method exists (magically or otherwise)
            $user->setLocked(0); // don't lock the user
            $user->setEnabled(1); // enable user (or enable later with a confirmation token in the email)
            $user->setPlainPassword($password); // encrypt password with default settings
            $userManager->updateUser($user);

            // TODO: send notification email? (to dev/admin & user)

            $data          = $user;
            $count         = 1;
            $http_response = Response::HTTP_OK; // 200
            $message       = '';
        }

        return new View(array('data' => $data, 'count' => $count, 'code' => $http_response, 'message' => $message), $http_response);
    }

    /**
     * Edit User (PUT)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "User",
     *   resource = true,
     *   description = "Edit User",
     *   input = "ApiBundle\Form\UserType",
     *   output = "ApiBundle\Entity\User",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     404 = "Returned when page is not found (implicit)"
     *   }
     * )
     *
     * @return user
     */
    public function putUserAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'User',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit User (PATCH)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "User",
     *   resource = true,
     *   description = "Edit User",
     *   input = "ApiBundle\Form\UserType",
     *   output = "ApiBundle\Entity\User",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     404 = "Returned when page is not found (implicit)"
     *   }
     * )
     *
     * @return user
     */
    public function patchUserAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'User',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a User
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "User",
     *   resource = true,
     *   description = "Delete User",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete"
     *   }
     * )
     *
     * @param integer $id
     *     the User id
     *
     * @return string
     *     JSON array
     */
    public function deleteUserAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'User',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }
}
