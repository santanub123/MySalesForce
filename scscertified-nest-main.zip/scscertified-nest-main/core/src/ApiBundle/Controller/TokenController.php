<?php
/* 
 * Not yet in use, but may be the way to inject more data into the token on login.
 * Many of these functions may be covered in the EventListeners, so this Controller may not be necessary 
 */

//namespace AppBundle\Controller\Api;
namespace ApiBundle\Controller;

//use AppBundle\Controller\BaseController;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;


//class TokenController extends BaseController
class TokenController extends Controller
{
    /**
     * @Route("/api/tokens")
     * @Method("POST")
     */
    public function newTokenAction(Request $request)
    {
        $user = $this->getDoctrine()
            ->getRepository('ApiBundle:User')
            ->findOneBy(['username' => $request->getUser()]);
        
        if (!$user) {
            throw $this->createNotFoundException();
        }
        
        $isValid = $this->get('security.password_encoder')
            ->isPasswordValid($user, $request->getPassword());
        
        if (!$isValid) {
            throw new BadCredentialsException();
        }
        
        // amendments below not yet showing up in the token -- see JWTCreated listener instead
        $token = $this->get('lexik_jwt_authentication.encoder')
            ->encode([
                'username' => $user->getUsername(),
                //'exp' => time() + 3600, // 1 hour expiration
                'test' => 'role-sample'
            ]); // this becomes part of the payload -- anything can be added (see jwt.io)
            
        return new JsonResponse(['token' => $token]);
    }
}
