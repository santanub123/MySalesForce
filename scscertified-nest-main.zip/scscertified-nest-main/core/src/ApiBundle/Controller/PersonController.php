<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Person;
use ApiBundle\Form\PersonType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
use FOS\RestBundle\Controller\Annotations\Patch;
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;


use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

use Doctrine\Common\Collections\ArrayCollection;

use Doctrine\DBAL\DBALException;
/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class PersonController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get Person with id",
     *   output = "ApiBundle\Entity\Person",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the Person id
     *
     * @return string
     *     JSON array of 1 Person object
     */
    public function getPersonAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Person',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all persons
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get all Persons (array of objects)",
     *   output = "ApiBundle\Entity\Person",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/persons/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_persons", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Person objects
     */
    public function getPersonsQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Person',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create Person
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Create Person",
     *   input = "ApiBundle\Form\PersonType",
     *   output = "ApiBundle\Entity\Person",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postPersonAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Person',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Person (replace)
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Edit Person (replace)",
     *   input = "ApiBundle\Form\PersonType",
     *   output = "ApiBundle\Entity\Person",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function putPersonAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Person',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Person (update)
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Edit Person (update)",
     *   input = "ApiBundle\Form\PersonType",
     *   output = "ApiBundle\Entity\Person",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function patchPersonAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Person',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a person
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Delete Person",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *    the Person id
     *
     * @return string
     *     JSON array
     */
    public function deletePersonAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Person',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /*** Extended functions (beyond basic CRUD ***/

    /**
     * Get persons by any field/value
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get Persons by any field, e.g., {""scsUserId"":""358""}",
     *   output = "ApiBundle\Entity\Person",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @Get("/persons/by/{query}", name="api_get_persons_by_query", options={"method_prefix" = false})
     *
     * @param string $query JSON {''fieldname'':''value''}
     *
     * @return string
     */
    /* DEPRECATED
    public function getPersonsByQuery($query=null)
    {

        $query = json_decode($query, true); // to array

        if (!is_array($query)) {
            $data          = null;
            $count         = 0;
            $message       = '$query must be an array and/or is not valid JSON';
            $http_response = Response::HTTP_UNPROCESSABLE_ENTITY; // 422
        }

        $persons = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->findBy($query);

        if (is_null($persons)) {
            $data          = null;
            $count         = 0;
            $message       = 'No Persons found';
            $http_response = Response::HTTP_OK; // 200
        } else {
            $data          = $persons;
            $count         = count($persons);
            $message       = '';
            $http_response = Response::HTTP_OK; // 200
        }

        return new View(array('count' => $count, 'data' => $data, 'code' => $http_response, 'message' => $message), $http_response);
    }
    */

    /**
     * Retrieve person's org's ancestors<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get ancestral Orgs for a given Person",
     *   output = "ApiBundle\Entity\Org",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty),"
     *   }
     * )
     *
     * @return string
     */
    public function getPersonOrgAncestorsAction($id=null)
    {
        // TODO: amend input variable be full Person object, to save the initial query?
        $person = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->find($id);

        if (is_null($person)) {
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_OK; // 200
            $message       = 'No Person found';
        } else {
            $data          = $person->getOrgAncestors();
            $count         = count($data);
            $http_response = Response::HTTP_OK; // 200
            $message       = '';
        }

        return new View(array('count' => $count, 'data' => $data, 'code' => $http_response, 'message' => $message), $http_response);
    }

    /**
     * Retrieve person's direct assignedroles<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get Assignedroles for a given Person",
     *   output = "ApiBundle\Entity\Assignedrole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty),"
     *   }
     * )
     *
     * @Get("/person/{id}/assignedroles/self/{options}", defaults={"options" = "{}"}, name="api_get_person_assignedroles_self", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getPersonAssignedrolesSelfQuery(
        $id      = null,
        $options = null
    ) {
        $merged_options = ApiController::processOptions($options);

        $person = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->find($id);

        if (is_null($person)) {
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_OK; // 200
            $message       = 'No Person found';
        } else {

            //if ($merged_options['flat_result']) {
            $dql_use = 1;
            if ($dql_use == 0) {

                // DQL (flat) version
                $flat_result = $merged_options['flat_result'];
                $include_entities = json_encode($merged_options['include_entities']);
                $assignedroles   = $this->forward('ApiBundle:Api:getEntityBy', array(
                    'name'    => 'assignedrole',
                    'query'   => '{"personId":"' . $id . '"}',
                    'options' => '{"status":"2","flat_result":"' . $flat_result . '","include_entities":' . $include_entities . '}',
                ));

                $data          = json_decode($assignedroles->getContent(), true);

                $http_response = $data['code'];
                $message       = $data['message'];
                $data          = $data['data'];
                $count         = count($data);

            }
            // traditional, non-DQL (flat) version -- can be expensive
            else {

                $assigned_roles = $person->getAssignedroles();

                // Filter results based on status.
                $data = ApiController::filterByStatus(
                    $assigned_roles,
                    $merged_options['status']
                );

                $count         = count($data);
                $http_response = Response::HTTP_OK; // 200
                $message       = '';
            }
        }

        return new View(
            [
                'code'    => $http_response,
                'message' => $message,
                'count'   => $count,
                'data'    => $data,
            ],
            $http_response
        );
    }

    /**
     * Retrieve person's org's assignedroles<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get Assignedroles from parent Org of Person",
     *   output = "ApiBundle\Entity\Assignedrole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty),"
     *   }
     * )
     *
     * @Get("/person/{id}/assignedroles/org/{options}", name="api_get_person_assignedroles_org", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getPersonAssignedrolesOrgQuery($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $person = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->find($id);

        if (is_null($person)) {
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_OK; // 200
            $message       = 'No Person found';
        } else {

            // DQL (flat) query
            $dql_use = 1;
            if ($dql_use == 0) {

                $org_id = $person->getOrg()->getId();
                //$org_id = $person->getOrgId(); // more performant, but only by a little
                $flat_result      = $merged_options['flat_result'];
                $include_entities = json_encode($merged_options['include_entities']);
                $assignedroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                    'name'    => 'assignedrole',
                    'query'   => '{"orgId":"' . $org_id . '"}',
                    'options' => '{"status":"2","flat_result":' . $flat_result . ',"include_entities":' . $include_entities . '}',
                ));
                $data = json_decode($assignedroles->getContent(), true); // unserialize to array

                $http_response = $data['code'];
                $message       = $data['message'];
                $count         = $data['count'];
                $data          = $data['data'];
            }
            // non-DQL (flat)
            else {

                $assigned_roles = $person->getAssignedrolesOrg();
                // Filter results based on status.
                $data = ApiController::filterByStatus(
                    $assigned_roles,
                    $merged_options['status']
                );

                $count         = count($data);
                $http_response = Response::HTTP_OK; // 200
                $message       = '';
            }
        }

        return new View(
            [
                'code'    => $http_response,
                'message' => $message,
                'count'   => $count,
                'data'    => $data,
            ],
            $http_response
        );
    }

    /**
     * Retrieve person's direct and org-assignedroles<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get Assignedroles for a Person from all sources (self & Org)",
     *   output = "ApiBundle\Entity\Assignedrole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty),"
     *   }
     * )
     *
     * @Get("/person/{id}/assignedroles/all/{options}", name="api_get_person_assignedroles_all", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getPersonAssignedrolesAllQuery($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $person = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->find($id);

        if (is_null($person)) {
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_OK; // 200
            $message       = 'No Person found';
        } else {

            $dql_use = 1;
            if ($dql_use == 0) {

                // traditional, non-DQL (flat)
                $assigned_roles = $person->getAssignedrolesAll();
                // Filter results based on status.
                $data = ApiController::filterByStatus(
                    $assigned_roles,
                    $merged_options['status']
                );

                $message = '';

            }
            // use DQL (flat)
            else {

                // TODO: this replicates queries contained in getPersonAssignedrolesOrgQuery() and
                //       getPersonAssignedrolesSelfQuery, on order to avoid searching for Person object twice.
                //       This could be refactored.

                $flat_result      = $merged_options['flat_result'];
                $include_entities = json_encode($merged_options['include_entities']);

                $org_id = $person->getOrg()->getId();
                $org_assignedroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                    'name'    => 'assignedrole',
                    'query'   => '{"orgId":"' . $org_id . '"}',
                    'options' => '{"status":"2","flat_result":"' . $flat_result . '","include_entities":' . $include_entities . '}',
                ));
                $org_assignedroles = json_decode($org_assignedroles->getContent(),true);
                $org_assignedroles = (array) $org_assignedroles; // cast in case result is null
                if (!isset($org_assignedroles['data'])) {
                  $org_assignedroles['data'] = [];
                }

                $person_assignedroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                    'name'    => 'assignedrole',
                    'query'   => '{"personId":"' . $id . '"}',
                    'options' => '{"status":"2","flat_result":"' . $flat_result . '","include_entities":' . $include_entities . '}',
                ));
                $person_assignedroles = json_decode($person_assignedroles->getContent(), true);
                $person_assignedroles = (array) $person_assignedroles; // cast in case result is null
                if (!isset($person_assignedroles['data'])) {
                  $person_assignedroles['data'] = [];
                }

                $data = new ArrayCollection(
                           array_merge(
                               $person_assignedroles['data'],
                               $org_assignedroles['data']
                           )
                       );

                $message = 'Filtered by DQL';

            }

            $count         = count($data);
            $http_response = Response::HTTP_OK; // 200
        }

        return new View(
            [
                'code'    => $http_response,
                'message' => $message,
                'count'   => $count,
                'data'    => $data,
            ],
            $http_response
        );
    }

    /**
     * Retrieve person's privilege roles (via assignedroles->roles & assignedroles->units)<br />
     * TODO: add pagination<br />
     * TODO: returns null 'data' for no Privilegeroles *or* for no matching Person
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get Privilegeroles for a Person, through Roles and Units. Optional filtering by appkey.",
     *   output = "ApiBundle\Entity\Privilegeroles",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty),"
     *   }
     * )
     *
     * @Get("/person/{id}/privilegeroles/{appkey}/{options}", name="api_get_person_privilegeroles", options={"method_prefix" = false}, defaults={"appkey"="{}","options"="{}"})
     *
     * @return string
     */
    public function getPersonPrivilegerolesQuery(
        $id = null,
        $appkey = null,
        $options = null
        //$options = '{"flat_result":"0"}' // avoid DQL (flat) in this case, which is default for method called further down
    ) {
        // artifacts of empty fields in ApiDoc sandbox
        $id      = str_ireplace('{id}',      '', $id);
        $appkey  = str_ireplace('{appkey}',  '', $appkey);
        $appkey  = str_ireplace('{}',        '', $appkey); // route default, when not from sandbox
        $options = str_ireplace('{options}', '', $options);

        $merged_options = ApiController::processOptions($options); // static method, drops unrecognized keys

        $status          = $merged_options['status'];
        $dql_use         = 1; //$merged_options['dql_use'];
        $flat_result     = $merged_options['flat_result'];

        $privilegeroles = [];
        $data    = [];
        $message = '';

        $person = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->find($id);

        if ($person != null) {

            /*** 3 possible methods at work ***/



            /*** METHOD 1 ***/

            /* Karen's 1st method

            //KD - This code should work, but doesn't. It produces an infinite loop. I'm stumped by it.
            //I'm leaving it in here in case someone else would like to examine. If we come up with a
            //more efficient solution, I'm happy to delete this.

            //VR - 'forwarding' usage is nice, but could this entire method be replaced with DQL? Might be more straightforward, and faster. (The latter isn't a huge consideration unless this method is called repeatedly -- say, in a list of users....)

            //VR - turned out some small-ish modifications bring this close to success.

            $serializer = \JMS\Serializer\SerializerBuilder::create()->build();
            //$serializer = $container->get('jms_serializer'); // from service
            //$data = $serializer->deserialize($inputStr, $typeName, $format);

            $ars = $this->getPersonAssignedrolesAllQuery($id); // returns View object
            $ars = $ars->getData();
            $ars = $ars['data']; // content of our standard return key (of 'data,' 'count,' 'code,' and 'message')
            $privilegeroles = array();
            for($i = 0; $i < count($ars); $i++){
                $prs_get = $this->forward(
                    'ApiBundle\Controller\AssignedroleController::getAssignedrolePrivilegerolesAction',
                    array("id" => $ars[$i]->getId())
                );
                //$prs_get = $prs_get->getContent(); // method from Response object
                $prs_get = $serializer->deserialize($prs_get->getContent(), 'ApiBundle\Entity\Privilegerole', 'json'); // very close!

                $privilegeroles[] = $prs_get;
            }

            $message       = 'Method 1';

            */


            /*** METHOD 2 ***/

            /* Most viable method so far. */

            /* Karen's 2nd method */


            // Temp, until we fix the traditional/non-DQL handling
            ////$flat_result = 1; // override incoming options for now. This also means value of $dql_use has no effect.

            /* Here, include_entities is hard-coded because a value passed in from the parent method won't
             * make sense throughout the chain of endpoint calls (whereas flat_result does). If flat_result is 0,
             * include_entities is ignored.
             */
            // Note use of other method directly, rather than by $this->forward(): doesn't make use of route defaults but otherwise the same (and arguably faster to invoke); consider elsewhere?
            $assignedroles = $this->getPersonAssignedrolesAllQuery($id, '{"status":"' . $status . '","dql_use":"' . $dql_use . '","flat_result":"' . $flat_result . '","include_entities":["role","unit"]}'); // results in View object (variation of Response object)
            $assignedroles = $assignedroles->getData(); // method from View object
            $assignedroles = $assignedroles['data']; // our key
            //if(method_exists($assignedroles, 'toArray')) {
            //    $assignedroles = $assignedroles->toArray(); // Doctrine ArrayCollection method
            //}

            if (!empty($assignedroles)) {
            //if (!empty($assignedroles) && is_array($assignedroles)) {

                //Create 2 dimensional associative array.
                //The first level has an array at the value of a role id
                //The second level has a true at every unit id.
                //This is a simple way of removing duplicates

                $privilegeroles = array();
                $pairs = array();

                // from assignedroles, get units as de-duped array and combined into pairs with $role_id

                // DQL (flat)
                if ($flat_result) {

                    foreach ($assignedroles as $assignedrole) {

                        // Role
                        $r_id = $assignedrole['roleId'];

                        // Unit & pair
                        if ($r_id) { // should always be true, but it might not be
                            $u_id = $assignedrole['unitId'];
                            $pairs[$r_id][$u_id] = true; // primary unit, if any
                            $units = $this->forward('ApiBundle:Unit:getUnitAncestors', array('id' => $u_id));
                            $units = json_decode($units->getContent(), true); // deserialize to array
                            $units = $units['data'];
                            foreach ($units as $u) {
                                $u_id = $u['id'];
                                $pairs[$r_id][$u_id] = true;
                            }
                        }

                    }
                }
                // traditional, non-DQL (flat)
                else {

                    foreach ($assignedroles as $assignedrole) {

                        // Role
                        if(method_exists($assignedrole, 'getRole')) {
                            $role = $assignedrole->getRole();
                        }
                        // ?
                        else {
                            //$role = $assignedrole->role;
                            $role = $assignedrole['role'];
                        }
                        if ($role !== null) { // not supposed to happen, but it can
                            if(method_exists($role, 'getId')) {
                                $r_id = $role->getId();
                            }
                            else {
                                $r_id = $role['id'];
                            }
                        } else {
                            $r_id = null;
                        };

                        // Unit & pair
                        if ($r_id) { // should always be true, but it might not be

                            if(method_exists($assignedrole, 'getUnit')) {
                                $unit = $assignedrole->getUnit();
                            }
                            // ?
                            else {
                                //$Unit = $assignedrole->Unit;
                                $unit = $assignedrole['unit'];
                            }


                            if ($unit === null) {
                                $pairs[$r_id]['null'] = true;
                            }
                            else {

                                // get Ancestors for current Unit
                                if(method_exists($unit, 'getAncestors')) {
                                    $units = $unit->getAncestors();
                                }
                                // ?
                                else {
                                    $unit_id = $unit['id'];
                                    $units = $this->forward('\ApiBundle\Controller\UnitController::getUnitAncestorsAction', array('id' => $unit_id, 'options' => '{}'));
                                    $units = json_decode($units->getContent(), true); // deserialize to array
                                    
                                    if (!empty($units['data'])) {
                                        $units = $units['data'];
                                    }
                                    else {
                                        // diagnostic
                                        //error_log(__FILE__ . ' ' . __LINE__ . ': $unit = ' . $unit_id . '. $units = ' . json_encode($units));
                                        $units = [];
                                    }
                                    
                                    /*
                                    if ($units['code'] > 299) {
                                        error_log(__FILE__ . ' ' . __LINE__ . ': $units['code'] returned. $unit = ' . $unit_id . '. $units = ' . json_encode($units));
                                        $units = []; // no useable results; should probably exit altogether, otherwise might introduct a sneaky bug
                                    }
                                    else {
                                        $units = $units['data'];
                                    }
                                    */
                                }

                                $units[] = $unit;
                                foreach ($units as $u) {
                                    if(method_exists($u, 'getId')) {
                                        $u_id = $u->getId();
                                    }
                                    // ?
                                    else {
                                        $u_id = $u['id'];
                                    }
                                    $pairs[$r_id][$u_id] = true;
                                }
                            }
                        }
                    }
                }

                /*
                 * Santa: all I want for Christmas is a way of encoding the following query:
                 *
                 *     SELECT *
                 *     FROM Privilegerole p
                 *     WHERE (p.role_id, p.unit_id)
                 *     IN ((1,46),(4,1))
                 *
                 * Where the contents of IN is the array of $pairs.
                 *
                 * We would probably have to add a special operator key (e.g., 'IN_SET'). If we
                 * had it, the API call might look like:
                 *
                 *    /privilegerole/{["roleId","unitId"]:[["1","46"],["4","1"]]}/{"dql_operators":{"":"IN_SET"}}
                 */

                //For every role/unit pair, look for privilegeroles.
                //Also look for privilege roles with a given role and a null unit

                $privilegeroles = [];

                foreach ($pairs as $rk => $rv) { // values are just TRUE; we actually want the keys
                    foreach ($rv as $uk => $uv) {

                        if ($uk !== 'null') {

                            // traditional Symfony objects
                            if (!$flat_result) {
                                $prs = $this
                                        ->getDoctrine()
                                        ->getRepository('ApiBundle:Privilegerole')
                                        ->findBy(array("role" => $rk, "unit" => $uk));
                            }
                            // DQL (flat) data style
                            else {
                                $pr_query   = '{"roleId":"' . $rk . '","unitId":"' . $uk . '"}';
                                $pr_options = '{"dql_use":"' . $dql_use . '","flat_result":"' . $flat_result . '","include_entities":["privilege","unit","role"]}';

                                //$prs = $this->forward('ApiBundle:Privilegerole:getPrivilegerolesQuery', array('query' => $pr_query,'options' => $pr_options));

                                // TODO: note difference in syntax -- the version above is deprecated in Symfony 3, and the version below gets around the '...Action()' requirement. Change other examples elsewhere.

                                $prs = $this->forward('\ApiBundle\Controller\PrivilegeroleController::getPrivilegerolesQuery', array('query' => $pr_query,'options' => $pr_options));

                                $prs = json_decode($prs->getContent(), true); // deserialize to array
                                $prs = $prs['data'];
                            }

                            $privilegeroles = array_merge(
                                $privilegeroles,
                                $prs
                            );
                        }
                    }
                    $privilegeroles = array_merge(
                        $privilegeroles,
                        $this
                            ->getDoctrine()
                            ->getRepository('ApiBundle:Privilegerole')
                            ->findBy(array("role" => $rk, "unit" => null))
                    );
                }
            }
            // no Assignedroles for the person
            else {
                // debug
                //$message = '$assignedroles: ' . print_r($assignedroles, true);

            }

            // debug
            //$message .= '; $pairs: ' . print_r($pairs, true);

            $message .= 'Method 2';



            /*** METHOD 3 ***/

            /* Vincent's method (uses DQL query in Repository method -
               fast and avoids duplicates, but doesn't account for Unit inheritance)

            $privilegeroles = null;

            $person = $this
                ->getDoctrine()
                ->getRepository('ApiBundle:Person')
                ->find($id);

            if ($person != null) {
                $privilegeroles = $this
                        ->getDoctrine()
                        ->getRepository('ApiBundle:Person')
                        ->findPrivilegeroles($id);
            }

            $message       = 'Method 3';

            */

            // optional filtering by $appkey

            $removed = 0;
            if ($appkey) {
                // traditional Symfony objects
                if (!$flat_result) {
                    foreach ($privilegeroles as $pk => $pv) {
                        if ($pv->getPrivilege()->getApp()->getAppkey() != "$appkey") {
                            unset($privilegeroles[$pk]);
                            $removed++;
                        }
                    }
                }
                // DQL (flat)
                else {

                  // TODO: doesn't work with DQL (flat) data return style
                  $message .= '; filtering by appkey for flat result not supported';

                }
                $privilegeroles = array_values($privilegeroles);
            }

            // Filter results based on status. (TODO: Redundant for DQL)
            $data = ApiController::filterByStatus(
                $privilegeroles,
                $merged_options['status']
            );

        } elseif (empty($id)) {

            $message = '$id not allowed to be empty';

        } else {

            $message = 'No Person found';
        }

        /*** COMMON ***/

        //if (!empty($removed)) {
        if (!empty($appkey && !$flat_result)) { // take out second condition when it's fixed
            $message .= '; filtered by appkey (' . $appkey . ')';
        }

        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200
        //$message       = array('debug-view-getdata' => $test['data']);

        return new View(
            [
                'code'    => $http_response,
                'message' => $message,
                'count'   => $count,
                'data'    => $data,
            ],
            $http_response
        );
    }

    /**
     * Retrieve person's privileges (via assignedroles->roles & assignedroles->units)<br />
     * TODO: add pagination<br />
     * TODO: returns null 'data' for no Privileges *or* for no matching Person
     * TODO: underlying entity-based method doesn't work (was needed for controller-less context), needs to be replaced
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get Privileges for a Person, through Roles and Units",
     *   output = "ApiBundle\Entity\Privileges",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty),"
     *   }
     * )
     *
     * #Get("/person/{id}/privileges/{options}", name="api_get_person_privileges", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getPersonPrivilegesAction($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $data = null;

        $person = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->find($id);

        if ($person != null) {
            $privileges = $person->getPrivileges();
            // Filter results based on status.
            $data = ApiController::filterByStatus(
                $privileges,
                $merged_options['status']
            );
            $message       = '';
        } else {
            $message       = 'No Person found';
        }

        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200
        //$message       = array('debug-___' => $assignedroles);

        return new View(
            [
                'count'   => $count,
                'data'    => $data,
                'code'    => $http_response,
                'message' => $message
            ],
            $http_response
        );
    }

    /**
     * Retrieve a set of units for a person and privilege
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get units for a person and privilege",
     *   output = "ApiBundle\Entity\Units",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty),"
     *   }
     * )
     *
     * @Get("/person/{person_id}/privilege/{privilege_id}/units/{options}", defaults={"options"="{}"}, name="api_get_person_privilege_units", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getPersonPrivilegeUnitsQuery(
        $person_id,
        $privilege_id,
        $options = '{}'
    ) {
        $merged_options  = ApiController::processOptions($options);
        $status          = $merged_options['status'];
        $dql_use         = 1; //$merged_options['dql_use'];
        $flat_result     = $merged_options['flat_result'];
        $data = [];
        $message = '';

        // Retrieve active Assignedroles for specified person.
        $assignedrole_query_response = $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'assignedrole',
                'query'   => '{"personId":"' . $person_id . '"}',
                'options' => '{"status":"1","flat_result":"1"}',
            ]
        );
        $ar_response = json_decode(
            $assignedrole_query_response->getContent(),
            true
        );
        $assignedroles = [];
        if (is_array($ar_response) && isset($ar_response['data'])) {
            $assignedroles = $ar_response['data'];
        }
        if (empty($assignedroles)) {
            $message = 'No active assignedroles found for person ' . $person_id;
        } else {
            // Remove duplicate Assignedroles.
            $unique_assignedrole_ids = array_unique(array_map(
                function ($assignedrole) {
                    return (string) $assignedrole['id'];
                },
                $assignedroles
            ));
            $unique_assignedroles = array_filter(
                $assignedroles,
                function ($assignedrole) use ($unique_assignedrole_ids) {
                    return in_array(
                        $assignedrole['id'],
                        $unique_assignedrole_ids
                    );
                }
            );

            // Create an instance of the Privilegerole repository.
            $pr_repository = $this->getDoctrine()->getRepository(
                'ApiBundle:Privilegerole'
            );

            // Collect the unit ids for the Assignedroles that have
            // Privilegeroles for the requested privilege.
            $ar_unit_ids = [];
            foreach ($unique_assignedroles as $assignedrole) {
                $privilegeroles = $pr_repository->findByAssignedrolePrivilege(
                    $assignedrole['id'],
                    (int) $privilege_id,
                    true
                );
                if (!empty($privilegeroles)) {
                    $ar_unit_ids[] = $assignedrole['unitId'];
                }
            }
            $unit_ids = array_unique($ar_unit_ids);
            sort($unit_ids, SORT_NUMERIC);

            if (empty($unit_ids)) {
                $message =
                    'No active privilegeroles found for assignedrole ids [' .
                    implode(',', $unique_assignedrole_ids) .
                    '] and privilege ' . $privilege_id;
            } else {
                // Retrieve the units.
                if (is_array($unit_ids)) {
                    // Filter by status if specified.
                    $where_active_expression = '';
                    if (($status === 0) || ($status === 1)) {
                        $where_active_expression = ' AND u.active = ' . $status;
                    }

                    $em = $this->getDoctrine()->getManager();
                    $query = $em->createQuery(
                        'SELECT u
                        FROM ApiBundle\Entity\Unit u
                        WHERE
                          u.id IN (' . implode(',', $unit_ids) . ')' .
                          $where_active_expression . '
                        ORDER BY u.id ASC'
                    );

                    if ($dql_use && $flat_result) {
                        $data = $query->getArrayResult();
                    } else {
                        $data = $query->getResult();
                    }
                } else {
                    error_log(
                        __FILE__ . ' line ' . __LINE__ .
                        ': Bad value for $unit_ids: ' . var_export(
                            $unit_ids,
                            true
                        )
                    );
                }
            }
        }

        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200

        return new View(
            [
                'data'      => $data,
                'count'     => $count,
                'code'      => $http_response,
                'message'   => $message,
            ],
            $http_response
        );
    }

    /**
     * Retrieve a set of persons having privilege2 and a unit related to a
     * person and privilege1
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Get persons with a privilege related to a person/privilege/unit",
     *   output = "ApiBundle\Entity\Persons",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty),"
     *   }
     * )
     *
     * #Get("/person/{person_id}/privilege1/{privilege1_id}/privilege2/{privilege2_id}/persons/{options}", defaults={"options"="{}"}, name="api_get_person_privilege_privilege_persons", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getPersonPrivilegePrivilegePersonsAction(
        $person_id,
        $privilege1_id,
        $privilege2_id,
        $options = '{}'
    ) {
        // Handle default from doc/sandbox page.
        $filtered_options = str_ireplace('{options}', '{}', $options);

        // Initialize response parameters.
        $data = [];
        $message = '';

        // Retrieve units for this person and privilege1.
        $unit_response_view = $this->getPersonPrivilegeUnitsQuery(
            $person_id,
            $privilege1_id,
            '{"flat_result":"1"}'
        );
        $units = [];
        if (is_object($unit_response_view)) {
            $unit_response = $unit_response_view->getData();
            if (is_array($unit_response) && isset($unit_response['data'])) {
                $units = $unit_response['data'];
            }
        }
        if (empty($units)) {
            $message = 'No units found for person ' . $person_id .
                ' and privilege ' . $privilege1_id;
        } else {
            $consolidated_persons = [];
            foreach ($units as $unit) {
                // Retrieve persons having an assignedrole for each unit and
                // priv2.
                $person_query_response = $this->forward(
                    'ApiBundle:Unit:getUnitPrivilegePersons',
                    [
                        'id'            => $unit['id'],
                        'privilege_id'  => (int) $privilege2_id,
                        'options'       => $filtered_options,
                    ]
                );
                $person_content = $person_query_response->getContent();
                $person_response = json_decode($person_content, true);
                $persons = [];
                if (is_array($person_response) &&
                    isset($person_response['data'])) {
                    $persons = $person_response['data'];
                }

                // Consolidate persons into a single array.
                foreach ($persons as $person) {
                    // Handle object or array result.
                    if (is_array($person)) {
                        $person_id = (int) $person['id'];
                    } elseif ($person instanceof \stdClass) {
                        $person_id = (int) $person->id;
                    } else {
                        $person_id = (int) $person->getId();
                    }
                    if (!array_key_exists($person_id, $consolidated_persons)) {
                        $consolidated_persons[$person_id] = $person;
                    }
                }
            }

            // Sort the person array by id.
            ksort($consolidated_persons);
            $data          = array_values($consolidated_persons);
        }

        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200

        return new View(
            [
                'data'      => $data,
                'count'     => $count,
                'code'      => $http_response,
                'message'   => $message,
            ],
            $http_response
        );
    }

   /**
    * @ApiDoc(
    *   views = {"default", "nest-users"},
    *   section = "Person",
    *   resource = true,
    *   description = "Set registration data for person (token, start/end dates). (Possibly move to a separate controller or bundle -KD 02/28/19)",
     *   parameters = {
     *     {
     *       "name" = "id",
     *       "dataType" = "integer",
     *       "required" = 1,
     *       "format" = "string",
     *       "description" = "Person Id",
     *     },
     *     {
     *       "name" = "options",
     *       "dataType" = "string",
     *       "required" = 0,
     *       "format" = "JSON",
     *       "description" = "e.g., {""start_date"":""2018-10-01"",""token_start_date"":""2018-10-01 11:12:13"",""token_duration"":""86400""}",
     *     },
     *   },
    *   output = "ApiBundle\Entity\Person",
    *   statusCodes = {
    *     200 = "Returned when successful (empty or non-empty)",
    *     422 = "Returned when options have invalid JSON"
    *   }
    * )
    *
    * #Get("/person/{id}/register/{options}", name="api_get_person_register", defaults={"id"=null}, options={"method_prefix" = false})
    */
    public function getPersonRegisterAction($id = null, $options = null)
    {

      // $options is JSON array of: start_date, token_start_date, duration -- e.g.,
      // {"start_date":"2018-10-01","token_start_date":"2018-10-01 11:00:07","token_duration":"600"}
      //
      // Note: currently, values in $options with non-matching keys vs. $defaults are ignored without returning an error.
      // Planned updates to ApiBundle:Api:mergeOptions will fix this.

      $defaults = [
          'start_date'       => '',
          'token_start_date' => date('Y-m-d H:i:s'), // render current datetime from time()
          'token_duration'   => 10 * (24 * 60 * 60), // 10(days) * 24hrs: hrs/day * mins/hr * secs/min
      ];

      // set default vars
      foreach ($defaults as $k => $v) {
          $$k = $v;
      }

      // set vars based on default keys and received options
      if($options == '{options}') { // remove placeholder text sent by ApiDoc page sandbox
          $options = '';
          $merged = [];
      } else {
          // TODO: see if another notation avoids need for 'Action' suffix on referenced method
          $response = $this->forward('ApiBundle:Api:mergeOptions', array('defaults' => $defaults, 'options' => $options));
          // response is JSON because it's a full View object (extension of Response object)
          $merged = json_decode($response->getContent(), true); // to array
      }

      if(empty($options) || is_array($merged)){

          // overwrite matching default vars. If no matching default, we just ignore the var anyway
          foreach ($merged as $k => $v) {
              if($v) { // skip blank values (or should we?)
                  $$k = $v;
              }
          }

          // error messaging should mimic PATCH, since that's what it's similar to
          $count         = null;
          $data          = null;
          $http_response = Response::HTTP_OK; // 200;
          $message       = '';

          $person = $this
                ->getDoctrine()
                ->getRepository('ApiBundle:Person')
                ->find($id);

          if ($person != null) {

              // generate token
              $token = hash('sha512', openssl_random_pseudo_bytes(128)); // 128 char alphanumeric string from sha512 (converts characters that database can't handle from openssl function)


              if (is_string($token_start_date)) {
                  $token_start_date = new \DateTime("$token_start_date");
              }
              if (!empty($start_date) && is_string($start_date)) {
                  // TODO: more thorough checking for valid date content/format (e.g., checkdate()
                  $start_date = new \DateTime("$start_date");
              }

              $person->setRegisterToken($token);
              $person->setRegisterTokenDuration($token_duration);
              $person->setRegisterTokenStartDate($token_start_date); // stores datetime
              if ($start_date) {
                  $person->setStartDate($start_date);                // stores date (truncates time component)
              }

              $em = $this->getDoctrine()->getManager();
              $em->persist($person);
              $em->flush();

              $count         = 1;
              $data          = $person; // TODO: confirm this fits our pattern (vs. array of 1)
              $http_response = Response::HTTP_ACCEPTED; // 202 (mimics PATCH)
              $message       = '';

          } else {

              $count         = 0;
              $data          = null;
              $http_response = Response::HTTP_OK; // 200
              $message       = 'No Person found';

          }

      } else {
         // There was a problem with $options
         $count         = 0;
         $data          = null;
         $http_response = Response::HTTP_UNPROCESSABLE_ENTITY; // 422
         $message       = 'There was a problem with $options. $options: ' . print_r($options, true); // . ', ' . print_r($merged, true);

      }

      return new View(
          [
              'count'   => $count,
              'data'    => $data,
              'code'    => $http_response,
              'message' => $message
          ],
          $http_response
      );

    }

   /**
    * Supports registration process (note rendering of twig as return value)
    * (Possibly move to a separate controller or bundle -KD 02/2)
    *
    * @Get("/person/by/{query}", name="api_get_person_by", defaults={}, options={"method_prefix" = false})
    */
    public function getPersonByAction($query)
    {
        // JSON array, e.g., '["registerToken":"1a2b3c4d","email1":"nest.api.user@scscertified.com"]'
        //$query = json_decode($query, true);

        $results = array(
                'method'     => '',
                'count_orm'  => '',
                'count_dql'  => '',

                'person_orm' => '',
                'person_dql' => '',
                'person'     => '',

                'nameFirst'  => '',
                'nameLast'   => '',
                'email1'     => '',
                'org'        => '',
            );

        // default var values
        foreach($results as $k => $v) {
            $$k = $v;
        }

        if (is_array($query)) {

            // TODO: sanitize by known keys

            $model = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person');

            // TODO: get list of properties via property_info (see https://symfony.com/doc/2.8/components/property_info.html)
            // Until then, use a manually updated array

            $allowed_fields = array('registerToken','email1');

            $is_blocked = 0;
            foreach($query as $k => $v) {
                if(!in_array($k, $allowed_fields)) {
                    $is_blocked = 1;
                }
            }

            if(!$is_blocked) {

                $persons = $model->findBy($query); // returns array of objects, even when none found

                $method = 'orm';

                $count_orm = count($persons);
                $count_dql = '';
                $person_orm = '';
                if (count($persons)) {
                    $person_orm = $persons[0];
                }

                if(!isset($persons[0]->id)) {

                    $em = $this->getDoctrine()->getManager();

                    /*
                    $commit = $em->createQuery("
                        SELECT p, o
                        FROM ApiBundle:Person p
                        JOIN ApiBundle:Org o
                        WHERE p.{$field} = :id"
                    )->setParameter('id', "{$value}");
                    */

                    $sql = '
                        SELECT p, o
                        FROM ApiBundle:Person p
                        JOIN ApiBundle:Org o
                        ';

                    $i = 0;
                    foreach($query as $k => $v) {
                        $where = ($i ? 'WHERE' : 'AND');
                        $sql .= "
                        {$where} p.{$k} = :{$k}";
                        $i++;
                    }

                    $commit = $em->createQuery("$sql");

                    foreach($query as $k => $v) {
                        $commit->setParameter("{$k}", "{$v}");
                    }

                    $persons = $commit->getArrayResult();

                    $method = 'dql';
                    $count_dql = count($persons);
                    $person_dql = '';
                    if (count($persons)) {
                        $person_dql = $persons[0];
                    }
                }

                //$person = '';
                if (count($persons)) {
                    $person = $persons[0];
                    $org = $persons[1];
                }

            }

        }

        $result = array(
                'query'      => $query,
                'method'     => $method,
                'count_orm'  => $count_orm,
                'count_dql'  => $count_dql,

                'person_orm' => $person_orm,
                'person_dql' => $person_dql,
                'person'     => $person,
                'org'        => $org,

                'nameFirst'  => (isset($person['nameFirst']) ? $person['nameFirst'] : ''),
                'nameLast'   => (isset($person['nameLast'])  ? $person['nameLast']  : ''),
                'email1'     => (isset($person['email1'])    ? $person['email1']    : ''),
                'org_name'   => (isset($org['name'])         ? $org['name']         : ''),
            );

        return $this->render(
            'ApiBundle:Person:register_data.html.twig',
            $result
        );

    }


    /**
     * Modify a person's and user's email
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Changes the email of Person and User's e-mail",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully modified Person and User's email",
     *     200 = "Returned when no record available to deactivate",
     *   }
     * )
     *
     * @Patch("/person/{id}/update-email/{options}", defaults={"options" = "{}"}, name="api_patch_person_email", options={"method_prefix" = false})
     *
     * @return string
     */
    function updatePersonUserEmail($id = null, $options = null) {

        $merged_options = ApiController::processOptions($options);
        $bundle = $merged_options['bundle'];

        $person = $this
        ->getDoctrine()
        ->getRepository($bundle . ':Person')
        ->find($id);

        $email = json_decode($options)->email;

        if (!empty($person)) {

            $em = $this->getDoctrine()->getManager();
            $user = $person->getUser();
            try {
                if (!empty($user)) {
                    $user->setEmail($email);
                    $em->persist($user);
                    $em->flush();
                }
                $person->setEmail1($email);
                $em->persist($person);
                $em->flush();
                $data          = $person;
                $count         = 1;
                $http_response = Response::HTTP_ACCEPTED;
                $message       = '';
            }
            catch (DBALException $e) {
                $data = null;
                $message =  "E-mail is already in used";
                $count = 0;
                $http_response = Response::HTTP_UNPROCESSABLE_ENTITY;
            }

        } else {
            $data = null;
            $count = 0;
            $http_response = Response::HTTP_OK;
            $message = "No record found";
        }

        return new View([
            'count' => $count,
            'data'  => $data,
            'code'  => $http_response,
            'message' => $message
            ],
            $http_response
        );

    }

    /**
     * Deactivate a person
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Person",
     *   resource = true,
     *   description = "Deactivate a person",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deactivated",
     *     200 = "Returned when no record available to deactivate",
     *   }
     * )
     *
     * @Get("/person/{id}/deactivate/{options}", defaults={"options" = "{}"}, name="api_get_person_deactivate", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getPersonDeactivateAction($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);
        $bundle = $merged_options['bundle'];

        $person = $this
              ->getDoctrine()
              ->getRepository($bundle . ':Person')
              ->find($id);

        if (empty($person)) {
            // Person not found.
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_OK;
            $message       = 'No Person found';
        } else {
            $em = $this->getDoctrine()->getManager();

            // Disable the User record.
            $user = $person->getUser();
            if (!empty($user)) {
                $user->setEnabled(false);
                $em->persist($user);
                $em->flush();
            }

            // Deactivate the Person record.
            $person->setActive(false);
            $person->setRegisterToken(null);
            $person->setRegisterTokenStartDate(null);
            $person->setRegisterTokenDuration(null);
            $em->persist($person);
            $em->flush();

            $data          = $person;
            $count         = 1;
            $http_response = Response::HTTP_ACCEPTED;
            $message       = '';
        }

        return new View(
            [
                'count'   => $count,
                'data'    => $data,
                'code'    => $http_response,
                'message' => $message
            ],
            $http_response
        );
    }
}
