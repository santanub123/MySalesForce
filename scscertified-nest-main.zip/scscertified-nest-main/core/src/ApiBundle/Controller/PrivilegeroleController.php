<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Privilegerole;
use ApiBundle\Form\PrivilegeroleType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

use Doctrine\Common\Collections\ArrayCollection;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class PrivilegeroleController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Privilegerole",
     *   resource = true,
     *   description = "Get Privilegerole with id",
     *   output = "ApiBundle\Entity\Privilegerole",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the Privilegerole id
     *
     * @return string
     *     JSON array of 1 Privilegerole object
     */
    public function getPrivilegeroleAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Privilegerole',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all privilegeroles<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Privilegerole",
     *   resource = true,
     *   description = "Get all Privilegeroles",
     *   output = "ApiBundle\Entity\Privilegerole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/privilegeroles/{query}/{options}", defaults={"query"="{}","options"="{}"}, name="api_get_privilegeroles", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Privilegerole objects
     */
    public function getPrivilegerolesQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Privilegerole',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create Privilegerole
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Privilegerole",
     *   resource = true,
     *   description = "Create Privilegerole",
     *   input = "ApiBundle\Form\PrivilegeroleType",
     *   output = "ApiBundle\Entity\Privilegerole",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postPrivilegeroleAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Privilegerole',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Privilegerole (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Privilegerole",
     *   resource = true,
     *   description = "Edit Privilegerole (replace)",
     *   input = "ApiBundle\Form\PrivilegeroleType",
     *   output = "ApiBundle\Entity\Privilegerole",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function putPrivilegeroleAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Privilegerole',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Privilegerole (update)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Privilegerole",
     *   resource = true,
     *   description = "Edit Privilegerole (update)",
     *   input = "ApiBundle\Form\PrivilegeroleType",
     *   output = "ApiBundle\Entity\Privilegerole",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function patchPrivilegeroleAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Privilegerole',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a Privilegerole
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Privilegerole",
     *   resource = true,
     *   description = "Delete Privilegerole",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the Privilegerole id
     *
     * @return string
     *     JSON array
     */
    public function deletePrivilegeroleAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Privilegerole',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /**
     * Retrieve assignedroles through roles and units<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Privilegerole",
     *   resource = true,
     *   description = "Get Assignedroles through roles and units",
     *   output = "ApiBundle\Entity\Assignedroles",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/privilegerole/{id}/assignedroles/{options}", defaults={"options"="{}"}, name="api_get_privilegerole_assignedroles"), options={"method_prefix" = false}
     *
     * @return string
     */
    public function getPrivilegeroleAssignedrolesQuery($id = null, $options = null)
    {
        //TEMPORARY ERROR MESSAGE
        return new View(
            array(
                'code'    => 402,
                'message' => "This function is temporarily broken. Please see Jira INTR-1296.",
                'count'   => null,
                'data'    => null,
            ), 
            402
        );
        //END OF ERROR MESSAGE
        $merged_options = ApiController::processOptions($options);
        
        $assignedroles = $this->getPrivilegeroleAssignedrolesLocal($id, $merged_options);
        
        // Accommodate 2 styles
        if (isset($assignedroles['code'])) {            // DQL (flat) case
            $http_response = $assignedroles['code'];
            $message       = $assignedroles['message'];
            $assignedroles = (isset($assignedroles['data']) ? $assignedroles['data'] : []);
        } else {                                        // traditional / non-DQL case
            $http_response = Response::HTTP_OK; // 200
            $message       = '';
        }
        
        /*
        // Filter results based on status (redundant for DQL case)
        $data = ApiController::filterByStatus(
            $assignedroles,
            $merged_options['status']
        );
        $count = count($data);
        
        if ($merged_options['status'] != 2) {
            $message .= ($message ? '; ' : '');
            $message .= 'Filtered by status: ' . $merged_options['status'];
        }
        */
        
        $data = $assignedroles;
        $count = count($data);
        
        //$message = '$merged_options: ' . print_r($merged_options, true) . '; ' . $message;

        return new View(
            [
                // debug
                //'assignedroles[0]' => $assignedroles[0],
                
                'code'    => $http_response,
                'message' => $message,
                'count'   => $count,
                'data'    => $data,
            ],
            $http_response
        );
    }

    /**
     * Retrieve persons related to privilegeroles<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Privilegerole",
     *   resource = true,
     *   description = "Get Persons related to a given privilegerole through roles, units and assignedroles",
     *   output = "ApiBundle\Entity\Persons",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/privilegerole/{id}/persons/{options}", defaults={"options"="{}"}, name="api_get_privilegerole_persons", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getPrivilegerolePersonsQuery($id = null, $options = null)
    {
        //TEMPORARY ERROR MESSAGE
        return new View(
            array(
                'code'    => 402,
                'message' => "This function is temporarily broken. Please see Jira INTR-1308.",
                'count'   => null,
                'data'    => null,
            ), 
            402
        );
        //END OF ERROR MESSAGE
        $merged_options = ApiController::processOptions($options);

        $assignedroles = $this->getPrivilegeroleAssignedrolesLocal($id, $merged_options);
        
        // TODO: this requires flat_result, in order to include_entities, in order to use IN operator
        $dql_use = 1;
        if ($dql_use == 0) {
            
            if (200 <= $assignedroles['code'] && $assignedroles['code'] <= 299) {
            
                    $person_ids = [];
                    foreach ($assignedroles['data'] as $ar) {
                        $person_id    = $ar['personId'];
                        $person_ids[] = $person_id;
                    }
                    
                    // path: /entity/person/by/{"id":["1","2","3"]}/{"flat_result":"1","dql_operators":{"id":"IN"}}
                    $persons = $this->forward(
                        'ApiBundle:Api:getEntityBy',
                        [
                            'name'    => 'person',
                            'query'   => '{"id":' . json_encode($person_ids) . '}',
                            'options' => '{"status":"' . $merged_options['status'] . '","dql_use":"' . $dql_use . '","flat_result":"' . $merged_options['flat_result'] . '","dql_operators":{"id":"IN"}}',
                            //'options' => '{"status":"' . $merged_options['status'] . '","flat_result":"1","dql_operators":{"id":"IN"},"include_entities":["org"]}',
                        ]);
                    $persons = json_decode($persons->getContent(), true); // unserialize to array

                    // Note these values are from the second internal call, not the first
                    $data          = $persons['data'];
                    $count         = count($data);
                    $http_response = $persons['code']; // expect 2xx
                    $message       = $persons['message'];
            
            }
            // something went wrong with subquery
            else {
              
                $data          = null;
                $count         = null;
                $http_response = $assignedrole['code'];
                $message       = $assignedrole['message'];
              
            }
        
        }
        // use traditional / non-DQL
        else {
            $persons = [];
            foreach ($assignedroles as $ar) {
                $persons = array_merge($persons, $ar->getPersonsAll()->toArray());
            }
            
            // Filter results based on status.
            $data          = ApiController::filterByStatus(
                $persons,
                $merged_options['status']
            );
            $count         = count($data);
            $http_response = Response::HTTP_OK; // 200
            $message       = '';
        }
        
        return new View(
            [
                'code'    => $http_response,
                'message' => $message,
                'count'   => $count,
                'data'    => $data,
            ],
            $http_response
        );
    }

    private function getPrivilegeroleAssignedrolesLocal($id=null, $options)
    {
        //$merged_options = ApiController::processOptions($options);
        $merged_options = $options; // since this method is only called from within other methods that have already run processOptions on $options, we don't run it again.
        
        $privilegerole = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Privilegerole')
            ->find($id); // null value for $id generates a 500 and a comprehensible error in the 'message' key

        $status          = $merged_options['status'];
        $dql_use         = 1; //$merged_options['dql_use'];
        $flat_result     = $merged_options['flat_result'];
        
        $assignedroles = [];
        
        // default values (where no Assignedrole is found)
        if ($dql_use) {
            $assignedroles['code']    = Response::HTTP_OK; // 200
            $assignedroles['message'] = (is_null($privilegerole) ? 'No Privilegerole found' : '');
            $assignedroles['count']   = null;
            $assignedroles['data']    = null;
        }
            
        if ($privilegerole) {
          
            $role  = $privilegerole->getRole();
            $unit  = $privilegerole->getUnit();
            
            if (empty($unit)) { // this condition should not really be happening any more (by convention)
                
                // force traditional / non-DQL
                if ($dql_use === 0) {
                    
                    $assignedroles = $this
                        ->getDoctrine()
                        ->getRepository('ApiBundle:Assignedrole')
                        ->findBy(array("role" => $role->getId()));
                }
                // DQL -- include_entities is ignored if flat_result is false, so we leave it hard-coded
                else {
                    $assignedroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                            'name'    => 'assignedrole',
                            'query'   => '{"roleId":"' . $role_id . '"}',
                            'options' => '{"status":"' . $status . '","dql_use":"' . $dql_use . '","flat_result":"' . $flat_result . '","include_entities":["unit","role","person","org"]}',
                        ));
                    $assignedroles = json_decode($assignedroles->getContent(),true);
                }
                
            } else {
                
                $units         = $unit->getChildren();
                $units[]       = $unit;
                $role_id       = $role->getId();
                $assignedroles = [];
                $count_units   = count($units); // debug
                
                $unit_id = $unit->getId();
                    
                // DQL -- include_entities is ignored if flat_result is false
                // force traditional / non-DQL
                if ($dql_use) {
                    
                    // debug
                    //$test = 'DQL';
                    
                    $unit_ids = [];
                    foreach ($units as $unit) {
                        $unit_ids[] = $unit->getId();
                    }
                    $unit_ids = json_encode($unit_ids);
                    
                    // Use 'IN'
                    $assignedroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                        'name'    => 'assignedrole',
                        'query'   => '{"roleId":"' . $role_id . '","unitId":' . $unit_ids . '}',
                        'options' => '{"status":"' . $status . '","flat_result":"' . $flat_result . '","include_entities":["unit","role","person","org"],"dql_operators":{"unitId":"IN"}}',
                    ));
                    
                    
                    $assignedroles = json_decode($assignedroles->getContent(), true); // unserialize to array
                    
                    /* Precede loop (but doesn't this generate a duplicate chunk of data?
                    
                    $assignedroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                        'name'    => 'assignedrole',
                        'query'   => '{"roleId":"' . $role_id . '","unitId":"' . $unit_id . '"}',
                        'options' => '{"status":"' . $status . '","flat_result":"' . $flat_result . '","include_entities":["unit","role","person","org"]}',
                    ));
                    
                    $assignedroles = json_decode($assignedroles->getContent(), true); // unserialize to array
                    */
                    
                    /*
                    foreach($units as $u){
                        
                        $unit_id = $u->getId();
                        
                        $unit_role_assignedroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                            'name'    => 'assignedrole',
                            'query'   => '{"roleId":"' . $role_id . '","unitId":"' . $unit_id . '"}',
                            'options' => '{"status":"' . $status . '","flat_result":"' . $flat_result . '","include_entities":["unit","role","person","org"]}',
                        ));
                        $unit_role_assignedroles = json_decode($unit_role_assignedroles->getContent(), true); // unserialize to array
                        
                        $ar_code        = $assignedroles['code'];
                        $ar_message     = $assignedroles['message'];
                        $u_r_ar_code    = $unit_role_assignedroles['code'];
                        $u_r_ar_message = $unit_role_assignedroles['message'];
                        if (!($ar_code == $u_r_ar_code && $ar_message == $u_r_ar_message)) {
                            $assignedroles['code']    .= '; ' . $unit_role_assignedroles['code'];
                            $assignedroles['message'] .= '; ' . $unit_role_assignedroles['message'];
                        } else {
                            $assignedroles['code']    = $unit_role_assignedroles['code'];
                            $assignedroles['message'] = $unit_role_assignedroles['message'];
                        }
                        
                        $u_r_ar_count = (isset($unit_role_assignedroles['count']) ? 1 : 0);
                        $u_r_ar_data = (isset($unit_role_assignedroles['data']) ? 1 : 0);
                        if (isset($assignedroles['count']) && isset($assignedroles['data'])) {
                            $assignedroles['count']   += ($u_r_ar_count ? $unit_role_assignedroles['count'] : 0);
                            $assignedroles['data']    += ($u_r_ar_count ? $unit_role_assignedroles['data'] : []);
                        }
                        else {
                            $assignedroles['count']   = $unit_role_assignedroles['count'];
                            $assignedroles['data']    = $unit_role_assignedroles['data'];
                        }
                    }
                    */
                }
                // use traditional / non-DQL
                else {
                    
                    // debug
                    //$test = 'trad, non-DQL';
                    
                    $assignedroles = $this
                        ->getDoctrine()
                        ->getRepository('ApiBundle:Assignedrole')
                        ->findBy(array("role" => $role_id, "unit" => $unit_id));
                    
                    foreach($units as $u){
                    
                        $unit_id = $u->getId();
                        
                        $assignedroles += $this
                            ->getDoctrine()
                            ->getRepository('ApiBundle:Assignedrole')
                            ->findBy(array("role" => $role_id, "unit" => $unit_id));
                    }
                    
                }
                 
            }
            
        }
        
        // debug DQL
        if (isset($assignedroles['message'])) {
            //$assignedroles['message'] .= '; $unit_ids: ' . $unit_ids;
            //$assignedroles['message'] .= '; $count_units: ' . $count_units;
            //$assignedroles['message'] .= '; $assignedroles[0]: ' . print_r($assignedroles[0], true);
            //$assignedroles['message'] .= '; $options[\'dql_use\']: ' . $options['dql_use'];
            //$assignedroles['message'] .= '; $merged_options[\'dql_use\']: ' . $merged_options['dql_use'];
            //$assignedroles['message'] .= '; $test: ' . $test;
        }
        
        // TODO: consuming methods have to trap for 2 data styles: plain array (non-DQL), or keyed array ('code','message,' etc. - DQL). So far, there are only 2, and they are in this class.
        return $assignedroles;
    }
    
}
