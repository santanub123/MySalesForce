<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Orgtype;
use ApiBundle\Form\OrgtypeType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class OrgtypeController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Orgtype",
     *   resource = true,
     *   description = "Get Orgtype with id",
     *   output = "ApiBundle\Entity\Orgtype",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the Orgtype id
     *
     * @return string
     *     JSON array of 1 Orgtype object
     */
    public function getOrgtypeAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Orgtype',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all roles
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Orgtype",
     *   resource = true,
     *   description = "Get all Orgtypes",
     *   output = "ApiBundle\Entity\Orgtype",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/orgtypes/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_orgtypes", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Orgtype objects
     */
    public function getOrgtypesQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Orgtype',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create Orgtype
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Orgtype",
     *   resource = true,
     *   description = "Create Orgtype",
     *   input = "ApiBundle\Form\OrgtypeType",
     *   output = "ApiBundle\Entity\Orgtype",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postOrgtypeAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Orgtype',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Orgtype (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Orgtype",
     *   resource = true,
     *   description = "Edit Orgtype (replace)",
     *   input = "ApiBundle\Form\OrgtypeType",
     *   output = "ApiBundle\Entity\Orgtype",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function putOrgtypeAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Orgtype',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Orgtype (update)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Orgtype",
     *   resource = true,
     *   description = "Edit Orgtype (update)",
     *   input = "ApiBundle\Form\OrgtypeType",
     *   output = "ApiBundle\Entity\Orgtype",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function patchOrgtypeAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Orgtype',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a Orgtype
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Orgtype",
     *   resource = true,
     *   description = "Delete Orgtype",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the Orgtype id
     *
     * @return string
     *     JSON array
     */
    public function deleteOrgtypeAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Orgtype',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }
}
