<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Org;
use ApiBundle\Form\OrgType;
use ApiBundle\Form\OrgqueryType;

use QbmBundle\Entity\QbCustomer;
use QbmBundle\Form\QbCustomerType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class OrgController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Org",
     *   resource = true,
     *   description = "Get Org with id",
     *   output = "ApiBundle\Entity\Org",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the Org id
     *
     * @return string
     *     JSON array of 1 Org object
     */
    public function getOrgAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Org',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all orgs<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Org",
     *   resource = true,
     *   description = "Get all Orgs",
     *   output = "ApiBundle\Entity\Org",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/orgs/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_orgs", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Org objects
     */
    public function getOrgsQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Org',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create Org
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Org",
     *   resource = true,
     *   description = "Create Org",
     *   input = "ApiBundle\Form\OrgType",
     *   output = "ApiBundle\Entity\Org",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postOrgAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Org',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Org (PUT)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Org",
     *   resource = true,
     *   description = "Edit Org",
     *   input = "ApiBundle\Form\OrgType",
     *   output = "ApiBundle\Entity\Org",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return org
     */
    public function putOrgAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Org',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Org (PATCH)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Org",
     *   resource = true,
     *   description = "Edit Org",
     *   input = "ApiBundle\Form\OrgType",
     *   output = "ApiBundle\Entity\Org",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return org
     */
    public function patchOrgAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Org',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a Org
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Org",
     *   resource = true,
     *   description = "Delete Org",
     *   output = "array()",
     *   statusCodes = {
     *     200 = "Returned when successfully deleted",
     *     404 = "Returned when page is not found (implicit)"
     *   }
     * )
     *
     * @param integer $id
     *     the Org id
     *
     * @return string
     *     JSON array
     */
    public function deleteOrgAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Org',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /**
     * Retrieve all org persons<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Org",
     *   resource = true,
     *   description = "Get Persons for a given Org",
     *   output = "ApiBundle\Entity\Person",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @return string
     */
    public function getOrgPersonsAction($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $persons = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->findByOrg($id);

        $data = ApiController::filterByStatus(
            $persons,
            $merged_options['status']
        );
        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200
        $message       = '';

        return new View(
            [
                'data'    => $data,
                'count'   => $count,
                'code'    => $http_response,
                'message' => $message
            ],
            $http_response
        );
    }

    /**
     * Retrieve all org direct assignedroles
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Org",
     *   resource = true,
     *   description = "Get Persons for a given Org",
     *   output = "ApiBundle\Entity\Assignedrole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @return assignedroles[]
     */
    public function getOrgAssignedrolesAction($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $results = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Assignedrole')
            ->findByOrg($id);

        // Filter results based on status.
        $data = ApiController::filterByStatus(
            $results,
            $merged_options['status']
        );
        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200
        $message       = '';

        return new View(
            [
                'data'    => $data,
                'count'   => $count,
                'code'    => $http_response,
                'message' => $message
            ],
            $http_response
        );
    }

    /**
     * Retrieve orgs with at least type of match to incoming query. Accesses information from both Nest and QB<br />
     * (Possibly move to a separate bundle or controller -KD 02/2/19).
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Org",
     *   resource = true,
     *   description = "Get Orgs by full or partial match.'query' is field and words to be searched as JSON {""name"":""farm""}; 'flags' is array of config values (JSON keys: ""source"", ""filter"")",
     *   parameters = {
     *     {
     *       "name" = "query",
     *       "dataType" = "string",
     *       "required" = 1,
     *       "format" = "JSON",
     *       "description" = "Example: {""name"":""farm""}",
     *     },
     *     {
     *       "name" = "flags",
     *       "dataType" = "string",
     *       "required" = 0,
     *       "format" = "JSON",
     *       "description" = "Example: {""source"":2,""filter"":0}",
     *     },
     *   },
     *   output = "ApiBundle\Entity\Org",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * #Get("/orgs/{query}/{flags}", name="api_get_orgs_search", options={"method_prefix" = false})
     * (default when suffixed as '...Action' is: /orgs/{query}/{flags}/search)
     *
     * @param string $query JSON (keys: 'name')
     * @param string $flags JSON (keys: 'source', 'filter')
     *
     * @return string
     */
    //public function getOrgsSearch($query=null, $flags=null)
    public function postOrgsSearchAction(Request $request)
    {
        // Could use form builder and insert the parameter values, but instead, we'll get data directly from POST.
        // Fields based on FormType don't show in API sandbox this way, but 'parameters' in @Apidoc annotation adds what we want.
        $query_raw = $request->get('query');
        $flags_raw = $request->get('flags');

        // incoming 'query' data should be json string, e.g. '{"name":"green label","email":"sales@woodpanel.cn", "address": {"street":"123 Main","postal_code":"94123"}}' -- any legitimate properties of the object being queried (Nest\Org, Qb_Mirror\Customer, etc.)
        $query = json_decode($query_raw, true);

        // incoming 'flags' data should be json string, e.g. '{"source":1,"filter":4}'
        $flags = json_decode($flags_raw, true);

        if (!$query) {
            return new View(array('data' => array(
                        'error' => 'No data for "query" or input format not valid JSON',
                        'query' => $query_raw,
                        'flags' => $flags_raw,
                    )
                ), Response::HTTP_OK);
        }

        // default flags
        $default_flags = [
            'source' => 1,                  // Nest::Org
            'filter' => 0,                  // All variations
        ];

        // set missing defaults, if any
        $flags = array_merge($default_flags, $flags);

        // translate flags to Entities for search (e = entity, m = manager/db)
        $sources[0] = ''; // 0; all (tbd)
        $sources[1] = array( // 1; Nest::Org
            'e' => 'ApiBundle:Org',
            'm' => 'default',
            'fields' => array('name', 'alternateName'), // properties, not fields
            //'select' => array('addressBlock', 'email', 'contactName'), // fields
            );
        $sources[2] = array( // 2; Qbm::Customer
            'e' => 'QbmBundle:QbCustomer',
            'm' => 'qbm',
            'fields' => array('FullName', 'CompanyName'),
            //'select' => array('addressBlock', 'email', 'contactName'), // fields
            );
        $source = $sources[$flags['source']];

        // define repository
        $repository = $this->getDoctrine()->getRepository($source['e'], $source['m']);

        // translate field names according to Source
        $fields = $source['fields'];

        // map returned field names to arbitrary labels, by source
        //...

        // translate flags to query(ies)
        $filters[0] = 'default'; // 0; all
        $filters[1] = 'exact only'; // 1
        $filters[2] = 'all words (in order)'; // 2
        $filters[3] = 'all words (any order)'; // 3
        $filters[4] = 'any words'; // 4
        $filter = $flags['filter'];

        // single array for results of the separate queries
        //$combinedResult = [];

        // expect no space on left; remove universally
        $punctuation = array('.', ',', '.,');

        // expect space on left; trim from end
        $trimWords = array('company', 'co', 'co.', 'corp', 'corp.', 'corporation', 'inc', 'inc.', 'incorporated', 'llc', 'ltd', 'ltd.', 'limited', 'gmbh');

        // expect spaces on at least one side; remove universally
        $ignoredWords = array('a', 'and', 'the', 'of', '&', '-');

        // remove only for 'any' search (too many results)
        $anyWordsIgnored = array('agricola');

        $nameExact = trim(strtolower($query['name'])); // use for exact match, and split separately for partials
        if ($flags['source'] == 2) { // QuickBooks source
            $nameExact = substr($nameExact, 0, 41); // match truncated value in QB
        }

        $nameWords = explode(' ', $nameExact);

        /* if (in_array(end($nameWords), $trimWords)) {
        //trim last word based on list
            array_pop($nameWords);
        } */

        // reduce the word array by 'trim' words/strings -- a few may occur not only at end
        $nameWords = array_diff($nameWords, $trimWords);

        // reduce the word array by ignored words/strings
        $nameWords = array_diff($nameWords, $ignoredWords);

        // prep 'all words' query string, for both variants
        $nameAllWords = implode('%', $nameWords);

        // Get word count for setting scoring levels.
        $countNameWords = count($nameWords);

        // Queries: blocks are in sequence of priority. If a query is allowed (by filter value), the succeeding queries are done also. Thus, Exact Match is always done. Filter value 0 does all queries all the time.

        // Exact Match
        $resultExact = null;
        $resultExactScore = [];
        if ($filter == 0 || $filter >= 1) {
            $query = $repository->createQueryBuilder('o')
                //->orwhere('o.name LIKE :name')
                //->orwhere('o.alternateName LIKE :nameA')
                ->orwhere('o.' . $fields[0] . ' LIKE :name')
                ->orwhere('o.' . $fields[1] . ' LIKE :nameA')
                ->setParameter('name', "$nameExact")
                ->setParameter('nameA', "$nameExact")
                //->orderBy('o.name', 'ASC')
                //->orderBy('o.alternateName', 'ASC')
                ->orderBy('o.' . $fields[0], 'ASC')
                ->orderBy('o.' . $fields[1], 'ASC');
            $resultExact = $query->getQuery()->getResult();
            if (count($resultExact)) {
                foreach ($resultExact as $result) {
                    $resultExactScore[] = array('score' => 100, 'org' => $result);
                }
            }
        }

        // All Words (in order) Match
        $resultAllInOrder = null;
        $resultAllInOrderFiltered = [];
        if ($filter == 0 || $filter >= 2) {
            $allInOrderScore = round(100 * ((($countNameWords - 1) / $countNameWords) + (.67 / $countNameWords)), 0);
            $query = $repository->createQueryBuilder('o')
                //->where('o.name LIKE :name')
                ->orwhere('o.' . $fields[0] . ' LIKE :name')
                ->setParameter('name', "%$nameAllWords%")
                //->orderBy('o.name', 'ASC');
                ->orderBy('o.' . $fields[0], 'ASC');
            $resultAllInOrder = $query->getQuery()->getResult();
            //$resultAllInOrder = array_diff($resultAllInOrder, $resultExact);
            foreach ($resultAllInOrder as $resultK => $resultV) {
                if (!isset($resultExact[0]) || $resultV != $resultExact[0]) {
                    array_push($resultAllInOrderFiltered, array('score' => $allInOrderScore, 'org' => $resultV));
                }
            }

        }

        // All Words (any order) Match
        $resultAllNoOrder = null;
        $resultAllNoOrderFiltered = [];
        if ($filter == 0 || $filter >= 3) {
            $allNoOrderScore = round(100 * ((($countNameWords - 1) / $countNameWords) + (.33 / $countNameWords)), 0);
            $query = $repository->createQueryBuilder('o');
            $i = 0;
            foreach ($nameWords as $nameWord) {
                $query->andwhere('o.' . $fields[0] . ' LIKE :name' . $i)
                      ->setParameter('name' . $i, "%$nameWord%");
                $i++;
            }
            $query->orderBy('o.' . $fields[0], 'ASC');
            $resultAllNoOrder = $query->getQuery()->getResult();
            //$resultAllNoOrder = array_diff($resultAllNoOrder, $resultAllInOrder);
            if (!empty($resultAllNoOrder)) {
                foreach ($resultAllNoOrder as $resultK => $resultV) {
                    $push = 1;
                    if (!empty($resultAllInOrder)) {
                        foreach ($resultAllInOrder as $resultK2 => $resultV2) {
                            if ($resultV == $resultV2) {
                                $push = 0;
                                break;
                            }
                        }
                    }
                    if ($push) {
                        array_push($resultAllNoOrderFiltered, array('score' => $allNoOrderScore, 'org' => $resultV));
                    }
                }
            }
        }

        // Any Match
        $resultAny = null;
        $resultAnyFiltered = [];
        if ($filter == 0 || $filter >= 4) {
            $anyScoreCeiling = 100 * ((($countNameWords - 1) / $countNameWords) + (.33 / $countNameWords));
            $query = $repository->createQueryBuilder('o');
            $i = 0;
            foreach ($nameWords as $nameWord) {
                $query->orwhere('o.' . $fields[0] . ' LIKE :name' . $i)
                      ->setParameter('name' . $i, "%$nameWord%");
                $i++;
            }
            $query->orderBy('o.' . $fields[0], 'ASC');
            $resultAny = $query->getQuery()->getResult();
            //$resultAny = array_diff($resultAny, $resultAllNoOrder);
            if (!empty($resultAny)) {
                foreach ($resultAny as $resultK => $resultV) {
                    $push = 1;
                    if (!empty($resultAllNoOrder)) {
                        foreach ($resultAllNoOrder as $resultK2 => $resultV2) {
                            if ($resultV == $resultV2) {
                                $push = 0;
                                break;
                            }
                        }
                    }
                    if ($push) {
                        // score: words matched / words avail * $anyScoreCeiling
                        $name = $resultV->getName();
                        $score = 0;
                        foreach ($nameWords as $word) {
                            if (stripos($name, $word) !== false) {
                                $score++;
                            }
                        }
                        $score = $score / count($nameWords);
                        $score = round(($anyScoreCeiling * $score), 0);
                        array_push($resultAnyFiltered, array('score' => $score, 'org' => $resultV));
                    }
                }
                usort($resultAnyFiltered, function ($a, $b) {
                    if ($a['score'] == $b['score']) {
                        return strcasecmp($a['org']->getName(), $b['org']->getName());
                    }
                    return $a['score'] > $b['score'] ? -1 : 1;
                });
            }
        }

        //move everything into a single array ($results)
        $queries = array(
            'exact words'           => $resultExactScore,
            'all words (in order)'  => $resultAllInOrderFiltered,
            'all words (any order)' => $resultAllNoOrderFiltered,
            'any word'              => $resultAnyFiltered,
        );
        $results = [];
        $resultKeys = [];
        foreach ($queries as $resultSetK => $resultSetV) {
            if (!empty($resultSetV)) {
                foreach ($resultSetV as $result) {
                    if ($source['e'] === 'QbmBundle:QbCustomer') {
                        // Convert QB customer record to Nest format.
                        $qb_customer = new \Scs\Integration\Quickbooks\QbCustomer();
                        $qb_customer->loadFromObject($result['org']);
                        $qb_nest_org = $qb_customer->exportToNest();
                        $qb_nest_org_array = $qb_nest_org->exportAsArray(true);
                        $new_result = $result;
                        $new_result['org'] = $qb_nest_org_array;
                        array_push($results, $new_result);
                        unset($qb_customer);
                        unset($qb_nest_org);
                    } elseif ($source['e'] === 'ApiBundle:Org') {
                        // Populate NestOrg record with related addresses.
                        $id = $result['org']->getId();

                        // Populate addresses property.
                        $addresses = $this
                            ->getDoctrine()
                            ->getRepository('ApiBundle:Address')
                            ->findByOrg(['id' => $id], [], 5);
                        foreach ($addresses as $address) {
                            $result['org']->addAddress($address);
                        }

                        array_push($results, $result);
                        unset($addresses);
                    }
                }
                $resultKeys[] = $resultSetK;
            }
        }

        $data = array(
                'flags'     => $flags,
                'source'    => $source,
                'queries'   => $resultKeys, // currently only shows when a search has been successful.
                                            // TODO: show searches attempted regardless of outcome
                'terms'     => array('exact' => $nameExact, 'words' => $nameWords),
                'results'   => $results,
            );
        $count = count($results);
        $http_response = Response::HTTP_OK;
        $message = '';


        return new View(array('data' => $data, 'count' => $count, 'code' => $http_response, 'message' => $message), $http_response);

    }
}
