<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Program;
use ApiBundle\Form\ProgramType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Doctrine\Common\Collections\ArrayCollection;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class ProgramController extends FOSRestController
{

    /**
     * <pre>
     * Note: the name of the function generates the route:
     * 'get'        (required)  => the method: HTTP GET in this case
     * 'Program'    (required)  => the entity: first route fragment /program/{id}
     * 'Optionword'             => the option: additional fragment for route /optionword/{optionvar}
     * 'Action'     (*)         => the suffix: trigger route generation (*: use annotation if not using 'Action')
     *
     * Example generates:
     *     route:  GET /program/{id}/optionword/{optionvar}
     *     method: getProgramOptionwordAction($id, $optionvar)
     * </pre>
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Program",
     *   resource = true,
     *   description = "Get Program with id",
     *   output = "ApiBundle\Entity\Program",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id the program id
     *
     * @return string JSON object
     */
    public function getProgramAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Program',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all programs<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Program",
     *   resource = true,
     *   description = "Get all Programs (no filter yet): JSON object {""data"": [], ""count"": 0, ""code"": 200, ""message"": """"}",
     *   output = "ApiBundle\Entity\Program",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty): array('data' => Bool|Array $programs, 'count' => Integer $count, 'code' => Integer $http_response, 'message' => String $message)",
     *   }
     * )
     *
     * @Get("/programs/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_programs", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     */
    public function getProgramsQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Program',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create program
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Program",
     *   resource = true,
     *   description = "Create Program",
     *   input = "ApiBundle\Form\ProgramType",
     *   output = "ApiBundle\Entity\Program",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function postProgramAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Program',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit program (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Program",
     *   resource = true,
     *   description = "Edit Program (replace)",
     *   input = "ApiBundle\Form\ProgramType",
     *   output = "ApiBundle\Entity\Program",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function putProgramAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Program',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit program (update)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Program",
     *   resource = true,
     *   description = "Edit Program (update)",
     *   input = "ApiBundle\Form\ProgramType",
     *   output = "ApiBundle\Entity\Program",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function patchProgramAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Program',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete an program
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Program",
     *   resource = true,
     *   description = "Delete Program",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id the program id
     *
     * @return string
     */
    public function deleteProgramAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Privilegerole',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /**
     * Get programs by any field/value
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Program",
     *   resource = true,
     *   description = "Get Programs by any field, e.g., {""scsUserId"":""358""}",
     *   output = "ApiBundle\Entity\Program",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @Get("/programs/by/{query}", name="api_get_programs_by_query", options={"method_prefix" = false})
     *
     * @param string $query JSON {''fieldname'':''value''}
     *
     * @return string
     */
    /* DEPRECATED
    public function getProgramsByQuery($query=null)
    {

        $query = json_decode($query, true); // to array

        if (!is_array($query)) {
            $data          = null;
            $count         = 0;
            $message       = '$query must be an array and/or is not valid JSON';
            $http_response = Response::HTTP_UNPROCESSABLE_ENTITY; // 422
        }

        $programs = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Program')
            ->findBy($query);

        if (is_null($programs)) {
            $data          = null;
            $count         = 0;
            $message       = 'No Programs found';
            $http_response = Response::HTTP_OK; // 200
        } else {
            $data          = $programs;
            $count         = count($programs);
            $message       = '';
            $http_response = Response::HTTP_OK; // 200
        }

        return new View(array('data' => $data, 'count' => $count, 'code' => $http_response, 'message' => $message), $http_response);
    }
    */

}
