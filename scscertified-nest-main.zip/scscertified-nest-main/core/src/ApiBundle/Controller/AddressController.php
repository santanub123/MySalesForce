<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Address;
use ApiBundle\Form\AddressType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Doctrine\Common\Collections\ArrayCollection;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class AddressController extends FOSRestController
{
    // Use include file and constructor below to encapsulate legacy code, until replaced by generic methods in ApiController.
    // NOte: fails to provoke associated routes, unless include file is an actual class (Controller) file.
    //       However, that causes an error here. So for now, it's just a reference to the code we're going to delete.
    /*
    public function __construct() {
        require_once __DIR__ . '/include/Address.inc.php';
    }

    public function __call($functionName, $args) {
        if(function_exists($functionName))
            return call_user_func_array($functionName, $args);
    }
    */

    /**
     * Placeholder for address controller<br />
     *
     * CRUD methods are available through <a href="#section-~Global">generic endpoints</a>:<br />
     *<pre>
     * GET    /entity/{name}/by/{query}/{options}<br />
     * PATCH  /entity/{name}/{id}/{options}<br />
     * POST   /entity/{name}/{options}<br />
     * PUT    /entity/{name}/{id}/{options}<br />
     * DELETE /entity/{name}/{id}/{options}
     *</pre>
     * Specialty methods may be added to the <a href="#section-Address">Address section</a> of this documentation.
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Address",
     *   resource = true,
     *   description = "Address CRUD Reference",
     *   output = "void",
     *   statusCodes = {
     *     204 = "Any action ('No Content')",
     *   }
     * )
     *
     * @return void
     */
    public function getAddressAboutAction()
    {
        // placeholder for ApiDoc annotation
        // Actually return more documentation data?
    }

    /**
     * Retrieve all addresses<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Address",
     *   resource = true,
     *   description = "Get all Addresses (JSON object)",
     *   output = "ApiBundle\Entity\Address",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty): array( <br />
     *'data' => Bool|Array $addresses, 
     *'count' => Integer $count, 
     *'code' => Integer $http_response, 
     *'message' => String $message)",
     *   }
     * )
     *
     * @Get("/addresses/{query}/{options}", defaults={"query"="","options"=""}, name="get_addresses", options={"method_prefix" = false})
     *
     * @param JSON $query {''property-name'':''property-value'', etc.}
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Address objects
     */
    public function getAddressesQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Address',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }
    
    
    
    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Address",
     *   resource = true,
     *   description = "Get Address with id",
     *   output = "ApiBundle\Entity\Address",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id the address id
     *
     * @return string JSON object
     */
    public function getAddressAction($id)
    {
        $response = $this->forward('ApiBundle:Api:getEntityBy', array(
                'name'    => 'Address',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ));

        return $response;
    }

    // Add any non-generic, Address-specific methods below

    /**
     * Delete address
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Address",
     *   resource = true,
     *   description = "Delete Address",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the Address id
     *
     * @return string
     *     JSON array
     */
    public function deleteAddressAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Address',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /**
     * Create Address
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },

     *   section = "Address",
     *   resource = true,
     *   description = "Create Address",
     *   input = "ApiBundle\Form\AddressType",
     *   output = "ApiBundle\Entity\Address",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postAddressAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Address',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Address (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Address",
     *   resource = true,
     *   description = "Edit Address (replace)",
     *   input = "ApiBundle\Form\AddressType",
     *   output = "ApiBundle\Entity\Address",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return address
     */
    public function putAddressAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Address',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Address (update)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Address",
     *   resource = true,
     *   description = "Edit Address (update)",
     *   input = "ApiBundle\Form\AddressType",
     *   output = "ApiBundle\Entity\Address",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return address
     */
    public function patchAddressAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Address',
                'options' => '{}',
            ]
        );
    }
}
