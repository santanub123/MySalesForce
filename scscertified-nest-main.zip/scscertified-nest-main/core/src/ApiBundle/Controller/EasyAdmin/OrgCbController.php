<?php

namespace ApiBundle\Controller\EasyAdmin;

// extends AdminController in this directory, which extends the base EasyAdmin controller

/**
 * Allow better filters on "entities" displayed by EasyAdminBundle.
 * For example, "OrgCb" would show just Orgs with Orgtype "CB".
 */
class OrgCbController extends AdminController
{
  
    public function createListQueryBuilder($entityClass, $sortDirection, $sortField = null, $dqlFilter = null)
    {
        // TODO: Get this to work properly with IN
        $qb =  parent::createListQueryBuilder($entityClass, $sortDirection, $sortField, $dqlFilter);

        $cb_org_type_id = 5;
        $qb->join('entity.orgtypes','ots');
        $qb->andWhere( $qb->expr()->eq('ots.id', ':ot') );
        //$qb->andWhere( $qb->expr()->eq('entity.orgtypes', ':ot') );
        //$qb->andWhere( $qb->expr()->in( 'entity.orgtypes', array(':ot') ) );
        //$qb->andWhere( $qb->expr()->in( ':ot', array('entity.orgtypes') ) );
        //$qb->andWhere( $qb->expr()->in( ':ot', 'entity.orgtypes' ) );
        //$qb->andWhere( $qb->expr()->in( ':ot', 'ots' ) );
        $qb->setParameter('ot', $cb_org_type_id);

        return $qb;
    }
  
}
