<?php

namespace ApiBundle\Controller\EasyAdmin;

use EasyCorp\Bundle\EasyAdminBundle\Controller\AdminController as BaseAdminController;

class AdminController extends BaseAdminController
{
    // nothing extended yet, but makes entity-based controllers easier
    // (see https://symfonycasts.com/screencast/easyadminbundle/custom-controllers)
}