<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Country;
use ApiBundle\Form\CountryType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class CountryController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Country",
     *   resource = true,
     *   description = "Get Country with id",
     *   output = "ApiBundle\Entity\Country",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the Country id
     *
     * @return string
     *     JSON array of 1 Country object
     */
    public function getCountryAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Country',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all countries<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Country",
     *   resource = true,
     *   description = "Get all Countries",
     *   output = "ApiBundle\Entity\Country",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/countries/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_countries", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Country objects
     */
    public function getCountriesQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Country',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create Country
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Country",
     *   resource = true,
     *   description = "Create Country",
     *   input = "ApiBundle\Form\CountryType",
     *   output = "ApiBundle\Entity\Country",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postCountryAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Country',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Country (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Country",
     *   resource = true,
     *   description = "Edit Country (replace)",
     *   input = "ApiBundle\Form\CountryType",
     *   output = "ApiBundle\Entity\Country",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function putCountryAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Country',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Country (update)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Country",
     *   resource = true,
     *   description = "Edit Country (update)",
     *   input = "ApiBundle\Form\CountryType",
     *   output = "ApiBundle\Entity\Country",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function patchCountryAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Country',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a Country
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Country",
     *   resource = true,
     *   description = "Delete Country",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the Country id
     *
     * @return string
     *     JSON array
     */
    public function deleteCountryAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Country',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }
}
