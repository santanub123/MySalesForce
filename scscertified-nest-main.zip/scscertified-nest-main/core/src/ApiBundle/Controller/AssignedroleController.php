<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Assignedrole;
use ApiBundle\Form\AssignedroleType;

use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;


use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

use Doctrine\Common\Collections\ArrayCollection;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class AssignedroleController extends ApiController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Assignedrole",
     *   resource = true,
     *   description = "Get Assignedrole with id",
     *   output = "ApiBundle\Entity\Assignedrole",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the Assignedrole id
     *
     * @return string
     *     JSON array of 1 Assignedrole object
     */
    public function getAssignedroleAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Assignedrole',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }
    
    /**
     * Retrieve all assignedroles<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Assignedrole",
     *   resource = true,
     *   description = "Get all Assignedroles",
     *   output = "ApiBundle\Entity\Assignedrole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/assignedroles/{query}/{options}", defaults={"query"="{}","options"="{}"}, name="api_get_assignedroles", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Assignedrole objects
     */
    public function getAssignedrolesQuery($query, $options)
    {
        //If the query parameter includes person, forward to the specialty controller
        $name = 'Assignedrole';
        $this->unpackInput($name, $query, $options);
        
        if(array_key_exists("person", $this->input_query)){
            $id = $this->input_query['person'];
            $options = json_encode($options);
            
            $results = $this->getAssignedrolesByPersonAllQuery($id, $options);
        }
        elseif(array_key_exists("person_direct", $this->input_query)){
            $results = $this->getAssignedrolesByPersonSelfQuery();
        }
        elseif(array_key_exists("person_throughOrg", $this->input_query)){
            $id = $this->input_query['person_throughOrg'];
            $options = json_encode($options);
            
            $results = $this->getAssignedrolesByPersonThroughOrgQuery($id, $options);
        }
        elseif(array_key_exists("privilegerole", $this->input_query)){
            $results = $this->getAssignedrolesByPrivilegeRole();
        }
        else{
            $this->performQuery();
            $results = $this->getViewResponse();
        }
        
        return $results;
    }

    /**
     * Create Assignedrole
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Assignedrole",
     *   resource = true,
     *   description = "Create Assignedrole",
     *   input = "ApiBundle\Form\AssignedroleType",
     *   output = "ApiBundle\Entity\Assignedrole",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postAssignedroleAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Assignedrole',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Assignedrole
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Assignedrole",
     *   resource = true,
     *   description = "Edit Assignedrole",
     *   input = "ApiBundle\Form\AssignedroleType",
     *   output = "ApiBundle\Entity\Assignedrole",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return assignedrole
     */
    public function putAssignedroleAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Assignedrole',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Assignedrole
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Assignedrole",
     *   resource = true,
     *   description = "Edit Assignedrole",
     *   input = "ApiBundle\Form\AssignedroleType",
     *   output = "ApiBundle\Entity\Assignedrole",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return Assignedrole
     */
    public function patchAssignedroleAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Assignedrole',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a Assignedrole
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Assignedrole",
     *   resource = true,
     *   description = "Delete Assignedrole",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the Assignedrole id
     *
     * @return string
     *     JSON array
     */
    public function deleteAssignedroleAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Assignedrole',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /**
     * Retrieve privilegeroles related to assigned roles<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Assignedrole",
     *   resource = true,
     *   description = "Get Privilegeroles related to a given assignedrole through roles and units",
     *   output = "ApiBundle\Entity\Privilegeroles",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/assignedrole/{id}/privilegeroles/{options}", defaults={"options"="{}"}, name="api_get_assignedrole_privilegeroles", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getAssignedrolePrivilegerolesQuery($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);
        
        $status          = $merged_options['status'];
        $dql_use         =  1; //$merged_options['dql_use'];
        $flat_result     = $merged_options['flat_result'];

        $assignedrole = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Assignedrole')
            ->find($id);

        /* Privilegeroles relate to assignedroles if they share a role AND:
               - they share a unit, or
               - the privilegerole unit is an ancestor of the assignedroles unit, or
               - the unit is null 
         */

        $privilegeroles = [];
        
        // default values (where no Assignedrole is found)
        $http_response = Response::HTTP_OK; // 200
        $message       = (is_null($assignedrole) ? 'No Assignedrole found' : '');
        $data          = null;
        $count         = null;

        if (!is_null($assignedrole)) {
            
            $role = $assignedrole->getRole();
            $unit = $assignedrole->getUnit();
                
            // traditional / non-DQL
            if (empty($dql_use)) {

                if (!is_null($role)) {
                    if (!is_null($unit)) {
                        $units = array();
                        $units = $unit->getAncestors();
                        $privilegeroles = $this
                                ->getDoctrine()
                                ->getRepository('ApiBundle:Privilegerole')
                                ->findBy(array("role" => $role->getId(), "unit" => $unit->getId()));
                        foreach ($units as $u) {
                            $privilegeroles = array_merge(
                                $privilegeroles,
                                $this
                                    ->getDoctrine()
                                    ->getRepository('ApiBundle:Privilegerole')
                                    ->findBy(array("role" => $role->getId(), "unit" => $u->getId()))
                            );
                        }
                    }
                    // add privilegeroles sharing role but having blank unit
                    $privilegeroles = array_merge(
                        $privilegeroles,
                        $this
                            ->getDoctrine()
                            ->getRepository('ApiBundle:Privilegerole')
                            ->findBy(array("role" => $role->getId(), "unit" => null))
                    );
                }
                
                // Filter results based on status.
                $data = ApiController::filterByStatus(
                    $privilegeroles,
                    $merged_options['status']
                );
                $count         = count($data);
            
            }
            // DQL
            else {
              
                if (!is_null($role)) {
                  
                    $role_id = $role->getId();
                  
                    if (!is_null($unit)) {
                        
                        $units = [];
                        $units = $unit->getAncestors();
                        
                        $unit_ids = [];
                        $unit_ids[] = $unit->getId();
                        foreach ($units as $u) {
                            $unit_ids[] = $u->getId();
                        }
                        
                        $unit_ids = json_encode($unit_ids);
                        
                        // Use 'IN'
                        $privilegeroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                            'name'    => 'privilegerole',
                            'query'   => '{"roleId":"' . $role_id . '","unitId":' . $unit_ids . '}',
                            'options' => '{"status":"' . $status . '","flat_result":"' . $flat_result . '","include_entities":["unit","role","privilege"],"dql_operators":{"unitId":"IN"}}',
                        ));
                    }
                    // Unit is null -- would this ever happen? Assignedroles cannot have null Units, even though privilegeroles might
                    else {
                      
                        // Unit is null
                        $privilegeroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                            'name'    => 'privilegerole',
                            'query'   => '{"roleId":"' . $role_id . '","unitId":null}',
                            'options' => '{"status":"' . $status . '","flat_result":"' . $flat_result . '","include_entities":["unit","role","privilege"],"dql_operators":{"unitId":"IS NULL"}}',
                        ));
                      
                      
                    }
                }
                
                $privilegeroles = json_decode($privilegeroles->getContent(),true); // deserialize to array
                
                $http_response = $privilegeroles['code'];
                $message       = $privilegeroles['message'];
                $count         = $privilegeroles['count'];
                $data          = $privilegeroles['data'];
            }
        }

        return new View(
            [
                'code'    => $http_response,
                'message' => $message,
                'count'   => $count,
                'data'    => $data,
            ],
            $http_response
        );
    }

    /**
     * Retrieve all persons related to an assigned role (there will either be 1 directly related person, or an array related through org)<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Assignedrole",
     *   resource = true,
     *   description = "Get Persons for a given Assignedrole, either directly, or through Org",
     *   output = "ApiBundle\Entity\Persons",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/assignedrole/{id}/persons/all/{options}", defaults={"options"="{}"}, name="api_get_assignedrole_persons_all", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getAssignedrolePersonsAllQuery($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $persons = [];

        $assignedrole = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Assignedrole')
            ->find($id);

        if (is_null($assignedrole)) {
            $data = null;
            $count = 0;
            $http_response = Response::HTTP_OK; // 200
            $message = 'No Assignedrole found';
        }
        else {
            // get direct Person, *or* persons related to direct Org of assignedrole, as collection
            $persons = $assignedrole->getPersonsAll(); 
            
            // Filter results based on status.
            $data = ApiController::filterByStatus(
                $persons,
                $merged_options['status']
            );
            
            $count   = count($data);
            $http_response = Response::HTTP_OK; // 200
            $message = ($count ? '' : 'No Persons with Assignedrole found');
        }

        return new View(
            [
                'data'    => $data,
                'count'   => $count,
                'code'    => $http_response,
                'message' => $message
            ],
            $http_response
        );
    }
    
    /***NEW SPECIALTY CONTROLLERS***/
    
    /**
     * Retrieve person's direct and org-assignedroles<br />
     * TODO: add pagination
     *
     * @return string
     */
    private function getAssignedrolesByPersonAllQuery($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $person = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->find($id);

        if (is_null($person)) {
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_OK; // 200
            $message       = 'No Person found';
        } else {

            $dql_use = 1;
            if ($dql_use == 0) {

                // traditional, non-DQL (flat)
                $assigned_roles = $person->getAssignedrolesAll();
                // Filter results based on status.
                $data = ApiController::filterByStatus(
                    $assigned_roles,
                    $merged_options['status']
                );

                $message = '';

            }
            // use DQL (flat)
            else {

                // TODO: this replicates queries contained in getPersonAssignedrolesOrgQuery() and
                //       getPersonAssignedrolesSelfQuery, on order to avoid searching for Person object twice.
                //       This could be refactored.

                $flat_result      = $merged_options['flat_result'];
                $include_entities = json_encode($merged_options['include_entities']);

                $org_id = $person->getOrg()->getId();
                $org_assignedroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                    'name'    => 'assignedrole',
                    'query'   => '{"orgId":"' . $org_id . '"}',
                    'options' => '{"status":"2","flat_result":"' . $flat_result . '","include_entities":' . $include_entities . '}',
                ));
                $org_assignedroles = json_decode($org_assignedroles->getContent(),true);
                $org_assignedroles = (array) $org_assignedroles; // cast in case result is null
                if (!isset($org_assignedroles['data'])) {
                  $org_assignedroles['data'] = [];
                }

                $person_assignedroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                    'name'    => 'assignedrole',
                    'query'   => '{"personId":"' . $id . '"}',
                    'options' => '{"status":"2","flat_result":"' . $flat_result . '","include_entities":' . $include_entities . '}',
                ));
                $person_assignedroles = json_decode($person_assignedroles->getContent(), true);
                $person_assignedroles = (array) $person_assignedroles; // cast in case result is null
                if (!isset($person_assignedroles['data'])) {
                  $person_assignedroles['data'] = [];
                }

                $data = new ArrayCollection(
                           array_merge(
                               $person_assignedroles['data'],
                               $org_assignedroles['data']
                           )
                       );

                $message = 'Filtered by DQL';

            }

            $count         = count($data);
            $http_response = Response::HTTP_OK; // 200
        }

        return new View(
            [
                'code'    => $http_response,
                'message' => $message,
                'count'   => $count,
                'data'    => $data,
            ],
            $http_response
        );
    }
    
    /**
     * Retrieve person's direct assignedroles<br />
     * TODO: add pagination
     *
     * @return string
     */
    private function getAssignedrolesByPersonSelfQuery()
    {
        $this->input_query['person'] = $this->input_query['person_direct'];
        unset($this->input_query['person_direct']);
        $this->performQuery();
        
        return $this->getViewResponse();
    }
    
    /**
     * Retrieve person's org's assignedroles<br />
     * TODO: add pagination
     *
     * @return string
     */
    private function getAssignedrolesByPersonThroughOrgQuery($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $person = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Person')
            ->find($id);

        if (is_null($person)) {
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_OK; // 200
            $message       = 'No Person found';
        } else {

            // DQL (flat) query
            $dql_use = 1;
            if ($dql_use == 0) {

                $org_id = $person->getOrg()->getId();
                //$org_id = $person->getOrgId(); // more performant, but only by a little
                $flat_result      = $merged_options['flat_result'];
                $include_entities = json_encode($merged_options['include_entities']);
                $assignedroles = $this->forward('ApiBundle:Api:getEntityBy', array(
                    'name'    => 'assignedrole',
                    'query'   => '{"orgId":"' . $org_id . '"}',
                    'options' => '{"status":"2","flat_result":' . $flat_result . ',"include_entities":' . $include_entities . '}',
                ));
                $data = json_decode($assignedroles->getContent(), true); // unserialize to array

                $http_response = $data['code'];
                $message       = $data['message'];
                $count         = $data['count'];
                $data          = $data['data'];
            }
            // non-DQL (flat)
            else {

                $assigned_roles = $person->getAssignedrolesOrg();
                // Filter results based on status.
                $data = ApiController::filterByStatus(
                    $assigned_roles,
                    $merged_options['status']
                );

                $count         = count($data);
                $http_response = Response::HTTP_OK; // 200
                $message       = '';
            }
        }

        return new View(
            [
                'code'    => $http_response,
                'message' => $message,
                'count'   => $count,
                'data'    => $data,
            ],
            $http_response
        );
    }
    
    private function getAssignedrolesByPrivilegeRole(){
        /*The function this is trying to replace is broken, I am not going to try to fix it now. -KD*/
        
        //TEMPORARY ERROR MESSAGE
        return new View(
            array(
                'code'    => 402,
                'message' => "This function is temporarily broken. (Please see Jira INTR-1296)",
                'count'   => null,
                'data'    => null,
            ), 
            402
        );
        //END OF ERROR MESSAGE
    }
}
