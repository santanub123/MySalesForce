<?php

namespace ApiBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;

class DefaultController extends Controller
{
    /*** Action methods for HTTP rendering (not API endpoints) ***/
    
    /**
     * @Route("/", name="api_default_index")
     * @Method({"GET"})
     */
    public function indexAction()
    {
        //return $this->render('ApiBundle:Default:index.html.twig');
        return $this->render('ApiBundle:Default:index.html.php'); // switch to PHP for this, so we can more easily re-used the actual Nest home page
    }
    
    /**
     * @Route("/api/view/{path}", name="api_view_index", defaults={"path"=""}) // (?) knocks out other API routes if evaluated early, but now at end of routing list (routing.yml)
     * @Method({"GET"})
     */
    public function viewIndexAction($path)
    {
        /*
        // allowed top-level directories (see ApiBundle/Resources/views/Default)
        $allowed = array(
            'backbone',
            'plain',
            'react',
            'vue',
        );
        
        $isValid = 0;
        foreach ($allowed as $v) {
            $test = explode($v, $path);
            if (empty($test[0])) {
                $isValid = 1;
            }
        }
        
        if (!$isValid) {
            $path = '';
        }
        */
        
        //$path='some/folder';
        
        if ($path) {
            return $this->render('ApiBundle:Default/' . $path . ':index.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
            'path' => $path,
            ));
        } else {
            return $this->render('ApiBundle:Default:index.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
            'path' => $path,
            ));
        }
    }
    

    /**
     * @Route("/workbench/{path}", name="api_workbench_index", requirements={"path" = ".+"}) // 'path' must neither begin nor end with a "/"
     * @Method({"GET"})
     */
    public function workbenchAction($path="")
    {
        $render = self::returnRender('workbench', $path);
        //return $this->render('ApiBundle:Api/logintest/' . $path . ':' . $last . '.html.twig', array(

        return $this->render($render, array(
            //'base_dir' => $base_dir,
            //'path'     => $path,
            //'last'     => $last,
            //'type'     => $type,
            ));
    }

    /*
     * @Route("/menu")
     */
    /*
    public function menuAction()
    {
        return $this->render('ApiBundle:Default:menu.html.twig');
    }
    */
    
    /**
     * @Route("/menu/{path}", name="api_default_menu_index", requirements={"path" = ".+"}) // 'path' must neither begin nor end with a "/"
     * @Method({"GET"})
     */
    public function menuAction($path="")
    {
        $render = self::returnRender('menu', $path);
        //return $this->render('ApiBundle:Api/menu/' . $path . ':' . $last . '.html.twig', array(

        return $this->render($render, array(
            //'base_dir' => $base_dir,
            //'path'     => $path,
            //'last'     => $last,
            //'type'     => $type,
            ));
    }

    
    public function returnRender($root, $path) {
    
        $last = 'index';
        if ($path) {
            $parts = explode('/', $path);
            $last = array_pop($parts);
            if (count($parts) > 1) {
                $path = implode('/', $parts);
            } else { // 1 part only
                $path = '';
            }
        }
        
        $base_dir = realpath($this->container->getParameter('kernel.root_dir').'/..');

        $fs = new Filesystem();
        
        /*
        try {
            $fs->exists('ApiBundle:Default/' . $root . '/' . $path . ':' . $last . '.html.twig');
        } catch (IOExceptionInterface $e) {
            echo "An error occurred looking for " . $e->getPath();
        }
        */
        
        // Is last array element a dir or a page?
        $type = '';
        if ($fs->exists($base_dir . '/src/ApiBundle/Resources/views/Default/' . $root . '/' . $path . '/' . $last . '.html.twig')) {
            $render = 'ApiBundle:Default/' . $root . '/' . $path . ':' . $last . '.html.twig';
            $type = 'page';
        } elseif ($fs->exists($base_dir . '/src/ApiBundle/Resources/views/Default/' . $root . '/' . $path . '/' . $last . '/' . 'index' . '.html.twig')) {
            $render = 'ApiBundle:Default/' . $root . '/' . $path . '/' . $last . '/' . 'index' . '.html.twig';
            $type = 'dir';
        } else {
            $render = 'ApiBundle:Default/' . $root . ':' . 'index' . '.html.twig'; // default route; replace with error page? In former case, no longer matches browser's URL, which can be problematic
            $type = 'invalid';
        }
        
        return $render;
    
    }
    
}