<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Unit;
use ApiBundle\Form\UnitType;

use QbmBundle\Entity\QbCustomer;
use QbmBundle\Form\QbCustomerType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

use Doctrine\ORM\Query\ResultSetMapping;

use Scs\Integration\Nest\NestObject;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class UnitController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Get Unit with id",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the Unit id
     *
     * @return string
     *     JSON array of 1 Unit object
     */
    public function getUnitAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Unit',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all units<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Get all Units (array of objects)",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/units/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_units", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Unit objects
     */
    public function getUnitsQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Unit',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create Unit
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Create Unit",
     *   input = "ApiBundle\Form\UnitType",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postUnitAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Unit',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Unit (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Edit Unit (replace)",
     *   input = "ApiBundle\Form\UnitType",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function putUnitAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Unit',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Unit (update)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Edit Unit (update)",
     *   input = "ApiBundle\Form\UnitType",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function patchUnitAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Unit',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a Unit
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Delete Unit",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the Unit id
     *
     * @return string
     *     JSON array
     */
    public function deleteUnitAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Unit',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /**
     * Retrieve all unit direct assignedroles<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Get Assignedroles for a given Unit",
     *   output = "ApiBundle\Entity\Assignedrole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @return string
     */
    public function getUnitAssignedrolesAction($id=null)
    {

        $assignedroles = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Assignedrole')
            ->findByUnit($id);
        if ($assignedroles == null) {
            $message       = 'No Assignedroles';
        } else {
            $message       = '';
        }

        $data          = $assignedroles;
        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200

        return new View(array('data' => $data, 'count' => $count, 'code' => $http_response, 'message' => $message), $http_response);

    }

    /**
     * Retrieve all unit direct privilegeroles
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Get Privilegeroles for a given Unit",
     *   output = "ApiBundle\Entity\Privilegerole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * #Get("/unit/{id}/privilegeroles/{options}", name="api_get_unit_privilegeroles", options={"method_prefix" = false}, defaults={"options"="{}"})

     * @return string
     */
    public function getUnitPrivilegerolesAction($id = null, $options = null)
    {
        // Merge supplied options with default values.
        $merged_options = ApiController::processOptions($options);
        $json_merged_options = json_encode(
            $merged_options,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_NUMERIC_CHECK
        );

        $data = null;
        if ($merged_options['flat_result']) {
            $privilegerole_query_response = $this->forward(
                'ApiBundle:Api:getEntityBy',
                [
                    'name'    => 'Privilegerole',
                    'query'   => '{"unitId":"' . $id . '"}',
                    'options' => $json_merged_options,
                ]
            );
            $pr_response = json_decode(
                $privilegerole_query_response->getContent(),
                true
            );
            if (is_array($pr_response) && isset($pr_response['data'])) {
                $data = $pr_response['data'];
            }
        } else {
            $unit = $this
                ->getDoctrine()
                ->getRepository('ApiBundle:Unit')
                ->find($id);
            if (is_null($unit)) {
                $message = 'No such Unit';
            } else {
                $data = $unit->getPrivilegeroles();
                $message = '';
            }
        }

        $count         = is_array($data) ? count($data) : 0;
        $http_response = Response::HTTP_OK; // 200

        return new View(
            [
                'data'      => $data,
                'count'     => $count,
                'code'      => $http_response,
                'message'   => $message,
            ],
            $http_response
        );
    }

    /**
     * Retrieve all unit's Children Units<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Get Child Units for a given Unit",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @return string
     */
    public function getUnitChildrenAction($id=null)
    {

        $unit = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Unit')
            ->find($id);
        if (is_null($unit)) {
            $children = null;
            $message = 'No such Unit';
        } else {
            $children = $unit->getChildren();
            $message = '';
        }

        $data          = $children;
        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200

        return new View(array('data' => $data, 'count' => $count, 'code' => $http_response, 'message' => $message), $http_response);

    }

    /**
     * Retrieve all unit's Ancestor Units (parent and parent's parent, etc.)<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Get Ancestor Units for a given Unit",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @return string
     */
    public function getUnitAncestorsAction($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $ancestors = [];
        $unit = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Unit')
            ->find($id);
        if (is_null($unit)) {
            $message = 'No such Unit';
        } else {
            // Note: So long as we return parent with the object, you get Ancestors for free in non-DQL (or, non-DQL (flat)).
            //       For DQL (flat) contexts, this remains useful.
            $ancestors = $unit->getAncestors();
            $message = '';
        }

        // Filter results based on status.
        $data = ApiController::filterByStatus(
            $ancestors,
            $merged_options['status']
        );
        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200

        return new View(
            [
                'data'    => $data,
                'count'   => $count,
                'code'    => $http_response,
                'message' => $message
            ],
            $http_response
        );
    }

    /**
     * Retrieve all unit's Descendant Units (children and children's children, etc.)<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Get Descendant Units for a given Unit (array of objects)",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @return string
     */
    public function getUnitDescendantsAction($id = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $descendants = [];
        $unit = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Unit')
            ->find($id);
        if (is_null($unit)) {
            $message = 'No such Unit';
        } else {
            $descendants = $unit->getDescendants();
            $message = '';
        }

        // Filter results based on status.
        $data = ApiController::filterByStatus(
            $descendants,
            $merged_options['status']
        );
        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200

        return new View(
            [
                'data' => $data,
                'count' => $count,
                'code' => $http_response,
                'message' => $message
            ],
            $http_response
        );
    }

    /**
     * Retrieve all the descendants of a list of Units
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Get descendant Units for a given list of Units",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @param string $unit_list
     *     comma-separated list of unit ids to match
     *
     * @return string
     *     JSON array of Unit objects
     */
    public function getUnitsDescendantsAction($unit_list, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $status          = $merged_options['status'];
        $dql_use         = 1; //$merged_options['dql_use'];
        $flat_result     = $merged_options['flat_result'];

        // Initialize response parameters.
        $data = [];
        $http_response = Response::HTTP_OK;
        $message = '';

        // Filter by status if specified.
        $where_active_expression = '';
        if (($status === 0) || ($status === 1)) {
            $where_active_expression = ' AND u.active = ' . $status;
        }

        // Retrieve the set of descendant units.
        $clean_unit_list = trim(str_ireplace('{unit_list}', '', $unit_list));
        if (empty($clean_unit_list)) {
            $http_response = Response::HTTP_BAD_REQUEST;    // 400
            $message = 'Unit list is empty';
        } else {
            $rsm = new ResultSetMapping();
            $rsm->addEntityResult('ApiBundle\Entity\Unit', 'u');
            $rsm->addFieldResult('u', 'id', 'id');
            $rsm->addFieldResult('u', 'deptCode', 'deptCode');
            $rsm->addFieldResult('u', 'name', 'name');
            $rsm->addFieldResult('u', 'description', 'description');
            $rsm->addFieldResult('u', 'active', 'active');
            $rsm->addFieldResult('u', 'Parent_id', 'parentId');
            $rsm->addFieldResult('u', 'shortname', 'shortname');
            $rsm->addFieldResult('u', 'salesforce_id', 'salesforceId');
            $rsm->addFieldResult('u', 'qb_class_listid', 'qbClassListid');

            $em = $this->getDoctrine()->getManager();
            $query = $em->createNativeQuery(
                'SELECT
                  id, dept_code, name, description, active, Parent_id, shortname, salesforce_id, qb_class_listid
                FROM Unit u
                WHERE
                  u.id IN (
                    SELECT DISTINCT descendant_id
                    FROM Unittree ut
                    WHERE ut.ancestor_id IN (' . $unit_list . ')
                  )' . $where_active_expression .'
                ORDER BY name',
                $rsm
            );

            if ($dql_use && $flat_result) {
                $data = $query->getArrayResult();
            } else {
                $data = $query->getResult();
            }
        }

        $count = is_array($data) ? count($data) : 0;

        return new View(
            [
                'data'      => $data,
                'count'     => $count,
                'code'      => $http_response,
                'message'   => $message,
            ],
            $http_response
        );
    }

    private function checkBranch($unit)
    {
        $manager = $this->getDoctrine()->getManager();
        $branchChanges = array();

        //Check ancestor relationships for this unit
        $recordsToUpdate = $unit->updateUnittree();
        if(count($recordsToUpdate['added']) + count($recordsToUpdate['removed']) > 0)
        {
            $manager->persist($unit);
            $manager->flush($unit);
            $recordsToUpdate["unit"] = $unit;
            $branchChanges[] = $recordsToUpdate;
        }

        //Run check on children records
        $children = $unit->getChildren();
        $children = $children->toArray();
        $results = array();
        foreach($children as $child)
        {
            $results = array_merge($results, $this->checkBranch($child));
        }
        $results = array_merge($branchChanges, $results);

        return $results;
    }

    /**
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Check that the unit and it's descendants have the correct relationships in the unit tree",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     200 = "Returned when all records were already up-to-date",
     *     201 = "Returned when the unit tree needs to and has been updated",
     *   },
     * )
     *
     * @param integer $id
     *     the Unit id (0 or null will search the entire tree)
     *
     * @return string
     *     JSON array of records that have been updated
     */
    public function checktreeUnitAction($id)
    {
        try
        {
            $id = (int)$id;
            $repository = $this->getDoctrine()->getRepository(Unit::class);
            if($id === 0){
                //Find all units without a parent, and check each branch
                $ancestorUnits = $repository->findBy(["parent" => null]);
            }
            else{
                $ancestorUnits = $repository->findBy(["id" => $id]);
            }
            $results = array();
            foreach($ancestorUnits as $ancestorUnit){
                $results = array_merge($results, $this->checkBranch($ancestorUnit));
            }

            //Set up response
            $responseArray = array();
            $responseArray["data"] = $results;
            $responseArray["count"] = count($results);
            if($responseArray["count"] === 0){
                $responseArray["code"] = 200;
                $responseArray["message"] = "Unittree relationships already up-to-date";
            }
            else{
                $responseArray["code"] = 201;
                $responseArray["message"] = "Unittree was incorrect, and has been updated.";
            }
        }
        catch(\Exception $e){
            $responseArray = array(
                'code' => Response::HTTP_UNPROCESSABLE_ENTITY,
                'message' => "Unknown error: " . $e,
                'data' => null,
                'count' => null,
            );
        }

        return $responseArray;
    }

    /**
     * Retrieve persons having an assignedrole for a given privilege and unit,
     *     or a descendant of the given unit
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Get Persons having an Assignedrole for a Privilege and Unit (array of objects)",
     *   output = "ApiBundle\Entity\Person",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * #Get("/unit/{id}/privilege/{privilege_id}/persons/{options}", defaults={"options"="{}"}, name="api_get_unit_privilege_persons", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getUnitPrivilegePersonsAction(
        $id,
        $privilege_id,
        $options = '{}'
    ) {
        $merged_options = ApiController::processOptions($options);
        $status          = $merged_options['status'];
        $dql_use         = 1; //$merged_options['dql_use'];
        $flat_result     = $merged_options['flat_result'];
        $data = [];
        $message = '';

        // Retrieve the privilegeroles for the specified privilege and unit.
        $privilegerole_query_response = $this->forward(
            'ApiBundle:Privilege:getPrivilegeUnitsPrivilegeroles',
            [
                'privilege_id' => $privilege_id,
                'unit_list'    => (string) $id,
                'options'      => '{"status":"1","flat_result":"1"}',
            ]
        );
        $pr_response = json_decode(
            $privilegerole_query_response->getContent(),
            true
        );
        $privilegeroles = [];
        if (is_array($pr_response) && isset($pr_response['data'])) {
            $privilegeroles = $pr_response['data'];
        }
        if (empty($privilegeroles)) {
            $message = 'No active privilegeroles found for unit ' . $id .
                ' and privilege ' . $privilege_id;
        } else {
            // Extract privilegerole ids and remove duplicates.
            $privilegerole_ids = array_unique(array_map(
                function ($privilegerole) {
                    return (string) $privilegerole['id'];
                },
                $privilegeroles
            ));

            // Retrieve the assignedroles for the privilegeroles.
            $ar_repository = $this->getDoctrine()->getRepository(
                'ApiBundle:Assignedrole'
            );
            $assignedroles = $ar_repository->findByPrivilegeroles(
                $privilegerole_ids,
                true
            );
            if (empty($assignedroles)) {
                $message =
                    'No active assignedroles found for privilegerole ids [' .
                    implode(',', $privilegerole_ids) . ']';
            } else {
                // Retrieve the person ids for the assignedroles.
                $ar_person_ids = array_map(
                    function ($ar) {
                        return $ar['personId'];
                    },
                    $assignedroles
                );
                $person_ids = array_unique($ar_person_ids);

                // Retrieve the persons.
                if (!empty($person_ids)) {
                    // Filter by status if specified.
                    $where_active_expression = '';
                    if (($status === 0) || ($status === 1)) {
                        $where_active_expression = ' AND p.active = ' . $status;
                    }

                    $em = $this->getDoctrine()->getManager();
                    $query = $em->createQuery(
                        'SELECT p
                        FROM ApiBundle\Entity\Person p
                        WHERE
                          p.id IN (' . implode(',', $person_ids) . ')' .
                          $where_active_expression . '
                        ORDER BY p.id ASC'
                    );

                    if ($dql_use && $flat_result) {
                        $data = $query->getArrayResult();
                    } else {
                        $data = $query->getResult();
                    }
                }
            }
        }

        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200

        return new View(
            [
                'data'      => $data,
                'count'     => $count,
                'code'      => $http_response,
                'message'   => $message,
            ],
            $http_response
        );
    }

    /**
     * Retrieve Qbm\QbClass for a Unit
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "Unit",
     *   resource = true,
     *   description = "Get Qbm\QbClass for a Unit",
     *   output = "QbmBundle\Entity\QbClass",
     *   statusCodes = {
     *     200 = "Returned when successful",
     *   }
     * )
     *
     * @Get("/unit/{id}/qb_class", name="api_get_unit_qb_class")
     *
     * @return string
     */
    public function getUnitQbClass($id)
    {
        // Set up default response.
        $data = [];
        $count = 0;
        $http_code = Response::HTTP_OK;                     // 200
        $message = '';

        // Retrieve the QB ListID from the unit or its ancestor.
        $unit_response = $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Unit',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"flat_result":"0"}',
            ]
        );
        $unit_response_body = json_decode($unit_response->getContent(), true);
        $qb_class_list_id = '';
        $qb_mirror_em = null;
        if ($unit_response_body['code'] === 200) {
            $units = $unit_response_body['data'];
            if (isset($units[0])) {
                $unit = $units[0];

                // Determine corporate legal entity.
                while (!empty($unit['parent'])) {
                    $unit = $unit['parent'];
                }
                $legal_entity_unit_id = $unit['id'];

                // Look up QB mirror Doctrine entity manager for legal entity.
                foreach (NestObject::$legal_entities as $legal_entity) {
                    if ($legal_entity['nest_unit_id'] === $legal_entity_unit_id) {
                        $qb_mirror_em = $legal_entity['qb_mirror_em'];
                        break;
                    }
                }

                if (!empty($qb_mirror_em)) {
                    // Find unit with useParentDept = false.
                    $unit = $units[0];
                    while (isset($unit) && $unit['useParentDept']) {
                        $unit = $unit['parent'];
                    }
                    if (isset($unit)) {
                        $qb_class_list_id = $unit['qbClassListid'];
                    } else {
                        $message = 'Reached top of Unit hierarchy.';
                    }
                } else {
                    $message = 'No qb mirror em for corporate entity ' .
                        $legal_entity_unit_id;
                }
            } else {
                $message = 'Unit ' . $id . ' not found.';
            }
        } else {
            $message = 'Status ' . $unit_response_body['code'] .
            'returned by request for unit ' . $id . '.';
        }

        // If QB class ListID obtained, retrieve QBClass record.
        if (!empty($qb_class_list_id)) {
            $em = $this->getDoctrine()->getManager($qb_mirror_em);
            $query = $em->createQueryBuilder()
                ->select('qc.listid', 'qc.name', 'qc.fullname')
                ->from('QbmBundle:QbClass', 'qc')
                ->where('qc.listid = :listid')
                ->setParameter('listid', $qb_class_list_id)
                ->getQuery();
            $result = $query->getResult();
            if (is_array($result)) {
                $data = $result;
                $count = count($result);
                if ($count === 0) {
                    $message = 'No QbClass found for listid ' .
                        $qb_class_list_id . '.';
                }
            } else {
                $message = 'Could not retrieve QbClass for listid ' .
                    $qb_class_list_id . '.';
            }
        }

        return new View(
            [
                'data'      => $data,
                'count'     => $count,
                'code'      => $http_code,
                'message'   => $message,
            ],
            $http_code
        );
    }
}
