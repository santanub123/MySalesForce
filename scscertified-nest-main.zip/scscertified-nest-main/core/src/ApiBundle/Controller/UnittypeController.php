<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Unittype;
use ApiBundle\Form\UnittypeType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class UnittypeController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Unittype",
     *   resource = true,
     *   description = "Get Unittype with id",
     *   output = "ApiBundle\Entity\Unittype",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the Unittype id
     *
     * @return string
     *     JSON array of 1 Unittype object
     */
    public function getUnittypeAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Unittype',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all unittypes
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Unittype",
     *   resource = true,
     *   description = "Get all Unittypes (array of objects)",
     *   output = "ApiBundle\Entity\Unittype",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/unittypes/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_unittypes", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Unittype objects
     */
    public function getUnittypesQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Unittype',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create Unittype
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Unittype",
     *   resource = true,
     *   description = "Create Unittype",
     *   input = "ApiBundle\Form\UnittypeType",
     *   output = "ApiBundle\Entity\Unittype",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postUnittypeAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Unittype',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Unittype (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Unittype",
     *   resource = true,
     *   description = "Edit Unittype (replace)",
     *   input = "ApiBundle\Form\UnittypeType",
     *   output = "ApiBundle\Entity\Unittype",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function putUnittypeAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Unittype',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Unittype (update)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Unittype",
     *   resource = true,
     *   description = "Edit Unittype (update)",
     *   input = "ApiBundle\Form\UnittypeType",
     *   output = "ApiBundle\Entity\Unittype",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function patchUnittypeAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Unittype',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a Unittype
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Unittype",
     *   resource = true,
     *   description = "Delete Unittype",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the Unittype id
     *
     * @return string
     *     JSON array
     */
    public function deleteUnittypeAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Unittype',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Unittype",
     *   resource = true,
     *   description = "Get Units of a given unit type",
     *   output = "ApiBundle\Entity\Unit",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)"
     *   },
     * )
     *
     * @uses ApiBundle\Entity\Unit
     * @param integer $id the unit id
     *
     * @return string
     */
    public function getUnittypeUnitsAction($id)
    {
        $unittype = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Unittype')
            ->find($id);
        if (is_null($unittype)) {
            $units = null;
            $message = 'No such Unittype';
        } else {
            $units = $unittype->getUnits();
            $message = '';
        }

        $data          = $units;
        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200
        $message       = '';

        return new View(array('data' => $data, 'count' => $count, 'code' => $http_response, 'message' => $message), $http_response);
    }
}
