<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Role;
use ApiBundle\Form\RoleType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 * This file originally Role.php
 */
class RoleController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Role",
     *   resource = true,
     *   description = "Get Role with id",
     *   output = "ApiBundle\Entity\Role",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the Role id
     *
     * @return string
     *     JSON array of 1 Role object
     */
    public function getRoleAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Role',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all Roles<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Role",
     *   resource = true,
     *   description = "Get all Roles",
     *   output = "ApiBundle\Entity\Role",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   }
     * )
     *
     * @Get("/roles/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_roles", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Role objects
     */
    public function getRolesQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Role',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create role
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Role",
     *   resource = true,
     *   description = "Create Role",
     *   input = "ApiBundle\Form\RoleType",
     *   output = "ApiBundle\Entity\Role",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postRoleAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Role',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Role (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Role",
     *   resource = true,
     *   description = "Edit Role (replace)",
     *   input = "ApiBundle\Form\RoleType",
     *   output = "ApiBundle\Entity\Role",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function putRoleAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Role',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Role (update)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Role",
     *   resource = true,
     *   description = "Edit Role (update)",
     *   input = "ApiBundle\Form\RoleType",
     *   output = "ApiBundle\Entity\Role",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function patchRoleAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Role',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a Role
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Role",
     *   resource = true,
     *   description = "Delete Role",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the Role id
     *
     * @return string
     *     JSON array
     */
    public function deleteRoleAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Role',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Role",
     *   resource = true,
     *   description = "Get Privilegeroles for role",
     *   output = "ApiBundle\Entity\Privilegerole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   },
     * )
     *
     * @param integer $id the role id
     *
     * @return string
     */
    public function getRolePrivilegerolesAction($id)
    {
        $role = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Role')
            ->find($id);
        if (is_null($role)) {
            $privilegeroles = null;
            $message = 'No such role';
        } else {
            $privilegeroles = $role->getPrivilegeroles();
            $message = '';
        }

        $data          = $privilegeroles;
        $count         = count($privilegeroles);
        $http_response = Response::HTTP_OK; // 200
        $message       = '';

        return new View(array('data' => $data, 'count' => $count, 'code' => $http_response, 'message' => $message), $http_response);

    }

    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Role",
     *   resource = true,
     *   description = "Get Assignedroles for role",
     *   output = "ApiBundle\Entity\Assignedroles",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   },
     * )
     *
     * @param integer $id the Role id
     *
     * @return string
     */
    public function getRoleAssignedrolesAction($id)
    {
        $role = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Role')
            ->find($id);
        if (is_null($role)) {
            $assignedroles = null;
            $message = 'No such role';
        } else {
            $assignedroles = $role->getAssignedroles();
            $message = '';
        }

        $data          = $assignedroles;
        $count         = count($assignedroles);
        $http_response = Response::HTTP_OK; // 200
        $message       = '';

        return new View(array('data' => $data, 'count' => $count, 'code' => $http_response, 'message' => $message), $http_response);

    }
}
