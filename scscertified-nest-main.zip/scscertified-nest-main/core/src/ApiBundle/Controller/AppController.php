<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\App;
use ApiBundle\Form\AppType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;// as SensioRoute;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security; // allows @Security annotation

/**
 * Pluralization turned off via Util/NoopInflector
 *
 * #Security("is_granted('ROLE_USER')"; // covered by security.yml rules, but always an option
 */
class AppController extends FOSRestController
{
    /* This method may not have any value (as a non-API call)
     * This method is  not in use. MOVE THIS METHOD TO SANDBOX BRANCH (once we decide how sandbox branches will work) -KD 02/28/19
     *
     * @Route("/view/app/{id}", name="view_app_id")
     * #Get("/view/app/{id}", name="view_app_id", options={"method_prefix" = false})
     *
     */
    public function showAction($id)
    {
        $app = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:App')
            ->find($id);
        if (is_null($app)) {
            throw $this->createNotFoundException('No such App');
        }

        /*
        $app = $this->container
        ->get('app.app.handler')
        ->get($id);
        */

        return $this->render('ApiBundle:App/view:show.html.twig', array(
            'entity' => $app, // avoid conflict with built-in var 'app'
        ));
    }

    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "App",
     *   resource = true,
     *   description = "Get App with id",
     *   output = "ApiBundle\Entity\App",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the App id
     *
     * @return string
     *     JSON array of 1 App object
     */
    public function getAppAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'App',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all apps<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "App",
     *   resource = true,
     *   description = "Get all Apps (JSON object)",
     *   output = "ApiBundle\Entity\App",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty): array('data' => Bool|Array $apps, 'count' => Integer $count, 'code' => Integer $http_response, 'message' => String $message)",
     *   }
     * )
     *
     * @Get("/apps/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_apps", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of App objects
     */
    public function getAppsQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'App',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create App
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },

     *   section = "App",
     *   resource = true,
     *   description = "Create App",
     *   input = "ApiBundle\Form\AppType",
     *   output = "ApiBundle\Entity\App",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postAppAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'App',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit App (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "App",
     *   resource = true,
     *   description = "Edit App (replace)",
     *   input = "ApiBundle\Form\AppType",
     *   output = "ApiBundle\Entity\App",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return app
     */
    public function putAppAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'App',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit App (update)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "App",
     *   resource = true,
     *   description = "Edit App (update)",
     *   input = "ApiBundle\Form\AppType",
     *   output = "ApiBundle\Entity\App",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return app
     */
    public function patchAppAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'App',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete App
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "App",
     *   resource = true,
     *   description = "Delete App",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the App id
     *
     * @return string
     *     JSON array
     */
    public function deleteAppAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'App',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /**
     * Get app's privileges (using appkey rather than native id)<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-rights"},
     *   section = "App",
     *   resource = true,
     *   description = "Get app's privileges (using appkey rather than native id)",
     *   output = "ApiBundle\Entity\Privilege",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   }
     * )
     *
     * @Get("/app/{appkey}/privileges/{options}", defaults={"options"="{}"}, name="api_get_app_privileges", options={"method_prefix" = false})

     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     */
    public function getAppAppkeyPrivileges($appkey = null, $options = null)
    {
        $merged_options = ApiController::processOptions($options);

        $app = $this
            ->getDoctrine()
            ->getRepository($merged_options['bundle'] . ':App')
            ->findByAppkey($appkey); // array

        if ($app == null) {
            $data          = false;
            $count         = 0;
            $http_response = Response::HTTP_OK; // 200
            $message       = 'No App found';
        } elseif (count($app) > 1) {
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_PRECONDITION_FAILED; // 412
            $message       = 'Non-unique Appkey. Contact an administrator.';
        } elseif (count($app) > 0) {
            $results = $app[0]->getPrivileges()->getValues();

            // Filter results based on status.
            $data = ApiController::filterByStatus(
                $results,
                $merged_options['status']
            );

            $count         = count($data);
            $http_response = Response::HTTP_OK; // 200
            if ($count > 0) {
                $message   = '';
            } else {
                $message   = 'No active privileges found for App';
            }
        } else {
            $data          = null;
            $count         = 0;
            $http_response = Response::HTTP_OK; // 200
            $message       = 'No privileges found for App';
        }

        return new View(
            [
                'data' => $data,
                'count' => $count,
                'code' => $http_response,
                'message' => $message
            ],
            $http_response
        );
    }

    /**
     * Retrieve app's persons with given privilege<br />
     * TODO: add pagination
     * TODO: couldn't this be replaced by /privilege/{id}/persons? Privileges are unique by Id already so we don't need appkey and the search in Apps...?
     *
     * @ApiDoc(
     *   views = {"default", "nest-rights"},
     *   section = "App",
     *   resource = true,
     *   description = "Get Persons with a given Privilege for a given App (array of objects)",
     *   output = "ApiBundle\Entity\Persons",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   }
     * )
     *
     * @Get("/app/{appkey}/privilege/{id}/persons/{options}", defaults={"options"="{}"}, name="api_get_app_privilege_persons", options={"method_prefix" = false})
     *
     * @return string
     */
    public function getAppAppkeyPrivilegePersons(
        $appkey = null,
        $id = null,
        $options = null
    ) {
        $merged_options = ApiController::processOptions($options);

        $app = $this
            ->getDoctrine()
            ->getRepository($merged_options['bundle'] . ':App')
            ->findByAppkey($appkey); // returns an array

        if (count($app) == 0) {

            $data          = false;
            $count         = 0;
            $http_response = Response::HTTP_OK; // 200
            $message       = 'No App found.';

        } elseif (count($app) > 1) {

            $data          = false;
            $count         = 0;
            $http_response = Response::HTTP_UNPROCESSABLE_ENTITY; // 422
            $message       = 'Non-unique Appkey. Contact an administrator.';

        } elseif (count($app) > 0) {

            $privileges    = $app[0]->getPrivileges();

            $privilege = null;
            foreach ($privileges as $privilege) {
                if ($privilege->getId() == $id) {
                    break;
                }
            }

            // All logic above this line could be skipped if this were /privilege/{id}/persons

            /* From the point of view of Privileges, the SQL looks like:

            SELECT DISTINCT P.*
            FROM Privilege Pv
            JOIN Privilegerole Pr
                ON Pr.privilege_id = Pv.id
            JOIN Assignedrole A
                ON A.role_id = Pr.role_id
                AND A.unit_id = Pr.unit_id
            JOIN Person P
                ON P.id = A.person_id
            WHERE Pv.id = 1{$id}

            An object oriented logic is going to result in lots of individual SQL queries to get the intermediate relationships (Privilege -> Privilegerole -> (Unit && Role) -> Assignedrole -> Person), especially the link between Privilegerole and Assignedrole. So am advocating a DQL method below.

            */

            /*
            $roles = null;
            $persons = [];
            if ($privilege) {
            */

            $privilege = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Privilege')
            ->find($id); // returns an array

            $data = null;
            if ($privilege) {

                $persons = $this
                    ->getDoctrine()
                    ->getRepository('ApiBundle:Privilege')
                    ->findPersons($id);

                // Filter results based on status.
                $data = ApiController::filterByStatus(
                    $persons,
                    $merged_options['status']
                );
                $message = '';

                /*
                $roles = $privilege->getPrivilegeroles();
                foreach ($roles as $role) {
                    $assignedroles = $role->getAssignedroles();
                    foreach ($assignedroles as $assignedrole) {
                        $persons[] = $assignedrole->getPerson();
                        // TODO: problematic for Ted when invoked through Nest\PersonManager class for IAP
                        $org = $assignedrole->getOrg();
                        //if ($org) {
                        if ($org->persons) {
                            foreach ($org->persons as $person) { // causes an error if Person has no Org, though that's not supposed to happen.
                                $persons[] = $person;
                            }
                        } else { // this seems maybe more useful as diagnostic than in production
                          $persons[] = 'empty org (no persons)';
                          // TODO: data structure should correspond to Person
                          //       (... = new ApiBundle\Entity\Person()->setTitle('empty org (no persons)') ?)
                        }
                    }
                }
                */

            } else {

                $message = 'No Privilege found.';

            }

            $count         = count($data);
            $http_response = Response::HTTP_OK; // 200

        }

        return new View(
            [
                'data' => $data,
                'count' => $count,
                'code' => $http_response,
                'message' => $message
            ],
            $http_response
        );
    }


    /**
     * Retrieve app's roles from given approle
     * TODO: add Units; add pagination
     *
     * @ApiDoc(
     *   views = {"default", "nest-rights"},
     *   section = "App",
     *   resource = true,
     *   description = "Get Roles with a given Approle for a given App (array of objects)",
     *   output = "ApiBundle\Entity\Roles",
     *   statusCodes = {
     *     200 = "Returned when successful",
     *     404 = "Returned when page is not found (implicit)"
     *   }
     * )
     *
     * @Get("/app/{appkey}/approle/{id}/roles", name="api_get_app_approle_roles", options={"method_prefix" = false})
     *
     * @return roles[]
     */
    /*
    //KAREN 01/23/19 - This is deprecated code referencing an old structure, and should just be deleted
    public function getAppAppkeyApproleRoles($appkey=null, $id=null)
    {

          // TODO: make use of the function above, so we do next have to repeat the next dozen lines of code

          $app = $this
              ->getDoctrine()
              ->getRepository('ApiBundle:App')
              ->findByAppkey($appkey); // returns an array

          $approles = [];
          if (count($app) > 1) {
              $approles = array("Error" => 403, "Text" => "Non-unique Appkey. Contact an administrator.");
          } elseif (count($app) > 0) {
              $approles = $app[0]->getApproles();
              $count = count($approles);
          }

          // end duplicate code

          $approle = null;
          foreach ($approles as $approle) {
              if ($approle->getId() == $id) {
                  break; // leaves $approle set to a value
              }
          }

          $roles = [];
          if ($approle) {
              $roles = $approle->getRoles();
          }

          //return new View(array('count' => $count, 'data' => $approles), Response::HTTP_OK);
          return new View(array('data' => array('roles' => $roles)), Response::HTTP_OK);
    }
    */

}
