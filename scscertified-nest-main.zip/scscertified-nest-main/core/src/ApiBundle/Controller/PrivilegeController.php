<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\Privilege;
use ApiBundle\Form\PrivilegeType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
#use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class PrivilegeController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Privilege",
     *   resource = true,
     *   description = "Get Privilege with id",
     *   output = "ApiBundle\Entity\Privilege",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the Privilege id
     *
     * @return string
     *     JSON array of 1 Privilege object
     */
    public function getPrivilegeAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Privilege',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all privileges<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Privilege",
     *   resource = true,
     *   description = "Get all Privileges",
     *   output = "ApiBundle\Entity\Privilege",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/privileges/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_privileges", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of Privilege objects
     */
    public function getPrivilegesQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'Privilege',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create Privilege
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Privilege",
     *   resource = true,
     *   description = "Create Privilege",
     *   input = "ApiBundle\Form\PrivilegeType",
     *   output = "ApiBundle\Entity\Privilege",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return Privilege
     */
    public function postPrivilegeAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'Privilege',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Privilege (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Privilege",
     *   resource = true,
     *   description = "Edit Privilege (replace)",
     *   input = "ApiBundle\Form\PrivilegeType",
     *   output = "ApiBundle\Entity\Privilege",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function putPrivilegeAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'Privilege',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit Privilege (update)
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Privilege",
     *   resource = true,
     *   description = "Edit Privilege (update)",
     *   input = "ApiBundle\Form\PrivilegeType",
     *   output = "ApiBundle\Entity\Privilege",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function patchPrivilegeAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'Privilege',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a Privilege
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Privilege",
     *   resource = true,
     *   description = "Delete Privilege",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the Privilege id
     *
     * @return string
     *     JSON array
     */
    public function deletePrivilegeAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'Privilege',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }

    /**
     * @ApiDoc(
     *   views = { "default", "nest-rights" },
     *   section = "Privilege",
     *   resource = true,
     *   description = "Get Privilegeroles for Privilege",
     *   output = "ApiBundle\Entity\Privilegerole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   },
     * )
     *
     * @param integer $id the Privilege id
     *
     * @return string
     */
    public function getPrivilegePrivilegerolesAction($id)
    {
        $privilege = $this
            ->getDoctrine()
            ->getRepository('ApiBundle:Privilege')
            ->find($id);
        if (is_null($privilege)) {
            $privilegeroles = null;
            $message = 'No such Privilege';
        } else {
            $privilegeroles = $privilege->getPrivilegeroles();
            $message = '';
        }

        $data          = $privilegeroles;
        $count         = count($data);
        $http_response = Response::HTTP_OK; // 200

        return new View(array('data' => $data, 'count' => $count, 'code' => $http_response, 'message' => $message), $http_response);
    }

    /**
     * Retrieve all active privilegeroles matching a privilege and a set of units
     *
     * @ApiDoc(
     *   views = { "default", "nest-rights", "nest-users" },
     *   section = "Privilege",
     *   resource = true,
     *   description = "Get all active Privilegeroles matching a privilege and a set of units",
     *   output = "ApiBundle\Entity\Privilegerole",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * #Get("/privilege/{privilege_id}/units/{unit_list}/privilegeroles/{options}", defaults={"options"="{}"}, name="api_get_privilege_units_privilegeroles", options={"method_prefix" = false})
     *
     * @param integer $privilege_id
     *     id of privilege to match
     * @param string $unit_list
     *     comma-separated list of unit ids to match
     *
     * @return string
     *     JSON array of Privilegerole objects
     */
    public function getPrivilegeUnitsPrivilegerolesAction(
        $privilege_id,
        $unit_list,
        $options = '{}'
    ) {
        $merged_options = ApiController::processOptions($options);
        $status          = $merged_options['status'];
        $dql_use         = 1; //$merged_options['dql_use'];
        $flat_result     = $merged_options['flat_result'];

        // Initialize response parameters.
        $data = [];
        $http_response = Response::HTTP_OK;
        $message = '';

        // Filter by status if specified.
        $where_active_expression = '';
        if (($status === 0) || ($status === 1)) {
            $where_active_expression = ' AND pr.active = ' . $status;
        }

        $unit_list = str_ireplace('{unit_list}', '', $unit_list);
        if (empty(trim($unit_list))) {
            $http_response = Response::HTTP_BAD_REQUEST;    // 400
            $message = 'Unit list is empty';
        } else {
            $em = $this->getDoctrine()->getManager();
            $query = $em->createQuery(
                'SELECT pr
                FROM ApiBundle\Entity\Privilegerole pr
                WHERE
                  pr.privilegeId = ' . $privilege_id . ' AND
                  pr.unitId IN (' . $unit_list . ')' .
                  $where_active_expression . '
                ORDER BY pr.id ASC'
            );
            if ($dql_use && $flat_result) {
                $data = $query->getArrayResult();
            } else {
                $data = $query->getResult();
            }
        }

        $count = is_array($data) ? count($data) : 0;

        return new View(
            [
                'data'      => $data,
                'count'     => $count,
                'code'      => $http_response,
                'message'   => $message,
            ],
            $http_response
        );
    }
}
