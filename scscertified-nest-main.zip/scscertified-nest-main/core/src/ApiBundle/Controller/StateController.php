<?php

namespace ApiBundle\Controller;

use ApiBundle\Entity\State;
use ApiBundle\Form\StateType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Pluralization turned off via Util/NoopInflector
 *
 */
class StateController extends FOSRestController
{

    /**
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "State",
     *   resource = true,
     *   description = "Get State with id",
     *   output = "ApiBundle\Entity\State",
     *   statusCodes = {
     *     200 = "Returned when successful (including none found)",
     *   },
     * )
     *
     * @param integer $id
     *     the State id
     *
     * @return string
     *     JSON array of 1 State object
     */
    public function getStateAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'State',
                'query'   => '{"id":"' . $id . '"}',
                'options' => '{"status":"2"}',
            ]
        );
    }

    /**
     * Retrieve all states<br />
     * TODO: add pagination
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "State",
     *   resource = true,
     *   description = "Get all States",
     *   output = "ApiBundle\Entity\State",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty)",
     *   }
     * )
     *
     * @Get("/states/{query}/{options}", defaults={"query"="","options"=""}, name="api_get_states", options={"method_prefix" = false})
     *
     * @param JSON $options {''bundle'':''ApiBundle'', ''status'':1, etc.}
     *
     * @return string
     *     JSON array of State objects
     */
    public function getStatesQuery($query, $options)
    {
        return $this->forward(
            'ApiBundle:Api:getEntityBy',
            [
                'name'    => 'State',
                'query'   => $query,
                'options' => $options,
            ]
        );
    }

    /**
     * Create state
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "State",
     *   resource = true,
     *   description = "Create State",
     *   input = "ApiBundle\Form\StateType",
     *   output = "ApiBundle\Entity\State",
     *   statusCodes = {
     *     201 = "Returned when successfully created",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     *     JSON array
     */
    public function postStateAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:postEntity',
            [
                'request' => $request,
                'name'    => 'State',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit State (replace)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "State",
     *   resource = true,
     *   description = "Edit State (replace)",
     *   input = "ApiBundle\Form\StateType",
     *   output = "ApiBundle\Entity\State",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function putStateAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:putEntity',
            [
                'request' => $request,
                'name'    => 'State',
                'options' => '{}',
            ]
        );
    }

    /**
     * Edit State (upate)
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "State",
     *   resource = true,
     *   description = "Edit State (update)",
     *   input = "ApiBundle\Form\StateType",
     *   output = "ApiBundle\Entity\State",
     *   statusCodes = {
     *     202 = "Returned when successfully edited",
     *     200 = "Returned when no record available to edit",
     *     422 = "Returned when validation fails",
     *   }
     * )
     *
     * @return string
     */
    public function patchStateAction(Request $request)
    {
        return $this->forward(
            'ApiBundle:Api:patchEntity',
            [
                'request' => $request,
                'name'    => 'State',
                'options' => '{}',
            ]
        );
    }

    /**
     * Delete a State
     *
     * @ApiDoc(
     *   views = { "default", "nest-users" },
     *   section = "State",
     *   resource = true,
     *   description = "Delete State",
     *   output = "array()",
     *   statusCodes = {
     *     202 = "Returned when successfully deleted",
     *     200 = "Returned when no record available to delete",
     *   }
     * )
     *
     * @param integer $id
     *     the State id
     *
     * @return string
     *     JSON array
     */
    public function deleteStateAction($id)
    {
        return $this->forward(
            'ApiBundle:Api:deleteEntity',
            [
                'name'    => 'State',
                'id'      => $id,
                'options' => '{}',
            ]
        );
    }
}
