<?php 

namespace ApiBundle\Controller;

use ApiBundle\Entity\Person;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

// Support outside calls to public methods in this class
use Twig\Environment; // as Twig_Environment;
use Symfony\Bundle\FrameworkBundle\Templating\EngineInterface;

class EmailController extends Controller {

    // TODO: set this into nest_config.php so it can be better shared
    private $staff_id = 1;
    
    // Support outside calls to public methods in this class
    private $twig;
    
    // Support use of this class as a service (didn't have a constructor previously)
    //public function __construct(EngineInterface $twig = null)
    public function __construct($twig = null)
    {
        $this->twig = $twig;
    }
    
    
    public function getStaffId() {
        return $this->staff_id;
    }

    public function setPersonDetailsAction($personObj) {

        $is_staff = false;
        // Will just pass a array map instead of the person object due to the unnecessary inherited properties from the getDoctrine() method
        // I'll invoke http_build_query() so I'm not going to add the is_staff in the array, is_staff isn't necessary in the url for the register link
        // is_staff will be passed as a 2nd argument
        $personDetails = [
            'id'            => $personObj->getId(),
            'email'         => $personObj->getEmail1(),
            'nameFirst'     => $personObj->getNameFirst(),
            'nameLast'      => $personObj->getNameLast(),
            'registerToken' => $personObj->getRegisterToken()
        ];

        //Set is_staff to true if there's an assignedrole
        foreach($personObj->getAssignedroles() as $assignedrole) {
            if($assignedrole->getRole()->getId() === $this->staff_id) {
                $is_staff = true;
                break; //Break out of the loop if the staff is set to true
            }
        }
        
        //Trigger email
        $this->messageAction($personDetails, $is_staff);

        //Update Person Register Status to 1
        //
        //Note: we could also use standard Symfony/Doctrine methods to do this, especially since we
        //      have the Person object available already:
        //          $personObj->setRegisterStatus(1);
        //          $personObj->setActive(1);
        //          $entityManager->persist($personObj);
        //          $entityManager->flush();
        //      There would no noticeable difference in performance (on 1 record).
        //      Both schemes work, of course!
        $entityManager = $this->getDoctrine()->getManager();
        $query = $entityManager->createQuery(
                "UPDATE ApiBundle:Person p SET p.registerStatus = 1, p.active = 1 WHERE p.id = :id"
            )->setParameter('id', $personDetails['id']);

        $persons = $query->getResult();

        // Nothing being done with this info. Important? More work to be done?
        $count = count($persons);
        $http_response = Response::HTTP_OK; // 200
    }

    /**
     * @Route("person/dailyEmail/")
     */
    public function emailPersonStartDate() {
 
        //should run via curl
        $repositoryPerson = $this->getDoctrine()->getRepository(Person::class);
        $current_date = date('Y-m-d');
        $entityManager = $this->getDoctrine()->getManager();
        $query = $entityManager->createQuery(
                "SELECT p
                FROM ApiBundle:Person p 
                WHERE p.active = 0 AND p.startDate = :start_date"
            )->setParameter('start_date', $current_date);

        $persons = $query->getResult();

        $count = count($persons);
        $http_response = Response::HTTP_OK; // 200
        $message = '';

        foreach($persons as $person) {
            $this->setPersonDetailsAction($person); // sends mail
        }

        return new View(array('count' => $count, 'data' => $persons, 'code' => $http_response, 'message' => $message), $http_response);

    }

    /**
     * @Route("/person/email/{personId}")
     * @Method({"POST","GET"})
     */
    public function emailPerson($personId) {
        //manually triggers the e-mail for a single user
        $repository = $this->getDoctrine()->getRepository(Person::class);
        $person = $repository->find($personId);
        if (!$person) {
            return new Response('No record found');
        }
        $this->setPersonDetailsAction($person);
        return new Response('Sending email for ' . $person->getEmail1());
    }

    public function messageAction($personDetails, $is_staff = false, $send = true) {
        require_once dirname(dirname(dirname(dirname(__DIR__)))) . '/web-root/nest/nest_config.php';
        $request_scheme = $_SERVER['REQUEST_SCHEME'] . "://";
        $title                  = "Welcome to Nest - your home base for SCS Global Services!";
        $port                   = ((BASE_PORT == '80' || BASE_PORT == '') ? '' : ':' . BASE_PORT);
        $link                   = $request_scheme . NEST_DOMAIN . $port . NEST_API_RELATIVE_URL . '/register/';
        $imageHeader            = $request_scheme . NEST_DOMAIN . $port . NEST_HOME_URL . '/img/email/email-header-nest.jpg';
        $imageFooter            = $request_scheme . NEST_DOMAIN . $port . NEST_HOME_URL . '/img/email/email-bottom.jpg';
        $home                   = $request_scheme . NEST_DOMAIN . $port . NEST_HOME_URL;
        $year                   = date('Y',time());
        $user_registration_link = $link . '?t=' . $personDetails['registerToken'];
        $sender                 = "nestadmin@scsglobalservices.com"; // TODO: set this a config value (nest_config.php or Symfony config.yml)
        $user_email_address     = $personDetails['email']; // This will be based on the created user's email
        $content      = ($is_staff) 
        ? 'Nest is where you’ll find tools and resources to work with our Auditors, Clients, and internal staff. Please take a few moments to set up your Nest user account. Click the "Activate Link" below to create your new password and log in.' 
        : 'Nest is where you’ll find tools and resources to assist in your collaboration with SCS. Please take a few moments to set up your Nest user account. Click the "Activate Link" below to create your new password and log in.';
        
        $email_contents =  array(
            'link'                   => $link,
            'imageHeader'            => $imageHeader,
            'content'                => $content,
            'imageFooter'            => $imageFooter,
            'home'                   => $home,
            'year'                   => $year,
            'title'                  => $title,
            'user_registration_link' => $user_registration_link,
            'nest_home_url'          => $request_scheme . NEST_DOMAIN . $port
        );

        // normal operation -- send immediately
        if ($send) {
            
            $body = $this->renderView('email/message.html.twig', $email_contents);
            $message = (new \Swift_Message($title));
            $message->setFrom($sender);
            $message->setTo($user_email_address);
            $message->setBody($body,'text/html');
            
            return $this->get('mailer')->send($message);
            // returns integer for # of successful recipients -- https://swiftmailer.symfony.com/docs/sending.html
        }
        // if supporting and external service or listener which manages sending
        else {
            return [
                'title'              => $title, 
                'sender'             => $sender, 
                'user_email_address' => $user_email_address,
                'email_contents'     => $email_contents
            ];
        };
        
    }

}
