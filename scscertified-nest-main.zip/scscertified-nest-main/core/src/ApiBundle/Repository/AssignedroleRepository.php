<?php

namespace ApiBundle\Repository;

/**
 * AssignedroleRepository
 */
class AssignedroleRepository extends \Doctrine\ORM\EntityRepository
{
    /**
     * Retrieve assignedroles for a set of privilegeroles (active only)
     *
     * @param array $privilegerole_ids
     *     array of privilegerole ids
     * @param boolean $flat_result
     *     optional, if true, use getArrayResult for query
     *
     * @return array
     *     array of Assignedrole objects
     */
    public function findByPrivilegeroles(
        $privilegerole_ids,
        $flat_result = false
    ) {
        if (!is_array($privilegerole_ids) || empty($privilegerole_ids)) {
            return [];
        }

        $privilegerole_list = implode(',', $privilegerole_ids);
        $query = $this->getEntityManager()->createQuery(
            'SELECT ar
            FROM ApiBundle\Entity\Assignedrole ar
            WHERE
              ar.id IN (
                SELECT DISTINCT arpr.assignedroleId
                FROM ApiBundle\Entity\AssignedrolePrivilegerole arpr
                WHERE arpr.privilegeroleId IN (' . $privilegerole_list . ')
              ) AND
              ar.active = 1'
        );
        if ($flat_result) {
            return $query->getArrayResult();
        } else {
            return $query->getResult();
        }
    }
}
