<?php

namespace ApiBundle\Repository;

/**
 * PrivilegeroleRepository
 */
class PrivilegeroleRepository extends \Doctrine\ORM\EntityRepository
{
    /**
     * Retrieve privilegeroles for a set of assignedroles (active only)
     *
     * @param array $assignedrole_ids
     *     array of assignedrole ids
     * @param boolean $flat_result
     *     optional, if true, use getArrayResult for query
     *
     * @return array
     *     array of Privilegerole objects
     */
    public function findByAssignedroles(
        $assignedrole_ids,
        $flat_result = false
    ) {
        if (!is_array($assignedrole_ids) || empty($assignedrole_ids)) {
            return [];
        }

        $assignedrole_list = implode(',', $assignedrole_ids);
        $query = $this->getEntityManager()->createQuery(
            'SELECT pr
            FROM ApiBundle\Entity\Privilegerole pr
            WHERE
              pr.id IN (
                SELECT DISTINCT arpr.privilegeroleId
                FROM ApiBundle\Entity\AssignedrolePrivilegerole arpr
                WHERE arpr.assignedroleId IN (' . $assignedrole_list . ')
              ) AND
              pr.active = 1'
        );
        if ($flat_result) {
            return $query->getArrayResult();
        } else {
            return $query->getResult();
        }
    }

    /* Retrieve privilegeroles for an assignedrole_id and optional privilege_id
     *
     * Only active privilegeroles are returned.
     *
     * @param integer $assignedrole_id
     *     id of Assignedrole to query by
     * @param integer $privilege_id
     *     optional, Privilege id to filter results by
     * @param boolean $flat_result
     *     optional, if true, use getArrayResult for query
     *
     * @return array
     *     array of Privilegerole objects
     */
    public function findByAssignedrolePrivilege(
        $assignedrole_id,
        $privilege_id = 0,
        $flat_result = false
    ) {
        if (empty($assignedrole_id)) {
            return [];
        }

        $sql = 'SELECT pr
            FROM ApiBundle\Entity\Privilegerole pr
            WHERE
              pr.id IN (
                SELECT DISTINCT arpr.privilegeroleId
                FROM ApiBundle\Entity\AssignedrolePrivilegerole arpr
                WHERE arpr.assignedroleId = ' . $assignedrole_id . '
              ) AND
              pr.active = 1';
        if (!empty($privilege_id)) {
            $sql .= ' AND
                pr.privilegeId = ' . $privilege_id;
        }
        $query = $this->getEntityManager()->createQuery($sql);
        if ($flat_result) {
            return $query->getArrayResult();
        } else {
            return $query->getResult();
        }
    }
}
