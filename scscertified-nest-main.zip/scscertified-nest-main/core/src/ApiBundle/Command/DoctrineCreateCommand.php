<?php

namespace ApiBundle\Command;

use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Doctrine\ORM\Tools\SchemaTool;

class DoctrineCreateCommand extends \Doctrine\Bundle\DoctrineBundle\Command\Proxy\CreateSchemaDoctrineCommand {

    protected $ignoredEntities = array(
        'ApiBundle\Entity\AssignedrolePrivilegerole',
    );
    protected $ignoreAssociationMappings = array(
        'ApiBundle\Entity\Privilegerole' => 'assignedroles',
        'ApiBundle\Entity\Assignedrole' => 'privilegeroles',
    );

    //protected function executeSchemaCommand(InputInterface $input, OutputInterface $output, SchemaTool $schemaTool, array $metadatas) {
    protected function executeSchemaCommand(InputInterface $input, OutputInterface $output, SchemaTool $schemaTool, array $metadatas, SymfonyStyle $ui) {

      /** @var $metadata \Doctrine\ORM\Mapping\ClassMetadata */
      $newMetadatas = array();
      foreach ($metadatas as $metadata) {
          if (array_key_exists($metadata->getName(), $this->ignoreAssociationMappings)) {
              if(array_key_exists($this->ignoreAssociationMappings[$metadata->getName()], $metadata->getAssociationMappings())){
                  unset($metadata->associationMappings[$this->ignoreAssociationMappings[$metadata->getName()]]);
              }
          }
          //If metadata element is not in the ignore array, add it to the new metadata array             
          if (!in_array($metadata->getName(), $this->ignoredEntities)) {
              array_push($newMetadatas, $metadata);
          }
      }

      //parent::executeSchemaCommand($input, $output, $schemaTool, $newMetadatas);
      parent::executeSchemaCommand($input, $output, $schemaTool, $newMetadatas, $ui);
        $output->writeln("------Create view for assignedrole_privilegerole");
        $output->writeln("CREATE VIEW `assignedrole_privilegerole`  AS  select `Assignedrole`.`id` AS `assignedrole_id`,`Privilegerole`.`id` AS `privilegerole_id` from (`Assignedrole` join `Privilegerole`) where ((`Assignedrole`.`role_id` = `Privilegerole`.`role_id`) and ((`Assignedrole`.`unit_id` = `Privilegerole`.`unit_id`) or `Privilegerole`.`unit_id` in (select `Unittree`.`ancestor_id` from `Unittree` where (`Unittree`.`descendant_id` = `Assignedrole`.`unit_id`)))) ;");
    }

}