<?php
$path = __DIR__ . '/../../../../../../sites/nest';
require_once $path . '/nest_config.php';
require_once $path . '/includes/nest_top.php';
require_once $path . '/index.php';
?>
