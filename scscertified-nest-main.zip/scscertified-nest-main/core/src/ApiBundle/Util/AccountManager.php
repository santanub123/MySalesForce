<?php
namespace ApiBundle\Util;

use Doctrine\ORM\EntityManager;
use ApiBundle\Entity\User;

class AccountManager {

  private $user;

  function __construct($user) {
      $this->user = $user;
  }

  public function isAccountLocked($user) {
    return $user->isAccountLocked();
  }

  public function isUserEnabled($user) {
    return $user->getEnabled();
  }

  public function isLockDateInPast($user) {
    if (empty($user->getLockoutExpirationTime())) {
      return true;
    }
    return $user->getLockoutExpirationTime()->getTimestamp() < (new \DateTime())->getTimestamp();
  }

}