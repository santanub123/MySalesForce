<?php

namespace QbmBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class QbmBundle extends Bundle
{
}
