<?php

namespace QbmBundle\Entity;

/**
 * QbBill
 */
class QbBill
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $tax1total;

    /**
     * @var string
     */
    private $tax2total;

    /**
     * @var string
     */
    private $txnid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var integer
     */
    private $txnnumber = '0';

    /**
     * @var string
     */
    private $vendorListid;

    /**
     * @var string
     */
    private $vendorFullname;

    /**
     * @var string
     */
    private $apaccountListid;

    /**
     * @var string
     */
    private $apaccountFullname;

    /**
     * @var \DateTime
     */
    private $txndate;

    /**
     * @var \DateTime
     */
    private $duedate;

    /**
     * @var string
     */
    private $amountdue;

    /**
     * @var string
     */
    private $currencyListid;

    /**
     * @var string
     */
    private $currencyFullname;

    /**
     * @var string
     */
    private $exchangerate;

    /**
     * @var string
     */
    private $amountdueinhomecurrency;

    /**
     * @var string
     */
    private $refnumber;

    /**
     * @var string
     */
    private $termsListid;

    /**
     * @var string
     */
    private $termsFullname;

    /**
     * @var string
     */
    private $memo;

    /**
     * @var boolean
     */
    private $ispaid = '0';

    /**
     * @var string
     */
    private $openamount;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbBill
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbBill
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set tax1total
     *
     * @param string $tax1total
     *
     * @return QbBill
     */
    public function setTax1total($tax1total)
    {
        $this->tax1total = $tax1total;

        return $this;
    }

    /**
     * Get tax1total
     *
     * @return string
     */
    public function getTax1total()
    {
        return $this->tax1total;
    }

    /**
     * Set tax2total
     *
     * @param string $tax2total
     *
     * @return QbBill
     */
    public function setTax2total($tax2total)
    {
        $this->tax2total = $tax2total;

        return $this;
    }

    /**
     * Get tax2total
     *
     * @return string
     */
    public function getTax2total()
    {
        return $this->tax2total;
    }

    /**
     * Set txnid
     *
     * @param string $txnid
     *
     * @return QbBill
     */
    public function setTxnid($txnid)
    {
        $this->txnid = $txnid;

        return $this;
    }

    /**
     * Get txnid
     *
     * @return string
     */
    public function getTxnid()
    {
        return $this->txnid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbBill
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbBill
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbBill
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set txnnumber
     *
     * @param integer $txnnumber
     *
     * @return QbBill
     */
    public function setTxnnumber($txnnumber)
    {
        $this->txnnumber = $txnnumber;

        return $this;
    }

    /**
     * Get txnnumber
     *
     * @return integer
     */
    public function getTxnnumber()
    {
        return $this->txnnumber;
    }

    /**
     * Set vendorListid
     *
     * @param string $vendorListid
     *
     * @return QbBill
     */
    public function setVendorListid($vendorListid)
    {
        $this->vendorListid = $vendorListid;

        return $this;
    }

    /**
     * Get vendorListid
     *
     * @return string
     */
    public function getVendorListid()
    {
        return $this->vendorListid;
    }

    /**
     * Set vendorFullname
     *
     * @param string $vendorFullname
     *
     * @return QbBill
     */
    public function setVendorFullname($vendorFullname)
    {
        $this->vendorFullname = $vendorFullname;

        return $this;
    }

    /**
     * Get vendorFullname
     *
     * @return string
     */
    public function getVendorFullname()
    {
        return $this->vendorFullname;
    }

    /**
     * Set apaccountListid
     *
     * @param string $apaccountListid
     *
     * @return QbBill
     */
    public function setApaccountListid($apaccountListid)
    {
        $this->apaccountListid = $apaccountListid;

        return $this;
    }

    /**
     * Get apaccountListid
     *
     * @return string
     */
    public function getApaccountListid()
    {
        return $this->apaccountListid;
    }

    /**
     * Set apaccountFullname
     *
     * @param string $apaccountFullname
     *
     * @return QbBill
     */
    public function setApaccountFullname($apaccountFullname)
    {
        $this->apaccountFullname = $apaccountFullname;

        return $this;
    }

    /**
     * Get apaccountFullname
     *
     * @return string
     */
    public function getApaccountFullname()
    {
        return $this->apaccountFullname;
    }

    /**
     * Set txndate
     *
     * @param \DateTime $txndate
     *
     * @return QbBill
     */
    public function setTxndate($txndate)
    {
        $this->txndate = $txndate;

        return $this;
    }

    /**
     * Get txndate
     *
     * @return \DateTime
     */
    public function getTxndate()
    {
        return $this->txndate;
    }

    /**
     * Set duedate
     *
     * @param \DateTime $duedate
     *
     * @return QbBill
     */
    public function setDuedate($duedate)
    {
        $this->duedate = $duedate;

        return $this;
    }

    /**
     * Get duedate
     *
     * @return \DateTime
     */
    public function getDuedate()
    {
        return $this->duedate;
    }

    /**
     * Set amountdue
     *
     * @param string $amountdue
     *
     * @return QbBill
     */
    public function setAmountdue($amountdue)
    {
        $this->amountdue = $amountdue;

        return $this;
    }

    /**
     * Get amountdue
     *
     * @return string
     */
    public function getAmountdue()
    {
        return $this->amountdue;
    }

    /**
     * Set currencyListid
     *
     * @param string $currencyListid
     *
     * @return QbBill
     */
    public function setCurrencyListid($currencyListid)
    {
        $this->currencyListid = $currencyListid;

        return $this;
    }

    /**
     * Get currencyListid
     *
     * @return string
     */
    public function getCurrencyListid()
    {
        return $this->currencyListid;
    }

    /**
     * Set currencyFullname
     *
     * @param string $currencyFullname
     *
     * @return QbBill
     */
    public function setCurrencyFullname($currencyFullname)
    {
        $this->currencyFullname = $currencyFullname;

        return $this;
    }

    /**
     * Get currencyFullname
     *
     * @return string
     */
    public function getCurrencyFullname()
    {
        return $this->currencyFullname;
    }

    /**
     * Set exchangerate
     *
     * @param string $exchangerate
     *
     * @return QbBill
     */
    public function setExchangerate($exchangerate)
    {
        $this->exchangerate = $exchangerate;

        return $this;
    }

    /**
     * Get exchangerate
     *
     * @return string
     */
    public function getExchangerate()
    {
        return $this->exchangerate;
    }

    /**
     * Set amountdueinhomecurrency
     *
     * @param string $amountdueinhomecurrency
     *
     * @return QbBill
     */
    public function setAmountdueinhomecurrency($amountdueinhomecurrency)
    {
        $this->amountdueinhomecurrency = $amountdueinhomecurrency;

        return $this;
    }

    /**
     * Get amountdueinhomecurrency
     *
     * @return string
     */
    public function getAmountdueinhomecurrency()
    {
        return $this->amountdueinhomecurrency;
    }

    /**
     * Set refnumber
     *
     * @param string $refnumber
     *
     * @return QbBill
     */
    public function setRefnumber($refnumber)
    {
        $this->refnumber = $refnumber;

        return $this;
    }

    /**
     * Get refnumber
     *
     * @return string
     */
    public function getRefnumber()
    {
        return $this->refnumber;
    }

    /**
     * Set termsListid
     *
     * @param string $termsListid
     *
     * @return QbBill
     */
    public function setTermsListid($termsListid)
    {
        $this->termsListid = $termsListid;

        return $this;
    }

    /**
     * Get termsListid
     *
     * @return string
     */
    public function getTermsListid()
    {
        return $this->termsListid;
    }

    /**
     * Set termsFullname
     *
     * @param string $termsFullname
     *
     * @return QbBill
     */
    public function setTermsFullname($termsFullname)
    {
        $this->termsFullname = $termsFullname;

        return $this;
    }

    /**
     * Get termsFullname
     *
     * @return string
     */
    public function getTermsFullname()
    {
        return $this->termsFullname;
    }

    /**
     * Set memo
     *
     * @param string $memo
     *
     * @return QbBill
     */
    public function setMemo($memo)
    {
        $this->memo = $memo;

        return $this;
    }

    /**
     * Get memo
     *
     * @return string
     */
    public function getMemo()
    {
        return $this->memo;
    }

    /**
     * Set ispaid
     *
     * @param boolean $ispaid
     *
     * @return QbBill
     */
    public function setIspaid($ispaid)
    {
        $this->ispaid = $ispaid;

        return $this;
    }

    /**
     * Get ispaid
     *
     * @return boolean
     */
    public function getIspaid()
    {
        return $this->ispaid;
    }

    /**
     * Set openamount
     *
     * @param string $openamount
     *
     * @return QbBill
     */
    public function setOpenamount($openamount)
    {
        $this->openamount = $openamount;

        return $this;
    }

    /**
     * Get openamount
     *
     * @return string
     */
    public function getOpenamount()
    {
        return $this->openamount;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbBill
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbBill
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbBill
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbBill
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbBill
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbBill
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbBill
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbBill
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbBill
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbBill
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbBill
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbBill
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbBill
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbBill
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbBill
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbBill
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbBill
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbBill
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

