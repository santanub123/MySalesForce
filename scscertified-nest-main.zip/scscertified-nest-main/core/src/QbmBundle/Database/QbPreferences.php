<?php

namespace QbmBundle\Entity;

/**
 * QbPreferences
 */
class QbPreferences
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var boolean
     */
    private $accountingprefsIsusingaccountnumbers = '0';

    /**
     * @var boolean
     */
    private $accountingprefsIsrequiringaccounts = '0';

    /**
     * @var boolean
     */
    private $accountingprefsIsusingclasstracking = '0';

    /**
     * @var boolean
     */
    private $accountingprefsIsusingaudittrail = '0';

    /**
     * @var boolean
     */
    private $accountingprefsIsassigningjournalentrynumbers = '0';

    /**
     * @var \DateTime
     */
    private $accountingprefsClosingdate;

    /**
     * @var string
     */
    private $financechargeprefsAnnualinterestrate;

    /**
     * @var string
     */
    private $financechargeprefsMinfinancecharge;

    /**
     * @var integer
     */
    private $financechargeprefsGraceperiod = '0';

    /**
     * @var string
     */
    private $financechargeprefsFinancechargeaccountListid;

    /**
     * @var string
     */
    private $financechargeprefsFinancechargeaccountFullname;

    /**
     * @var boolean
     */
    private $financechargeprefsIsassessingforoverduecharges = '0';

    /**
     * @var string
     */
    private $financechargeprefsCalculatechargesfrom;

    /**
     * @var boolean
     */
    private $financechargeprefsIsmarkedtobeprinted = '0';

    /**
     * @var boolean
     */
    private $jobsandestimatesprefsIsusingestimates = '0';

    /**
     * @var boolean
     */
    private $jobsandestimatesprefsIsusingprogressinvoicing = '0';

    /**
     * @var boolean
     */
    private $jobsandestimatesprefsIsprintingitemswithzeroamounts = '0';

    /**
     * @var boolean
     */
    private $multicurrencyprefsIsmulticurrencyon = '0';

    /**
     * @var string
     */
    private $multicurrencyprefsHomecurrencyListid;

    /**
     * @var string
     */
    private $multicurrencyprefsHomecurrencyFullname;

    /**
     * @var boolean
     */
    private $multilocationinventoryprefsIsmultilocationinventoryavailable = '0';

    /**
     * @var boolean
     */
    private $multilocationinventoryprefsIsmultilocationinventoryenabled = '0';

    /**
     * @var boolean
     */
    private $purchasesandvendorsprefsIsusinginventory = '0';

    /**
     * @var integer
     */
    private $purchasesandvendorsprefsDaysbillsaredue = '0';

    /**
     * @var boolean
     */
    private $purchasesandvendorsprefsIsautomaticallyusingdiscounts = '0';

    /**
     * @var string
     */
    private $purchasesandvendorsprefsDefaultdiscountaccountListid;

    /**
     * @var string
     */
    private $purchasesandvendorsprefsDefaultdiscountaccountFullname;

    /**
     * @var string
     */
    private $reportsprefsAgingreportbasis;

    /**
     * @var string
     */
    private $reportsprefsSummaryreportbasis;

    /**
     * @var string
     */
    private $salesandcustomersprefsDefaultshipmethodListid;

    /**
     * @var string
     */
    private $salesandcustomersprefsDefaultshipmethodFullname;

    /**
     * @var string
     */
    private $salesandcustomersprefsDefaultfob;

    /**
     * @var string
     */
    private $salesandcustomersprefsDefaultmarkup;

    /**
     * @var boolean
     */
    private $salesandcustomersprefsIstrackingreimbursedexpensesasincome = '0';

    /**
     * @var boolean
     */
    private $salesandcustomersprefsIsautoapplyingpayments = '0';

    /**
     * @var boolean
     */
    private $salesandcustomersprefsPricelevelsIsusingpricelevels = '0';

    /**
     * @var boolean
     */
    private $salesandcustomersprefsPricelevelsIsroundingsalespriceup = '0';

    /**
     * @var string
     */
    private $salestaxprefsDefaultitemsalestaxListid;

    /**
     * @var string
     */
    private $salestaxprefsDefaultitemsalestaxFullname;

    /**
     * @var string
     */
    private $salestaxprefsPaysalestax;

    /**
     * @var string
     */
    private $salestaxprefsDefaulttaxablesalestaxcodeListid;

    /**
     * @var string
     */
    private $salestaxprefsDefaulttaxablesalestaxcodeFullname;

    /**
     * @var string
     */
    private $salestaxprefsDefaultnontaxablesalestaxcodeListid;

    /**
     * @var string
     */
    private $salestaxprefsDefaultnontaxablesalestaxcodeFullname;

    /**
     * @var boolean
     */
    private $salestaxprefsIsusingvendortaxcode = '0';

    /**
     * @var boolean
     */
    private $salestaxprefsIsusingcustomertaxcode = '0';

    /**
     * @var boolean
     */
    private $salestaxprefsIsusingamountsincludetax = '0';

    /**
     * @var string
     */
    private $timetrackingprefsFirstdayofweek;

    /**
     * @var boolean
     */
    private $currentappaccessrightsIsautomaticloginallowed = '0';

    /**
     * @var string
     */
    private $currentappaccessrightsAutomaticloginusername;

    /**
     * @var boolean
     */
    private $currentappaccessrightsIspersonaldataaccessallowed = '0';

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbPreferences
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbPreferences
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set accountingprefsIsusingaccountnumbers
     *
     * @param boolean $accountingprefsIsusingaccountnumbers
     *
     * @return QbPreferences
     */
    public function setAccountingprefsIsusingaccountnumbers($accountingprefsIsusingaccountnumbers)
    {
        $this->accountingprefsIsusingaccountnumbers = $accountingprefsIsusingaccountnumbers;

        return $this;
    }

    /**
     * Get accountingprefsIsusingaccountnumbers
     *
     * @return boolean
     */
    public function getAccountingprefsIsusingaccountnumbers()
    {
        return $this->accountingprefsIsusingaccountnumbers;
    }

    /**
     * Set accountingprefsIsrequiringaccounts
     *
     * @param boolean $accountingprefsIsrequiringaccounts
     *
     * @return QbPreferences
     */
    public function setAccountingprefsIsrequiringaccounts($accountingprefsIsrequiringaccounts)
    {
        $this->accountingprefsIsrequiringaccounts = $accountingprefsIsrequiringaccounts;

        return $this;
    }

    /**
     * Get accountingprefsIsrequiringaccounts
     *
     * @return boolean
     */
    public function getAccountingprefsIsrequiringaccounts()
    {
        return $this->accountingprefsIsrequiringaccounts;
    }

    /**
     * Set accountingprefsIsusingclasstracking
     *
     * @param boolean $accountingprefsIsusingclasstracking
     *
     * @return QbPreferences
     */
    public function setAccountingprefsIsusingclasstracking($accountingprefsIsusingclasstracking)
    {
        $this->accountingprefsIsusingclasstracking = $accountingprefsIsusingclasstracking;

        return $this;
    }

    /**
     * Get accountingprefsIsusingclasstracking
     *
     * @return boolean
     */
    public function getAccountingprefsIsusingclasstracking()
    {
        return $this->accountingprefsIsusingclasstracking;
    }

    /**
     * Set accountingprefsIsusingaudittrail
     *
     * @param boolean $accountingprefsIsusingaudittrail
     *
     * @return QbPreferences
     */
    public function setAccountingprefsIsusingaudittrail($accountingprefsIsusingaudittrail)
    {
        $this->accountingprefsIsusingaudittrail = $accountingprefsIsusingaudittrail;

        return $this;
    }

    /**
     * Get accountingprefsIsusingaudittrail
     *
     * @return boolean
     */
    public function getAccountingprefsIsusingaudittrail()
    {
        return $this->accountingprefsIsusingaudittrail;
    }

    /**
     * Set accountingprefsIsassigningjournalentrynumbers
     *
     * @param boolean $accountingprefsIsassigningjournalentrynumbers
     *
     * @return QbPreferences
     */
    public function setAccountingprefsIsassigningjournalentrynumbers($accountingprefsIsassigningjournalentrynumbers)
    {
        $this->accountingprefsIsassigningjournalentrynumbers = $accountingprefsIsassigningjournalentrynumbers;

        return $this;
    }

    /**
     * Get accountingprefsIsassigningjournalentrynumbers
     *
     * @return boolean
     */
    public function getAccountingprefsIsassigningjournalentrynumbers()
    {
        return $this->accountingprefsIsassigningjournalentrynumbers;
    }

    /**
     * Set accountingprefsClosingdate
     *
     * @param \DateTime $accountingprefsClosingdate
     *
     * @return QbPreferences
     */
    public function setAccountingprefsClosingdate($accountingprefsClosingdate)
    {
        $this->accountingprefsClosingdate = $accountingprefsClosingdate;

        return $this;
    }

    /**
     * Get accountingprefsClosingdate
     *
     * @return \DateTime
     */
    public function getAccountingprefsClosingdate()
    {
        return $this->accountingprefsClosingdate;
    }

    /**
     * Set financechargeprefsAnnualinterestrate
     *
     * @param string $financechargeprefsAnnualinterestrate
     *
     * @return QbPreferences
     */
    public function setFinancechargeprefsAnnualinterestrate($financechargeprefsAnnualinterestrate)
    {
        $this->financechargeprefsAnnualinterestrate = $financechargeprefsAnnualinterestrate;

        return $this;
    }

    /**
     * Get financechargeprefsAnnualinterestrate
     *
     * @return string
     */
    public function getFinancechargeprefsAnnualinterestrate()
    {
        return $this->financechargeprefsAnnualinterestrate;
    }

    /**
     * Set financechargeprefsMinfinancecharge
     *
     * @param string $financechargeprefsMinfinancecharge
     *
     * @return QbPreferences
     */
    public function setFinancechargeprefsMinfinancecharge($financechargeprefsMinfinancecharge)
    {
        $this->financechargeprefsMinfinancecharge = $financechargeprefsMinfinancecharge;

        return $this;
    }

    /**
     * Get financechargeprefsMinfinancecharge
     *
     * @return string
     */
    public function getFinancechargeprefsMinfinancecharge()
    {
        return $this->financechargeprefsMinfinancecharge;
    }

    /**
     * Set financechargeprefsGraceperiod
     *
     * @param integer $financechargeprefsGraceperiod
     *
     * @return QbPreferences
     */
    public function setFinancechargeprefsGraceperiod($financechargeprefsGraceperiod)
    {
        $this->financechargeprefsGraceperiod = $financechargeprefsGraceperiod;

        return $this;
    }

    /**
     * Get financechargeprefsGraceperiod
     *
     * @return integer
     */
    public function getFinancechargeprefsGraceperiod()
    {
        return $this->financechargeprefsGraceperiod;
    }

    /**
     * Set financechargeprefsFinancechargeaccountListid
     *
     * @param string $financechargeprefsFinancechargeaccountListid
     *
     * @return QbPreferences
     */
    public function setFinancechargeprefsFinancechargeaccountListid($financechargeprefsFinancechargeaccountListid)
    {
        $this->financechargeprefsFinancechargeaccountListid = $financechargeprefsFinancechargeaccountListid;

        return $this;
    }

    /**
     * Get financechargeprefsFinancechargeaccountListid
     *
     * @return string
     */
    public function getFinancechargeprefsFinancechargeaccountListid()
    {
        return $this->financechargeprefsFinancechargeaccountListid;
    }

    /**
     * Set financechargeprefsFinancechargeaccountFullname
     *
     * @param string $financechargeprefsFinancechargeaccountFullname
     *
     * @return QbPreferences
     */
    public function setFinancechargeprefsFinancechargeaccountFullname($financechargeprefsFinancechargeaccountFullname)
    {
        $this->financechargeprefsFinancechargeaccountFullname = $financechargeprefsFinancechargeaccountFullname;

        return $this;
    }

    /**
     * Get financechargeprefsFinancechargeaccountFullname
     *
     * @return string
     */
    public function getFinancechargeprefsFinancechargeaccountFullname()
    {
        return $this->financechargeprefsFinancechargeaccountFullname;
    }

    /**
     * Set financechargeprefsIsassessingforoverduecharges
     *
     * @param boolean $financechargeprefsIsassessingforoverduecharges
     *
     * @return QbPreferences
     */
    public function setFinancechargeprefsIsassessingforoverduecharges($financechargeprefsIsassessingforoverduecharges)
    {
        $this->financechargeprefsIsassessingforoverduecharges = $financechargeprefsIsassessingforoverduecharges;

        return $this;
    }

    /**
     * Get financechargeprefsIsassessingforoverduecharges
     *
     * @return boolean
     */
    public function getFinancechargeprefsIsassessingforoverduecharges()
    {
        return $this->financechargeprefsIsassessingforoverduecharges;
    }

    /**
     * Set financechargeprefsCalculatechargesfrom
     *
     * @param string $financechargeprefsCalculatechargesfrom
     *
     * @return QbPreferences
     */
    public function setFinancechargeprefsCalculatechargesfrom($financechargeprefsCalculatechargesfrom)
    {
        $this->financechargeprefsCalculatechargesfrom = $financechargeprefsCalculatechargesfrom;

        return $this;
    }

    /**
     * Get financechargeprefsCalculatechargesfrom
     *
     * @return string
     */
    public function getFinancechargeprefsCalculatechargesfrom()
    {
        return $this->financechargeprefsCalculatechargesfrom;
    }

    /**
     * Set financechargeprefsIsmarkedtobeprinted
     *
     * @param boolean $financechargeprefsIsmarkedtobeprinted
     *
     * @return QbPreferences
     */
    public function setFinancechargeprefsIsmarkedtobeprinted($financechargeprefsIsmarkedtobeprinted)
    {
        $this->financechargeprefsIsmarkedtobeprinted = $financechargeprefsIsmarkedtobeprinted;

        return $this;
    }

    /**
     * Get financechargeprefsIsmarkedtobeprinted
     *
     * @return boolean
     */
    public function getFinancechargeprefsIsmarkedtobeprinted()
    {
        return $this->financechargeprefsIsmarkedtobeprinted;
    }

    /**
     * Set jobsandestimatesprefsIsusingestimates
     *
     * @param boolean $jobsandestimatesprefsIsusingestimates
     *
     * @return QbPreferences
     */
    public function setJobsandestimatesprefsIsusingestimates($jobsandestimatesprefsIsusingestimates)
    {
        $this->jobsandestimatesprefsIsusingestimates = $jobsandestimatesprefsIsusingestimates;

        return $this;
    }

    /**
     * Get jobsandestimatesprefsIsusingestimates
     *
     * @return boolean
     */
    public function getJobsandestimatesprefsIsusingestimates()
    {
        return $this->jobsandestimatesprefsIsusingestimates;
    }

    /**
     * Set jobsandestimatesprefsIsusingprogressinvoicing
     *
     * @param boolean $jobsandestimatesprefsIsusingprogressinvoicing
     *
     * @return QbPreferences
     */
    public function setJobsandestimatesprefsIsusingprogressinvoicing($jobsandestimatesprefsIsusingprogressinvoicing)
    {
        $this->jobsandestimatesprefsIsusingprogressinvoicing = $jobsandestimatesprefsIsusingprogressinvoicing;

        return $this;
    }

    /**
     * Get jobsandestimatesprefsIsusingprogressinvoicing
     *
     * @return boolean
     */
    public function getJobsandestimatesprefsIsusingprogressinvoicing()
    {
        return $this->jobsandestimatesprefsIsusingprogressinvoicing;
    }

    /**
     * Set jobsandestimatesprefsIsprintingitemswithzeroamounts
     *
     * @param boolean $jobsandestimatesprefsIsprintingitemswithzeroamounts
     *
     * @return QbPreferences
     */
    public function setJobsandestimatesprefsIsprintingitemswithzeroamounts($jobsandestimatesprefsIsprintingitemswithzeroamounts)
    {
        $this->jobsandestimatesprefsIsprintingitemswithzeroamounts = $jobsandestimatesprefsIsprintingitemswithzeroamounts;

        return $this;
    }

    /**
     * Get jobsandestimatesprefsIsprintingitemswithzeroamounts
     *
     * @return boolean
     */
    public function getJobsandestimatesprefsIsprintingitemswithzeroamounts()
    {
        return $this->jobsandestimatesprefsIsprintingitemswithzeroamounts;
    }

    /**
     * Set multicurrencyprefsIsmulticurrencyon
     *
     * @param boolean $multicurrencyprefsIsmulticurrencyon
     *
     * @return QbPreferences
     */
    public function setMulticurrencyprefsIsmulticurrencyon($multicurrencyprefsIsmulticurrencyon)
    {
        $this->multicurrencyprefsIsmulticurrencyon = $multicurrencyprefsIsmulticurrencyon;

        return $this;
    }

    /**
     * Get multicurrencyprefsIsmulticurrencyon
     *
     * @return boolean
     */
    public function getMulticurrencyprefsIsmulticurrencyon()
    {
        return $this->multicurrencyprefsIsmulticurrencyon;
    }

    /**
     * Set multicurrencyprefsHomecurrencyListid
     *
     * @param string $multicurrencyprefsHomecurrencyListid
     *
     * @return QbPreferences
     */
    public function setMulticurrencyprefsHomecurrencyListid($multicurrencyprefsHomecurrencyListid)
    {
        $this->multicurrencyprefsHomecurrencyListid = $multicurrencyprefsHomecurrencyListid;

        return $this;
    }

    /**
     * Get multicurrencyprefsHomecurrencyListid
     *
     * @return string
     */
    public function getMulticurrencyprefsHomecurrencyListid()
    {
        return $this->multicurrencyprefsHomecurrencyListid;
    }

    /**
     * Set multicurrencyprefsHomecurrencyFullname
     *
     * @param string $multicurrencyprefsHomecurrencyFullname
     *
     * @return QbPreferences
     */
    public function setMulticurrencyprefsHomecurrencyFullname($multicurrencyprefsHomecurrencyFullname)
    {
        $this->multicurrencyprefsHomecurrencyFullname = $multicurrencyprefsHomecurrencyFullname;

        return $this;
    }

    /**
     * Get multicurrencyprefsHomecurrencyFullname
     *
     * @return string
     */
    public function getMulticurrencyprefsHomecurrencyFullname()
    {
        return $this->multicurrencyprefsHomecurrencyFullname;
    }

    /**
     * Set multilocationinventoryprefsIsmultilocationinventoryavailable
     *
     * @param boolean $multilocationinventoryprefsIsmultilocationinventoryavailable
     *
     * @return QbPreferences
     */
    public function setMultilocationinventoryprefsIsmultilocationinventoryavailable($multilocationinventoryprefsIsmultilocationinventoryavailable)
    {
        $this->multilocationinventoryprefsIsmultilocationinventoryavailable = $multilocationinventoryprefsIsmultilocationinventoryavailable;

        return $this;
    }

    /**
     * Get multilocationinventoryprefsIsmultilocationinventoryavailable
     *
     * @return boolean
     */
    public function getMultilocationinventoryprefsIsmultilocationinventoryavailable()
    {
        return $this->multilocationinventoryprefsIsmultilocationinventoryavailable;
    }

    /**
     * Set multilocationinventoryprefsIsmultilocationinventoryenabled
     *
     * @param boolean $multilocationinventoryprefsIsmultilocationinventoryenabled
     *
     * @return QbPreferences
     */
    public function setMultilocationinventoryprefsIsmultilocationinventoryenabled($multilocationinventoryprefsIsmultilocationinventoryenabled)
    {
        $this->multilocationinventoryprefsIsmultilocationinventoryenabled = $multilocationinventoryprefsIsmultilocationinventoryenabled;

        return $this;
    }

    /**
     * Get multilocationinventoryprefsIsmultilocationinventoryenabled
     *
     * @return boolean
     */
    public function getMultilocationinventoryprefsIsmultilocationinventoryenabled()
    {
        return $this->multilocationinventoryprefsIsmultilocationinventoryenabled;
    }

    /**
     * Set purchasesandvendorsprefsIsusinginventory
     *
     * @param boolean $purchasesandvendorsprefsIsusinginventory
     *
     * @return QbPreferences
     */
    public function setPurchasesandvendorsprefsIsusinginventory($purchasesandvendorsprefsIsusinginventory)
    {
        $this->purchasesandvendorsprefsIsusinginventory = $purchasesandvendorsprefsIsusinginventory;

        return $this;
    }

    /**
     * Get purchasesandvendorsprefsIsusinginventory
     *
     * @return boolean
     */
    public function getPurchasesandvendorsprefsIsusinginventory()
    {
        return $this->purchasesandvendorsprefsIsusinginventory;
    }

    /**
     * Set purchasesandvendorsprefsDaysbillsaredue
     *
     * @param integer $purchasesandvendorsprefsDaysbillsaredue
     *
     * @return QbPreferences
     */
    public function setPurchasesandvendorsprefsDaysbillsaredue($purchasesandvendorsprefsDaysbillsaredue)
    {
        $this->purchasesandvendorsprefsDaysbillsaredue = $purchasesandvendorsprefsDaysbillsaredue;

        return $this;
    }

    /**
     * Get purchasesandvendorsprefsDaysbillsaredue
     *
     * @return integer
     */
    public function getPurchasesandvendorsprefsDaysbillsaredue()
    {
        return $this->purchasesandvendorsprefsDaysbillsaredue;
    }

    /**
     * Set purchasesandvendorsprefsIsautomaticallyusingdiscounts
     *
     * @param boolean $purchasesandvendorsprefsIsautomaticallyusingdiscounts
     *
     * @return QbPreferences
     */
    public function setPurchasesandvendorsprefsIsautomaticallyusingdiscounts($purchasesandvendorsprefsIsautomaticallyusingdiscounts)
    {
        $this->purchasesandvendorsprefsIsautomaticallyusingdiscounts = $purchasesandvendorsprefsIsautomaticallyusingdiscounts;

        return $this;
    }

    /**
     * Get purchasesandvendorsprefsIsautomaticallyusingdiscounts
     *
     * @return boolean
     */
    public function getPurchasesandvendorsprefsIsautomaticallyusingdiscounts()
    {
        return $this->purchasesandvendorsprefsIsautomaticallyusingdiscounts;
    }

    /**
     * Set purchasesandvendorsprefsDefaultdiscountaccountListid
     *
     * @param string $purchasesandvendorsprefsDefaultdiscountaccountListid
     *
     * @return QbPreferences
     */
    public function setPurchasesandvendorsprefsDefaultdiscountaccountListid($purchasesandvendorsprefsDefaultdiscountaccountListid)
    {
        $this->purchasesandvendorsprefsDefaultdiscountaccountListid = $purchasesandvendorsprefsDefaultdiscountaccountListid;

        return $this;
    }

    /**
     * Get purchasesandvendorsprefsDefaultdiscountaccountListid
     *
     * @return string
     */
    public function getPurchasesandvendorsprefsDefaultdiscountaccountListid()
    {
        return $this->purchasesandvendorsprefsDefaultdiscountaccountListid;
    }

    /**
     * Set purchasesandvendorsprefsDefaultdiscountaccountFullname
     *
     * @param string $purchasesandvendorsprefsDefaultdiscountaccountFullname
     *
     * @return QbPreferences
     */
    public function setPurchasesandvendorsprefsDefaultdiscountaccountFullname($purchasesandvendorsprefsDefaultdiscountaccountFullname)
    {
        $this->purchasesandvendorsprefsDefaultdiscountaccountFullname = $purchasesandvendorsprefsDefaultdiscountaccountFullname;

        return $this;
    }

    /**
     * Get purchasesandvendorsprefsDefaultdiscountaccountFullname
     *
     * @return string
     */
    public function getPurchasesandvendorsprefsDefaultdiscountaccountFullname()
    {
        return $this->purchasesandvendorsprefsDefaultdiscountaccountFullname;
    }

    /**
     * Set reportsprefsAgingreportbasis
     *
     * @param string $reportsprefsAgingreportbasis
     *
     * @return QbPreferences
     */
    public function setReportsprefsAgingreportbasis($reportsprefsAgingreportbasis)
    {
        $this->reportsprefsAgingreportbasis = $reportsprefsAgingreportbasis;

        return $this;
    }

    /**
     * Get reportsprefsAgingreportbasis
     *
     * @return string
     */
    public function getReportsprefsAgingreportbasis()
    {
        return $this->reportsprefsAgingreportbasis;
    }

    /**
     * Set reportsprefsSummaryreportbasis
     *
     * @param string $reportsprefsSummaryreportbasis
     *
     * @return QbPreferences
     */
    public function setReportsprefsSummaryreportbasis($reportsprefsSummaryreportbasis)
    {
        $this->reportsprefsSummaryreportbasis = $reportsprefsSummaryreportbasis;

        return $this;
    }

    /**
     * Get reportsprefsSummaryreportbasis
     *
     * @return string
     */
    public function getReportsprefsSummaryreportbasis()
    {
        return $this->reportsprefsSummaryreportbasis;
    }

    /**
     * Set salesandcustomersprefsDefaultshipmethodListid
     *
     * @param string $salesandcustomersprefsDefaultshipmethodListid
     *
     * @return QbPreferences
     */
    public function setSalesandcustomersprefsDefaultshipmethodListid($salesandcustomersprefsDefaultshipmethodListid)
    {
        $this->salesandcustomersprefsDefaultshipmethodListid = $salesandcustomersprefsDefaultshipmethodListid;

        return $this;
    }

    /**
     * Get salesandcustomersprefsDefaultshipmethodListid
     *
     * @return string
     */
    public function getSalesandcustomersprefsDefaultshipmethodListid()
    {
        return $this->salesandcustomersprefsDefaultshipmethodListid;
    }

    /**
     * Set salesandcustomersprefsDefaultshipmethodFullname
     *
     * @param string $salesandcustomersprefsDefaultshipmethodFullname
     *
     * @return QbPreferences
     */
    public function setSalesandcustomersprefsDefaultshipmethodFullname($salesandcustomersprefsDefaultshipmethodFullname)
    {
        $this->salesandcustomersprefsDefaultshipmethodFullname = $salesandcustomersprefsDefaultshipmethodFullname;

        return $this;
    }

    /**
     * Get salesandcustomersprefsDefaultshipmethodFullname
     *
     * @return string
     */
    public function getSalesandcustomersprefsDefaultshipmethodFullname()
    {
        return $this->salesandcustomersprefsDefaultshipmethodFullname;
    }

    /**
     * Set salesandcustomersprefsDefaultfob
     *
     * @param string $salesandcustomersprefsDefaultfob
     *
     * @return QbPreferences
     */
    public function setSalesandcustomersprefsDefaultfob($salesandcustomersprefsDefaultfob)
    {
        $this->salesandcustomersprefsDefaultfob = $salesandcustomersprefsDefaultfob;

        return $this;
    }

    /**
     * Get salesandcustomersprefsDefaultfob
     *
     * @return string
     */
    public function getSalesandcustomersprefsDefaultfob()
    {
        return $this->salesandcustomersprefsDefaultfob;
    }

    /**
     * Set salesandcustomersprefsDefaultmarkup
     *
     * @param string $salesandcustomersprefsDefaultmarkup
     *
     * @return QbPreferences
     */
    public function setSalesandcustomersprefsDefaultmarkup($salesandcustomersprefsDefaultmarkup)
    {
        $this->salesandcustomersprefsDefaultmarkup = $salesandcustomersprefsDefaultmarkup;

        return $this;
    }

    /**
     * Get salesandcustomersprefsDefaultmarkup
     *
     * @return string
     */
    public function getSalesandcustomersprefsDefaultmarkup()
    {
        return $this->salesandcustomersprefsDefaultmarkup;
    }

    /**
     * Set salesandcustomersprefsIstrackingreimbursedexpensesasincome
     *
     * @param boolean $salesandcustomersprefsIstrackingreimbursedexpensesasincome
     *
     * @return QbPreferences
     */
    public function setSalesandcustomersprefsIstrackingreimbursedexpensesasincome($salesandcustomersprefsIstrackingreimbursedexpensesasincome)
    {
        $this->salesandcustomersprefsIstrackingreimbursedexpensesasincome = $salesandcustomersprefsIstrackingreimbursedexpensesasincome;

        return $this;
    }

    /**
     * Get salesandcustomersprefsIstrackingreimbursedexpensesasincome
     *
     * @return boolean
     */
    public function getSalesandcustomersprefsIstrackingreimbursedexpensesasincome()
    {
        return $this->salesandcustomersprefsIstrackingreimbursedexpensesasincome;
    }

    /**
     * Set salesandcustomersprefsIsautoapplyingpayments
     *
     * @param boolean $salesandcustomersprefsIsautoapplyingpayments
     *
     * @return QbPreferences
     */
    public function setSalesandcustomersprefsIsautoapplyingpayments($salesandcustomersprefsIsautoapplyingpayments)
    {
        $this->salesandcustomersprefsIsautoapplyingpayments = $salesandcustomersprefsIsautoapplyingpayments;

        return $this;
    }

    /**
     * Get salesandcustomersprefsIsautoapplyingpayments
     *
     * @return boolean
     */
    public function getSalesandcustomersprefsIsautoapplyingpayments()
    {
        return $this->salesandcustomersprefsIsautoapplyingpayments;
    }

    /**
     * Set salesandcustomersprefsPricelevelsIsusingpricelevels
     *
     * @param boolean $salesandcustomersprefsPricelevelsIsusingpricelevels
     *
     * @return QbPreferences
     */
    public function setSalesandcustomersprefsPricelevelsIsusingpricelevels($salesandcustomersprefsPricelevelsIsusingpricelevels)
    {
        $this->salesandcustomersprefsPricelevelsIsusingpricelevels = $salesandcustomersprefsPricelevelsIsusingpricelevels;

        return $this;
    }

    /**
     * Get salesandcustomersprefsPricelevelsIsusingpricelevels
     *
     * @return boolean
     */
    public function getSalesandcustomersprefsPricelevelsIsusingpricelevels()
    {
        return $this->salesandcustomersprefsPricelevelsIsusingpricelevels;
    }

    /**
     * Set salesandcustomersprefsPricelevelsIsroundingsalespriceup
     *
     * @param boolean $salesandcustomersprefsPricelevelsIsroundingsalespriceup
     *
     * @return QbPreferences
     */
    public function setSalesandcustomersprefsPricelevelsIsroundingsalespriceup($salesandcustomersprefsPricelevelsIsroundingsalespriceup)
    {
        $this->salesandcustomersprefsPricelevelsIsroundingsalespriceup = $salesandcustomersprefsPricelevelsIsroundingsalespriceup;

        return $this;
    }

    /**
     * Get salesandcustomersprefsPricelevelsIsroundingsalespriceup
     *
     * @return boolean
     */
    public function getSalesandcustomersprefsPricelevelsIsroundingsalespriceup()
    {
        return $this->salesandcustomersprefsPricelevelsIsroundingsalespriceup;
    }

    /**
     * Set salestaxprefsDefaultitemsalestaxListid
     *
     * @param string $salestaxprefsDefaultitemsalestaxListid
     *
     * @return QbPreferences
     */
    public function setSalestaxprefsDefaultitemsalestaxListid($salestaxprefsDefaultitemsalestaxListid)
    {
        $this->salestaxprefsDefaultitemsalestaxListid = $salestaxprefsDefaultitemsalestaxListid;

        return $this;
    }

    /**
     * Get salestaxprefsDefaultitemsalestaxListid
     *
     * @return string
     */
    public function getSalestaxprefsDefaultitemsalestaxListid()
    {
        return $this->salestaxprefsDefaultitemsalestaxListid;
    }

    /**
     * Set salestaxprefsDefaultitemsalestaxFullname
     *
     * @param string $salestaxprefsDefaultitemsalestaxFullname
     *
     * @return QbPreferences
     */
    public function setSalestaxprefsDefaultitemsalestaxFullname($salestaxprefsDefaultitemsalestaxFullname)
    {
        $this->salestaxprefsDefaultitemsalestaxFullname = $salestaxprefsDefaultitemsalestaxFullname;

        return $this;
    }

    /**
     * Get salestaxprefsDefaultitemsalestaxFullname
     *
     * @return string
     */
    public function getSalestaxprefsDefaultitemsalestaxFullname()
    {
        return $this->salestaxprefsDefaultitemsalestaxFullname;
    }

    /**
     * Set salestaxprefsPaysalestax
     *
     * @param string $salestaxprefsPaysalestax
     *
     * @return QbPreferences
     */
    public function setSalestaxprefsPaysalestax($salestaxprefsPaysalestax)
    {
        $this->salestaxprefsPaysalestax = $salestaxprefsPaysalestax;

        return $this;
    }

    /**
     * Get salestaxprefsPaysalestax
     *
     * @return string
     */
    public function getSalestaxprefsPaysalestax()
    {
        return $this->salestaxprefsPaysalestax;
    }

    /**
     * Set salestaxprefsDefaulttaxablesalestaxcodeListid
     *
     * @param string $salestaxprefsDefaulttaxablesalestaxcodeListid
     *
     * @return QbPreferences
     */
    public function setSalestaxprefsDefaulttaxablesalestaxcodeListid($salestaxprefsDefaulttaxablesalestaxcodeListid)
    {
        $this->salestaxprefsDefaulttaxablesalestaxcodeListid = $salestaxprefsDefaulttaxablesalestaxcodeListid;

        return $this;
    }

    /**
     * Get salestaxprefsDefaulttaxablesalestaxcodeListid
     *
     * @return string
     */
    public function getSalestaxprefsDefaulttaxablesalestaxcodeListid()
    {
        return $this->salestaxprefsDefaulttaxablesalestaxcodeListid;
    }

    /**
     * Set salestaxprefsDefaulttaxablesalestaxcodeFullname
     *
     * @param string $salestaxprefsDefaulttaxablesalestaxcodeFullname
     *
     * @return QbPreferences
     */
    public function setSalestaxprefsDefaulttaxablesalestaxcodeFullname($salestaxprefsDefaulttaxablesalestaxcodeFullname)
    {
        $this->salestaxprefsDefaulttaxablesalestaxcodeFullname = $salestaxprefsDefaulttaxablesalestaxcodeFullname;

        return $this;
    }

    /**
     * Get salestaxprefsDefaulttaxablesalestaxcodeFullname
     *
     * @return string
     */
    public function getSalestaxprefsDefaulttaxablesalestaxcodeFullname()
    {
        return $this->salestaxprefsDefaulttaxablesalestaxcodeFullname;
    }

    /**
     * Set salestaxprefsDefaultnontaxablesalestaxcodeListid
     *
     * @param string $salestaxprefsDefaultnontaxablesalestaxcodeListid
     *
     * @return QbPreferences
     */
    public function setSalestaxprefsDefaultnontaxablesalestaxcodeListid($salestaxprefsDefaultnontaxablesalestaxcodeListid)
    {
        $this->salestaxprefsDefaultnontaxablesalestaxcodeListid = $salestaxprefsDefaultnontaxablesalestaxcodeListid;

        return $this;
    }

    /**
     * Get salestaxprefsDefaultnontaxablesalestaxcodeListid
     *
     * @return string
     */
    public function getSalestaxprefsDefaultnontaxablesalestaxcodeListid()
    {
        return $this->salestaxprefsDefaultnontaxablesalestaxcodeListid;
    }

    /**
     * Set salestaxprefsDefaultnontaxablesalestaxcodeFullname
     *
     * @param string $salestaxprefsDefaultnontaxablesalestaxcodeFullname
     *
     * @return QbPreferences
     */
    public function setSalestaxprefsDefaultnontaxablesalestaxcodeFullname($salestaxprefsDefaultnontaxablesalestaxcodeFullname)
    {
        $this->salestaxprefsDefaultnontaxablesalestaxcodeFullname = $salestaxprefsDefaultnontaxablesalestaxcodeFullname;

        return $this;
    }

    /**
     * Get salestaxprefsDefaultnontaxablesalestaxcodeFullname
     *
     * @return string
     */
    public function getSalestaxprefsDefaultnontaxablesalestaxcodeFullname()
    {
        return $this->salestaxprefsDefaultnontaxablesalestaxcodeFullname;
    }

    /**
     * Set salestaxprefsIsusingvendortaxcode
     *
     * @param boolean $salestaxprefsIsusingvendortaxcode
     *
     * @return QbPreferences
     */
    public function setSalestaxprefsIsusingvendortaxcode($salestaxprefsIsusingvendortaxcode)
    {
        $this->salestaxprefsIsusingvendortaxcode = $salestaxprefsIsusingvendortaxcode;

        return $this;
    }

    /**
     * Get salestaxprefsIsusingvendortaxcode
     *
     * @return boolean
     */
    public function getSalestaxprefsIsusingvendortaxcode()
    {
        return $this->salestaxprefsIsusingvendortaxcode;
    }

    /**
     * Set salestaxprefsIsusingcustomertaxcode
     *
     * @param boolean $salestaxprefsIsusingcustomertaxcode
     *
     * @return QbPreferences
     */
    public function setSalestaxprefsIsusingcustomertaxcode($salestaxprefsIsusingcustomertaxcode)
    {
        $this->salestaxprefsIsusingcustomertaxcode = $salestaxprefsIsusingcustomertaxcode;

        return $this;
    }

    /**
     * Get salestaxprefsIsusingcustomertaxcode
     *
     * @return boolean
     */
    public function getSalestaxprefsIsusingcustomertaxcode()
    {
        return $this->salestaxprefsIsusingcustomertaxcode;
    }

    /**
     * Set salestaxprefsIsusingamountsincludetax
     *
     * @param boolean $salestaxprefsIsusingamountsincludetax
     *
     * @return QbPreferences
     */
    public function setSalestaxprefsIsusingamountsincludetax($salestaxprefsIsusingamountsincludetax)
    {
        $this->salestaxprefsIsusingamountsincludetax = $salestaxprefsIsusingamountsincludetax;

        return $this;
    }

    /**
     * Get salestaxprefsIsusingamountsincludetax
     *
     * @return boolean
     */
    public function getSalestaxprefsIsusingamountsincludetax()
    {
        return $this->salestaxprefsIsusingamountsincludetax;
    }

    /**
     * Set timetrackingprefsFirstdayofweek
     *
     * @param string $timetrackingprefsFirstdayofweek
     *
     * @return QbPreferences
     */
    public function setTimetrackingprefsFirstdayofweek($timetrackingprefsFirstdayofweek)
    {
        $this->timetrackingprefsFirstdayofweek = $timetrackingprefsFirstdayofweek;

        return $this;
    }

    /**
     * Get timetrackingprefsFirstdayofweek
     *
     * @return string
     */
    public function getTimetrackingprefsFirstdayofweek()
    {
        return $this->timetrackingprefsFirstdayofweek;
    }

    /**
     * Set currentappaccessrightsIsautomaticloginallowed
     *
     * @param boolean $currentappaccessrightsIsautomaticloginallowed
     *
     * @return QbPreferences
     */
    public function setCurrentappaccessrightsIsautomaticloginallowed($currentappaccessrightsIsautomaticloginallowed)
    {
        $this->currentappaccessrightsIsautomaticloginallowed = $currentappaccessrightsIsautomaticloginallowed;

        return $this;
    }

    /**
     * Get currentappaccessrightsIsautomaticloginallowed
     *
     * @return boolean
     */
    public function getCurrentappaccessrightsIsautomaticloginallowed()
    {
        return $this->currentappaccessrightsIsautomaticloginallowed;
    }

    /**
     * Set currentappaccessrightsAutomaticloginusername
     *
     * @param string $currentappaccessrightsAutomaticloginusername
     *
     * @return QbPreferences
     */
    public function setCurrentappaccessrightsAutomaticloginusername($currentappaccessrightsAutomaticloginusername)
    {
        $this->currentappaccessrightsAutomaticloginusername = $currentappaccessrightsAutomaticloginusername;

        return $this;
    }

    /**
     * Get currentappaccessrightsAutomaticloginusername
     *
     * @return string
     */
    public function getCurrentappaccessrightsAutomaticloginusername()
    {
        return $this->currentappaccessrightsAutomaticloginusername;
    }

    /**
     * Set currentappaccessrightsIspersonaldataaccessallowed
     *
     * @param boolean $currentappaccessrightsIspersonaldataaccessallowed
     *
     * @return QbPreferences
     */
    public function setCurrentappaccessrightsIspersonaldataaccessallowed($currentappaccessrightsIspersonaldataaccessallowed)
    {
        $this->currentappaccessrightsIspersonaldataaccessallowed = $currentappaccessrightsIspersonaldataaccessallowed;

        return $this;
    }

    /**
     * Get currentappaccessrightsIspersonaldataaccessallowed
     *
     * @return boolean
     */
    public function getCurrentappaccessrightsIspersonaldataaccessallowed()
    {
        return $this->currentappaccessrightsIspersonaldataaccessallowed;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbPreferences
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbPreferences
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbPreferences
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbPreferences
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbPreferences
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbPreferences
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbPreferences
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbPreferences
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbPreferences
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbPreferences
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbPreferences
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbPreferences
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbPreferences
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbPreferences
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbPreferences
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbPreferences
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbPreferences
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbPreferences
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

