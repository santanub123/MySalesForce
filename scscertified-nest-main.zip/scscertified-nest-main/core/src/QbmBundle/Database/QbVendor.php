<?php

namespace QbmBundle\Entity;

/**
 * QbVendor
 */
class QbVendor
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $listid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var string
     */
    private $name;

    /**
     * @var boolean
     */
    private $isactive = '0';

    /**
     * @var string
     */
    private $companyname;

    /**
     * @var string
     */
    private $salutation;

    /**
     * @var string
     */
    private $firstname;

    /**
     * @var string
     */
    private $middlename;

    /**
     * @var string
     */
    private $lastname;

    /**
     * @var string
     */
    private $vendoraddressAddr1;

    /**
     * @var string
     */
    private $vendoraddressAddr2;

    /**
     * @var string
     */
    private $vendoraddressAddr3;

    /**
     * @var string
     */
    private $vendoraddressAddr4;

    /**
     * @var string
     */
    private $vendoraddressAddr5;

    /**
     * @var string
     */
    private $vendoraddressCity;

    /**
     * @var string
     */
    private $vendoraddressState;

    /**
     * @var string
     */
    private $vendoraddressPostalcode;

    /**
     * @var string
     */
    private $vendoraddressCountry;

    /**
     * @var string
     */
    private $vendoraddressNote;

    /**
     * @var string
     */
    private $vendoraddressblockAddr1;

    /**
     * @var string
     */
    private $vendoraddressblockAddr2;

    /**
     * @var string
     */
    private $vendoraddressblockAddr3;

    /**
     * @var string
     */
    private $vendoraddressblockAddr4;

    /**
     * @var string
     */
    private $vendoraddressblockAddr5;

    /**
     * @var string
     */
    private $phone;

    /**
     * @var string
     */
    private $altphone;

    /**
     * @var string
     */
    private $fax;

    /**
     * @var string
     */
    private $email;

    /**
     * @var string
     */
    private $contact;

    /**
     * @var string
     */
    private $altcontact;

    /**
     * @var string
     */
    private $nameoncheck;

    /**
     * @var string
     */
    private $accountnumber;

    /**
     * @var string
     */
    private $notes;

    /**
     * @var string
     */
    private $vendortypeListid;

    /**
     * @var string
     */
    private $vendortypeFullname;

    /**
     * @var string
     */
    private $termsListid;

    /**
     * @var string
     */
    private $termsFullname;

    /**
     * @var string
     */
    private $creditlimit;

    /**
     * @var string
     */
    private $vendortaxident;

    /**
     * @var boolean
     */
    private $isvendoreligiblefor1099 = '0';

    /**
     * @var string
     */
    private $balance;

    /**
     * @var string
     */
    private $billingrateListid;

    /**
     * @var string
     */
    private $billingrateFullname;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbVendor
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbVendor
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set listid
     *
     * @param string $listid
     *
     * @return QbVendor
     */
    public function setListid($listid)
    {
        $this->listid = $listid;

        return $this;
    }

    /**
     * Get listid
     *
     * @return string
     */
    public function getListid()
    {
        return $this->listid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbVendor
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbVendor
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbVendor
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return QbVendor
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set isactive
     *
     * @param boolean $isactive
     *
     * @return QbVendor
     */
    public function setIsactive($isactive)
    {
        $this->isactive = $isactive;

        return $this;
    }

    /**
     * Get isactive
     *
     * @return boolean
     */
    public function getIsactive()
    {
        return $this->isactive;
    }

    /**
     * Set companyname
     *
     * @param string $companyname
     *
     * @return QbVendor
     */
    public function setCompanyname($companyname)
    {
        $this->companyname = $companyname;

        return $this;
    }

    /**
     * Get companyname
     *
     * @return string
     */
    public function getCompanyname()
    {
        return $this->companyname;
    }

    /**
     * Set salutation
     *
     * @param string $salutation
     *
     * @return QbVendor
     */
    public function setSalutation($salutation)
    {
        $this->salutation = $salutation;

        return $this;
    }

    /**
     * Get salutation
     *
     * @return string
     */
    public function getSalutation()
    {
        return $this->salutation;
    }

    /**
     * Set firstname
     *
     * @param string $firstname
     *
     * @return QbVendor
     */
    public function setFirstname($firstname)
    {
        $this->firstname = $firstname;

        return $this;
    }

    /**
     * Get firstname
     *
     * @return string
     */
    public function getFirstname()
    {
        return $this->firstname;
    }

    /**
     * Set middlename
     *
     * @param string $middlename
     *
     * @return QbVendor
     */
    public function setMiddlename($middlename)
    {
        $this->middlename = $middlename;

        return $this;
    }

    /**
     * Get middlename
     *
     * @return string
     */
    public function getMiddlename()
    {
        return $this->middlename;
    }

    /**
     * Set lastname
     *
     * @param string $lastname
     *
     * @return QbVendor
     */
    public function setLastname($lastname)
    {
        $this->lastname = $lastname;

        return $this;
    }

    /**
     * Get lastname
     *
     * @return string
     */
    public function getLastname()
    {
        return $this->lastname;
    }

    /**
     * Set vendoraddressAddr1
     *
     * @param string $vendoraddressAddr1
     *
     * @return QbVendor
     */
    public function setVendoraddressAddr1($vendoraddressAddr1)
    {
        $this->vendoraddressAddr1 = $vendoraddressAddr1;

        return $this;
    }

    /**
     * Get vendoraddressAddr1
     *
     * @return string
     */
    public function getVendoraddressAddr1()
    {
        return $this->vendoraddressAddr1;
    }

    /**
     * Set vendoraddressAddr2
     *
     * @param string $vendoraddressAddr2
     *
     * @return QbVendor
     */
    public function setVendoraddressAddr2($vendoraddressAddr2)
    {
        $this->vendoraddressAddr2 = $vendoraddressAddr2;

        return $this;
    }

    /**
     * Get vendoraddressAddr2
     *
     * @return string
     */
    public function getVendoraddressAddr2()
    {
        return $this->vendoraddressAddr2;
    }

    /**
     * Set vendoraddressAddr3
     *
     * @param string $vendoraddressAddr3
     *
     * @return QbVendor
     */
    public function setVendoraddressAddr3($vendoraddressAddr3)
    {
        $this->vendoraddressAddr3 = $vendoraddressAddr3;

        return $this;
    }

    /**
     * Get vendoraddressAddr3
     *
     * @return string
     */
    public function getVendoraddressAddr3()
    {
        return $this->vendoraddressAddr3;
    }

    /**
     * Set vendoraddressAddr4
     *
     * @param string $vendoraddressAddr4
     *
     * @return QbVendor
     */
    public function setVendoraddressAddr4($vendoraddressAddr4)
    {
        $this->vendoraddressAddr4 = $vendoraddressAddr4;

        return $this;
    }

    /**
     * Get vendoraddressAddr4
     *
     * @return string
     */
    public function getVendoraddressAddr4()
    {
        return $this->vendoraddressAddr4;
    }

    /**
     * Set vendoraddressAddr5
     *
     * @param string $vendoraddressAddr5
     *
     * @return QbVendor
     */
    public function setVendoraddressAddr5($vendoraddressAddr5)
    {
        $this->vendoraddressAddr5 = $vendoraddressAddr5;

        return $this;
    }

    /**
     * Get vendoraddressAddr5
     *
     * @return string
     */
    public function getVendoraddressAddr5()
    {
        return $this->vendoraddressAddr5;
    }

    /**
     * Set vendoraddressCity
     *
     * @param string $vendoraddressCity
     *
     * @return QbVendor
     */
    public function setVendoraddressCity($vendoraddressCity)
    {
        $this->vendoraddressCity = $vendoraddressCity;

        return $this;
    }

    /**
     * Get vendoraddressCity
     *
     * @return string
     */
    public function getVendoraddressCity()
    {
        return $this->vendoraddressCity;
    }

    /**
     * Set vendoraddressState
     *
     * @param string $vendoraddressState
     *
     * @return QbVendor
     */
    public function setVendoraddressState($vendoraddressState)
    {
        $this->vendoraddressState = $vendoraddressState;

        return $this;
    }

    /**
     * Get vendoraddressState
     *
     * @return string
     */
    public function getVendoraddressState()
    {
        return $this->vendoraddressState;
    }

    /**
     * Set vendoraddressPostalcode
     *
     * @param string $vendoraddressPostalcode
     *
     * @return QbVendor
     */
    public function setVendoraddressPostalcode($vendoraddressPostalcode)
    {
        $this->vendoraddressPostalcode = $vendoraddressPostalcode;

        return $this;
    }

    /**
     * Get vendoraddressPostalcode
     *
     * @return string
     */
    public function getVendoraddressPostalcode()
    {
        return $this->vendoraddressPostalcode;
    }

    /**
     * Set vendoraddressCountry
     *
     * @param string $vendoraddressCountry
     *
     * @return QbVendor
     */
    public function setVendoraddressCountry($vendoraddressCountry)
    {
        $this->vendoraddressCountry = $vendoraddressCountry;

        return $this;
    }

    /**
     * Get vendoraddressCountry
     *
     * @return string
     */
    public function getVendoraddressCountry()
    {
        return $this->vendoraddressCountry;
    }

    /**
     * Set vendoraddressNote
     *
     * @param string $vendoraddressNote
     *
     * @return QbVendor
     */
    public function setVendoraddressNote($vendoraddressNote)
    {
        $this->vendoraddressNote = $vendoraddressNote;

        return $this;
    }

    /**
     * Get vendoraddressNote
     *
     * @return string
     */
    public function getVendoraddressNote()
    {
        return $this->vendoraddressNote;
    }

    /**
     * Set vendoraddressblockAddr1
     *
     * @param string $vendoraddressblockAddr1
     *
     * @return QbVendor
     */
    public function setVendoraddressblockAddr1($vendoraddressblockAddr1)
    {
        $this->vendoraddressblockAddr1 = $vendoraddressblockAddr1;

        return $this;
    }

    /**
     * Get vendoraddressblockAddr1
     *
     * @return string
     */
    public function getVendoraddressblockAddr1()
    {
        return $this->vendoraddressblockAddr1;
    }

    /**
     * Set vendoraddressblockAddr2
     *
     * @param string $vendoraddressblockAddr2
     *
     * @return QbVendor
     */
    public function setVendoraddressblockAddr2($vendoraddressblockAddr2)
    {
        $this->vendoraddressblockAddr2 = $vendoraddressblockAddr2;

        return $this;
    }

    /**
     * Get vendoraddressblockAddr2
     *
     * @return string
     */
    public function getVendoraddressblockAddr2()
    {
        return $this->vendoraddressblockAddr2;
    }

    /**
     * Set vendoraddressblockAddr3
     *
     * @param string $vendoraddressblockAddr3
     *
     * @return QbVendor
     */
    public function setVendoraddressblockAddr3($vendoraddressblockAddr3)
    {
        $this->vendoraddressblockAddr3 = $vendoraddressblockAddr3;

        return $this;
    }

    /**
     * Get vendoraddressblockAddr3
     *
     * @return string
     */
    public function getVendoraddressblockAddr3()
    {
        return $this->vendoraddressblockAddr3;
    }

    /**
     * Set vendoraddressblockAddr4
     *
     * @param string $vendoraddressblockAddr4
     *
     * @return QbVendor
     */
    public function setVendoraddressblockAddr4($vendoraddressblockAddr4)
    {
        $this->vendoraddressblockAddr4 = $vendoraddressblockAddr4;

        return $this;
    }

    /**
     * Get vendoraddressblockAddr4
     *
     * @return string
     */
    public function getVendoraddressblockAddr4()
    {
        return $this->vendoraddressblockAddr4;
    }

    /**
     * Set vendoraddressblockAddr5
     *
     * @param string $vendoraddressblockAddr5
     *
     * @return QbVendor
     */
    public function setVendoraddressblockAddr5($vendoraddressblockAddr5)
    {
        $this->vendoraddressblockAddr5 = $vendoraddressblockAddr5;

        return $this;
    }

    /**
     * Get vendoraddressblockAddr5
     *
     * @return string
     */
    public function getVendoraddressblockAddr5()
    {
        return $this->vendoraddressblockAddr5;
    }

    /**
     * Set phone
     *
     * @param string $phone
     *
     * @return QbVendor
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set altphone
     *
     * @param string $altphone
     *
     * @return QbVendor
     */
    public function setAltphone($altphone)
    {
        $this->altphone = $altphone;

        return $this;
    }

    /**
     * Get altphone
     *
     * @return string
     */
    public function getAltphone()
    {
        return $this->altphone;
    }

    /**
     * Set fax
     *
     * @param string $fax
     *
     * @return QbVendor
     */
    public function setFax($fax)
    {
        $this->fax = $fax;

        return $this;
    }

    /**
     * Get fax
     *
     * @return string
     */
    public function getFax()
    {
        return $this->fax;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return QbVendor
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set contact
     *
     * @param string $contact
     *
     * @return QbVendor
     */
    public function setContact($contact)
    {
        $this->contact = $contact;

        return $this;
    }

    /**
     * Get contact
     *
     * @return string
     */
    public function getContact()
    {
        return $this->contact;
    }

    /**
     * Set altcontact
     *
     * @param string $altcontact
     *
     * @return QbVendor
     */
    public function setAltcontact($altcontact)
    {
        $this->altcontact = $altcontact;

        return $this;
    }

    /**
     * Get altcontact
     *
     * @return string
     */
    public function getAltcontact()
    {
        return $this->altcontact;
    }

    /**
     * Set nameoncheck
     *
     * @param string $nameoncheck
     *
     * @return QbVendor
     */
    public function setNameoncheck($nameoncheck)
    {
        $this->nameoncheck = $nameoncheck;

        return $this;
    }

    /**
     * Get nameoncheck
     *
     * @return string
     */
    public function getNameoncheck()
    {
        return $this->nameoncheck;
    }

    /**
     * Set accountnumber
     *
     * @param string $accountnumber
     *
     * @return QbVendor
     */
    public function setAccountnumber($accountnumber)
    {
        $this->accountnumber = $accountnumber;

        return $this;
    }

    /**
     * Get accountnumber
     *
     * @return string
     */
    public function getAccountnumber()
    {
        return $this->accountnumber;
    }

    /**
     * Set notes
     *
     * @param string $notes
     *
     * @return QbVendor
     */
    public function setNotes($notes)
    {
        $this->notes = $notes;

        return $this;
    }

    /**
     * Get notes
     *
     * @return string
     */
    public function getNotes()
    {
        return $this->notes;
    }

    /**
     * Set vendortypeListid
     *
     * @param string $vendortypeListid
     *
     * @return QbVendor
     */
    public function setVendortypeListid($vendortypeListid)
    {
        $this->vendortypeListid = $vendortypeListid;

        return $this;
    }

    /**
     * Get vendortypeListid
     *
     * @return string
     */
    public function getVendortypeListid()
    {
        return $this->vendortypeListid;
    }

    /**
     * Set vendortypeFullname
     *
     * @param string $vendortypeFullname
     *
     * @return QbVendor
     */
    public function setVendortypeFullname($vendortypeFullname)
    {
        $this->vendortypeFullname = $vendortypeFullname;

        return $this;
    }

    /**
     * Get vendortypeFullname
     *
     * @return string
     */
    public function getVendortypeFullname()
    {
        return $this->vendortypeFullname;
    }

    /**
     * Set termsListid
     *
     * @param string $termsListid
     *
     * @return QbVendor
     */
    public function setTermsListid($termsListid)
    {
        $this->termsListid = $termsListid;

        return $this;
    }

    /**
     * Get termsListid
     *
     * @return string
     */
    public function getTermsListid()
    {
        return $this->termsListid;
    }

    /**
     * Set termsFullname
     *
     * @param string $termsFullname
     *
     * @return QbVendor
     */
    public function setTermsFullname($termsFullname)
    {
        $this->termsFullname = $termsFullname;

        return $this;
    }

    /**
     * Get termsFullname
     *
     * @return string
     */
    public function getTermsFullname()
    {
        return $this->termsFullname;
    }

    /**
     * Set creditlimit
     *
     * @param string $creditlimit
     *
     * @return QbVendor
     */
    public function setCreditlimit($creditlimit)
    {
        $this->creditlimit = $creditlimit;

        return $this;
    }

    /**
     * Get creditlimit
     *
     * @return string
     */
    public function getCreditlimit()
    {
        return $this->creditlimit;
    }

    /**
     * Set vendortaxident
     *
     * @param string $vendortaxident
     *
     * @return QbVendor
     */
    public function setVendortaxident($vendortaxident)
    {
        $this->vendortaxident = $vendortaxident;

        return $this;
    }

    /**
     * Get vendortaxident
     *
     * @return string
     */
    public function getVendortaxident()
    {
        return $this->vendortaxident;
    }

    /**
     * Set isvendoreligiblefor1099
     *
     * @param boolean $isvendoreligiblefor1099
     *
     * @return QbVendor
     */
    public function setIsvendoreligiblefor1099($isvendoreligiblefor1099)
    {
        $this->isvendoreligiblefor1099 = $isvendoreligiblefor1099;

        return $this;
    }

    /**
     * Get isvendoreligiblefor1099
     *
     * @return boolean
     */
    public function getIsvendoreligiblefor1099()
    {
        return $this->isvendoreligiblefor1099;
    }

    /**
     * Set balance
     *
     * @param string $balance
     *
     * @return QbVendor
     */
    public function setBalance($balance)
    {
        $this->balance = $balance;

        return $this;
    }

    /**
     * Get balance
     *
     * @return string
     */
    public function getBalance()
    {
        return $this->balance;
    }

    /**
     * Set billingrateListid
     *
     * @param string $billingrateListid
     *
     * @return QbVendor
     */
    public function setBillingrateListid($billingrateListid)
    {
        $this->billingrateListid = $billingrateListid;

        return $this;
    }

    /**
     * Get billingrateListid
     *
     * @return string
     */
    public function getBillingrateListid()
    {
        return $this->billingrateListid;
    }

    /**
     * Set billingrateFullname
     *
     * @param string $billingrateFullname
     *
     * @return QbVendor
     */
    public function setBillingrateFullname($billingrateFullname)
    {
        $this->billingrateFullname = $billingrateFullname;

        return $this;
    }

    /**
     * Get billingrateFullname
     *
     * @return string
     */
    public function getBillingrateFullname()
    {
        return $this->billingrateFullname;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbVendor
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbVendor
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbVendor
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbVendor
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbVendor
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbVendor
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbVendor
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbVendor
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbVendor
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbVendor
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbVendor
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbVendor
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbVendor
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbVendor
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbVendor
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbVendor
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbVendor
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbVendor
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

