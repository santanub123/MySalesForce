<?php

namespace QbmBundle\Entity;

/**
 * QbCompany
 */
class QbCompany
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var boolean
     */
    private $issamplecompany = '0';

    /**
     * @var string
     */
    private $companyname;

    /**
     * @var string
     */
    private $legalcompanyname;

    /**
     * @var string
     */
    private $addressAddr1;

    /**
     * @var string
     */
    private $addressAddr2;

    /**
     * @var string
     */
    private $addressAddr3;

    /**
     * @var string
     */
    private $addressAddr4;

    /**
     * @var string
     */
    private $addressAddr5;

    /**
     * @var string
     */
    private $addressCity;

    /**
     * @var string
     */
    private $addressState;

    /**
     * @var string
     */
    private $addressPostalcode;

    /**
     * @var string
     */
    private $addressCountry;

    /**
     * @var string
     */
    private $addressNote;

    /**
     * @var string
     */
    private $addressblockAddr1;

    /**
     * @var string
     */
    private $addressblockAddr2;

    /**
     * @var string
     */
    private $addressblockAddr3;

    /**
     * @var string
     */
    private $addressblockAddr4;

    /**
     * @var string
     */
    private $addressblockAddr5;

    /**
     * @var string
     */
    private $legaladdressAddr1;

    /**
     * @var string
     */
    private $legaladdressAddr2;

    /**
     * @var string
     */
    private $legaladdressAddr3;

    /**
     * @var string
     */
    private $legaladdressAddr4;

    /**
     * @var string
     */
    private $legaladdressAddr5;

    /**
     * @var string
     */
    private $legaladdressCity;

    /**
     * @var string
     */
    private $legaladdressState;

    /**
     * @var string
     */
    private $legaladdressPostalcode;

    /**
     * @var string
     */
    private $legaladdressCountry;

    /**
     * @var string
     */
    private $legaladdressNote;

    /**
     * @var string
     */
    private $companyCompanyaddressforcustomerAddr1;

    /**
     * @var string
     */
    private $companyCompanyaddressforcustomerAddr2;

    /**
     * @var string
     */
    private $companyCompanyaddressforcustomerAddr3;

    /**
     * @var string
     */
    private $companyCompanyaddressforcustomerAddr4;

    /**
     * @var string
     */
    private $companyCompanyaddressforcustomerAddr5;

    /**
     * @var string
     */
    private $companyCompanyaddressforcustomerCity;

    /**
     * @var string
     */
    private $companyCompanyaddressforcustomerState;

    /**
     * @var string
     */
    private $companyCompanyaddressforcustomerPostalcode;

    /**
     * @var string
     */
    private $companyCompanyaddressforcustomerCountry;

    /**
     * @var string
     */
    private $companyCompanyaddressforcustomerNote;

    /**
     * @var string
     */
    private $companyCompanyaddressblockforcustomerAddr1;

    /**
     * @var string
     */
    private $companyCompanyaddressblockforcustomerAddr2;

    /**
     * @var string
     */
    private $companyCompanyaddressblockforcustomerAddr3;

    /**
     * @var string
     */
    private $companyCompanyaddressblockforcustomerAddr4;

    /**
     * @var string
     */
    private $companyCompanyaddressblockforcustomerAddr5;

    /**
     * @var string
     */
    private $phone;

    /**
     * @var string
     */
    private $fax;

    /**
     * @var string
     */
    private $email;

    /**
     * @var string
     */
    private $companywebsite;

    /**
     * @var string
     */
    private $firstmonthfiscalyear;

    /**
     * @var string
     */
    private $firstmonthincometaxyear;

    /**
     * @var string
     */
    private $companytype;

    /**
     * @var string
     */
    private $ein;

    /**
     * @var string
     */
    private $ssn;

    /**
     * @var string
     */
    private $taxform;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbCompany
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbCompany
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set issamplecompany
     *
     * @param boolean $issamplecompany
     *
     * @return QbCompany
     */
    public function setIssamplecompany($issamplecompany)
    {
        $this->issamplecompany = $issamplecompany;

        return $this;
    }

    /**
     * Get issamplecompany
     *
     * @return boolean
     */
    public function getIssamplecompany()
    {
        return $this->issamplecompany;
    }

    /**
     * Set companyname
     *
     * @param string $companyname
     *
     * @return QbCompany
     */
    public function setCompanyname($companyname)
    {
        $this->companyname = $companyname;

        return $this;
    }

    /**
     * Get companyname
     *
     * @return string
     */
    public function getCompanyname()
    {
        return $this->companyname;
    }

    /**
     * Set legalcompanyname
     *
     * @param string $legalcompanyname
     *
     * @return QbCompany
     */
    public function setLegalcompanyname($legalcompanyname)
    {
        $this->legalcompanyname = $legalcompanyname;

        return $this;
    }

    /**
     * Get legalcompanyname
     *
     * @return string
     */
    public function getLegalcompanyname()
    {
        return $this->legalcompanyname;
    }

    /**
     * Set addressAddr1
     *
     * @param string $addressAddr1
     *
     * @return QbCompany
     */
    public function setAddressAddr1($addressAddr1)
    {
        $this->addressAddr1 = $addressAddr1;

        return $this;
    }

    /**
     * Get addressAddr1
     *
     * @return string
     */
    public function getAddressAddr1()
    {
        return $this->addressAddr1;
    }

    /**
     * Set addressAddr2
     *
     * @param string $addressAddr2
     *
     * @return QbCompany
     */
    public function setAddressAddr2($addressAddr2)
    {
        $this->addressAddr2 = $addressAddr2;

        return $this;
    }

    /**
     * Get addressAddr2
     *
     * @return string
     */
    public function getAddressAddr2()
    {
        return $this->addressAddr2;
    }

    /**
     * Set addressAddr3
     *
     * @param string $addressAddr3
     *
     * @return QbCompany
     */
    public function setAddressAddr3($addressAddr3)
    {
        $this->addressAddr3 = $addressAddr3;

        return $this;
    }

    /**
     * Get addressAddr3
     *
     * @return string
     */
    public function getAddressAddr3()
    {
        return $this->addressAddr3;
    }

    /**
     * Set addressAddr4
     *
     * @param string $addressAddr4
     *
     * @return QbCompany
     */
    public function setAddressAddr4($addressAddr4)
    {
        $this->addressAddr4 = $addressAddr4;

        return $this;
    }

    /**
     * Get addressAddr4
     *
     * @return string
     */
    public function getAddressAddr4()
    {
        return $this->addressAddr4;
    }

    /**
     * Set addressAddr5
     *
     * @param string $addressAddr5
     *
     * @return QbCompany
     */
    public function setAddressAddr5($addressAddr5)
    {
        $this->addressAddr5 = $addressAddr5;

        return $this;
    }

    /**
     * Get addressAddr5
     *
     * @return string
     */
    public function getAddressAddr5()
    {
        return $this->addressAddr5;
    }

    /**
     * Set addressCity
     *
     * @param string $addressCity
     *
     * @return QbCompany
     */
    public function setAddressCity($addressCity)
    {
        $this->addressCity = $addressCity;

        return $this;
    }

    /**
     * Get addressCity
     *
     * @return string
     */
    public function getAddressCity()
    {
        return $this->addressCity;
    }

    /**
     * Set addressState
     *
     * @param string $addressState
     *
     * @return QbCompany
     */
    public function setAddressState($addressState)
    {
        $this->addressState = $addressState;

        return $this;
    }

    /**
     * Get addressState
     *
     * @return string
     */
    public function getAddressState()
    {
        return $this->addressState;
    }

    /**
     * Set addressPostalcode
     *
     * @param string $addressPostalcode
     *
     * @return QbCompany
     */
    public function setAddressPostalcode($addressPostalcode)
    {
        $this->addressPostalcode = $addressPostalcode;

        return $this;
    }

    /**
     * Get addressPostalcode
     *
     * @return string
     */
    public function getAddressPostalcode()
    {
        return $this->addressPostalcode;
    }

    /**
     * Set addressCountry
     *
     * @param string $addressCountry
     *
     * @return QbCompany
     */
    public function setAddressCountry($addressCountry)
    {
        $this->addressCountry = $addressCountry;

        return $this;
    }

    /**
     * Get addressCountry
     *
     * @return string
     */
    public function getAddressCountry()
    {
        return $this->addressCountry;
    }

    /**
     * Set addressNote
     *
     * @param string $addressNote
     *
     * @return QbCompany
     */
    public function setAddressNote($addressNote)
    {
        $this->addressNote = $addressNote;

        return $this;
    }

    /**
     * Get addressNote
     *
     * @return string
     */
    public function getAddressNote()
    {
        return $this->addressNote;
    }

    /**
     * Set addressblockAddr1
     *
     * @param string $addressblockAddr1
     *
     * @return QbCompany
     */
    public function setAddressblockAddr1($addressblockAddr1)
    {
        $this->addressblockAddr1 = $addressblockAddr1;

        return $this;
    }

    /**
     * Get addressblockAddr1
     *
     * @return string
     */
    public function getAddressblockAddr1()
    {
        return $this->addressblockAddr1;
    }

    /**
     * Set addressblockAddr2
     *
     * @param string $addressblockAddr2
     *
     * @return QbCompany
     */
    public function setAddressblockAddr2($addressblockAddr2)
    {
        $this->addressblockAddr2 = $addressblockAddr2;

        return $this;
    }

    /**
     * Get addressblockAddr2
     *
     * @return string
     */
    public function getAddressblockAddr2()
    {
        return $this->addressblockAddr2;
    }

    /**
     * Set addressblockAddr3
     *
     * @param string $addressblockAddr3
     *
     * @return QbCompany
     */
    public function setAddressblockAddr3($addressblockAddr3)
    {
        $this->addressblockAddr3 = $addressblockAddr3;

        return $this;
    }

    /**
     * Get addressblockAddr3
     *
     * @return string
     */
    public function getAddressblockAddr3()
    {
        return $this->addressblockAddr3;
    }

    /**
     * Set addressblockAddr4
     *
     * @param string $addressblockAddr4
     *
     * @return QbCompany
     */
    public function setAddressblockAddr4($addressblockAddr4)
    {
        $this->addressblockAddr4 = $addressblockAddr4;

        return $this;
    }

    /**
     * Get addressblockAddr4
     *
     * @return string
     */
    public function getAddressblockAddr4()
    {
        return $this->addressblockAddr4;
    }

    /**
     * Set addressblockAddr5
     *
     * @param string $addressblockAddr5
     *
     * @return QbCompany
     */
    public function setAddressblockAddr5($addressblockAddr5)
    {
        $this->addressblockAddr5 = $addressblockAddr5;

        return $this;
    }

    /**
     * Get addressblockAddr5
     *
     * @return string
     */
    public function getAddressblockAddr5()
    {
        return $this->addressblockAddr5;
    }

    /**
     * Set legaladdressAddr1
     *
     * @param string $legaladdressAddr1
     *
     * @return QbCompany
     */
    public function setLegaladdressAddr1($legaladdressAddr1)
    {
        $this->legaladdressAddr1 = $legaladdressAddr1;

        return $this;
    }

    /**
     * Get legaladdressAddr1
     *
     * @return string
     */
    public function getLegaladdressAddr1()
    {
        return $this->legaladdressAddr1;
    }

    /**
     * Set legaladdressAddr2
     *
     * @param string $legaladdressAddr2
     *
     * @return QbCompany
     */
    public function setLegaladdressAddr2($legaladdressAddr2)
    {
        $this->legaladdressAddr2 = $legaladdressAddr2;

        return $this;
    }

    /**
     * Get legaladdressAddr2
     *
     * @return string
     */
    public function getLegaladdressAddr2()
    {
        return $this->legaladdressAddr2;
    }

    /**
     * Set legaladdressAddr3
     *
     * @param string $legaladdressAddr3
     *
     * @return QbCompany
     */
    public function setLegaladdressAddr3($legaladdressAddr3)
    {
        $this->legaladdressAddr3 = $legaladdressAddr3;

        return $this;
    }

    /**
     * Get legaladdressAddr3
     *
     * @return string
     */
    public function getLegaladdressAddr3()
    {
        return $this->legaladdressAddr3;
    }

    /**
     * Set legaladdressAddr4
     *
     * @param string $legaladdressAddr4
     *
     * @return QbCompany
     */
    public function setLegaladdressAddr4($legaladdressAddr4)
    {
        $this->legaladdressAddr4 = $legaladdressAddr4;

        return $this;
    }

    /**
     * Get legaladdressAddr4
     *
     * @return string
     */
    public function getLegaladdressAddr4()
    {
        return $this->legaladdressAddr4;
    }

    /**
     * Set legaladdressAddr5
     *
     * @param string $legaladdressAddr5
     *
     * @return QbCompany
     */
    public function setLegaladdressAddr5($legaladdressAddr5)
    {
        $this->legaladdressAddr5 = $legaladdressAddr5;

        return $this;
    }

    /**
     * Get legaladdressAddr5
     *
     * @return string
     */
    public function getLegaladdressAddr5()
    {
        return $this->legaladdressAddr5;
    }

    /**
     * Set legaladdressCity
     *
     * @param string $legaladdressCity
     *
     * @return QbCompany
     */
    public function setLegaladdressCity($legaladdressCity)
    {
        $this->legaladdressCity = $legaladdressCity;

        return $this;
    }

    /**
     * Get legaladdressCity
     *
     * @return string
     */
    public function getLegaladdressCity()
    {
        return $this->legaladdressCity;
    }

    /**
     * Set legaladdressState
     *
     * @param string $legaladdressState
     *
     * @return QbCompany
     */
    public function setLegaladdressState($legaladdressState)
    {
        $this->legaladdressState = $legaladdressState;

        return $this;
    }

    /**
     * Get legaladdressState
     *
     * @return string
     */
    public function getLegaladdressState()
    {
        return $this->legaladdressState;
    }

    /**
     * Set legaladdressPostalcode
     *
     * @param string $legaladdressPostalcode
     *
     * @return QbCompany
     */
    public function setLegaladdressPostalcode($legaladdressPostalcode)
    {
        $this->legaladdressPostalcode = $legaladdressPostalcode;

        return $this;
    }

    /**
     * Get legaladdressPostalcode
     *
     * @return string
     */
    public function getLegaladdressPostalcode()
    {
        return $this->legaladdressPostalcode;
    }

    /**
     * Set legaladdressCountry
     *
     * @param string $legaladdressCountry
     *
     * @return QbCompany
     */
    public function setLegaladdressCountry($legaladdressCountry)
    {
        $this->legaladdressCountry = $legaladdressCountry;

        return $this;
    }

    /**
     * Get legaladdressCountry
     *
     * @return string
     */
    public function getLegaladdressCountry()
    {
        return $this->legaladdressCountry;
    }

    /**
     * Set legaladdressNote
     *
     * @param string $legaladdressNote
     *
     * @return QbCompany
     */
    public function setLegaladdressNote($legaladdressNote)
    {
        $this->legaladdressNote = $legaladdressNote;

        return $this;
    }

    /**
     * Get legaladdressNote
     *
     * @return string
     */
    public function getLegaladdressNote()
    {
        return $this->legaladdressNote;
    }

    /**
     * Set companyCompanyaddressforcustomerAddr1
     *
     * @param string $companyCompanyaddressforcustomerAddr1
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressforcustomerAddr1($companyCompanyaddressforcustomerAddr1)
    {
        $this->companyCompanyaddressforcustomerAddr1 = $companyCompanyaddressforcustomerAddr1;

        return $this;
    }

    /**
     * Get companyCompanyaddressforcustomerAddr1
     *
     * @return string
     */
    public function getCompanyCompanyaddressforcustomerAddr1()
    {
        return $this->companyCompanyaddressforcustomerAddr1;
    }

    /**
     * Set companyCompanyaddressforcustomerAddr2
     *
     * @param string $companyCompanyaddressforcustomerAddr2
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressforcustomerAddr2($companyCompanyaddressforcustomerAddr2)
    {
        $this->companyCompanyaddressforcustomerAddr2 = $companyCompanyaddressforcustomerAddr2;

        return $this;
    }

    /**
     * Get companyCompanyaddressforcustomerAddr2
     *
     * @return string
     */
    public function getCompanyCompanyaddressforcustomerAddr2()
    {
        return $this->companyCompanyaddressforcustomerAddr2;
    }

    /**
     * Set companyCompanyaddressforcustomerAddr3
     *
     * @param string $companyCompanyaddressforcustomerAddr3
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressforcustomerAddr3($companyCompanyaddressforcustomerAddr3)
    {
        $this->companyCompanyaddressforcustomerAddr3 = $companyCompanyaddressforcustomerAddr3;

        return $this;
    }

    /**
     * Get companyCompanyaddressforcustomerAddr3
     *
     * @return string
     */
    public function getCompanyCompanyaddressforcustomerAddr3()
    {
        return $this->companyCompanyaddressforcustomerAddr3;
    }

    /**
     * Set companyCompanyaddressforcustomerAddr4
     *
     * @param string $companyCompanyaddressforcustomerAddr4
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressforcustomerAddr4($companyCompanyaddressforcustomerAddr4)
    {
        $this->companyCompanyaddressforcustomerAddr4 = $companyCompanyaddressforcustomerAddr4;

        return $this;
    }

    /**
     * Get companyCompanyaddressforcustomerAddr4
     *
     * @return string
     */
    public function getCompanyCompanyaddressforcustomerAddr4()
    {
        return $this->companyCompanyaddressforcustomerAddr4;
    }

    /**
     * Set companyCompanyaddressforcustomerAddr5
     *
     * @param string $companyCompanyaddressforcustomerAddr5
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressforcustomerAddr5($companyCompanyaddressforcustomerAddr5)
    {
        $this->companyCompanyaddressforcustomerAddr5 = $companyCompanyaddressforcustomerAddr5;

        return $this;
    }

    /**
     * Get companyCompanyaddressforcustomerAddr5
     *
     * @return string
     */
    public function getCompanyCompanyaddressforcustomerAddr5()
    {
        return $this->companyCompanyaddressforcustomerAddr5;
    }

    /**
     * Set companyCompanyaddressforcustomerCity
     *
     * @param string $companyCompanyaddressforcustomerCity
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressforcustomerCity($companyCompanyaddressforcustomerCity)
    {
        $this->companyCompanyaddressforcustomerCity = $companyCompanyaddressforcustomerCity;

        return $this;
    }

    /**
     * Get companyCompanyaddressforcustomerCity
     *
     * @return string
     */
    public function getCompanyCompanyaddressforcustomerCity()
    {
        return $this->companyCompanyaddressforcustomerCity;
    }

    /**
     * Set companyCompanyaddressforcustomerState
     *
     * @param string $companyCompanyaddressforcustomerState
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressforcustomerState($companyCompanyaddressforcustomerState)
    {
        $this->companyCompanyaddressforcustomerState = $companyCompanyaddressforcustomerState;

        return $this;
    }

    /**
     * Get companyCompanyaddressforcustomerState
     *
     * @return string
     */
    public function getCompanyCompanyaddressforcustomerState()
    {
        return $this->companyCompanyaddressforcustomerState;
    }

    /**
     * Set companyCompanyaddressforcustomerPostalcode
     *
     * @param string $companyCompanyaddressforcustomerPostalcode
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressforcustomerPostalcode($companyCompanyaddressforcustomerPostalcode)
    {
        $this->companyCompanyaddressforcustomerPostalcode = $companyCompanyaddressforcustomerPostalcode;

        return $this;
    }

    /**
     * Get companyCompanyaddressforcustomerPostalcode
     *
     * @return string
     */
    public function getCompanyCompanyaddressforcustomerPostalcode()
    {
        return $this->companyCompanyaddressforcustomerPostalcode;
    }

    /**
     * Set companyCompanyaddressforcustomerCountry
     *
     * @param string $companyCompanyaddressforcustomerCountry
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressforcustomerCountry($companyCompanyaddressforcustomerCountry)
    {
        $this->companyCompanyaddressforcustomerCountry = $companyCompanyaddressforcustomerCountry;

        return $this;
    }

    /**
     * Get companyCompanyaddressforcustomerCountry
     *
     * @return string
     */
    public function getCompanyCompanyaddressforcustomerCountry()
    {
        return $this->companyCompanyaddressforcustomerCountry;
    }

    /**
     * Set companyCompanyaddressforcustomerNote
     *
     * @param string $companyCompanyaddressforcustomerNote
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressforcustomerNote($companyCompanyaddressforcustomerNote)
    {
        $this->companyCompanyaddressforcustomerNote = $companyCompanyaddressforcustomerNote;

        return $this;
    }

    /**
     * Get companyCompanyaddressforcustomerNote
     *
     * @return string
     */
    public function getCompanyCompanyaddressforcustomerNote()
    {
        return $this->companyCompanyaddressforcustomerNote;
    }

    /**
     * Set companyCompanyaddressblockforcustomerAddr1
     *
     * @param string $companyCompanyaddressblockforcustomerAddr1
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressblockforcustomerAddr1($companyCompanyaddressblockforcustomerAddr1)
    {
        $this->companyCompanyaddressblockforcustomerAddr1 = $companyCompanyaddressblockforcustomerAddr1;

        return $this;
    }

    /**
     * Get companyCompanyaddressblockforcustomerAddr1
     *
     * @return string
     */
    public function getCompanyCompanyaddressblockforcustomerAddr1()
    {
        return $this->companyCompanyaddressblockforcustomerAddr1;
    }

    /**
     * Set companyCompanyaddressblockforcustomerAddr2
     *
     * @param string $companyCompanyaddressblockforcustomerAddr2
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressblockforcustomerAddr2($companyCompanyaddressblockforcustomerAddr2)
    {
        $this->companyCompanyaddressblockforcustomerAddr2 = $companyCompanyaddressblockforcustomerAddr2;

        return $this;
    }

    /**
     * Get companyCompanyaddressblockforcustomerAddr2
     *
     * @return string
     */
    public function getCompanyCompanyaddressblockforcustomerAddr2()
    {
        return $this->companyCompanyaddressblockforcustomerAddr2;
    }

    /**
     * Set companyCompanyaddressblockforcustomerAddr3
     *
     * @param string $companyCompanyaddressblockforcustomerAddr3
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressblockforcustomerAddr3($companyCompanyaddressblockforcustomerAddr3)
    {
        $this->companyCompanyaddressblockforcustomerAddr3 = $companyCompanyaddressblockforcustomerAddr3;

        return $this;
    }

    /**
     * Get companyCompanyaddressblockforcustomerAddr3
     *
     * @return string
     */
    public function getCompanyCompanyaddressblockforcustomerAddr3()
    {
        return $this->companyCompanyaddressblockforcustomerAddr3;
    }

    /**
     * Set companyCompanyaddressblockforcustomerAddr4
     *
     * @param string $companyCompanyaddressblockforcustomerAddr4
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressblockforcustomerAddr4($companyCompanyaddressblockforcustomerAddr4)
    {
        $this->companyCompanyaddressblockforcustomerAddr4 = $companyCompanyaddressblockforcustomerAddr4;

        return $this;
    }

    /**
     * Get companyCompanyaddressblockforcustomerAddr4
     *
     * @return string
     */
    public function getCompanyCompanyaddressblockforcustomerAddr4()
    {
        return $this->companyCompanyaddressblockforcustomerAddr4;
    }

    /**
     * Set companyCompanyaddressblockforcustomerAddr5
     *
     * @param string $companyCompanyaddressblockforcustomerAddr5
     *
     * @return QbCompany
     */
    public function setCompanyCompanyaddressblockforcustomerAddr5($companyCompanyaddressblockforcustomerAddr5)
    {
        $this->companyCompanyaddressblockforcustomerAddr5 = $companyCompanyaddressblockforcustomerAddr5;

        return $this;
    }

    /**
     * Get companyCompanyaddressblockforcustomerAddr5
     *
     * @return string
     */
    public function getCompanyCompanyaddressblockforcustomerAddr5()
    {
        return $this->companyCompanyaddressblockforcustomerAddr5;
    }

    /**
     * Set phone
     *
     * @param string $phone
     *
     * @return QbCompany
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set fax
     *
     * @param string $fax
     *
     * @return QbCompany
     */
    public function setFax($fax)
    {
        $this->fax = $fax;

        return $this;
    }

    /**
     * Get fax
     *
     * @return string
     */
    public function getFax()
    {
        return $this->fax;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return QbCompany
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set companywebsite
     *
     * @param string $companywebsite
     *
     * @return QbCompany
     */
    public function setCompanywebsite($companywebsite)
    {
        $this->companywebsite = $companywebsite;

        return $this;
    }

    /**
     * Get companywebsite
     *
     * @return string
     */
    public function getCompanywebsite()
    {
        return $this->companywebsite;
    }

    /**
     * Set firstmonthfiscalyear
     *
     * @param string $firstmonthfiscalyear
     *
     * @return QbCompany
     */
    public function setFirstmonthfiscalyear($firstmonthfiscalyear)
    {
        $this->firstmonthfiscalyear = $firstmonthfiscalyear;

        return $this;
    }

    /**
     * Get firstmonthfiscalyear
     *
     * @return string
     */
    public function getFirstmonthfiscalyear()
    {
        return $this->firstmonthfiscalyear;
    }

    /**
     * Set firstmonthincometaxyear
     *
     * @param string $firstmonthincometaxyear
     *
     * @return QbCompany
     */
    public function setFirstmonthincometaxyear($firstmonthincometaxyear)
    {
        $this->firstmonthincometaxyear = $firstmonthincometaxyear;

        return $this;
    }

    /**
     * Get firstmonthincometaxyear
     *
     * @return string
     */
    public function getFirstmonthincometaxyear()
    {
        return $this->firstmonthincometaxyear;
    }

    /**
     * Set companytype
     *
     * @param string $companytype
     *
     * @return QbCompany
     */
    public function setCompanytype($companytype)
    {
        $this->companytype = $companytype;

        return $this;
    }

    /**
     * Get companytype
     *
     * @return string
     */
    public function getCompanytype()
    {
        return $this->companytype;
    }

    /**
     * Set ein
     *
     * @param string $ein
     *
     * @return QbCompany
     */
    public function setEin($ein)
    {
        $this->ein = $ein;

        return $this;
    }

    /**
     * Get ein
     *
     * @return string
     */
    public function getEin()
    {
        return $this->ein;
    }

    /**
     * Set ssn
     *
     * @param string $ssn
     *
     * @return QbCompany
     */
    public function setSsn($ssn)
    {
        $this->ssn = $ssn;

        return $this;
    }

    /**
     * Get ssn
     *
     * @return string
     */
    public function getSsn()
    {
        return $this->ssn;
    }

    /**
     * Set taxform
     *
     * @param string $taxform
     *
     * @return QbCompany
     */
    public function setTaxform($taxform)
    {
        $this->taxform = $taxform;

        return $this;
    }

    /**
     * Get taxform
     *
     * @return string
     */
    public function getTaxform()
    {
        return $this->taxform;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbCompany
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbCompany
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbCompany
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbCompany
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbCompany
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbCompany
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbCompany
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbCompany
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbCompany
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbCompany
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbCompany
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbCompany
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbCompany
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbCompany
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbCompany
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbCompany
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbCompany
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbCompany
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

