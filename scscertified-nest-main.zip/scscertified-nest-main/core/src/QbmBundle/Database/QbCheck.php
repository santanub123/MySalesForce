<?php

namespace QbmBundle\Entity;

/**
 * QbCheck
 */
class QbCheck
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $txnid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var integer
     */
    private $txnnumber = '0';

    /**
     * @var string
     */
    private $accountListid;

    /**
     * @var string
     */
    private $accountFullname;

    /**
     * @var string
     */
    private $payeeentityrefListid;

    /**
     * @var string
     */
    private $payeeentityrefFullname;

    /**
     * @var string
     */
    private $refnumber;

    /**
     * @var \DateTime
     */
    private $txndate;

    /**
     * @var string
     */
    private $amount;

    /**
     * @var string
     */
    private $memo;

    /**
     * @var string
     */
    private $addressAddr1;

    /**
     * @var string
     */
    private $addressAddr2;

    /**
     * @var string
     */
    private $addressAddr3;

    /**
     * @var string
     */
    private $addressAddr4;

    /**
     * @var string
     */
    private $addressAddr5;

    /**
     * @var string
     */
    private $addressCity;

    /**
     * @var string
     */
    private $addressState;

    /**
     * @var string
     */
    private $addressPostalcode;

    /**
     * @var string
     */
    private $addressCountry;

    /**
     * @var string
     */
    private $addressNote;

    /**
     * @var string
     */
    private $addressblockAddr1;

    /**
     * @var string
     */
    private $addressblockAddr2;

    /**
     * @var string
     */
    private $addressblockAddr3;

    /**
     * @var string
     */
    private $addressblockAddr4;

    /**
     * @var string
     */
    private $addressblockAddr5;

    /**
     * @var boolean
     */
    private $istobeprinted;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbCheck
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbCheck
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set txnid
     *
     * @param string $txnid
     *
     * @return QbCheck
     */
    public function setTxnid($txnid)
    {
        $this->txnid = $txnid;

        return $this;
    }

    /**
     * Get txnid
     *
     * @return string
     */
    public function getTxnid()
    {
        return $this->txnid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbCheck
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbCheck
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbCheck
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set txnnumber
     *
     * @param integer $txnnumber
     *
     * @return QbCheck
     */
    public function setTxnnumber($txnnumber)
    {
        $this->txnnumber = $txnnumber;

        return $this;
    }

    /**
     * Get txnnumber
     *
     * @return integer
     */
    public function getTxnnumber()
    {
        return $this->txnnumber;
    }

    /**
     * Set accountListid
     *
     * @param string $accountListid
     *
     * @return QbCheck
     */
    public function setAccountListid($accountListid)
    {
        $this->accountListid = $accountListid;

        return $this;
    }

    /**
     * Get accountListid
     *
     * @return string
     */
    public function getAccountListid()
    {
        return $this->accountListid;
    }

    /**
     * Set accountFullname
     *
     * @param string $accountFullname
     *
     * @return QbCheck
     */
    public function setAccountFullname($accountFullname)
    {
        $this->accountFullname = $accountFullname;

        return $this;
    }

    /**
     * Get accountFullname
     *
     * @return string
     */
    public function getAccountFullname()
    {
        return $this->accountFullname;
    }

    /**
     * Set payeeentityrefListid
     *
     * @param string $payeeentityrefListid
     *
     * @return QbCheck
     */
    public function setPayeeentityrefListid($payeeentityrefListid)
    {
        $this->payeeentityrefListid = $payeeentityrefListid;

        return $this;
    }

    /**
     * Get payeeentityrefListid
     *
     * @return string
     */
    public function getPayeeentityrefListid()
    {
        return $this->payeeentityrefListid;
    }

    /**
     * Set payeeentityrefFullname
     *
     * @param string $payeeentityrefFullname
     *
     * @return QbCheck
     */
    public function setPayeeentityrefFullname($payeeentityrefFullname)
    {
        $this->payeeentityrefFullname = $payeeentityrefFullname;

        return $this;
    }

    /**
     * Get payeeentityrefFullname
     *
     * @return string
     */
    public function getPayeeentityrefFullname()
    {
        return $this->payeeentityrefFullname;
    }

    /**
     * Set refnumber
     *
     * @param string $refnumber
     *
     * @return QbCheck
     */
    public function setRefnumber($refnumber)
    {
        $this->refnumber = $refnumber;

        return $this;
    }

    /**
     * Get refnumber
     *
     * @return string
     */
    public function getRefnumber()
    {
        return $this->refnumber;
    }

    /**
     * Set txndate
     *
     * @param \DateTime $txndate
     *
     * @return QbCheck
     */
    public function setTxndate($txndate)
    {
        $this->txndate = $txndate;

        return $this;
    }

    /**
     * Get txndate
     *
     * @return \DateTime
     */
    public function getTxndate()
    {
        return $this->txndate;
    }

    /**
     * Set amount
     *
     * @param string $amount
     *
     * @return QbCheck
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return string
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set memo
     *
     * @param string $memo
     *
     * @return QbCheck
     */
    public function setMemo($memo)
    {
        $this->memo = $memo;

        return $this;
    }

    /**
     * Get memo
     *
     * @return string
     */
    public function getMemo()
    {
        return $this->memo;
    }

    /**
     * Set addressAddr1
     *
     * @param string $addressAddr1
     *
     * @return QbCheck
     */
    public function setAddressAddr1($addressAddr1)
    {
        $this->addressAddr1 = $addressAddr1;

        return $this;
    }

    /**
     * Get addressAddr1
     *
     * @return string
     */
    public function getAddressAddr1()
    {
        return $this->addressAddr1;
    }

    /**
     * Set addressAddr2
     *
     * @param string $addressAddr2
     *
     * @return QbCheck
     */
    public function setAddressAddr2($addressAddr2)
    {
        $this->addressAddr2 = $addressAddr2;

        return $this;
    }

    /**
     * Get addressAddr2
     *
     * @return string
     */
    public function getAddressAddr2()
    {
        return $this->addressAddr2;
    }

    /**
     * Set addressAddr3
     *
     * @param string $addressAddr3
     *
     * @return QbCheck
     */
    public function setAddressAddr3($addressAddr3)
    {
        $this->addressAddr3 = $addressAddr3;

        return $this;
    }

    /**
     * Get addressAddr3
     *
     * @return string
     */
    public function getAddressAddr3()
    {
        return $this->addressAddr3;
    }

    /**
     * Set addressAddr4
     *
     * @param string $addressAddr4
     *
     * @return QbCheck
     */
    public function setAddressAddr4($addressAddr4)
    {
        $this->addressAddr4 = $addressAddr4;

        return $this;
    }

    /**
     * Get addressAddr4
     *
     * @return string
     */
    public function getAddressAddr4()
    {
        return $this->addressAddr4;
    }

    /**
     * Set addressAddr5
     *
     * @param string $addressAddr5
     *
     * @return QbCheck
     */
    public function setAddressAddr5($addressAddr5)
    {
        $this->addressAddr5 = $addressAddr5;

        return $this;
    }

    /**
     * Get addressAddr5
     *
     * @return string
     */
    public function getAddressAddr5()
    {
        return $this->addressAddr5;
    }

    /**
     * Set addressCity
     *
     * @param string $addressCity
     *
     * @return QbCheck
     */
    public function setAddressCity($addressCity)
    {
        $this->addressCity = $addressCity;

        return $this;
    }

    /**
     * Get addressCity
     *
     * @return string
     */
    public function getAddressCity()
    {
        return $this->addressCity;
    }

    /**
     * Set addressState
     *
     * @param string $addressState
     *
     * @return QbCheck
     */
    public function setAddressState($addressState)
    {
        $this->addressState = $addressState;

        return $this;
    }

    /**
     * Get addressState
     *
     * @return string
     */
    public function getAddressState()
    {
        return $this->addressState;
    }

    /**
     * Set addressPostalcode
     *
     * @param string $addressPostalcode
     *
     * @return QbCheck
     */
    public function setAddressPostalcode($addressPostalcode)
    {
        $this->addressPostalcode = $addressPostalcode;

        return $this;
    }

    /**
     * Get addressPostalcode
     *
     * @return string
     */
    public function getAddressPostalcode()
    {
        return $this->addressPostalcode;
    }

    /**
     * Set addressCountry
     *
     * @param string $addressCountry
     *
     * @return QbCheck
     */
    public function setAddressCountry($addressCountry)
    {
        $this->addressCountry = $addressCountry;

        return $this;
    }

    /**
     * Get addressCountry
     *
     * @return string
     */
    public function getAddressCountry()
    {
        return $this->addressCountry;
    }

    /**
     * Set addressNote
     *
     * @param string $addressNote
     *
     * @return QbCheck
     */
    public function setAddressNote($addressNote)
    {
        $this->addressNote = $addressNote;

        return $this;
    }

    /**
     * Get addressNote
     *
     * @return string
     */
    public function getAddressNote()
    {
        return $this->addressNote;
    }

    /**
     * Set addressblockAddr1
     *
     * @param string $addressblockAddr1
     *
     * @return QbCheck
     */
    public function setAddressblockAddr1($addressblockAddr1)
    {
        $this->addressblockAddr1 = $addressblockAddr1;

        return $this;
    }

    /**
     * Get addressblockAddr1
     *
     * @return string
     */
    public function getAddressblockAddr1()
    {
        return $this->addressblockAddr1;
    }

    /**
     * Set addressblockAddr2
     *
     * @param string $addressblockAddr2
     *
     * @return QbCheck
     */
    public function setAddressblockAddr2($addressblockAddr2)
    {
        $this->addressblockAddr2 = $addressblockAddr2;

        return $this;
    }

    /**
     * Get addressblockAddr2
     *
     * @return string
     */
    public function getAddressblockAddr2()
    {
        return $this->addressblockAddr2;
    }

    /**
     * Set addressblockAddr3
     *
     * @param string $addressblockAddr3
     *
     * @return QbCheck
     */
    public function setAddressblockAddr3($addressblockAddr3)
    {
        $this->addressblockAddr3 = $addressblockAddr3;

        return $this;
    }

    /**
     * Get addressblockAddr3
     *
     * @return string
     */
    public function getAddressblockAddr3()
    {
        return $this->addressblockAddr3;
    }

    /**
     * Set addressblockAddr4
     *
     * @param string $addressblockAddr4
     *
     * @return QbCheck
     */
    public function setAddressblockAddr4($addressblockAddr4)
    {
        $this->addressblockAddr4 = $addressblockAddr4;

        return $this;
    }

    /**
     * Get addressblockAddr4
     *
     * @return string
     */
    public function getAddressblockAddr4()
    {
        return $this->addressblockAddr4;
    }

    /**
     * Set addressblockAddr5
     *
     * @param string $addressblockAddr5
     *
     * @return QbCheck
     */
    public function setAddressblockAddr5($addressblockAddr5)
    {
        $this->addressblockAddr5 = $addressblockAddr5;

        return $this;
    }

    /**
     * Get addressblockAddr5
     *
     * @return string
     */
    public function getAddressblockAddr5()
    {
        return $this->addressblockAddr5;
    }

    /**
     * Set istobeprinted
     *
     * @param boolean $istobeprinted
     *
     * @return QbCheck
     */
    public function setIstobeprinted($istobeprinted)
    {
        $this->istobeprinted = $istobeprinted;

        return $this;
    }

    /**
     * Get istobeprinted
     *
     * @return boolean
     */
    public function getIstobeprinted()
    {
        return $this->istobeprinted;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbCheck
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbCheck
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbCheck
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbCheck
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbCheck
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbCheck
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbCheck
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbCheck
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbCheck
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbCheck
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbCheck
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbCheck
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbCheck
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbCheck
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbCheck
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbCheck
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbCheck
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbCheck
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

