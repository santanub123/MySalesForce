<?php

namespace QbmBundle\Entity;

/**
 * QuickbooksLog
 */
class QuickbooksLog
{
    /**
     * @var integer
     */
    private $quickbooksLogId;

    /**
     * @var integer
     */
    private $quickbooksTicketId;

    /**
     * @var integer
     */
    private $batch;

    /**
     * @var string
     */
    private $msg;

    /**
     * @var \DateTime
     */
    private $logDatetime;


    /**
     * Get quickbooksLogId
     *
     * @return integer
     */
    public function getQuickbooksLogId()
    {
        return $this->quickbooksLogId;
    }

    /**
     * Set quickbooksTicketId
     *
     * @param integer $quickbooksTicketId
     *
     * @return QuickbooksLog
     */
    public function setQuickbooksTicketId($quickbooksTicketId)
    {
        $this->quickbooksTicketId = $quickbooksTicketId;

        return $this;
    }

    /**
     * Get quickbooksTicketId
     *
     * @return integer
     */
    public function getQuickbooksTicketId()
    {
        return $this->quickbooksTicketId;
    }

    /**
     * Set batch
     *
     * @param integer $batch
     *
     * @return QuickbooksLog
     */
    public function setBatch($batch)
    {
        $this->batch = $batch;

        return $this;
    }

    /**
     * Get batch
     *
     * @return integer
     */
    public function getBatch()
    {
        return $this->batch;
    }

    /**
     * Set msg
     *
     * @param string $msg
     *
     * @return QuickbooksLog
     */
    public function setMsg($msg)
    {
        $this->msg = $msg;

        return $this;
    }

    /**
     * Get msg
     *
     * @return string
     */
    public function getMsg()
    {
        return $this->msg;
    }

    /**
     * Set logDatetime
     *
     * @param \DateTime $logDatetime
     *
     * @return QuickbooksLog
     */
    public function setLogDatetime($logDatetime)
    {
        $this->logDatetime = $logDatetime;

        return $this;
    }

    /**
     * Get logDatetime
     *
     * @return \DateTime
     */
    public function getLogDatetime()
    {
        return $this->logDatetime;
    }
}

