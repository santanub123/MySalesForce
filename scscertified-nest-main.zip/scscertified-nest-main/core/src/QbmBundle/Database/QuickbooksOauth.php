<?php

namespace QbmBundle\Entity;

/**
 * QuickbooksOauth
 */
class QuickbooksOauth
{
    /**
     * @var integer
     */
    private $quickbooksOauthId;

    /**
     * @var string
     */
    private $appUsername;

    /**
     * @var string
     */
    private $appTenant;

    /**
     * @var string
     */
    private $oauthRequestToken;

    /**
     * @var string
     */
    private $oauthRequestTokenSecret;

    /**
     * @var string
     */
    private $oauthAccessToken;

    /**
     * @var string
     */
    private $oauthAccessTokenSecret;

    /**
     * @var string
     */
    private $qbRealm;

    /**
     * @var string
     */
    private $qbFlavor;

    /**
     * @var string
     */
    private $qbUser;

    /**
     * @var \DateTime
     */
    private $requestDatetime;

    /**
     * @var \DateTime
     */
    private $accessDatetime;

    /**
     * @var \DateTime
     */
    private $touchDatetime;


    /**
     * Get quickbooksOauthId
     *
     * @return integer
     */
    public function getQuickbooksOauthId()
    {
        return $this->quickbooksOauthId;
    }

    /**
     * Set appUsername
     *
     * @param string $appUsername
     *
     * @return QuickbooksOauth
     */
    public function setAppUsername($appUsername)
    {
        $this->appUsername = $appUsername;

        return $this;
    }

    /**
     * Get appUsername
     *
     * @return string
     */
    public function getAppUsername()
    {
        return $this->appUsername;
    }

    /**
     * Set appTenant
     *
     * @param string $appTenant
     *
     * @return QuickbooksOauth
     */
    public function setAppTenant($appTenant)
    {
        $this->appTenant = $appTenant;

        return $this;
    }

    /**
     * Get appTenant
     *
     * @return string
     */
    public function getAppTenant()
    {
        return $this->appTenant;
    }

    /**
     * Set oauthRequestToken
     *
     * @param string $oauthRequestToken
     *
     * @return QuickbooksOauth
     */
    public function setOauthRequestToken($oauthRequestToken)
    {
        $this->oauthRequestToken = $oauthRequestToken;

        return $this;
    }

    /**
     * Get oauthRequestToken
     *
     * @return string
     */
    public function getOauthRequestToken()
    {
        return $this->oauthRequestToken;
    }

    /**
     * Set oauthRequestTokenSecret
     *
     * @param string $oauthRequestTokenSecret
     *
     * @return QuickbooksOauth
     */
    public function setOauthRequestTokenSecret($oauthRequestTokenSecret)
    {
        $this->oauthRequestTokenSecret = $oauthRequestTokenSecret;

        return $this;
    }

    /**
     * Get oauthRequestTokenSecret
     *
     * @return string
     */
    public function getOauthRequestTokenSecret()
    {
        return $this->oauthRequestTokenSecret;
    }

    /**
     * Set oauthAccessToken
     *
     * @param string $oauthAccessToken
     *
     * @return QuickbooksOauth
     */
    public function setOauthAccessToken($oauthAccessToken)
    {
        $this->oauthAccessToken = $oauthAccessToken;

        return $this;
    }

    /**
     * Get oauthAccessToken
     *
     * @return string
     */
    public function getOauthAccessToken()
    {
        return $this->oauthAccessToken;
    }

    /**
     * Set oauthAccessTokenSecret
     *
     * @param string $oauthAccessTokenSecret
     *
     * @return QuickbooksOauth
     */
    public function setOauthAccessTokenSecret($oauthAccessTokenSecret)
    {
        $this->oauthAccessTokenSecret = $oauthAccessTokenSecret;

        return $this;
    }

    /**
     * Get oauthAccessTokenSecret
     *
     * @return string
     */
    public function getOauthAccessTokenSecret()
    {
        return $this->oauthAccessTokenSecret;
    }

    /**
     * Set qbRealm
     *
     * @param string $qbRealm
     *
     * @return QuickbooksOauth
     */
    public function setQbRealm($qbRealm)
    {
        $this->qbRealm = $qbRealm;

        return $this;
    }

    /**
     * Get qbRealm
     *
     * @return string
     */
    public function getQbRealm()
    {
        return $this->qbRealm;
    }

    /**
     * Set qbFlavor
     *
     * @param string $qbFlavor
     *
     * @return QuickbooksOauth
     */
    public function setQbFlavor($qbFlavor)
    {
        $this->qbFlavor = $qbFlavor;

        return $this;
    }

    /**
     * Get qbFlavor
     *
     * @return string
     */
    public function getQbFlavor()
    {
        return $this->qbFlavor;
    }

    /**
     * Set qbUser
     *
     * @param string $qbUser
     *
     * @return QuickbooksOauth
     */
    public function setQbUser($qbUser)
    {
        $this->qbUser = $qbUser;

        return $this;
    }

    /**
     * Get qbUser
     *
     * @return string
     */
    public function getQbUser()
    {
        return $this->qbUser;
    }

    /**
     * Set requestDatetime
     *
     * @param \DateTime $requestDatetime
     *
     * @return QuickbooksOauth
     */
    public function setRequestDatetime($requestDatetime)
    {
        $this->requestDatetime = $requestDatetime;

        return $this;
    }

    /**
     * Get requestDatetime
     *
     * @return \DateTime
     */
    public function getRequestDatetime()
    {
        return $this->requestDatetime;
    }

    /**
     * Set accessDatetime
     *
     * @param \DateTime $accessDatetime
     *
     * @return QuickbooksOauth
     */
    public function setAccessDatetime($accessDatetime)
    {
        $this->accessDatetime = $accessDatetime;

        return $this;
    }

    /**
     * Get accessDatetime
     *
     * @return \DateTime
     */
    public function getAccessDatetime()
    {
        return $this->accessDatetime;
    }

    /**
     * Set touchDatetime
     *
     * @param \DateTime $touchDatetime
     *
     * @return QuickbooksOauth
     */
    public function setTouchDatetime($touchDatetime)
    {
        $this->touchDatetime = $touchDatetime;

        return $this;
    }

    /**
     * Get touchDatetime
     *
     * @return \DateTime
     */
    public function getTouchDatetime()
    {
        return $this->touchDatetime;
    }
}

