<?php

namespace QbmBundle\Entity;

/**
 * QbBillpaymentcheck
 */
class QbBillpaymentcheck
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $exchangerate;

    /**
     * @var string
     */
    private $amountinhomecurrency;

    /**
     * @var string
     */
    private $txnid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var integer
     */
    private $txnnumber = '0';

    /**
     * @var string
     */
    private $payeeentityListid;

    /**
     * @var string
     */
    private $payeeentityFullname;

    /**
     * @var string
     */
    private $apaccountListid;

    /**
     * @var string
     */
    private $apaccountFullname;

    /**
     * @var \DateTime
     */
    private $txndate;

    /**
     * @var string
     */
    private $bankaccountListid;

    /**
     * @var string
     */
    private $bankaccountFullname;

    /**
     * @var string
     */
    private $amount;

    /**
     * @var string
     */
    private $refnumber;

    /**
     * @var string
     */
    private $memo;

    /**
     * @var string
     */
    private $addressAddr1;

    /**
     * @var string
     */
    private $addressAddr2;

    /**
     * @var string
     */
    private $addressAddr3;

    /**
     * @var string
     */
    private $addressAddr4;

    /**
     * @var string
     */
    private $addressNote;

    /**
     * @var string
     */
    private $addressCity;

    /**
     * @var string
     */
    private $addressState;

    /**
     * @var string
     */
    private $addressPostalcode;

    /**
     * @var string
     */
    private $addressCountry;

    /**
     * @var string
     */
    private $addressblockAddr1;

    /**
     * @var string
     */
    private $addressblockAddr2;

    /**
     * @var string
     */
    private $addressblockAddr3;

    /**
     * @var string
     */
    private $addressblockAddr4;

    /**
     * @var string
     */
    private $addressblockAddr5;

    /**
     * @var boolean
     */
    private $istobeprinted;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set exchangerate
     *
     * @param string $exchangerate
     *
     * @return QbBillpaymentcheck
     */
    public function setExchangerate($exchangerate)
    {
        $this->exchangerate = $exchangerate;

        return $this;
    }

    /**
     * Get exchangerate
     *
     * @return string
     */
    public function getExchangerate()
    {
        return $this->exchangerate;
    }

    /**
     * Set amountinhomecurrency
     *
     * @param string $amountinhomecurrency
     *
     * @return QbBillpaymentcheck
     */
    public function setAmountinhomecurrency($amountinhomecurrency)
    {
        $this->amountinhomecurrency = $amountinhomecurrency;

        return $this;
    }

    /**
     * Get amountinhomecurrency
     *
     * @return string
     */
    public function getAmountinhomecurrency()
    {
        return $this->amountinhomecurrency;
    }

    /**
     * Set txnid
     *
     * @param string $txnid
     *
     * @return QbBillpaymentcheck
     */
    public function setTxnid($txnid)
    {
        $this->txnid = $txnid;

        return $this;
    }

    /**
     * Get txnid
     *
     * @return string
     */
    public function getTxnid()
    {
        return $this->txnid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbBillpaymentcheck
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbBillpaymentcheck
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbBillpaymentcheck
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set txnnumber
     *
     * @param integer $txnnumber
     *
     * @return QbBillpaymentcheck
     */
    public function setTxnnumber($txnnumber)
    {
        $this->txnnumber = $txnnumber;

        return $this;
    }

    /**
     * Get txnnumber
     *
     * @return integer
     */
    public function getTxnnumber()
    {
        return $this->txnnumber;
    }

    /**
     * Set payeeentityListid
     *
     * @param string $payeeentityListid
     *
     * @return QbBillpaymentcheck
     */
    public function setPayeeentityListid($payeeentityListid)
    {
        $this->payeeentityListid = $payeeentityListid;

        return $this;
    }

    /**
     * Get payeeentityListid
     *
     * @return string
     */
    public function getPayeeentityListid()
    {
        return $this->payeeentityListid;
    }

    /**
     * Set payeeentityFullname
     *
     * @param string $payeeentityFullname
     *
     * @return QbBillpaymentcheck
     */
    public function setPayeeentityFullname($payeeentityFullname)
    {
        $this->payeeentityFullname = $payeeentityFullname;

        return $this;
    }

    /**
     * Get payeeentityFullname
     *
     * @return string
     */
    public function getPayeeentityFullname()
    {
        return $this->payeeentityFullname;
    }

    /**
     * Set apaccountListid
     *
     * @param string $apaccountListid
     *
     * @return QbBillpaymentcheck
     */
    public function setApaccountListid($apaccountListid)
    {
        $this->apaccountListid = $apaccountListid;

        return $this;
    }

    /**
     * Get apaccountListid
     *
     * @return string
     */
    public function getApaccountListid()
    {
        return $this->apaccountListid;
    }

    /**
     * Set apaccountFullname
     *
     * @param string $apaccountFullname
     *
     * @return QbBillpaymentcheck
     */
    public function setApaccountFullname($apaccountFullname)
    {
        $this->apaccountFullname = $apaccountFullname;

        return $this;
    }

    /**
     * Get apaccountFullname
     *
     * @return string
     */
    public function getApaccountFullname()
    {
        return $this->apaccountFullname;
    }

    /**
     * Set txndate
     *
     * @param \DateTime $txndate
     *
     * @return QbBillpaymentcheck
     */
    public function setTxndate($txndate)
    {
        $this->txndate = $txndate;

        return $this;
    }

    /**
     * Get txndate
     *
     * @return \DateTime
     */
    public function getTxndate()
    {
        return $this->txndate;
    }

    /**
     * Set bankaccountListid
     *
     * @param string $bankaccountListid
     *
     * @return QbBillpaymentcheck
     */
    public function setBankaccountListid($bankaccountListid)
    {
        $this->bankaccountListid = $bankaccountListid;

        return $this;
    }

    /**
     * Get bankaccountListid
     *
     * @return string
     */
    public function getBankaccountListid()
    {
        return $this->bankaccountListid;
    }

    /**
     * Set bankaccountFullname
     *
     * @param string $bankaccountFullname
     *
     * @return QbBillpaymentcheck
     */
    public function setBankaccountFullname($bankaccountFullname)
    {
        $this->bankaccountFullname = $bankaccountFullname;

        return $this;
    }

    /**
     * Get bankaccountFullname
     *
     * @return string
     */
    public function getBankaccountFullname()
    {
        return $this->bankaccountFullname;
    }

    /**
     * Set amount
     *
     * @param string $amount
     *
     * @return QbBillpaymentcheck
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return string
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set refnumber
     *
     * @param string $refnumber
     *
     * @return QbBillpaymentcheck
     */
    public function setRefnumber($refnumber)
    {
        $this->refnumber = $refnumber;

        return $this;
    }

    /**
     * Get refnumber
     *
     * @return string
     */
    public function getRefnumber()
    {
        return $this->refnumber;
    }

    /**
     * Set memo
     *
     * @param string $memo
     *
     * @return QbBillpaymentcheck
     */
    public function setMemo($memo)
    {
        $this->memo = $memo;

        return $this;
    }

    /**
     * Get memo
     *
     * @return string
     */
    public function getMemo()
    {
        return $this->memo;
    }

    /**
     * Set addressAddr1
     *
     * @param string $addressAddr1
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressAddr1($addressAddr1)
    {
        $this->addressAddr1 = $addressAddr1;

        return $this;
    }

    /**
     * Get addressAddr1
     *
     * @return string
     */
    public function getAddressAddr1()
    {
        return $this->addressAddr1;
    }

    /**
     * Set addressAddr2
     *
     * @param string $addressAddr2
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressAddr2($addressAddr2)
    {
        $this->addressAddr2 = $addressAddr2;

        return $this;
    }

    /**
     * Get addressAddr2
     *
     * @return string
     */
    public function getAddressAddr2()
    {
        return $this->addressAddr2;
    }

    /**
     * Set addressAddr3
     *
     * @param string $addressAddr3
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressAddr3($addressAddr3)
    {
        $this->addressAddr3 = $addressAddr3;

        return $this;
    }

    /**
     * Get addressAddr3
     *
     * @return string
     */
    public function getAddressAddr3()
    {
        return $this->addressAddr3;
    }

    /**
     * Set addressAddr4
     *
     * @param string $addressAddr4
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressAddr4($addressAddr4)
    {
        $this->addressAddr4 = $addressAddr4;

        return $this;
    }

    /**
     * Get addressAddr4
     *
     * @return string
     */
    public function getAddressAddr4()
    {
        return $this->addressAddr4;
    }

    /**
     * Set addressNote
     *
     * @param string $addressNote
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressNote($addressNote)
    {
        $this->addressNote = $addressNote;

        return $this;
    }

    /**
     * Get addressNote
     *
     * @return string
     */
    public function getAddressNote()
    {
        return $this->addressNote;
    }

    /**
     * Set addressCity
     *
     * @param string $addressCity
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressCity($addressCity)
    {
        $this->addressCity = $addressCity;

        return $this;
    }

    /**
     * Get addressCity
     *
     * @return string
     */
    public function getAddressCity()
    {
        return $this->addressCity;
    }

    /**
     * Set addressState
     *
     * @param string $addressState
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressState($addressState)
    {
        $this->addressState = $addressState;

        return $this;
    }

    /**
     * Get addressState
     *
     * @return string
     */
    public function getAddressState()
    {
        return $this->addressState;
    }

    /**
     * Set addressPostalcode
     *
     * @param string $addressPostalcode
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressPostalcode($addressPostalcode)
    {
        $this->addressPostalcode = $addressPostalcode;

        return $this;
    }

    /**
     * Get addressPostalcode
     *
     * @return string
     */
    public function getAddressPostalcode()
    {
        return $this->addressPostalcode;
    }

    /**
     * Set addressCountry
     *
     * @param string $addressCountry
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressCountry($addressCountry)
    {
        $this->addressCountry = $addressCountry;

        return $this;
    }

    /**
     * Get addressCountry
     *
     * @return string
     */
    public function getAddressCountry()
    {
        return $this->addressCountry;
    }

    /**
     * Set addressblockAddr1
     *
     * @param string $addressblockAddr1
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressblockAddr1($addressblockAddr1)
    {
        $this->addressblockAddr1 = $addressblockAddr1;

        return $this;
    }

    /**
     * Get addressblockAddr1
     *
     * @return string
     */
    public function getAddressblockAddr1()
    {
        return $this->addressblockAddr1;
    }

    /**
     * Set addressblockAddr2
     *
     * @param string $addressblockAddr2
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressblockAddr2($addressblockAddr2)
    {
        $this->addressblockAddr2 = $addressblockAddr2;

        return $this;
    }

    /**
     * Get addressblockAddr2
     *
     * @return string
     */
    public function getAddressblockAddr2()
    {
        return $this->addressblockAddr2;
    }

    /**
     * Set addressblockAddr3
     *
     * @param string $addressblockAddr3
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressblockAddr3($addressblockAddr3)
    {
        $this->addressblockAddr3 = $addressblockAddr3;

        return $this;
    }

    /**
     * Get addressblockAddr3
     *
     * @return string
     */
    public function getAddressblockAddr3()
    {
        return $this->addressblockAddr3;
    }

    /**
     * Set addressblockAddr4
     *
     * @param string $addressblockAddr4
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressblockAddr4($addressblockAddr4)
    {
        $this->addressblockAddr4 = $addressblockAddr4;

        return $this;
    }

    /**
     * Get addressblockAddr4
     *
     * @return string
     */
    public function getAddressblockAddr4()
    {
        return $this->addressblockAddr4;
    }

    /**
     * Set addressblockAddr5
     *
     * @param string $addressblockAddr5
     *
     * @return QbBillpaymentcheck
     */
    public function setAddressblockAddr5($addressblockAddr5)
    {
        $this->addressblockAddr5 = $addressblockAddr5;

        return $this;
    }

    /**
     * Get addressblockAddr5
     *
     * @return string
     */
    public function getAddressblockAddr5()
    {
        return $this->addressblockAddr5;
    }

    /**
     * Set istobeprinted
     *
     * @param boolean $istobeprinted
     *
     * @return QbBillpaymentcheck
     */
    public function setIstobeprinted($istobeprinted)
    {
        $this->istobeprinted = $istobeprinted;

        return $this;
    }

    /**
     * Get istobeprinted
     *
     * @return boolean
     */
    public function getIstobeprinted()
    {
        return $this->istobeprinted;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbBillpaymentcheck
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

