<?php

namespace QbmBundle\Entity;

/**
 * QbIteminventory
 */
class QbIteminventory
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $listid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $fullname;

    /**
     * @var boolean
     */
    private $isactive = '0';

    /**
     * @var string
     */
    private $parentListid;

    /**
     * @var string
     */
    private $parentFullname;

    /**
     * @var integer
     */
    private $sublevel = '0';

    /**
     * @var string
     */
    private $manufacturerpartnumber;

    /**
     * @var string
     */
    private $unitofmeasuresetListid;

    /**
     * @var string
     */
    private $unitofmeasuresetFullname;

    /**
     * @var string
     */
    private $salestaxcodeListid;

    /**
     * @var string
     */
    private $salestaxcodeFullname;

    /**
     * @var string
     */
    private $salesdesc;

    /**
     * @var string
     */
    private $salesprice;

    /**
     * @var string
     */
    private $incomeaccountListid;

    /**
     * @var string
     */
    private $incomeaccountFullname;

    /**
     * @var string
     */
    private $purchasedesc;

    /**
     * @var string
     */
    private $purchasecost;

    /**
     * @var string
     */
    private $cogsaccountListid;

    /**
     * @var string
     */
    private $cogsaccountFullname;

    /**
     * @var string
     */
    private $prefvendorListid;

    /**
     * @var string
     */
    private $prefvendorFullname;

    /**
     * @var string
     */
    private $assetaccountListid;

    /**
     * @var string
     */
    private $assetaccountFullname;

    /**
     * @var string
     */
    private $reorderpoint = '0.00000';

    /**
     * @var string
     */
    private $quantityonhand = '0.00000';

    /**
     * @var string
     */
    private $averagecost;

    /**
     * @var string
     */
    private $quantityonorder = '0.00000';

    /**
     * @var string
     */
    private $quantityonsalesorder = '0.00000';

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbIteminventory
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbIteminventory
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set listid
     *
     * @param string $listid
     *
     * @return QbIteminventory
     */
    public function setListid($listid)
    {
        $this->listid = $listid;

        return $this;
    }

    /**
     * Get listid
     *
     * @return string
     */
    public function getListid()
    {
        return $this->listid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbIteminventory
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbIteminventory
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbIteminventory
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return QbIteminventory
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set fullname
     *
     * @param string $fullname
     *
     * @return QbIteminventory
     */
    public function setFullname($fullname)
    {
        $this->fullname = $fullname;

        return $this;
    }

    /**
     * Get fullname
     *
     * @return string
     */
    public function getFullname()
    {
        return $this->fullname;
    }

    /**
     * Set isactive
     *
     * @param boolean $isactive
     *
     * @return QbIteminventory
     */
    public function setIsactive($isactive)
    {
        $this->isactive = $isactive;

        return $this;
    }

    /**
     * Get isactive
     *
     * @return boolean
     */
    public function getIsactive()
    {
        return $this->isactive;
    }

    /**
     * Set parentListid
     *
     * @param string $parentListid
     *
     * @return QbIteminventory
     */
    public function setParentListid($parentListid)
    {
        $this->parentListid = $parentListid;

        return $this;
    }

    /**
     * Get parentListid
     *
     * @return string
     */
    public function getParentListid()
    {
        return $this->parentListid;
    }

    /**
     * Set parentFullname
     *
     * @param string $parentFullname
     *
     * @return QbIteminventory
     */
    public function setParentFullname($parentFullname)
    {
        $this->parentFullname = $parentFullname;

        return $this;
    }

    /**
     * Get parentFullname
     *
     * @return string
     */
    public function getParentFullname()
    {
        return $this->parentFullname;
    }

    /**
     * Set sublevel
     *
     * @param integer $sublevel
     *
     * @return QbIteminventory
     */
    public function setSublevel($sublevel)
    {
        $this->sublevel = $sublevel;

        return $this;
    }

    /**
     * Get sublevel
     *
     * @return integer
     */
    public function getSublevel()
    {
        return $this->sublevel;
    }

    /**
     * Set manufacturerpartnumber
     *
     * @param string $manufacturerpartnumber
     *
     * @return QbIteminventory
     */
    public function setManufacturerpartnumber($manufacturerpartnumber)
    {
        $this->manufacturerpartnumber = $manufacturerpartnumber;

        return $this;
    }

    /**
     * Get manufacturerpartnumber
     *
     * @return string
     */
    public function getManufacturerpartnumber()
    {
        return $this->manufacturerpartnumber;
    }

    /**
     * Set unitofmeasuresetListid
     *
     * @param string $unitofmeasuresetListid
     *
     * @return QbIteminventory
     */
    public function setUnitofmeasuresetListid($unitofmeasuresetListid)
    {
        $this->unitofmeasuresetListid = $unitofmeasuresetListid;

        return $this;
    }

    /**
     * Get unitofmeasuresetListid
     *
     * @return string
     */
    public function getUnitofmeasuresetListid()
    {
        return $this->unitofmeasuresetListid;
    }

    /**
     * Set unitofmeasuresetFullname
     *
     * @param string $unitofmeasuresetFullname
     *
     * @return QbIteminventory
     */
    public function setUnitofmeasuresetFullname($unitofmeasuresetFullname)
    {
        $this->unitofmeasuresetFullname = $unitofmeasuresetFullname;

        return $this;
    }

    /**
     * Get unitofmeasuresetFullname
     *
     * @return string
     */
    public function getUnitofmeasuresetFullname()
    {
        return $this->unitofmeasuresetFullname;
    }

    /**
     * Set salestaxcodeListid
     *
     * @param string $salestaxcodeListid
     *
     * @return QbIteminventory
     */
    public function setSalestaxcodeListid($salestaxcodeListid)
    {
        $this->salestaxcodeListid = $salestaxcodeListid;

        return $this;
    }

    /**
     * Get salestaxcodeListid
     *
     * @return string
     */
    public function getSalestaxcodeListid()
    {
        return $this->salestaxcodeListid;
    }

    /**
     * Set salestaxcodeFullname
     *
     * @param string $salestaxcodeFullname
     *
     * @return QbIteminventory
     */
    public function setSalestaxcodeFullname($salestaxcodeFullname)
    {
        $this->salestaxcodeFullname = $salestaxcodeFullname;

        return $this;
    }

    /**
     * Get salestaxcodeFullname
     *
     * @return string
     */
    public function getSalestaxcodeFullname()
    {
        return $this->salestaxcodeFullname;
    }

    /**
     * Set salesdesc
     *
     * @param string $salesdesc
     *
     * @return QbIteminventory
     */
    public function setSalesdesc($salesdesc)
    {
        $this->salesdesc = $salesdesc;

        return $this;
    }

    /**
     * Get salesdesc
     *
     * @return string
     */
    public function getSalesdesc()
    {
        return $this->salesdesc;
    }

    /**
     * Set salesprice
     *
     * @param string $salesprice
     *
     * @return QbIteminventory
     */
    public function setSalesprice($salesprice)
    {
        $this->salesprice = $salesprice;

        return $this;
    }

    /**
     * Get salesprice
     *
     * @return string
     */
    public function getSalesprice()
    {
        return $this->salesprice;
    }

    /**
     * Set incomeaccountListid
     *
     * @param string $incomeaccountListid
     *
     * @return QbIteminventory
     */
    public function setIncomeaccountListid($incomeaccountListid)
    {
        $this->incomeaccountListid = $incomeaccountListid;

        return $this;
    }

    /**
     * Get incomeaccountListid
     *
     * @return string
     */
    public function getIncomeaccountListid()
    {
        return $this->incomeaccountListid;
    }

    /**
     * Set incomeaccountFullname
     *
     * @param string $incomeaccountFullname
     *
     * @return QbIteminventory
     */
    public function setIncomeaccountFullname($incomeaccountFullname)
    {
        $this->incomeaccountFullname = $incomeaccountFullname;

        return $this;
    }

    /**
     * Get incomeaccountFullname
     *
     * @return string
     */
    public function getIncomeaccountFullname()
    {
        return $this->incomeaccountFullname;
    }

    /**
     * Set purchasedesc
     *
     * @param string $purchasedesc
     *
     * @return QbIteminventory
     */
    public function setPurchasedesc($purchasedesc)
    {
        $this->purchasedesc = $purchasedesc;

        return $this;
    }

    /**
     * Get purchasedesc
     *
     * @return string
     */
    public function getPurchasedesc()
    {
        return $this->purchasedesc;
    }

    /**
     * Set purchasecost
     *
     * @param string $purchasecost
     *
     * @return QbIteminventory
     */
    public function setPurchasecost($purchasecost)
    {
        $this->purchasecost = $purchasecost;

        return $this;
    }

    /**
     * Get purchasecost
     *
     * @return string
     */
    public function getPurchasecost()
    {
        return $this->purchasecost;
    }

    /**
     * Set cogsaccountListid
     *
     * @param string $cogsaccountListid
     *
     * @return QbIteminventory
     */
    public function setCogsaccountListid($cogsaccountListid)
    {
        $this->cogsaccountListid = $cogsaccountListid;

        return $this;
    }

    /**
     * Get cogsaccountListid
     *
     * @return string
     */
    public function getCogsaccountListid()
    {
        return $this->cogsaccountListid;
    }

    /**
     * Set cogsaccountFullname
     *
     * @param string $cogsaccountFullname
     *
     * @return QbIteminventory
     */
    public function setCogsaccountFullname($cogsaccountFullname)
    {
        $this->cogsaccountFullname = $cogsaccountFullname;

        return $this;
    }

    /**
     * Get cogsaccountFullname
     *
     * @return string
     */
    public function getCogsaccountFullname()
    {
        return $this->cogsaccountFullname;
    }

    /**
     * Set prefvendorListid
     *
     * @param string $prefvendorListid
     *
     * @return QbIteminventory
     */
    public function setPrefvendorListid($prefvendorListid)
    {
        $this->prefvendorListid = $prefvendorListid;

        return $this;
    }

    /**
     * Get prefvendorListid
     *
     * @return string
     */
    public function getPrefvendorListid()
    {
        return $this->prefvendorListid;
    }

    /**
     * Set prefvendorFullname
     *
     * @param string $prefvendorFullname
     *
     * @return QbIteminventory
     */
    public function setPrefvendorFullname($prefvendorFullname)
    {
        $this->prefvendorFullname = $prefvendorFullname;

        return $this;
    }

    /**
     * Get prefvendorFullname
     *
     * @return string
     */
    public function getPrefvendorFullname()
    {
        return $this->prefvendorFullname;
    }

    /**
     * Set assetaccountListid
     *
     * @param string $assetaccountListid
     *
     * @return QbIteminventory
     */
    public function setAssetaccountListid($assetaccountListid)
    {
        $this->assetaccountListid = $assetaccountListid;

        return $this;
    }

    /**
     * Get assetaccountListid
     *
     * @return string
     */
    public function getAssetaccountListid()
    {
        return $this->assetaccountListid;
    }

    /**
     * Set assetaccountFullname
     *
     * @param string $assetaccountFullname
     *
     * @return QbIteminventory
     */
    public function setAssetaccountFullname($assetaccountFullname)
    {
        $this->assetaccountFullname = $assetaccountFullname;

        return $this;
    }

    /**
     * Get assetaccountFullname
     *
     * @return string
     */
    public function getAssetaccountFullname()
    {
        return $this->assetaccountFullname;
    }

    /**
     * Set reorderpoint
     *
     * @param string $reorderpoint
     *
     * @return QbIteminventory
     */
    public function setReorderpoint($reorderpoint)
    {
        $this->reorderpoint = $reorderpoint;

        return $this;
    }

    /**
     * Get reorderpoint
     *
     * @return string
     */
    public function getReorderpoint()
    {
        return $this->reorderpoint;
    }

    /**
     * Set quantityonhand
     *
     * @param string $quantityonhand
     *
     * @return QbIteminventory
     */
    public function setQuantityonhand($quantityonhand)
    {
        $this->quantityonhand = $quantityonhand;

        return $this;
    }

    /**
     * Get quantityonhand
     *
     * @return string
     */
    public function getQuantityonhand()
    {
        return $this->quantityonhand;
    }

    /**
     * Set averagecost
     *
     * @param string $averagecost
     *
     * @return QbIteminventory
     */
    public function setAveragecost($averagecost)
    {
        $this->averagecost = $averagecost;

        return $this;
    }

    /**
     * Get averagecost
     *
     * @return string
     */
    public function getAveragecost()
    {
        return $this->averagecost;
    }

    /**
     * Set quantityonorder
     *
     * @param string $quantityonorder
     *
     * @return QbIteminventory
     */
    public function setQuantityonorder($quantityonorder)
    {
        $this->quantityonorder = $quantityonorder;

        return $this;
    }

    /**
     * Get quantityonorder
     *
     * @return string
     */
    public function getQuantityonorder()
    {
        return $this->quantityonorder;
    }

    /**
     * Set quantityonsalesorder
     *
     * @param string $quantityonsalesorder
     *
     * @return QbIteminventory
     */
    public function setQuantityonsalesorder($quantityonsalesorder)
    {
        $this->quantityonsalesorder = $quantityonsalesorder;

        return $this;
    }

    /**
     * Get quantityonsalesorder
     *
     * @return string
     */
    public function getQuantityonsalesorder()
    {
        return $this->quantityonsalesorder;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbIteminventory
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbIteminventory
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbIteminventory
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbIteminventory
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbIteminventory
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbIteminventory
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbIteminventory
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbIteminventory
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbIteminventory
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbIteminventory
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbIteminventory
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbIteminventory
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbIteminventory
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbIteminventory
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbIteminventory
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbIteminventory
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbIteminventory
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbIteminventory
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

