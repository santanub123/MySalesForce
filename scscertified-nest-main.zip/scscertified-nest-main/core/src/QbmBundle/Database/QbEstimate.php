<?php

namespace QbmBundle\Entity;

/**
 * QbEstimate
 */
class QbEstimate
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $txnid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var integer
     */
    private $txnnumber = '0';

    /**
     * @var string
     */
    private $customerListid;

    /**
     * @var string
     */
    private $customerFullname;

    /**
     * @var string
     */
    private $classListid;

    /**
     * @var string
     */
    private $classFullname;

    /**
     * @var string
     */
    private $templateListid;

    /**
     * @var string
     */
    private $templateFullname;

    /**
     * @var \DateTime
     */
    private $txndate;

    /**
     * @var string
     */
    private $refnumber;

    /**
     * @var string
     */
    private $billaddressAddr1;

    /**
     * @var string
     */
    private $billaddressAddr2;

    /**
     * @var string
     */
    private $billaddressAddr3;

    /**
     * @var string
     */
    private $billaddressAddr4;

    /**
     * @var string
     */
    private $billaddressAddr5;

    /**
     * @var string
     */
    private $billaddressCity;

    /**
     * @var string
     */
    private $billaddressState;

    /**
     * @var string
     */
    private $billaddressPostalcode;

    /**
     * @var string
     */
    private $billaddressCountry;

    /**
     * @var string
     */
    private $billaddressNote;

    /**
     * @var string
     */
    private $billaddressblockAddr1;

    /**
     * @var string
     */
    private $billaddressblockAddr2;

    /**
     * @var string
     */
    private $billaddressblockAddr3;

    /**
     * @var string
     */
    private $billaddressblockAddr4;

    /**
     * @var string
     */
    private $billaddressblockAddr5;

    /**
     * @var string
     */
    private $shipaddressAddr1;

    /**
     * @var string
     */
    private $shipaddressAddr2;

    /**
     * @var string
     */
    private $shipaddressAddr3;

    /**
     * @var string
     */
    private $shipaddressAddr4;

    /**
     * @var string
     */
    private $shipaddressAddr5;

    /**
     * @var string
     */
    private $shipaddressCity;

    /**
     * @var string
     */
    private $shipaddressState;

    /**
     * @var string
     */
    private $shipaddressPostalcode;

    /**
     * @var string
     */
    private $shipaddressCountry;

    /**
     * @var string
     */
    private $shipaddressNote;

    /**
     * @var string
     */
    private $shipaddressblockAddr1;

    /**
     * @var string
     */
    private $shipaddressblockAddr2;

    /**
     * @var string
     */
    private $shipaddressblockAddr3;

    /**
     * @var string
     */
    private $shipaddressblockAddr4;

    /**
     * @var string
     */
    private $shipaddressblockAddr5;

    /**
     * @var boolean
     */
    private $isactive = '0';

    /**
     * @var string
     */
    private $ponumber;

    /**
     * @var string
     */
    private $termsListid;

    /**
     * @var string
     */
    private $termsFullname;

    /**
     * @var \DateTime
     */
    private $duedate;

    /**
     * @var string
     */
    private $salesrepListid;

    /**
     * @var string
     */
    private $salesrepFullname;

    /**
     * @var string
     */
    private $fob;

    /**
     * @var string
     */
    private $subtotal;

    /**
     * @var string
     */
    private $itemsalestaxListid;

    /**
     * @var string
     */
    private $itemsalestaxFullname;

    /**
     * @var string
     */
    private $salestaxpercentage;

    /**
     * @var string
     */
    private $salestaxtotal;

    /**
     * @var string
     */
    private $totalamount;

    /**
     * @var string
     */
    private $currencyListid;

    /**
     * @var string
     */
    private $currencyFullname;

    /**
     * @var string
     */
    private $exchangerate;

    /**
     * @var string
     */
    private $totalamountinhomecurrency;

    /**
     * @var string
     */
    private $memo;

    /**
     * @var string
     */
    private $customermsgListid;

    /**
     * @var string
     */
    private $customermsgFullname;

    /**
     * @var boolean
     */
    private $istobeemailed;

    /**
     * @var string
     */
    private $customersalestaxcodeListid;

    /**
     * @var string
     */
    private $customersalestaxcodeFullname;

    /**
     * @var string
     */
    private $other;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbEstimate
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbEstimate
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set txnid
     *
     * @param string $txnid
     *
     * @return QbEstimate
     */
    public function setTxnid($txnid)
    {
        $this->txnid = $txnid;

        return $this;
    }

    /**
     * Get txnid
     *
     * @return string
     */
    public function getTxnid()
    {
        return $this->txnid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbEstimate
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbEstimate
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbEstimate
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set txnnumber
     *
     * @param integer $txnnumber
     *
     * @return QbEstimate
     */
    public function setTxnnumber($txnnumber)
    {
        $this->txnnumber = $txnnumber;

        return $this;
    }

    /**
     * Get txnnumber
     *
     * @return integer
     */
    public function getTxnnumber()
    {
        return $this->txnnumber;
    }

    /**
     * Set customerListid
     *
     * @param string $customerListid
     *
     * @return QbEstimate
     */
    public function setCustomerListid($customerListid)
    {
        $this->customerListid = $customerListid;

        return $this;
    }

    /**
     * Get customerListid
     *
     * @return string
     */
    public function getCustomerListid()
    {
        return $this->customerListid;
    }

    /**
     * Set customerFullname
     *
     * @param string $customerFullname
     *
     * @return QbEstimate
     */
    public function setCustomerFullname($customerFullname)
    {
        $this->customerFullname = $customerFullname;

        return $this;
    }

    /**
     * Get customerFullname
     *
     * @return string
     */
    public function getCustomerFullname()
    {
        return $this->customerFullname;
    }

    /**
     * Set classListid
     *
     * @param string $classListid
     *
     * @return QbEstimate
     */
    public function setClassListid($classListid)
    {
        $this->classListid = $classListid;

        return $this;
    }

    /**
     * Get classListid
     *
     * @return string
     */
    public function getClassListid()
    {
        return $this->classListid;
    }

    /**
     * Set classFullname
     *
     * @param string $classFullname
     *
     * @return QbEstimate
     */
    public function setClassFullname($classFullname)
    {
        $this->classFullname = $classFullname;

        return $this;
    }

    /**
     * Get classFullname
     *
     * @return string
     */
    public function getClassFullname()
    {
        return $this->classFullname;
    }

    /**
     * Set templateListid
     *
     * @param string $templateListid
     *
     * @return QbEstimate
     */
    public function setTemplateListid($templateListid)
    {
        $this->templateListid = $templateListid;

        return $this;
    }

    /**
     * Get templateListid
     *
     * @return string
     */
    public function getTemplateListid()
    {
        return $this->templateListid;
    }

    /**
     * Set templateFullname
     *
     * @param string $templateFullname
     *
     * @return QbEstimate
     */
    public function setTemplateFullname($templateFullname)
    {
        $this->templateFullname = $templateFullname;

        return $this;
    }

    /**
     * Get templateFullname
     *
     * @return string
     */
    public function getTemplateFullname()
    {
        return $this->templateFullname;
    }

    /**
     * Set txndate
     *
     * @param \DateTime $txndate
     *
     * @return QbEstimate
     */
    public function setTxndate($txndate)
    {
        $this->txndate = $txndate;

        return $this;
    }

    /**
     * Get txndate
     *
     * @return \DateTime
     */
    public function getTxndate()
    {
        return $this->txndate;
    }

    /**
     * Set refnumber
     *
     * @param string $refnumber
     *
     * @return QbEstimate
     */
    public function setRefnumber($refnumber)
    {
        $this->refnumber = $refnumber;

        return $this;
    }

    /**
     * Get refnumber
     *
     * @return string
     */
    public function getRefnumber()
    {
        return $this->refnumber;
    }

    /**
     * Set billaddressAddr1
     *
     * @param string $billaddressAddr1
     *
     * @return QbEstimate
     */
    public function setBilladdressAddr1($billaddressAddr1)
    {
        $this->billaddressAddr1 = $billaddressAddr1;

        return $this;
    }

    /**
     * Get billaddressAddr1
     *
     * @return string
     */
    public function getBilladdressAddr1()
    {
        return $this->billaddressAddr1;
    }

    /**
     * Set billaddressAddr2
     *
     * @param string $billaddressAddr2
     *
     * @return QbEstimate
     */
    public function setBilladdressAddr2($billaddressAddr2)
    {
        $this->billaddressAddr2 = $billaddressAddr2;

        return $this;
    }

    /**
     * Get billaddressAddr2
     *
     * @return string
     */
    public function getBilladdressAddr2()
    {
        return $this->billaddressAddr2;
    }

    /**
     * Set billaddressAddr3
     *
     * @param string $billaddressAddr3
     *
     * @return QbEstimate
     */
    public function setBilladdressAddr3($billaddressAddr3)
    {
        $this->billaddressAddr3 = $billaddressAddr3;

        return $this;
    }

    /**
     * Get billaddressAddr3
     *
     * @return string
     */
    public function getBilladdressAddr3()
    {
        return $this->billaddressAddr3;
    }

    /**
     * Set billaddressAddr4
     *
     * @param string $billaddressAddr4
     *
     * @return QbEstimate
     */
    public function setBilladdressAddr4($billaddressAddr4)
    {
        $this->billaddressAddr4 = $billaddressAddr4;

        return $this;
    }

    /**
     * Get billaddressAddr4
     *
     * @return string
     */
    public function getBilladdressAddr4()
    {
        return $this->billaddressAddr4;
    }

    /**
     * Set billaddressAddr5
     *
     * @param string $billaddressAddr5
     *
     * @return QbEstimate
     */
    public function setBilladdressAddr5($billaddressAddr5)
    {
        $this->billaddressAddr5 = $billaddressAddr5;

        return $this;
    }

    /**
     * Get billaddressAddr5
     *
     * @return string
     */
    public function getBilladdressAddr5()
    {
        return $this->billaddressAddr5;
    }

    /**
     * Set billaddressCity
     *
     * @param string $billaddressCity
     *
     * @return QbEstimate
     */
    public function setBilladdressCity($billaddressCity)
    {
        $this->billaddressCity = $billaddressCity;

        return $this;
    }

    /**
     * Get billaddressCity
     *
     * @return string
     */
    public function getBilladdressCity()
    {
        return $this->billaddressCity;
    }

    /**
     * Set billaddressState
     *
     * @param string $billaddressState
     *
     * @return QbEstimate
     */
    public function setBilladdressState($billaddressState)
    {
        $this->billaddressState = $billaddressState;

        return $this;
    }

    /**
     * Get billaddressState
     *
     * @return string
     */
    public function getBilladdressState()
    {
        return $this->billaddressState;
    }

    /**
     * Set billaddressPostalcode
     *
     * @param string $billaddressPostalcode
     *
     * @return QbEstimate
     */
    public function setBilladdressPostalcode($billaddressPostalcode)
    {
        $this->billaddressPostalcode = $billaddressPostalcode;

        return $this;
    }

    /**
     * Get billaddressPostalcode
     *
     * @return string
     */
    public function getBilladdressPostalcode()
    {
        return $this->billaddressPostalcode;
    }

    /**
     * Set billaddressCountry
     *
     * @param string $billaddressCountry
     *
     * @return QbEstimate
     */
    public function setBilladdressCountry($billaddressCountry)
    {
        $this->billaddressCountry = $billaddressCountry;

        return $this;
    }

    /**
     * Get billaddressCountry
     *
     * @return string
     */
    public function getBilladdressCountry()
    {
        return $this->billaddressCountry;
    }

    /**
     * Set billaddressNote
     *
     * @param string $billaddressNote
     *
     * @return QbEstimate
     */
    public function setBilladdressNote($billaddressNote)
    {
        $this->billaddressNote = $billaddressNote;

        return $this;
    }

    /**
     * Get billaddressNote
     *
     * @return string
     */
    public function getBilladdressNote()
    {
        return $this->billaddressNote;
    }

    /**
     * Set billaddressblockAddr1
     *
     * @param string $billaddressblockAddr1
     *
     * @return QbEstimate
     */
    public function setBilladdressblockAddr1($billaddressblockAddr1)
    {
        $this->billaddressblockAddr1 = $billaddressblockAddr1;

        return $this;
    }

    /**
     * Get billaddressblockAddr1
     *
     * @return string
     */
    public function getBilladdressblockAddr1()
    {
        return $this->billaddressblockAddr1;
    }

    /**
     * Set billaddressblockAddr2
     *
     * @param string $billaddressblockAddr2
     *
     * @return QbEstimate
     */
    public function setBilladdressblockAddr2($billaddressblockAddr2)
    {
        $this->billaddressblockAddr2 = $billaddressblockAddr2;

        return $this;
    }

    /**
     * Get billaddressblockAddr2
     *
     * @return string
     */
    public function getBilladdressblockAddr2()
    {
        return $this->billaddressblockAddr2;
    }

    /**
     * Set billaddressblockAddr3
     *
     * @param string $billaddressblockAddr3
     *
     * @return QbEstimate
     */
    public function setBilladdressblockAddr3($billaddressblockAddr3)
    {
        $this->billaddressblockAddr3 = $billaddressblockAddr3;

        return $this;
    }

    /**
     * Get billaddressblockAddr3
     *
     * @return string
     */
    public function getBilladdressblockAddr3()
    {
        return $this->billaddressblockAddr3;
    }

    /**
     * Set billaddressblockAddr4
     *
     * @param string $billaddressblockAddr4
     *
     * @return QbEstimate
     */
    public function setBilladdressblockAddr4($billaddressblockAddr4)
    {
        $this->billaddressblockAddr4 = $billaddressblockAddr4;

        return $this;
    }

    /**
     * Get billaddressblockAddr4
     *
     * @return string
     */
    public function getBilladdressblockAddr4()
    {
        return $this->billaddressblockAddr4;
    }

    /**
     * Set billaddressblockAddr5
     *
     * @param string $billaddressblockAddr5
     *
     * @return QbEstimate
     */
    public function setBilladdressblockAddr5($billaddressblockAddr5)
    {
        $this->billaddressblockAddr5 = $billaddressblockAddr5;

        return $this;
    }

    /**
     * Get billaddressblockAddr5
     *
     * @return string
     */
    public function getBilladdressblockAddr5()
    {
        return $this->billaddressblockAddr5;
    }

    /**
     * Set shipaddressAddr1
     *
     * @param string $shipaddressAddr1
     *
     * @return QbEstimate
     */
    public function setShipaddressAddr1($shipaddressAddr1)
    {
        $this->shipaddressAddr1 = $shipaddressAddr1;

        return $this;
    }

    /**
     * Get shipaddressAddr1
     *
     * @return string
     */
    public function getShipaddressAddr1()
    {
        return $this->shipaddressAddr1;
    }

    /**
     * Set shipaddressAddr2
     *
     * @param string $shipaddressAddr2
     *
     * @return QbEstimate
     */
    public function setShipaddressAddr2($shipaddressAddr2)
    {
        $this->shipaddressAddr2 = $shipaddressAddr2;

        return $this;
    }

    /**
     * Get shipaddressAddr2
     *
     * @return string
     */
    public function getShipaddressAddr2()
    {
        return $this->shipaddressAddr2;
    }

    /**
     * Set shipaddressAddr3
     *
     * @param string $shipaddressAddr3
     *
     * @return QbEstimate
     */
    public function setShipaddressAddr3($shipaddressAddr3)
    {
        $this->shipaddressAddr3 = $shipaddressAddr3;

        return $this;
    }

    /**
     * Get shipaddressAddr3
     *
     * @return string
     */
    public function getShipaddressAddr3()
    {
        return $this->shipaddressAddr3;
    }

    /**
     * Set shipaddressAddr4
     *
     * @param string $shipaddressAddr4
     *
     * @return QbEstimate
     */
    public function setShipaddressAddr4($shipaddressAddr4)
    {
        $this->shipaddressAddr4 = $shipaddressAddr4;

        return $this;
    }

    /**
     * Get shipaddressAddr4
     *
     * @return string
     */
    public function getShipaddressAddr4()
    {
        return $this->shipaddressAddr4;
    }

    /**
     * Set shipaddressAddr5
     *
     * @param string $shipaddressAddr5
     *
     * @return QbEstimate
     */
    public function setShipaddressAddr5($shipaddressAddr5)
    {
        $this->shipaddressAddr5 = $shipaddressAddr5;

        return $this;
    }

    /**
     * Get shipaddressAddr5
     *
     * @return string
     */
    public function getShipaddressAddr5()
    {
        return $this->shipaddressAddr5;
    }

    /**
     * Set shipaddressCity
     *
     * @param string $shipaddressCity
     *
     * @return QbEstimate
     */
    public function setShipaddressCity($shipaddressCity)
    {
        $this->shipaddressCity = $shipaddressCity;

        return $this;
    }

    /**
     * Get shipaddressCity
     *
     * @return string
     */
    public function getShipaddressCity()
    {
        return $this->shipaddressCity;
    }

    /**
     * Set shipaddressState
     *
     * @param string $shipaddressState
     *
     * @return QbEstimate
     */
    public function setShipaddressState($shipaddressState)
    {
        $this->shipaddressState = $shipaddressState;

        return $this;
    }

    /**
     * Get shipaddressState
     *
     * @return string
     */
    public function getShipaddressState()
    {
        return $this->shipaddressState;
    }

    /**
     * Set shipaddressPostalcode
     *
     * @param string $shipaddressPostalcode
     *
     * @return QbEstimate
     */
    public function setShipaddressPostalcode($shipaddressPostalcode)
    {
        $this->shipaddressPostalcode = $shipaddressPostalcode;

        return $this;
    }

    /**
     * Get shipaddressPostalcode
     *
     * @return string
     */
    public function getShipaddressPostalcode()
    {
        return $this->shipaddressPostalcode;
    }

    /**
     * Set shipaddressCountry
     *
     * @param string $shipaddressCountry
     *
     * @return QbEstimate
     */
    public function setShipaddressCountry($shipaddressCountry)
    {
        $this->shipaddressCountry = $shipaddressCountry;

        return $this;
    }

    /**
     * Get shipaddressCountry
     *
     * @return string
     */
    public function getShipaddressCountry()
    {
        return $this->shipaddressCountry;
    }

    /**
     * Set shipaddressNote
     *
     * @param string $shipaddressNote
     *
     * @return QbEstimate
     */
    public function setShipaddressNote($shipaddressNote)
    {
        $this->shipaddressNote = $shipaddressNote;

        return $this;
    }

    /**
     * Get shipaddressNote
     *
     * @return string
     */
    public function getShipaddressNote()
    {
        return $this->shipaddressNote;
    }

    /**
     * Set shipaddressblockAddr1
     *
     * @param string $shipaddressblockAddr1
     *
     * @return QbEstimate
     */
    public function setShipaddressblockAddr1($shipaddressblockAddr1)
    {
        $this->shipaddressblockAddr1 = $shipaddressblockAddr1;

        return $this;
    }

    /**
     * Get shipaddressblockAddr1
     *
     * @return string
     */
    public function getShipaddressblockAddr1()
    {
        return $this->shipaddressblockAddr1;
    }

    /**
     * Set shipaddressblockAddr2
     *
     * @param string $shipaddressblockAddr2
     *
     * @return QbEstimate
     */
    public function setShipaddressblockAddr2($shipaddressblockAddr2)
    {
        $this->shipaddressblockAddr2 = $shipaddressblockAddr2;

        return $this;
    }

    /**
     * Get shipaddressblockAddr2
     *
     * @return string
     */
    public function getShipaddressblockAddr2()
    {
        return $this->shipaddressblockAddr2;
    }

    /**
     * Set shipaddressblockAddr3
     *
     * @param string $shipaddressblockAddr3
     *
     * @return QbEstimate
     */
    public function setShipaddressblockAddr3($shipaddressblockAddr3)
    {
        $this->shipaddressblockAddr3 = $shipaddressblockAddr3;

        return $this;
    }

    /**
     * Get shipaddressblockAddr3
     *
     * @return string
     */
    public function getShipaddressblockAddr3()
    {
        return $this->shipaddressblockAddr3;
    }

    /**
     * Set shipaddressblockAddr4
     *
     * @param string $shipaddressblockAddr4
     *
     * @return QbEstimate
     */
    public function setShipaddressblockAddr4($shipaddressblockAddr4)
    {
        $this->shipaddressblockAddr4 = $shipaddressblockAddr4;

        return $this;
    }

    /**
     * Get shipaddressblockAddr4
     *
     * @return string
     */
    public function getShipaddressblockAddr4()
    {
        return $this->shipaddressblockAddr4;
    }

    /**
     * Set shipaddressblockAddr5
     *
     * @param string $shipaddressblockAddr5
     *
     * @return QbEstimate
     */
    public function setShipaddressblockAddr5($shipaddressblockAddr5)
    {
        $this->shipaddressblockAddr5 = $shipaddressblockAddr5;

        return $this;
    }

    /**
     * Get shipaddressblockAddr5
     *
     * @return string
     */
    public function getShipaddressblockAddr5()
    {
        return $this->shipaddressblockAddr5;
    }

    /**
     * Set isactive
     *
     * @param boolean $isactive
     *
     * @return QbEstimate
     */
    public function setIsactive($isactive)
    {
        $this->isactive = $isactive;

        return $this;
    }

    /**
     * Get isactive
     *
     * @return boolean
     */
    public function getIsactive()
    {
        return $this->isactive;
    }

    /**
     * Set ponumber
     *
     * @param string $ponumber
     *
     * @return QbEstimate
     */
    public function setPonumber($ponumber)
    {
        $this->ponumber = $ponumber;

        return $this;
    }

    /**
     * Get ponumber
     *
     * @return string
     */
    public function getPonumber()
    {
        return $this->ponumber;
    }

    /**
     * Set termsListid
     *
     * @param string $termsListid
     *
     * @return QbEstimate
     */
    public function setTermsListid($termsListid)
    {
        $this->termsListid = $termsListid;

        return $this;
    }

    /**
     * Get termsListid
     *
     * @return string
     */
    public function getTermsListid()
    {
        return $this->termsListid;
    }

    /**
     * Set termsFullname
     *
     * @param string $termsFullname
     *
     * @return QbEstimate
     */
    public function setTermsFullname($termsFullname)
    {
        $this->termsFullname = $termsFullname;

        return $this;
    }

    /**
     * Get termsFullname
     *
     * @return string
     */
    public function getTermsFullname()
    {
        return $this->termsFullname;
    }

    /**
     * Set duedate
     *
     * @param \DateTime $duedate
     *
     * @return QbEstimate
     */
    public function setDuedate($duedate)
    {
        $this->duedate = $duedate;

        return $this;
    }

    /**
     * Get duedate
     *
     * @return \DateTime
     */
    public function getDuedate()
    {
        return $this->duedate;
    }

    /**
     * Set salesrepListid
     *
     * @param string $salesrepListid
     *
     * @return QbEstimate
     */
    public function setSalesrepListid($salesrepListid)
    {
        $this->salesrepListid = $salesrepListid;

        return $this;
    }

    /**
     * Get salesrepListid
     *
     * @return string
     */
    public function getSalesrepListid()
    {
        return $this->salesrepListid;
    }

    /**
     * Set salesrepFullname
     *
     * @param string $salesrepFullname
     *
     * @return QbEstimate
     */
    public function setSalesrepFullname($salesrepFullname)
    {
        $this->salesrepFullname = $salesrepFullname;

        return $this;
    }

    /**
     * Get salesrepFullname
     *
     * @return string
     */
    public function getSalesrepFullname()
    {
        return $this->salesrepFullname;
    }

    /**
     * Set fob
     *
     * @param string $fob
     *
     * @return QbEstimate
     */
    public function setFob($fob)
    {
        $this->fob = $fob;

        return $this;
    }

    /**
     * Get fob
     *
     * @return string
     */
    public function getFob()
    {
        return $this->fob;
    }

    /**
     * Set subtotal
     *
     * @param string $subtotal
     *
     * @return QbEstimate
     */
    public function setSubtotal($subtotal)
    {
        $this->subtotal = $subtotal;

        return $this;
    }

    /**
     * Get subtotal
     *
     * @return string
     */
    public function getSubtotal()
    {
        return $this->subtotal;
    }

    /**
     * Set itemsalestaxListid
     *
     * @param string $itemsalestaxListid
     *
     * @return QbEstimate
     */
    public function setItemsalestaxListid($itemsalestaxListid)
    {
        $this->itemsalestaxListid = $itemsalestaxListid;

        return $this;
    }

    /**
     * Get itemsalestaxListid
     *
     * @return string
     */
    public function getItemsalestaxListid()
    {
        return $this->itemsalestaxListid;
    }

    /**
     * Set itemsalestaxFullname
     *
     * @param string $itemsalestaxFullname
     *
     * @return QbEstimate
     */
    public function setItemsalestaxFullname($itemsalestaxFullname)
    {
        $this->itemsalestaxFullname = $itemsalestaxFullname;

        return $this;
    }

    /**
     * Get itemsalestaxFullname
     *
     * @return string
     */
    public function getItemsalestaxFullname()
    {
        return $this->itemsalestaxFullname;
    }

    /**
     * Set salestaxpercentage
     *
     * @param string $salestaxpercentage
     *
     * @return QbEstimate
     */
    public function setSalestaxpercentage($salestaxpercentage)
    {
        $this->salestaxpercentage = $salestaxpercentage;

        return $this;
    }

    /**
     * Get salestaxpercentage
     *
     * @return string
     */
    public function getSalestaxpercentage()
    {
        return $this->salestaxpercentage;
    }

    /**
     * Set salestaxtotal
     *
     * @param string $salestaxtotal
     *
     * @return QbEstimate
     */
    public function setSalestaxtotal($salestaxtotal)
    {
        $this->salestaxtotal = $salestaxtotal;

        return $this;
    }

    /**
     * Get salestaxtotal
     *
     * @return string
     */
    public function getSalestaxtotal()
    {
        return $this->salestaxtotal;
    }

    /**
     * Set totalamount
     *
     * @param string $totalamount
     *
     * @return QbEstimate
     */
    public function setTotalamount($totalamount)
    {
        $this->totalamount = $totalamount;

        return $this;
    }

    /**
     * Get totalamount
     *
     * @return string
     */
    public function getTotalamount()
    {
        return $this->totalamount;
    }

    /**
     * Set currencyListid
     *
     * @param string $currencyListid
     *
     * @return QbEstimate
     */
    public function setCurrencyListid($currencyListid)
    {
        $this->currencyListid = $currencyListid;

        return $this;
    }

    /**
     * Get currencyListid
     *
     * @return string
     */
    public function getCurrencyListid()
    {
        return $this->currencyListid;
    }

    /**
     * Set currencyFullname
     *
     * @param string $currencyFullname
     *
     * @return QbEstimate
     */
    public function setCurrencyFullname($currencyFullname)
    {
        $this->currencyFullname = $currencyFullname;

        return $this;
    }

    /**
     * Get currencyFullname
     *
     * @return string
     */
    public function getCurrencyFullname()
    {
        return $this->currencyFullname;
    }

    /**
     * Set exchangerate
     *
     * @param string $exchangerate
     *
     * @return QbEstimate
     */
    public function setExchangerate($exchangerate)
    {
        $this->exchangerate = $exchangerate;

        return $this;
    }

    /**
     * Get exchangerate
     *
     * @return string
     */
    public function getExchangerate()
    {
        return $this->exchangerate;
    }

    /**
     * Set totalamountinhomecurrency
     *
     * @param string $totalamountinhomecurrency
     *
     * @return QbEstimate
     */
    public function setTotalamountinhomecurrency($totalamountinhomecurrency)
    {
        $this->totalamountinhomecurrency = $totalamountinhomecurrency;

        return $this;
    }

    /**
     * Get totalamountinhomecurrency
     *
     * @return string
     */
    public function getTotalamountinhomecurrency()
    {
        return $this->totalamountinhomecurrency;
    }

    /**
     * Set memo
     *
     * @param string $memo
     *
     * @return QbEstimate
     */
    public function setMemo($memo)
    {
        $this->memo = $memo;

        return $this;
    }

    /**
     * Get memo
     *
     * @return string
     */
    public function getMemo()
    {
        return $this->memo;
    }

    /**
     * Set customermsgListid
     *
     * @param string $customermsgListid
     *
     * @return QbEstimate
     */
    public function setCustomermsgListid($customermsgListid)
    {
        $this->customermsgListid = $customermsgListid;

        return $this;
    }

    /**
     * Get customermsgListid
     *
     * @return string
     */
    public function getCustomermsgListid()
    {
        return $this->customermsgListid;
    }

    /**
     * Set customermsgFullname
     *
     * @param string $customermsgFullname
     *
     * @return QbEstimate
     */
    public function setCustomermsgFullname($customermsgFullname)
    {
        $this->customermsgFullname = $customermsgFullname;

        return $this;
    }

    /**
     * Get customermsgFullname
     *
     * @return string
     */
    public function getCustomermsgFullname()
    {
        return $this->customermsgFullname;
    }

    /**
     * Set istobeemailed
     *
     * @param boolean $istobeemailed
     *
     * @return QbEstimate
     */
    public function setIstobeemailed($istobeemailed)
    {
        $this->istobeemailed = $istobeemailed;

        return $this;
    }

    /**
     * Get istobeemailed
     *
     * @return boolean
     */
    public function getIstobeemailed()
    {
        return $this->istobeemailed;
    }

    /**
     * Set customersalestaxcodeListid
     *
     * @param string $customersalestaxcodeListid
     *
     * @return QbEstimate
     */
    public function setCustomersalestaxcodeListid($customersalestaxcodeListid)
    {
        $this->customersalestaxcodeListid = $customersalestaxcodeListid;

        return $this;
    }

    /**
     * Get customersalestaxcodeListid
     *
     * @return string
     */
    public function getCustomersalestaxcodeListid()
    {
        return $this->customersalestaxcodeListid;
    }

    /**
     * Set customersalestaxcodeFullname
     *
     * @param string $customersalestaxcodeFullname
     *
     * @return QbEstimate
     */
    public function setCustomersalestaxcodeFullname($customersalestaxcodeFullname)
    {
        $this->customersalestaxcodeFullname = $customersalestaxcodeFullname;

        return $this;
    }

    /**
     * Get customersalestaxcodeFullname
     *
     * @return string
     */
    public function getCustomersalestaxcodeFullname()
    {
        return $this->customersalestaxcodeFullname;
    }

    /**
     * Set other
     *
     * @param string $other
     *
     * @return QbEstimate
     */
    public function setOther($other)
    {
        $this->other = $other;

        return $this;
    }

    /**
     * Get other
     *
     * @return string
     */
    public function getOther()
    {
        return $this->other;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbEstimate
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbEstimate
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbEstimate
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbEstimate
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbEstimate
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbEstimate
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbEstimate
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbEstimate
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbEstimate
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbEstimate
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbEstimate
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbEstimate
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbEstimate
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbEstimate
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbEstimate
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbEstimate
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbEstimate
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbEstimate
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

