<?php

namespace QbmBundle\Entity;

/**
 * QbReceivepayment
 */
class QbReceivepayment
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $txnid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var integer
     */
    private $txnnumber = '0';

    /**
     * @var string
     */
    private $customerListid;

    /**
     * @var string
     */
    private $customerFullname;

    /**
     * @var string
     */
    private $araccountListid;

    /**
     * @var string
     */
    private $araccountFullname;

    /**
     * @var \DateTime
     */
    private $txndate;

    /**
     * @var string
     */
    private $refnumber;

    /**
     * @var string
     */
    private $totalamount;

    /**
     * @var string
     */
    private $paymentmethodListid;

    /**
     * @var string
     */
    private $paymentmethodFullname;

    /**
     * @var string
     */
    private $memo;

    /**
     * @var string
     */
    private $deposittoaccountListid;

    /**
     * @var string
     */
    private $deposittoaccountFullname;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoCreditcardnumber;

    /**
     * @var integer
     */
    private $creditcardtxninfoCreditcardtxninputinfoExpirationmonth;

    /**
     * @var integer
     */
    private $creditcardtxninfoCreditcardtxninputinfoExpirationyear;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoNameoncard;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoCreditcardaddress;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoCommercialcardcode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoTransactionmode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype;

    /**
     * @var integer
     */
    private $creditcardtxninfoCreditcardtxnresultinfoResultcode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoResultmessage;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoAvsstreet;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoAvszip;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoReconbatchid;

    /**
     * @var integer
     */
    private $creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoPaymentstatus;

    /**
     * @var \DateTime
     */
    private $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime;

    /**
     * @var integer
     */
    private $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoClienttransid;

    /**
     * @var string
     */
    private $unusedpayment;

    /**
     * @var string
     */
    private $unusedcredits;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbReceivepayment
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbReceivepayment
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set txnid
     *
     * @param string $txnid
     *
     * @return QbReceivepayment
     */
    public function setTxnid($txnid)
    {
        $this->txnid = $txnid;

        return $this;
    }

    /**
     * Get txnid
     *
     * @return string
     */
    public function getTxnid()
    {
        return $this->txnid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbReceivepayment
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbReceivepayment
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbReceivepayment
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set txnnumber
     *
     * @param integer $txnnumber
     *
     * @return QbReceivepayment
     */
    public function setTxnnumber($txnnumber)
    {
        $this->txnnumber = $txnnumber;

        return $this;
    }

    /**
     * Get txnnumber
     *
     * @return integer
     */
    public function getTxnnumber()
    {
        return $this->txnnumber;
    }

    /**
     * Set customerListid
     *
     * @param string $customerListid
     *
     * @return QbReceivepayment
     */
    public function setCustomerListid($customerListid)
    {
        $this->customerListid = $customerListid;

        return $this;
    }

    /**
     * Get customerListid
     *
     * @return string
     */
    public function getCustomerListid()
    {
        return $this->customerListid;
    }

    /**
     * Set customerFullname
     *
     * @param string $customerFullname
     *
     * @return QbReceivepayment
     */
    public function setCustomerFullname($customerFullname)
    {
        $this->customerFullname = $customerFullname;

        return $this;
    }

    /**
     * Get customerFullname
     *
     * @return string
     */
    public function getCustomerFullname()
    {
        return $this->customerFullname;
    }

    /**
     * Set araccountListid
     *
     * @param string $araccountListid
     *
     * @return QbReceivepayment
     */
    public function setAraccountListid($araccountListid)
    {
        $this->araccountListid = $araccountListid;

        return $this;
    }

    /**
     * Get araccountListid
     *
     * @return string
     */
    public function getAraccountListid()
    {
        return $this->araccountListid;
    }

    /**
     * Set araccountFullname
     *
     * @param string $araccountFullname
     *
     * @return QbReceivepayment
     */
    public function setAraccountFullname($araccountFullname)
    {
        $this->araccountFullname = $araccountFullname;

        return $this;
    }

    /**
     * Get araccountFullname
     *
     * @return string
     */
    public function getAraccountFullname()
    {
        return $this->araccountFullname;
    }

    /**
     * Set txndate
     *
     * @param \DateTime $txndate
     *
     * @return QbReceivepayment
     */
    public function setTxndate($txndate)
    {
        $this->txndate = $txndate;

        return $this;
    }

    /**
     * Get txndate
     *
     * @return \DateTime
     */
    public function getTxndate()
    {
        return $this->txndate;
    }

    /**
     * Set refnumber
     *
     * @param string $refnumber
     *
     * @return QbReceivepayment
     */
    public function setRefnumber($refnumber)
    {
        $this->refnumber = $refnumber;

        return $this;
    }

    /**
     * Get refnumber
     *
     * @return string
     */
    public function getRefnumber()
    {
        return $this->refnumber;
    }

    /**
     * Set totalamount
     *
     * @param string $totalamount
     *
     * @return QbReceivepayment
     */
    public function setTotalamount($totalamount)
    {
        $this->totalamount = $totalamount;

        return $this;
    }

    /**
     * Get totalamount
     *
     * @return string
     */
    public function getTotalamount()
    {
        return $this->totalamount;
    }

    /**
     * Set paymentmethodListid
     *
     * @param string $paymentmethodListid
     *
     * @return QbReceivepayment
     */
    public function setPaymentmethodListid($paymentmethodListid)
    {
        $this->paymentmethodListid = $paymentmethodListid;

        return $this;
    }

    /**
     * Get paymentmethodListid
     *
     * @return string
     */
    public function getPaymentmethodListid()
    {
        return $this->paymentmethodListid;
    }

    /**
     * Set paymentmethodFullname
     *
     * @param string $paymentmethodFullname
     *
     * @return QbReceivepayment
     */
    public function setPaymentmethodFullname($paymentmethodFullname)
    {
        $this->paymentmethodFullname = $paymentmethodFullname;

        return $this;
    }

    /**
     * Get paymentmethodFullname
     *
     * @return string
     */
    public function getPaymentmethodFullname()
    {
        return $this->paymentmethodFullname;
    }

    /**
     * Set memo
     *
     * @param string $memo
     *
     * @return QbReceivepayment
     */
    public function setMemo($memo)
    {
        $this->memo = $memo;

        return $this;
    }

    /**
     * Get memo
     *
     * @return string
     */
    public function getMemo()
    {
        return $this->memo;
    }

    /**
     * Set deposittoaccountListid
     *
     * @param string $deposittoaccountListid
     *
     * @return QbReceivepayment
     */
    public function setDeposittoaccountListid($deposittoaccountListid)
    {
        $this->deposittoaccountListid = $deposittoaccountListid;

        return $this;
    }

    /**
     * Get deposittoaccountListid
     *
     * @return string
     */
    public function getDeposittoaccountListid()
    {
        return $this->deposittoaccountListid;
    }

    /**
     * Set deposittoaccountFullname
     *
     * @param string $deposittoaccountFullname
     *
     * @return QbReceivepayment
     */
    public function setDeposittoaccountFullname($deposittoaccountFullname)
    {
        $this->deposittoaccountFullname = $deposittoaccountFullname;

        return $this;
    }

    /**
     * Get deposittoaccountFullname
     *
     * @return string
     */
    public function getDeposittoaccountFullname()
    {
        return $this->deposittoaccountFullname;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoCreditcardnumber
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoCreditcardnumber
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoCreditcardnumber($creditcardtxninfoCreditcardtxninputinfoCreditcardnumber)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoCreditcardnumber = $creditcardtxninfoCreditcardtxninputinfoCreditcardnumber;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoCreditcardnumber
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoCreditcardnumber()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoCreditcardnumber;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoExpirationmonth
     *
     * @param integer $creditcardtxninfoCreditcardtxninputinfoExpirationmonth
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoExpirationmonth($creditcardtxninfoCreditcardtxninputinfoExpirationmonth)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoExpirationmonth = $creditcardtxninfoCreditcardtxninputinfoExpirationmonth;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoExpirationmonth
     *
     * @return integer
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoExpirationmonth()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoExpirationmonth;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoExpirationyear
     *
     * @param integer $creditcardtxninfoCreditcardtxninputinfoExpirationyear
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoExpirationyear($creditcardtxninfoCreditcardtxninputinfoExpirationyear)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoExpirationyear = $creditcardtxninfoCreditcardtxninputinfoExpirationyear;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoExpirationyear
     *
     * @return integer
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoExpirationyear()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoExpirationyear;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoNameoncard
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoNameoncard
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoNameoncard($creditcardtxninfoCreditcardtxninputinfoNameoncard)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoNameoncard = $creditcardtxninfoCreditcardtxninputinfoNameoncard;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoNameoncard
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoNameoncard()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoNameoncard;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoCreditcardaddress
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoCreditcardaddress
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoCreditcardaddress($creditcardtxninfoCreditcardtxninputinfoCreditcardaddress)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoCreditcardaddress = $creditcardtxninfoCreditcardtxninputinfoCreditcardaddress;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoCreditcardaddress
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoCreditcardaddress()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoCreditcardaddress;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode($creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode = $creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoCommercialcardcode
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoCommercialcardcode
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoCommercialcardcode($creditcardtxninfoCreditcardtxninputinfoCommercialcardcode)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoCommercialcardcode = $creditcardtxninfoCreditcardtxninputinfoCommercialcardcode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoCommercialcardcode
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoCommercialcardcode()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoCommercialcardcode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoTransactionmode
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoTransactionmode
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoTransactionmode($creditcardtxninfoCreditcardtxninputinfoTransactionmode)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoTransactionmode = $creditcardtxninfoCreditcardtxninputinfoTransactionmode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoTransactionmode
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoTransactionmode()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoTransactionmode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoCreditcardtxntype($creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype = $creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoCreditcardtxntype()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoResultcode
     *
     * @param integer $creditcardtxninfoCreditcardtxnresultinfoResultcode
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoResultcode($creditcardtxninfoCreditcardtxnresultinfoResultcode)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoResultcode = $creditcardtxninfoCreditcardtxnresultinfoResultcode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoResultcode
     *
     * @return integer
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoResultcode()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoResultcode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoResultmessage
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoResultmessage
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoResultmessage($creditcardtxninfoCreditcardtxnresultinfoResultmessage)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoResultmessage = $creditcardtxninfoCreditcardtxnresultinfoResultmessage;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoResultmessage
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoResultmessage()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoResultmessage;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoCreditcardtransid($creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid = $creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoCreditcardtransid()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber($creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber = $creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoAuthorizationcode($creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode = $creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoAuthorizationcode()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoAvsstreet
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoAvsstreet
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoAvsstreet($creditcardtxninfoCreditcardtxnresultinfoAvsstreet)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoAvsstreet = $creditcardtxninfoCreditcardtxnresultinfoAvsstreet;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoAvsstreet
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoAvsstreet()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoAvsstreet;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoAvszip
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoAvszip
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoAvszip($creditcardtxninfoCreditcardtxnresultinfoAvszip)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoAvszip = $creditcardtxninfoCreditcardtxnresultinfoAvszip;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoAvszip
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoAvszip()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoAvszip;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch($creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch = $creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoReconbatchid
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoReconbatchid
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoReconbatchid($creditcardtxninfoCreditcardtxnresultinfoReconbatchid)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoReconbatchid = $creditcardtxninfoCreditcardtxnresultinfoReconbatchid;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoReconbatchid
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoReconbatchid()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoReconbatchid;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode
     *
     * @param integer $creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode($creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode = $creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode
     *
     * @return integer
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoPaymentstatus
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoPaymentstatus
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoPaymentstatus($creditcardtxninfoCreditcardtxnresultinfoPaymentstatus)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoPaymentstatus = $creditcardtxninfoCreditcardtxnresultinfoPaymentstatus;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoPaymentstatus
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoPaymentstatus()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoPaymentstatus;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime
     *
     * @param \DateTime $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime($creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime = $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime
     *
     * @return \DateTime
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp
     *
     * @param integer $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp($creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp = $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp
     *
     * @return integer
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoClienttransid
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoClienttransid
     *
     * @return QbReceivepayment
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoClienttransid($creditcardtxninfoCreditcardtxnresultinfoClienttransid)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoClienttransid = $creditcardtxninfoCreditcardtxnresultinfoClienttransid;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoClienttransid
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoClienttransid()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoClienttransid;
    }

    /**
     * Set unusedpayment
     *
     * @param string $unusedpayment
     *
     * @return QbReceivepayment
     */
    public function setUnusedpayment($unusedpayment)
    {
        $this->unusedpayment = $unusedpayment;

        return $this;
    }

    /**
     * Get unusedpayment
     *
     * @return string
     */
    public function getUnusedpayment()
    {
        return $this->unusedpayment;
    }

    /**
     * Set unusedcredits
     *
     * @param string $unusedcredits
     *
     * @return QbReceivepayment
     */
    public function setUnusedcredits($unusedcredits)
    {
        $this->unusedcredits = $unusedcredits;

        return $this;
    }

    /**
     * Get unusedcredits
     *
     * @return string
     */
    public function getUnusedcredits()
    {
        return $this->unusedcredits;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbReceivepayment
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbReceivepayment
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbReceivepayment
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbReceivepayment
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbReceivepayment
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbReceivepayment
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbReceivepayment
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbReceivepayment
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbReceivepayment
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbReceivepayment
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbReceivepayment
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbReceivepayment
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbReceivepayment
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbReceivepayment
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbReceivepayment
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbReceivepayment
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbReceivepayment
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbReceivepayment
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

