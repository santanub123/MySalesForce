<?php

namespace QbmBundle\Entity;

/**
 * QbItemfixedasset
 */
class QbItemfixedasset
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $listid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var string
     */
    private $name;

    /**
     * @var boolean
     */
    private $isactive = '0';

    /**
     * @var string
     */
    private $acquiredas;

    /**
     * @var string
     */
    private $purchasedesc;

    /**
     * @var \DateTime
     */
    private $purchasedate;

    /**
     * @var string
     */
    private $purchasecost;

    /**
     * @var string
     */
    private $vendororpayeename;

    /**
     * @var string
     */
    private $assetaccountListid;

    /**
     * @var string
     */
    private $assetaccountFullname;

    /**
     * @var string
     */
    private $fixedassetsalesinfoSalesdesc;

    /**
     * @var \DateTime
     */
    private $fixedassetsalesinfoSalesdate;

    /**
     * @var string
     */
    private $fixedassetsalesinfoSalesprice;

    /**
     * @var string
     */
    private $fixedassetsalesinfoSalesexpense;

    /**
     * @var string
     */
    private $assetdesc;

    /**
     * @var string
     */
    private $location;

    /**
     * @var string
     */
    private $ponumber;

    /**
     * @var string
     */
    private $serialnumber;

    /**
     * @var \DateTime
     */
    private $warrantyexpdate;

    /**
     * @var string
     */
    private $notes;

    /**
     * @var string
     */
    private $assetnumber;

    /**
     * @var string
     */
    private $costbasis;

    /**
     * @var string
     */
    private $yearendaccumulateddepreciation;

    /**
     * @var string
     */
    private $yearendbookvalue;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set listid
     *
     * @param string $listid
     *
     * @return QbItemfixedasset
     */
    public function setListid($listid)
    {
        $this->listid = $listid;

        return $this;
    }

    /**
     * Get listid
     *
     * @return string
     */
    public function getListid()
    {
        return $this->listid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbItemfixedasset
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbItemfixedasset
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbItemfixedasset
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return QbItemfixedasset
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set isactive
     *
     * @param boolean $isactive
     *
     * @return QbItemfixedasset
     */
    public function setIsactive($isactive)
    {
        $this->isactive = $isactive;

        return $this;
    }

    /**
     * Get isactive
     *
     * @return boolean
     */
    public function getIsactive()
    {
        return $this->isactive;
    }

    /**
     * Set acquiredas
     *
     * @param string $acquiredas
     *
     * @return QbItemfixedasset
     */
    public function setAcquiredas($acquiredas)
    {
        $this->acquiredas = $acquiredas;

        return $this;
    }

    /**
     * Get acquiredas
     *
     * @return string
     */
    public function getAcquiredas()
    {
        return $this->acquiredas;
    }

    /**
     * Set purchasedesc
     *
     * @param string $purchasedesc
     *
     * @return QbItemfixedasset
     */
    public function setPurchasedesc($purchasedesc)
    {
        $this->purchasedesc = $purchasedesc;

        return $this;
    }

    /**
     * Get purchasedesc
     *
     * @return string
     */
    public function getPurchasedesc()
    {
        return $this->purchasedesc;
    }

    /**
     * Set purchasedate
     *
     * @param \DateTime $purchasedate
     *
     * @return QbItemfixedasset
     */
    public function setPurchasedate($purchasedate)
    {
        $this->purchasedate = $purchasedate;

        return $this;
    }

    /**
     * Get purchasedate
     *
     * @return \DateTime
     */
    public function getPurchasedate()
    {
        return $this->purchasedate;
    }

    /**
     * Set purchasecost
     *
     * @param string $purchasecost
     *
     * @return QbItemfixedasset
     */
    public function setPurchasecost($purchasecost)
    {
        $this->purchasecost = $purchasecost;

        return $this;
    }

    /**
     * Get purchasecost
     *
     * @return string
     */
    public function getPurchasecost()
    {
        return $this->purchasecost;
    }

    /**
     * Set vendororpayeename
     *
     * @param string $vendororpayeename
     *
     * @return QbItemfixedasset
     */
    public function setVendororpayeename($vendororpayeename)
    {
        $this->vendororpayeename = $vendororpayeename;

        return $this;
    }

    /**
     * Get vendororpayeename
     *
     * @return string
     */
    public function getVendororpayeename()
    {
        return $this->vendororpayeename;
    }

    /**
     * Set assetaccountListid
     *
     * @param string $assetaccountListid
     *
     * @return QbItemfixedasset
     */
    public function setAssetaccountListid($assetaccountListid)
    {
        $this->assetaccountListid = $assetaccountListid;

        return $this;
    }

    /**
     * Get assetaccountListid
     *
     * @return string
     */
    public function getAssetaccountListid()
    {
        return $this->assetaccountListid;
    }

    /**
     * Set assetaccountFullname
     *
     * @param string $assetaccountFullname
     *
     * @return QbItemfixedasset
     */
    public function setAssetaccountFullname($assetaccountFullname)
    {
        $this->assetaccountFullname = $assetaccountFullname;

        return $this;
    }

    /**
     * Get assetaccountFullname
     *
     * @return string
     */
    public function getAssetaccountFullname()
    {
        return $this->assetaccountFullname;
    }

    /**
     * Set fixedassetsalesinfoSalesdesc
     *
     * @param string $fixedassetsalesinfoSalesdesc
     *
     * @return QbItemfixedasset
     */
    public function setFixedassetsalesinfoSalesdesc($fixedassetsalesinfoSalesdesc)
    {
        $this->fixedassetsalesinfoSalesdesc = $fixedassetsalesinfoSalesdesc;

        return $this;
    }

    /**
     * Get fixedassetsalesinfoSalesdesc
     *
     * @return string
     */
    public function getFixedassetsalesinfoSalesdesc()
    {
        return $this->fixedassetsalesinfoSalesdesc;
    }

    /**
     * Set fixedassetsalesinfoSalesdate
     *
     * @param \DateTime $fixedassetsalesinfoSalesdate
     *
     * @return QbItemfixedasset
     */
    public function setFixedassetsalesinfoSalesdate($fixedassetsalesinfoSalesdate)
    {
        $this->fixedassetsalesinfoSalesdate = $fixedassetsalesinfoSalesdate;

        return $this;
    }

    /**
     * Get fixedassetsalesinfoSalesdate
     *
     * @return \DateTime
     */
    public function getFixedassetsalesinfoSalesdate()
    {
        return $this->fixedassetsalesinfoSalesdate;
    }

    /**
     * Set fixedassetsalesinfoSalesprice
     *
     * @param string $fixedassetsalesinfoSalesprice
     *
     * @return QbItemfixedasset
     */
    public function setFixedassetsalesinfoSalesprice($fixedassetsalesinfoSalesprice)
    {
        $this->fixedassetsalesinfoSalesprice = $fixedassetsalesinfoSalesprice;

        return $this;
    }

    /**
     * Get fixedassetsalesinfoSalesprice
     *
     * @return string
     */
    public function getFixedassetsalesinfoSalesprice()
    {
        return $this->fixedassetsalesinfoSalesprice;
    }

    /**
     * Set fixedassetsalesinfoSalesexpense
     *
     * @param string $fixedassetsalesinfoSalesexpense
     *
     * @return QbItemfixedasset
     */
    public function setFixedassetsalesinfoSalesexpense($fixedassetsalesinfoSalesexpense)
    {
        $this->fixedassetsalesinfoSalesexpense = $fixedassetsalesinfoSalesexpense;

        return $this;
    }

    /**
     * Get fixedassetsalesinfoSalesexpense
     *
     * @return string
     */
    public function getFixedassetsalesinfoSalesexpense()
    {
        return $this->fixedassetsalesinfoSalesexpense;
    }

    /**
     * Set assetdesc
     *
     * @param string $assetdesc
     *
     * @return QbItemfixedasset
     */
    public function setAssetdesc($assetdesc)
    {
        $this->assetdesc = $assetdesc;

        return $this;
    }

    /**
     * Get assetdesc
     *
     * @return string
     */
    public function getAssetdesc()
    {
        return $this->assetdesc;
    }

    /**
     * Set location
     *
     * @param string $location
     *
     * @return QbItemfixedasset
     */
    public function setLocation($location)
    {
        $this->location = $location;

        return $this;
    }

    /**
     * Get location
     *
     * @return string
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Set ponumber
     *
     * @param string $ponumber
     *
     * @return QbItemfixedasset
     */
    public function setPonumber($ponumber)
    {
        $this->ponumber = $ponumber;

        return $this;
    }

    /**
     * Get ponumber
     *
     * @return string
     */
    public function getPonumber()
    {
        return $this->ponumber;
    }

    /**
     * Set serialnumber
     *
     * @param string $serialnumber
     *
     * @return QbItemfixedasset
     */
    public function setSerialnumber($serialnumber)
    {
        $this->serialnumber = $serialnumber;

        return $this;
    }

    /**
     * Get serialnumber
     *
     * @return string
     */
    public function getSerialnumber()
    {
        return $this->serialnumber;
    }

    /**
     * Set warrantyexpdate
     *
     * @param \DateTime $warrantyexpdate
     *
     * @return QbItemfixedasset
     */
    public function setWarrantyexpdate($warrantyexpdate)
    {
        $this->warrantyexpdate = $warrantyexpdate;

        return $this;
    }

    /**
     * Get warrantyexpdate
     *
     * @return \DateTime
     */
    public function getWarrantyexpdate()
    {
        return $this->warrantyexpdate;
    }

    /**
     * Set notes
     *
     * @param string $notes
     *
     * @return QbItemfixedasset
     */
    public function setNotes($notes)
    {
        $this->notes = $notes;

        return $this;
    }

    /**
     * Get notes
     *
     * @return string
     */
    public function getNotes()
    {
        return $this->notes;
    }

    /**
     * Set assetnumber
     *
     * @param string $assetnumber
     *
     * @return QbItemfixedasset
     */
    public function setAssetnumber($assetnumber)
    {
        $this->assetnumber = $assetnumber;

        return $this;
    }

    /**
     * Get assetnumber
     *
     * @return string
     */
    public function getAssetnumber()
    {
        return $this->assetnumber;
    }

    /**
     * Set costbasis
     *
     * @param string $costbasis
     *
     * @return QbItemfixedasset
     */
    public function setCostbasis($costbasis)
    {
        $this->costbasis = $costbasis;

        return $this;
    }

    /**
     * Get costbasis
     *
     * @return string
     */
    public function getCostbasis()
    {
        return $this->costbasis;
    }

    /**
     * Set yearendaccumulateddepreciation
     *
     * @param string $yearendaccumulateddepreciation
     *
     * @return QbItemfixedasset
     */
    public function setYearendaccumulateddepreciation($yearendaccumulateddepreciation)
    {
        $this->yearendaccumulateddepreciation = $yearendaccumulateddepreciation;

        return $this;
    }

    /**
     * Get yearendaccumulateddepreciation
     *
     * @return string
     */
    public function getYearendaccumulateddepreciation()
    {
        return $this->yearendaccumulateddepreciation;
    }

    /**
     * Set yearendbookvalue
     *
     * @param string $yearendbookvalue
     *
     * @return QbItemfixedasset
     */
    public function setYearendbookvalue($yearendbookvalue)
    {
        $this->yearendbookvalue = $yearendbookvalue;

        return $this;
    }

    /**
     * Get yearendbookvalue
     *
     * @return string
     */
    public function getYearendbookvalue()
    {
        return $this->yearendbookvalue;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbItemfixedasset
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

