<?php

namespace QbmBundle\Entity;

/**
 * QbInvoiceInvoicelinegroup
 */
class QbInvoiceInvoicelinegroup
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $invoiceTxnid;

    /**
     * @var integer
     */
    private $sortorder = '0';

    /**
     * @var string
     */
    private $txnlineid;

    /**
     * @var string
     */
    private $itemgroupListid;

    /**
     * @var string
     */
    private $itemgroupFullname;

    /**
     * @var string
     */
    private $descrip;

    /**
     * @var string
     */
    private $quantity = '0.00000';

    /**
     * @var string
     */
    private $unitofmeasure;

    /**
     * @var string
     */
    private $overrideuomsetListid;

    /**
     * @var string
     */
    private $overrideuomsetFullname;

    /**
     * @var boolean
     */
    private $isprintitemsingroup = '0';

    /**
     * @var string
     */
    private $totalamount;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set invoiceTxnid
     *
     * @param string $invoiceTxnid
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setInvoiceTxnid($invoiceTxnid)
    {
        $this->invoiceTxnid = $invoiceTxnid;

        return $this;
    }

    /**
     * Get invoiceTxnid
     *
     * @return string
     */
    public function getInvoiceTxnid()
    {
        return $this->invoiceTxnid;
    }

    /**
     * Set sortorder
     *
     * @param integer $sortorder
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setSortorder($sortorder)
    {
        $this->sortorder = $sortorder;

        return $this;
    }

    /**
     * Get sortorder
     *
     * @return integer
     */
    public function getSortorder()
    {
        return $this->sortorder;
    }

    /**
     * Set txnlineid
     *
     * @param string $txnlineid
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setTxnlineid($txnlineid)
    {
        $this->txnlineid = $txnlineid;

        return $this;
    }

    /**
     * Get txnlineid
     *
     * @return string
     */
    public function getTxnlineid()
    {
        return $this->txnlineid;
    }

    /**
     * Set itemgroupListid
     *
     * @param string $itemgroupListid
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setItemgroupListid($itemgroupListid)
    {
        $this->itemgroupListid = $itemgroupListid;

        return $this;
    }

    /**
     * Get itemgroupListid
     *
     * @return string
     */
    public function getItemgroupListid()
    {
        return $this->itemgroupListid;
    }

    /**
     * Set itemgroupFullname
     *
     * @param string $itemgroupFullname
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setItemgroupFullname($itemgroupFullname)
    {
        $this->itemgroupFullname = $itemgroupFullname;

        return $this;
    }

    /**
     * Get itemgroupFullname
     *
     * @return string
     */
    public function getItemgroupFullname()
    {
        return $this->itemgroupFullname;
    }

    /**
     * Set descrip
     *
     * @param string $descrip
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setDescrip($descrip)
    {
        $this->descrip = $descrip;

        return $this;
    }

    /**
     * Get descrip
     *
     * @return string
     */
    public function getDescrip()
    {
        return $this->descrip;
    }

    /**
     * Set quantity
     *
     * @param string $quantity
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQuantity($quantity)
    {
        $this->quantity = $quantity;

        return $this;
    }

    /**
     * Get quantity
     *
     * @return string
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * Set unitofmeasure
     *
     * @param string $unitofmeasure
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setUnitofmeasure($unitofmeasure)
    {
        $this->unitofmeasure = $unitofmeasure;

        return $this;
    }

    /**
     * Get unitofmeasure
     *
     * @return string
     */
    public function getUnitofmeasure()
    {
        return $this->unitofmeasure;
    }

    /**
     * Set overrideuomsetListid
     *
     * @param string $overrideuomsetListid
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setOverrideuomsetListid($overrideuomsetListid)
    {
        $this->overrideuomsetListid = $overrideuomsetListid;

        return $this;
    }

    /**
     * Get overrideuomsetListid
     *
     * @return string
     */
    public function getOverrideuomsetListid()
    {
        return $this->overrideuomsetListid;
    }

    /**
     * Set overrideuomsetFullname
     *
     * @param string $overrideuomsetFullname
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setOverrideuomsetFullname($overrideuomsetFullname)
    {
        $this->overrideuomsetFullname = $overrideuomsetFullname;

        return $this;
    }

    /**
     * Get overrideuomsetFullname
     *
     * @return string
     */
    public function getOverrideuomsetFullname()
    {
        return $this->overrideuomsetFullname;
    }

    /**
     * Set isprintitemsingroup
     *
     * @param boolean $isprintitemsingroup
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setIsprintitemsingroup($isprintitemsingroup)
    {
        $this->isprintitemsingroup = $isprintitemsingroup;

        return $this;
    }

    /**
     * Get isprintitemsingroup
     *
     * @return boolean
     */
    public function getIsprintitemsingroup()
    {
        return $this->isprintitemsingroup;
    }

    /**
     * Set totalamount
     *
     * @param string $totalamount
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setTotalamount($totalamount)
    {
        $this->totalamount = $totalamount;

        return $this;
    }

    /**
     * Get totalamount
     *
     * @return string
     */
    public function getTotalamount()
    {
        return $this->totalamount;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbInvoiceInvoicelinegroup
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

