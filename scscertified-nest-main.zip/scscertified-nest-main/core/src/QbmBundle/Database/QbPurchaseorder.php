<?php

namespace QbmBundle\Entity;

/**
 * QbPurchaseorder
 */
class QbPurchaseorder
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $txnid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var integer
     */
    private $txnnumber = '0';

    /**
     * @var string
     */
    private $vendorListid;

    /**
     * @var string
     */
    private $vendorFullname;

    /**
     * @var string
     */
    private $classListid;

    /**
     * @var string
     */
    private $classFullname;

    /**
     * @var string
     */
    private $shiptoentityListid;

    /**
     * @var string
     */
    private $shiptoentityFullname;

    /**
     * @var string
     */
    private $templateListid;

    /**
     * @var string
     */
    private $templateFullname;

    /**
     * @var \DateTime
     */
    private $txndate;

    /**
     * @var string
     */
    private $refnumber;

    /**
     * @var string
     */
    private $vendoraddressAddr1;

    /**
     * @var string
     */
    private $vendoraddressAddr2;

    /**
     * @var string
     */
    private $vendoraddressAddr3;

    /**
     * @var string
     */
    private $vendoraddressAddr4;

    /**
     * @var string
     */
    private $vendoraddressAddr5;

    /**
     * @var string
     */
    private $vendoraddressCity;

    /**
     * @var string
     */
    private $vendoraddressState;

    /**
     * @var string
     */
    private $vendoraddressPostalcode;

    /**
     * @var string
     */
    private $vendoraddressCountry;

    /**
     * @var string
     */
    private $vendoraddressNote;

    /**
     * @var string
     */
    private $vendoraddressblockAddr1;

    /**
     * @var string
     */
    private $vendoraddressblockAddr2;

    /**
     * @var string
     */
    private $vendoraddressblockAddr3;

    /**
     * @var string
     */
    private $vendoraddressblockAddr4;

    /**
     * @var string
     */
    private $vendoraddressblockAddr5;

    /**
     * @var string
     */
    private $shipaddressAddr1;

    /**
     * @var string
     */
    private $shipaddressAddr2;

    /**
     * @var string
     */
    private $shipaddressAddr3;

    /**
     * @var string
     */
    private $shipaddressAddr4;

    /**
     * @var string
     */
    private $shipaddressAddr5;

    /**
     * @var string
     */
    private $shipaddressCity;

    /**
     * @var string
     */
    private $shipaddressState;

    /**
     * @var string
     */
    private $shipaddressPostalcode;

    /**
     * @var string
     */
    private $shipaddressCountry;

    /**
     * @var string
     */
    private $shipaddressNote;

    /**
     * @var string
     */
    private $shipaddressblockAddr1;

    /**
     * @var string
     */
    private $shipaddressblockAddr2;

    /**
     * @var string
     */
    private $shipaddressblockAddr3;

    /**
     * @var string
     */
    private $shipaddressblockAddr4;

    /**
     * @var string
     */
    private $shipaddressblockAddr5;

    /**
     * @var string
     */
    private $termsListid;

    /**
     * @var string
     */
    private $termsFullname;

    /**
     * @var \DateTime
     */
    private $duedate;

    /**
     * @var \DateTime
     */
    private $expecteddate;

    /**
     * @var string
     */
    private $shipmethodListid;

    /**
     * @var string
     */
    private $shipmethodFullname;

    /**
     * @var string
     */
    private $fob;

    /**
     * @var string
     */
    private $totalamount;

    /**
     * @var string
     */
    private $currencyListid;

    /**
     * @var string
     */
    private $currencyFullname;

    /**
     * @var string
     */
    private $exchangerate;

    /**
     * @var string
     */
    private $totalamountinhomecurrency;

    /**
     * @var boolean
     */
    private $ismanuallyclosed;

    /**
     * @var boolean
     */
    private $isfullyreceived;

    /**
     * @var string
     */
    private $memo;

    /**
     * @var string
     */
    private $vendormsg;

    /**
     * @var boolean
     */
    private $istobeprinted;

    /**
     * @var boolean
     */
    private $istobeemailed;

    /**
     * @var string
     */
    private $other1;

    /**
     * @var string
     */
    private $other2;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set txnid
     *
     * @param string $txnid
     *
     * @return QbPurchaseorder
     */
    public function setTxnid($txnid)
    {
        $this->txnid = $txnid;

        return $this;
    }

    /**
     * Get txnid
     *
     * @return string
     */
    public function getTxnid()
    {
        return $this->txnid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbPurchaseorder
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbPurchaseorder
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbPurchaseorder
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set txnnumber
     *
     * @param integer $txnnumber
     *
     * @return QbPurchaseorder
     */
    public function setTxnnumber($txnnumber)
    {
        $this->txnnumber = $txnnumber;

        return $this;
    }

    /**
     * Get txnnumber
     *
     * @return integer
     */
    public function getTxnnumber()
    {
        return $this->txnnumber;
    }

    /**
     * Set vendorListid
     *
     * @param string $vendorListid
     *
     * @return QbPurchaseorder
     */
    public function setVendorListid($vendorListid)
    {
        $this->vendorListid = $vendorListid;

        return $this;
    }

    /**
     * Get vendorListid
     *
     * @return string
     */
    public function getVendorListid()
    {
        return $this->vendorListid;
    }

    /**
     * Set vendorFullname
     *
     * @param string $vendorFullname
     *
     * @return QbPurchaseorder
     */
    public function setVendorFullname($vendorFullname)
    {
        $this->vendorFullname = $vendorFullname;

        return $this;
    }

    /**
     * Get vendorFullname
     *
     * @return string
     */
    public function getVendorFullname()
    {
        return $this->vendorFullname;
    }

    /**
     * Set classListid
     *
     * @param string $classListid
     *
     * @return QbPurchaseorder
     */
    public function setClassListid($classListid)
    {
        $this->classListid = $classListid;

        return $this;
    }

    /**
     * Get classListid
     *
     * @return string
     */
    public function getClassListid()
    {
        return $this->classListid;
    }

    /**
     * Set classFullname
     *
     * @param string $classFullname
     *
     * @return QbPurchaseorder
     */
    public function setClassFullname($classFullname)
    {
        $this->classFullname = $classFullname;

        return $this;
    }

    /**
     * Get classFullname
     *
     * @return string
     */
    public function getClassFullname()
    {
        return $this->classFullname;
    }

    /**
     * Set shiptoentityListid
     *
     * @param string $shiptoentityListid
     *
     * @return QbPurchaseorder
     */
    public function setShiptoentityListid($shiptoentityListid)
    {
        $this->shiptoentityListid = $shiptoentityListid;

        return $this;
    }

    /**
     * Get shiptoentityListid
     *
     * @return string
     */
    public function getShiptoentityListid()
    {
        return $this->shiptoentityListid;
    }

    /**
     * Set shiptoentityFullname
     *
     * @param string $shiptoentityFullname
     *
     * @return QbPurchaseorder
     */
    public function setShiptoentityFullname($shiptoentityFullname)
    {
        $this->shiptoentityFullname = $shiptoentityFullname;

        return $this;
    }

    /**
     * Get shiptoentityFullname
     *
     * @return string
     */
    public function getShiptoentityFullname()
    {
        return $this->shiptoentityFullname;
    }

    /**
     * Set templateListid
     *
     * @param string $templateListid
     *
     * @return QbPurchaseorder
     */
    public function setTemplateListid($templateListid)
    {
        $this->templateListid = $templateListid;

        return $this;
    }

    /**
     * Get templateListid
     *
     * @return string
     */
    public function getTemplateListid()
    {
        return $this->templateListid;
    }

    /**
     * Set templateFullname
     *
     * @param string $templateFullname
     *
     * @return QbPurchaseorder
     */
    public function setTemplateFullname($templateFullname)
    {
        $this->templateFullname = $templateFullname;

        return $this;
    }

    /**
     * Get templateFullname
     *
     * @return string
     */
    public function getTemplateFullname()
    {
        return $this->templateFullname;
    }

    /**
     * Set txndate
     *
     * @param \DateTime $txndate
     *
     * @return QbPurchaseorder
     */
    public function setTxndate($txndate)
    {
        $this->txndate = $txndate;

        return $this;
    }

    /**
     * Get txndate
     *
     * @return \DateTime
     */
    public function getTxndate()
    {
        return $this->txndate;
    }

    /**
     * Set refnumber
     *
     * @param string $refnumber
     *
     * @return QbPurchaseorder
     */
    public function setRefnumber($refnumber)
    {
        $this->refnumber = $refnumber;

        return $this;
    }

    /**
     * Get refnumber
     *
     * @return string
     */
    public function getRefnumber()
    {
        return $this->refnumber;
    }

    /**
     * Set vendoraddressAddr1
     *
     * @param string $vendoraddressAddr1
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressAddr1($vendoraddressAddr1)
    {
        $this->vendoraddressAddr1 = $vendoraddressAddr1;

        return $this;
    }

    /**
     * Get vendoraddressAddr1
     *
     * @return string
     */
    public function getVendoraddressAddr1()
    {
        return $this->vendoraddressAddr1;
    }

    /**
     * Set vendoraddressAddr2
     *
     * @param string $vendoraddressAddr2
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressAddr2($vendoraddressAddr2)
    {
        $this->vendoraddressAddr2 = $vendoraddressAddr2;

        return $this;
    }

    /**
     * Get vendoraddressAddr2
     *
     * @return string
     */
    public function getVendoraddressAddr2()
    {
        return $this->vendoraddressAddr2;
    }

    /**
     * Set vendoraddressAddr3
     *
     * @param string $vendoraddressAddr3
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressAddr3($vendoraddressAddr3)
    {
        $this->vendoraddressAddr3 = $vendoraddressAddr3;

        return $this;
    }

    /**
     * Get vendoraddressAddr3
     *
     * @return string
     */
    public function getVendoraddressAddr3()
    {
        return $this->vendoraddressAddr3;
    }

    /**
     * Set vendoraddressAddr4
     *
     * @param string $vendoraddressAddr4
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressAddr4($vendoraddressAddr4)
    {
        $this->vendoraddressAddr4 = $vendoraddressAddr4;

        return $this;
    }

    /**
     * Get vendoraddressAddr4
     *
     * @return string
     */
    public function getVendoraddressAddr4()
    {
        return $this->vendoraddressAddr4;
    }

    /**
     * Set vendoraddressAddr5
     *
     * @param string $vendoraddressAddr5
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressAddr5($vendoraddressAddr5)
    {
        $this->vendoraddressAddr5 = $vendoraddressAddr5;

        return $this;
    }

    /**
     * Get vendoraddressAddr5
     *
     * @return string
     */
    public function getVendoraddressAddr5()
    {
        return $this->vendoraddressAddr5;
    }

    /**
     * Set vendoraddressCity
     *
     * @param string $vendoraddressCity
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressCity($vendoraddressCity)
    {
        $this->vendoraddressCity = $vendoraddressCity;

        return $this;
    }

    /**
     * Get vendoraddressCity
     *
     * @return string
     */
    public function getVendoraddressCity()
    {
        return $this->vendoraddressCity;
    }

    /**
     * Set vendoraddressState
     *
     * @param string $vendoraddressState
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressState($vendoraddressState)
    {
        $this->vendoraddressState = $vendoraddressState;

        return $this;
    }

    /**
     * Get vendoraddressState
     *
     * @return string
     */
    public function getVendoraddressState()
    {
        return $this->vendoraddressState;
    }

    /**
     * Set vendoraddressPostalcode
     *
     * @param string $vendoraddressPostalcode
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressPostalcode($vendoraddressPostalcode)
    {
        $this->vendoraddressPostalcode = $vendoraddressPostalcode;

        return $this;
    }

    /**
     * Get vendoraddressPostalcode
     *
     * @return string
     */
    public function getVendoraddressPostalcode()
    {
        return $this->vendoraddressPostalcode;
    }

    /**
     * Set vendoraddressCountry
     *
     * @param string $vendoraddressCountry
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressCountry($vendoraddressCountry)
    {
        $this->vendoraddressCountry = $vendoraddressCountry;

        return $this;
    }

    /**
     * Get vendoraddressCountry
     *
     * @return string
     */
    public function getVendoraddressCountry()
    {
        return $this->vendoraddressCountry;
    }

    /**
     * Set vendoraddressNote
     *
     * @param string $vendoraddressNote
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressNote($vendoraddressNote)
    {
        $this->vendoraddressNote = $vendoraddressNote;

        return $this;
    }

    /**
     * Get vendoraddressNote
     *
     * @return string
     */
    public function getVendoraddressNote()
    {
        return $this->vendoraddressNote;
    }

    /**
     * Set vendoraddressblockAddr1
     *
     * @param string $vendoraddressblockAddr1
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressblockAddr1($vendoraddressblockAddr1)
    {
        $this->vendoraddressblockAddr1 = $vendoraddressblockAddr1;

        return $this;
    }

    /**
     * Get vendoraddressblockAddr1
     *
     * @return string
     */
    public function getVendoraddressblockAddr1()
    {
        return $this->vendoraddressblockAddr1;
    }

    /**
     * Set vendoraddressblockAddr2
     *
     * @param string $vendoraddressblockAddr2
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressblockAddr2($vendoraddressblockAddr2)
    {
        $this->vendoraddressblockAddr2 = $vendoraddressblockAddr2;

        return $this;
    }

    /**
     * Get vendoraddressblockAddr2
     *
     * @return string
     */
    public function getVendoraddressblockAddr2()
    {
        return $this->vendoraddressblockAddr2;
    }

    /**
     * Set vendoraddressblockAddr3
     *
     * @param string $vendoraddressblockAddr3
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressblockAddr3($vendoraddressblockAddr3)
    {
        $this->vendoraddressblockAddr3 = $vendoraddressblockAddr3;

        return $this;
    }

    /**
     * Get vendoraddressblockAddr3
     *
     * @return string
     */
    public function getVendoraddressblockAddr3()
    {
        return $this->vendoraddressblockAddr3;
    }

    /**
     * Set vendoraddressblockAddr4
     *
     * @param string $vendoraddressblockAddr4
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressblockAddr4($vendoraddressblockAddr4)
    {
        $this->vendoraddressblockAddr4 = $vendoraddressblockAddr4;

        return $this;
    }

    /**
     * Get vendoraddressblockAddr4
     *
     * @return string
     */
    public function getVendoraddressblockAddr4()
    {
        return $this->vendoraddressblockAddr4;
    }

    /**
     * Set vendoraddressblockAddr5
     *
     * @param string $vendoraddressblockAddr5
     *
     * @return QbPurchaseorder
     */
    public function setVendoraddressblockAddr5($vendoraddressblockAddr5)
    {
        $this->vendoraddressblockAddr5 = $vendoraddressblockAddr5;

        return $this;
    }

    /**
     * Get vendoraddressblockAddr5
     *
     * @return string
     */
    public function getVendoraddressblockAddr5()
    {
        return $this->vendoraddressblockAddr5;
    }

    /**
     * Set shipaddressAddr1
     *
     * @param string $shipaddressAddr1
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressAddr1($shipaddressAddr1)
    {
        $this->shipaddressAddr1 = $shipaddressAddr1;

        return $this;
    }

    /**
     * Get shipaddressAddr1
     *
     * @return string
     */
    public function getShipaddressAddr1()
    {
        return $this->shipaddressAddr1;
    }

    /**
     * Set shipaddressAddr2
     *
     * @param string $shipaddressAddr2
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressAddr2($shipaddressAddr2)
    {
        $this->shipaddressAddr2 = $shipaddressAddr2;

        return $this;
    }

    /**
     * Get shipaddressAddr2
     *
     * @return string
     */
    public function getShipaddressAddr2()
    {
        return $this->shipaddressAddr2;
    }

    /**
     * Set shipaddressAddr3
     *
     * @param string $shipaddressAddr3
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressAddr3($shipaddressAddr3)
    {
        $this->shipaddressAddr3 = $shipaddressAddr3;

        return $this;
    }

    /**
     * Get shipaddressAddr3
     *
     * @return string
     */
    public function getShipaddressAddr3()
    {
        return $this->shipaddressAddr3;
    }

    /**
     * Set shipaddressAddr4
     *
     * @param string $shipaddressAddr4
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressAddr4($shipaddressAddr4)
    {
        $this->shipaddressAddr4 = $shipaddressAddr4;

        return $this;
    }

    /**
     * Get shipaddressAddr4
     *
     * @return string
     */
    public function getShipaddressAddr4()
    {
        return $this->shipaddressAddr4;
    }

    /**
     * Set shipaddressAddr5
     *
     * @param string $shipaddressAddr5
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressAddr5($shipaddressAddr5)
    {
        $this->shipaddressAddr5 = $shipaddressAddr5;

        return $this;
    }

    /**
     * Get shipaddressAddr5
     *
     * @return string
     */
    public function getShipaddressAddr5()
    {
        return $this->shipaddressAddr5;
    }

    /**
     * Set shipaddressCity
     *
     * @param string $shipaddressCity
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressCity($shipaddressCity)
    {
        $this->shipaddressCity = $shipaddressCity;

        return $this;
    }

    /**
     * Get shipaddressCity
     *
     * @return string
     */
    public function getShipaddressCity()
    {
        return $this->shipaddressCity;
    }

    /**
     * Set shipaddressState
     *
     * @param string $shipaddressState
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressState($shipaddressState)
    {
        $this->shipaddressState = $shipaddressState;

        return $this;
    }

    /**
     * Get shipaddressState
     *
     * @return string
     */
    public function getShipaddressState()
    {
        return $this->shipaddressState;
    }

    /**
     * Set shipaddressPostalcode
     *
     * @param string $shipaddressPostalcode
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressPostalcode($shipaddressPostalcode)
    {
        $this->shipaddressPostalcode = $shipaddressPostalcode;

        return $this;
    }

    /**
     * Get shipaddressPostalcode
     *
     * @return string
     */
    public function getShipaddressPostalcode()
    {
        return $this->shipaddressPostalcode;
    }

    /**
     * Set shipaddressCountry
     *
     * @param string $shipaddressCountry
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressCountry($shipaddressCountry)
    {
        $this->shipaddressCountry = $shipaddressCountry;

        return $this;
    }

    /**
     * Get shipaddressCountry
     *
     * @return string
     */
    public function getShipaddressCountry()
    {
        return $this->shipaddressCountry;
    }

    /**
     * Set shipaddressNote
     *
     * @param string $shipaddressNote
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressNote($shipaddressNote)
    {
        $this->shipaddressNote = $shipaddressNote;

        return $this;
    }

    /**
     * Get shipaddressNote
     *
     * @return string
     */
    public function getShipaddressNote()
    {
        return $this->shipaddressNote;
    }

    /**
     * Set shipaddressblockAddr1
     *
     * @param string $shipaddressblockAddr1
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressblockAddr1($shipaddressblockAddr1)
    {
        $this->shipaddressblockAddr1 = $shipaddressblockAddr1;

        return $this;
    }

    /**
     * Get shipaddressblockAddr1
     *
     * @return string
     */
    public function getShipaddressblockAddr1()
    {
        return $this->shipaddressblockAddr1;
    }

    /**
     * Set shipaddressblockAddr2
     *
     * @param string $shipaddressblockAddr2
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressblockAddr2($shipaddressblockAddr2)
    {
        $this->shipaddressblockAddr2 = $shipaddressblockAddr2;

        return $this;
    }

    /**
     * Get shipaddressblockAddr2
     *
     * @return string
     */
    public function getShipaddressblockAddr2()
    {
        return $this->shipaddressblockAddr2;
    }

    /**
     * Set shipaddressblockAddr3
     *
     * @param string $shipaddressblockAddr3
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressblockAddr3($shipaddressblockAddr3)
    {
        $this->shipaddressblockAddr3 = $shipaddressblockAddr3;

        return $this;
    }

    /**
     * Get shipaddressblockAddr3
     *
     * @return string
     */
    public function getShipaddressblockAddr3()
    {
        return $this->shipaddressblockAddr3;
    }

    /**
     * Set shipaddressblockAddr4
     *
     * @param string $shipaddressblockAddr4
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressblockAddr4($shipaddressblockAddr4)
    {
        $this->shipaddressblockAddr4 = $shipaddressblockAddr4;

        return $this;
    }

    /**
     * Get shipaddressblockAddr4
     *
     * @return string
     */
    public function getShipaddressblockAddr4()
    {
        return $this->shipaddressblockAddr4;
    }

    /**
     * Set shipaddressblockAddr5
     *
     * @param string $shipaddressblockAddr5
     *
     * @return QbPurchaseorder
     */
    public function setShipaddressblockAddr5($shipaddressblockAddr5)
    {
        $this->shipaddressblockAddr5 = $shipaddressblockAddr5;

        return $this;
    }

    /**
     * Get shipaddressblockAddr5
     *
     * @return string
     */
    public function getShipaddressblockAddr5()
    {
        return $this->shipaddressblockAddr5;
    }

    /**
     * Set termsListid
     *
     * @param string $termsListid
     *
     * @return QbPurchaseorder
     */
    public function setTermsListid($termsListid)
    {
        $this->termsListid = $termsListid;

        return $this;
    }

    /**
     * Get termsListid
     *
     * @return string
     */
    public function getTermsListid()
    {
        return $this->termsListid;
    }

    /**
     * Set termsFullname
     *
     * @param string $termsFullname
     *
     * @return QbPurchaseorder
     */
    public function setTermsFullname($termsFullname)
    {
        $this->termsFullname = $termsFullname;

        return $this;
    }

    /**
     * Get termsFullname
     *
     * @return string
     */
    public function getTermsFullname()
    {
        return $this->termsFullname;
    }

    /**
     * Set duedate
     *
     * @param \DateTime $duedate
     *
     * @return QbPurchaseorder
     */
    public function setDuedate($duedate)
    {
        $this->duedate = $duedate;

        return $this;
    }

    /**
     * Get duedate
     *
     * @return \DateTime
     */
    public function getDuedate()
    {
        return $this->duedate;
    }

    /**
     * Set expecteddate
     *
     * @param \DateTime $expecteddate
     *
     * @return QbPurchaseorder
     */
    public function setExpecteddate($expecteddate)
    {
        $this->expecteddate = $expecteddate;

        return $this;
    }

    /**
     * Get expecteddate
     *
     * @return \DateTime
     */
    public function getExpecteddate()
    {
        return $this->expecteddate;
    }

    /**
     * Set shipmethodListid
     *
     * @param string $shipmethodListid
     *
     * @return QbPurchaseorder
     */
    public function setShipmethodListid($shipmethodListid)
    {
        $this->shipmethodListid = $shipmethodListid;

        return $this;
    }

    /**
     * Get shipmethodListid
     *
     * @return string
     */
    public function getShipmethodListid()
    {
        return $this->shipmethodListid;
    }

    /**
     * Set shipmethodFullname
     *
     * @param string $shipmethodFullname
     *
     * @return QbPurchaseorder
     */
    public function setShipmethodFullname($shipmethodFullname)
    {
        $this->shipmethodFullname = $shipmethodFullname;

        return $this;
    }

    /**
     * Get shipmethodFullname
     *
     * @return string
     */
    public function getShipmethodFullname()
    {
        return $this->shipmethodFullname;
    }

    /**
     * Set fob
     *
     * @param string $fob
     *
     * @return QbPurchaseorder
     */
    public function setFob($fob)
    {
        $this->fob = $fob;

        return $this;
    }

    /**
     * Get fob
     *
     * @return string
     */
    public function getFob()
    {
        return $this->fob;
    }

    /**
     * Set totalamount
     *
     * @param string $totalamount
     *
     * @return QbPurchaseorder
     */
    public function setTotalamount($totalamount)
    {
        $this->totalamount = $totalamount;

        return $this;
    }

    /**
     * Get totalamount
     *
     * @return string
     */
    public function getTotalamount()
    {
        return $this->totalamount;
    }

    /**
     * Set currencyListid
     *
     * @param string $currencyListid
     *
     * @return QbPurchaseorder
     */
    public function setCurrencyListid($currencyListid)
    {
        $this->currencyListid = $currencyListid;

        return $this;
    }

    /**
     * Get currencyListid
     *
     * @return string
     */
    public function getCurrencyListid()
    {
        return $this->currencyListid;
    }

    /**
     * Set currencyFullname
     *
     * @param string $currencyFullname
     *
     * @return QbPurchaseorder
     */
    public function setCurrencyFullname($currencyFullname)
    {
        $this->currencyFullname = $currencyFullname;

        return $this;
    }

    /**
     * Get currencyFullname
     *
     * @return string
     */
    public function getCurrencyFullname()
    {
        return $this->currencyFullname;
    }

    /**
     * Set exchangerate
     *
     * @param string $exchangerate
     *
     * @return QbPurchaseorder
     */
    public function setExchangerate($exchangerate)
    {
        $this->exchangerate = $exchangerate;

        return $this;
    }

    /**
     * Get exchangerate
     *
     * @return string
     */
    public function getExchangerate()
    {
        return $this->exchangerate;
    }

    /**
     * Set totalamountinhomecurrency
     *
     * @param string $totalamountinhomecurrency
     *
     * @return QbPurchaseorder
     */
    public function setTotalamountinhomecurrency($totalamountinhomecurrency)
    {
        $this->totalamountinhomecurrency = $totalamountinhomecurrency;

        return $this;
    }

    /**
     * Get totalamountinhomecurrency
     *
     * @return string
     */
    public function getTotalamountinhomecurrency()
    {
        return $this->totalamountinhomecurrency;
    }

    /**
     * Set ismanuallyclosed
     *
     * @param boolean $ismanuallyclosed
     *
     * @return QbPurchaseorder
     */
    public function setIsmanuallyclosed($ismanuallyclosed)
    {
        $this->ismanuallyclosed = $ismanuallyclosed;

        return $this;
    }

    /**
     * Get ismanuallyclosed
     *
     * @return boolean
     */
    public function getIsmanuallyclosed()
    {
        return $this->ismanuallyclosed;
    }

    /**
     * Set isfullyreceived
     *
     * @param boolean $isfullyreceived
     *
     * @return QbPurchaseorder
     */
    public function setIsfullyreceived($isfullyreceived)
    {
        $this->isfullyreceived = $isfullyreceived;

        return $this;
    }

    /**
     * Get isfullyreceived
     *
     * @return boolean
     */
    public function getIsfullyreceived()
    {
        return $this->isfullyreceived;
    }

    /**
     * Set memo
     *
     * @param string $memo
     *
     * @return QbPurchaseorder
     */
    public function setMemo($memo)
    {
        $this->memo = $memo;

        return $this;
    }

    /**
     * Get memo
     *
     * @return string
     */
    public function getMemo()
    {
        return $this->memo;
    }

    /**
     * Set vendormsg
     *
     * @param string $vendormsg
     *
     * @return QbPurchaseorder
     */
    public function setVendormsg($vendormsg)
    {
        $this->vendormsg = $vendormsg;

        return $this;
    }

    /**
     * Get vendormsg
     *
     * @return string
     */
    public function getVendormsg()
    {
        return $this->vendormsg;
    }

    /**
     * Set istobeprinted
     *
     * @param boolean $istobeprinted
     *
     * @return QbPurchaseorder
     */
    public function setIstobeprinted($istobeprinted)
    {
        $this->istobeprinted = $istobeprinted;

        return $this;
    }

    /**
     * Get istobeprinted
     *
     * @return boolean
     */
    public function getIstobeprinted()
    {
        return $this->istobeprinted;
    }

    /**
     * Set istobeemailed
     *
     * @param boolean $istobeemailed
     *
     * @return QbPurchaseorder
     */
    public function setIstobeemailed($istobeemailed)
    {
        $this->istobeemailed = $istobeemailed;

        return $this;
    }

    /**
     * Get istobeemailed
     *
     * @return boolean
     */
    public function getIstobeemailed()
    {
        return $this->istobeemailed;
    }

    /**
     * Set other1
     *
     * @param string $other1
     *
     * @return QbPurchaseorder
     */
    public function setOther1($other1)
    {
        $this->other1 = $other1;

        return $this;
    }

    /**
     * Get other1
     *
     * @return string
     */
    public function getOther1()
    {
        return $this->other1;
    }

    /**
     * Set other2
     *
     * @param string $other2
     *
     * @return QbPurchaseorder
     */
    public function setOther2($other2)
    {
        $this->other2 = $other2;

        return $this;
    }

    /**
     * Get other2
     *
     * @return string
     */
    public function getOther2()
    {
        return $this->other2;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbPurchaseorder
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

