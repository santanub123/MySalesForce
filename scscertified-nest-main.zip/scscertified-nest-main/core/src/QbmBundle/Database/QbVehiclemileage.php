<?php

namespace QbmBundle\Entity;

/**
 * QbVehiclemileage
 */
class QbVehiclemileage
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $txnid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var string
     */
    private $vehicleListid;

    /**
     * @var string
     */
    private $vehicleFullname;

    /**
     * @var string
     */
    private $customerListid;

    /**
     * @var string
     */
    private $customerFullname;

    /**
     * @var string
     */
    private $itemListid;

    /**
     * @var string
     */
    private $itemFullname;

    /**
     * @var string
     */
    private $classListid;

    /**
     * @var string
     */
    private $classFullname;

    /**
     * @var \DateTime
     */
    private $tripstartdate;

    /**
     * @var \DateTime
     */
    private $tripenddate;

    /**
     * @var string
     */
    private $odometerstart = '0.00000';

    /**
     * @var string
     */
    private $odometerend = '0.00000';

    /**
     * @var string
     */
    private $totalmiles = '0.00000';

    /**
     * @var string
     */
    private $notes;

    /**
     * @var string
     */
    private $billablestatus;

    /**
     * @var string
     */
    private $standardmileagerate;

    /**
     * @var string
     */
    private $standardmileagetotalamount;

    /**
     * @var string
     */
    private $billablerate;

    /**
     * @var string
     */
    private $billableamount;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set txnid
     *
     * @param string $txnid
     *
     * @return QbVehiclemileage
     */
    public function setTxnid($txnid)
    {
        $this->txnid = $txnid;

        return $this;
    }

    /**
     * Get txnid
     *
     * @return string
     */
    public function getTxnid()
    {
        return $this->txnid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbVehiclemileage
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbVehiclemileage
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbVehiclemileage
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set vehicleListid
     *
     * @param string $vehicleListid
     *
     * @return QbVehiclemileage
     */
    public function setVehicleListid($vehicleListid)
    {
        $this->vehicleListid = $vehicleListid;

        return $this;
    }

    /**
     * Get vehicleListid
     *
     * @return string
     */
    public function getVehicleListid()
    {
        return $this->vehicleListid;
    }

    /**
     * Set vehicleFullname
     *
     * @param string $vehicleFullname
     *
     * @return QbVehiclemileage
     */
    public function setVehicleFullname($vehicleFullname)
    {
        $this->vehicleFullname = $vehicleFullname;

        return $this;
    }

    /**
     * Get vehicleFullname
     *
     * @return string
     */
    public function getVehicleFullname()
    {
        return $this->vehicleFullname;
    }

    /**
     * Set customerListid
     *
     * @param string $customerListid
     *
     * @return QbVehiclemileage
     */
    public function setCustomerListid($customerListid)
    {
        $this->customerListid = $customerListid;

        return $this;
    }

    /**
     * Get customerListid
     *
     * @return string
     */
    public function getCustomerListid()
    {
        return $this->customerListid;
    }

    /**
     * Set customerFullname
     *
     * @param string $customerFullname
     *
     * @return QbVehiclemileage
     */
    public function setCustomerFullname($customerFullname)
    {
        $this->customerFullname = $customerFullname;

        return $this;
    }

    /**
     * Get customerFullname
     *
     * @return string
     */
    public function getCustomerFullname()
    {
        return $this->customerFullname;
    }

    /**
     * Set itemListid
     *
     * @param string $itemListid
     *
     * @return QbVehiclemileage
     */
    public function setItemListid($itemListid)
    {
        $this->itemListid = $itemListid;

        return $this;
    }

    /**
     * Get itemListid
     *
     * @return string
     */
    public function getItemListid()
    {
        return $this->itemListid;
    }

    /**
     * Set itemFullname
     *
     * @param string $itemFullname
     *
     * @return QbVehiclemileage
     */
    public function setItemFullname($itemFullname)
    {
        $this->itemFullname = $itemFullname;

        return $this;
    }

    /**
     * Get itemFullname
     *
     * @return string
     */
    public function getItemFullname()
    {
        return $this->itemFullname;
    }

    /**
     * Set classListid
     *
     * @param string $classListid
     *
     * @return QbVehiclemileage
     */
    public function setClassListid($classListid)
    {
        $this->classListid = $classListid;

        return $this;
    }

    /**
     * Get classListid
     *
     * @return string
     */
    public function getClassListid()
    {
        return $this->classListid;
    }

    /**
     * Set classFullname
     *
     * @param string $classFullname
     *
     * @return QbVehiclemileage
     */
    public function setClassFullname($classFullname)
    {
        $this->classFullname = $classFullname;

        return $this;
    }

    /**
     * Get classFullname
     *
     * @return string
     */
    public function getClassFullname()
    {
        return $this->classFullname;
    }

    /**
     * Set tripstartdate
     *
     * @param \DateTime $tripstartdate
     *
     * @return QbVehiclemileage
     */
    public function setTripstartdate($tripstartdate)
    {
        $this->tripstartdate = $tripstartdate;

        return $this;
    }

    /**
     * Get tripstartdate
     *
     * @return \DateTime
     */
    public function getTripstartdate()
    {
        return $this->tripstartdate;
    }

    /**
     * Set tripenddate
     *
     * @param \DateTime $tripenddate
     *
     * @return QbVehiclemileage
     */
    public function setTripenddate($tripenddate)
    {
        $this->tripenddate = $tripenddate;

        return $this;
    }

    /**
     * Get tripenddate
     *
     * @return \DateTime
     */
    public function getTripenddate()
    {
        return $this->tripenddate;
    }

    /**
     * Set odometerstart
     *
     * @param string $odometerstart
     *
     * @return QbVehiclemileage
     */
    public function setOdometerstart($odometerstart)
    {
        $this->odometerstart = $odometerstart;

        return $this;
    }

    /**
     * Get odometerstart
     *
     * @return string
     */
    public function getOdometerstart()
    {
        return $this->odometerstart;
    }

    /**
     * Set odometerend
     *
     * @param string $odometerend
     *
     * @return QbVehiclemileage
     */
    public function setOdometerend($odometerend)
    {
        $this->odometerend = $odometerend;

        return $this;
    }

    /**
     * Get odometerend
     *
     * @return string
     */
    public function getOdometerend()
    {
        return $this->odometerend;
    }

    /**
     * Set totalmiles
     *
     * @param string $totalmiles
     *
     * @return QbVehiclemileage
     */
    public function setTotalmiles($totalmiles)
    {
        $this->totalmiles = $totalmiles;

        return $this;
    }

    /**
     * Get totalmiles
     *
     * @return string
     */
    public function getTotalmiles()
    {
        return $this->totalmiles;
    }

    /**
     * Set notes
     *
     * @param string $notes
     *
     * @return QbVehiclemileage
     */
    public function setNotes($notes)
    {
        $this->notes = $notes;

        return $this;
    }

    /**
     * Get notes
     *
     * @return string
     */
    public function getNotes()
    {
        return $this->notes;
    }

    /**
     * Set billablestatus
     *
     * @param string $billablestatus
     *
     * @return QbVehiclemileage
     */
    public function setBillablestatus($billablestatus)
    {
        $this->billablestatus = $billablestatus;

        return $this;
    }

    /**
     * Get billablestatus
     *
     * @return string
     */
    public function getBillablestatus()
    {
        return $this->billablestatus;
    }

    /**
     * Set standardmileagerate
     *
     * @param string $standardmileagerate
     *
     * @return QbVehiclemileage
     */
    public function setStandardmileagerate($standardmileagerate)
    {
        $this->standardmileagerate = $standardmileagerate;

        return $this;
    }

    /**
     * Get standardmileagerate
     *
     * @return string
     */
    public function getStandardmileagerate()
    {
        return $this->standardmileagerate;
    }

    /**
     * Set standardmileagetotalamount
     *
     * @param string $standardmileagetotalamount
     *
     * @return QbVehiclemileage
     */
    public function setStandardmileagetotalamount($standardmileagetotalamount)
    {
        $this->standardmileagetotalamount = $standardmileagetotalamount;

        return $this;
    }

    /**
     * Get standardmileagetotalamount
     *
     * @return string
     */
    public function getStandardmileagetotalamount()
    {
        return $this->standardmileagetotalamount;
    }

    /**
     * Set billablerate
     *
     * @param string $billablerate
     *
     * @return QbVehiclemileage
     */
    public function setBillablerate($billablerate)
    {
        $this->billablerate = $billablerate;

        return $this;
    }

    /**
     * Get billablerate
     *
     * @return string
     */
    public function getBillablerate()
    {
        return $this->billablerate;
    }

    /**
     * Set billableamount
     *
     * @param string $billableamount
     *
     * @return QbVehiclemileage
     */
    public function setBillableamount($billableamount)
    {
        $this->billableamount = $billableamount;

        return $this;
    }

    /**
     * Get billableamount
     *
     * @return string
     */
    public function getBillableamount()
    {
        return $this->billableamount;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbVehiclemileage
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

