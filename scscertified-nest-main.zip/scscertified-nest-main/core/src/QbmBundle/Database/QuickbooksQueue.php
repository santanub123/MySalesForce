<?php

namespace QbmBundle\Entity;

/**
 * QuickbooksQueue
 */
class QuickbooksQueue
{
    /**
     * @var integer
     */
    private $quickbooksQueueId;

    /**
     * @var integer
     */
    private $quickbooksTicketId;

    /**
     * @var string
     */
    private $qbUsername;

    /**
     * @var string
     */
    private $qbAction;

    /**
     * @var string
     */
    private $ident;

    /**
     * @var string
     */
    private $extra;

    /**
     * @var string
     */
    private $qbxml;

    /**
     * @var integer
     */
    private $priority = '0';

    /**
     * @var string
     */
    private $qbStatus;

    /**
     * @var string
     */
    private $msg;

    /**
     * @var \DateTime
     */
    private $enqueueDatetime;

    /**
     * @var \DateTime
     */
    private $dequeueDatetime;


    /**
     * Get quickbooksQueueId
     *
     * @return integer
     */
    public function getQuickbooksQueueId()
    {
        return $this->quickbooksQueueId;
    }

    /**
     * Set quickbooksTicketId
     *
     * @param integer $quickbooksTicketId
     *
     * @return QuickbooksQueue
     */
    public function setQuickbooksTicketId($quickbooksTicketId)
    {
        $this->quickbooksTicketId = $quickbooksTicketId;

        return $this;
    }

    /**
     * Get quickbooksTicketId
     *
     * @return integer
     */
    public function getQuickbooksTicketId()
    {
        return $this->quickbooksTicketId;
    }

    /**
     * Set qbUsername
     *
     * @param string $qbUsername
     *
     * @return QuickbooksQueue
     */
    public function setQbUsername($qbUsername)
    {
        $this->qbUsername = $qbUsername;

        return $this;
    }

    /**
     * Get qbUsername
     *
     * @return string
     */
    public function getQbUsername()
    {
        return $this->qbUsername;
    }

    /**
     * Set qbAction
     *
     * @param string $qbAction
     *
     * @return QuickbooksQueue
     */
    public function setQbAction($qbAction)
    {
        $this->qbAction = $qbAction;

        return $this;
    }

    /**
     * Get qbAction
     *
     * @return string
     */
    public function getQbAction()
    {
        return $this->qbAction;
    }

    /**
     * Set ident
     *
     * @param string $ident
     *
     * @return QuickbooksQueue
     */
    public function setIdent($ident)
    {
        $this->ident = $ident;

        return $this;
    }

    /**
     * Get ident
     *
     * @return string
     */
    public function getIdent()
    {
        return $this->ident;
    }

    /**
     * Set extra
     *
     * @param string $extra
     *
     * @return QuickbooksQueue
     */
    public function setExtra($extra)
    {
        $this->extra = $extra;

        return $this;
    }

    /**
     * Get extra
     *
     * @return string
     */
    public function getExtra()
    {
        return $this->extra;
    }

    /**
     * Set qbxml
     *
     * @param string $qbxml
     *
     * @return QuickbooksQueue
     */
    public function setQbxml($qbxml)
    {
        $this->qbxml = $qbxml;

        return $this;
    }

    /**
     * Get qbxml
     *
     * @return string
     */
    public function getQbxml()
    {
        return $this->qbxml;
    }

    /**
     * Set priority
     *
     * @param integer $priority
     *
     * @return QuickbooksQueue
     */
    public function setPriority($priority)
    {
        $this->priority = $priority;

        return $this;
    }

    /**
     * Get priority
     *
     * @return integer
     */
    public function getPriority()
    {
        return $this->priority;
    }

    /**
     * Set qbStatus
     *
     * @param string $qbStatus
     *
     * @return QuickbooksQueue
     */
    public function setQbStatus($qbStatus)
    {
        $this->qbStatus = $qbStatus;

        return $this;
    }

    /**
     * Get qbStatus
     *
     * @return string
     */
    public function getQbStatus()
    {
        return $this->qbStatus;
    }

    /**
     * Set msg
     *
     * @param string $msg
     *
     * @return QuickbooksQueue
     */
    public function setMsg($msg)
    {
        $this->msg = $msg;

        return $this;
    }

    /**
     * Get msg
     *
     * @return string
     */
    public function getMsg()
    {
        return $this->msg;
    }

    /**
     * Set enqueueDatetime
     *
     * @param \DateTime $enqueueDatetime
     *
     * @return QuickbooksQueue
     */
    public function setEnqueueDatetime($enqueueDatetime)
    {
        $this->enqueueDatetime = $enqueueDatetime;

        return $this;
    }

    /**
     * Get enqueueDatetime
     *
     * @return \DateTime
     */
    public function getEnqueueDatetime()
    {
        return $this->enqueueDatetime;
    }

    /**
     * Set dequeueDatetime
     *
     * @param \DateTime $dequeueDatetime
     *
     * @return QuickbooksQueue
     */
    public function setDequeueDatetime($dequeueDatetime)
    {
        $this->dequeueDatetime = $dequeueDatetime;

        return $this;
    }

    /**
     * Get dequeueDatetime
     *
     * @return \DateTime
     */
    public function getDequeueDatetime()
    {
        return $this->dequeueDatetime;
    }
}

