<?php

namespace QbmBundle\Entity;

/**
 * QuickbooksRecur
 */
class QuickbooksRecur
{
    /**
     * @var integer
     */
    private $quickbooksRecurId;

    /**
     * @var string
     */
    private $qbUsername;

    /**
     * @var string
     */
    private $qbAction;

    /**
     * @var string
     */
    private $ident;

    /**
     * @var string
     */
    private $extra;

    /**
     * @var string
     */
    private $qbxml;

    /**
     * @var integer
     */
    private $priority = '0';

    /**
     * @var integer
     */
    private $runEvery;

    /**
     * @var integer
     */
    private $recurLasttime;

    /**
     * @var \DateTime
     */
    private $enqueueDatetime;


    /**
     * Get quickbooksRecurId
     *
     * @return integer
     */
    public function getQuickbooksRecurId()
    {
        return $this->quickbooksRecurId;
    }

    /**
     * Set qbUsername
     *
     * @param string $qbUsername
     *
     * @return QuickbooksRecur
     */
    public function setQbUsername($qbUsername)
    {
        $this->qbUsername = $qbUsername;

        return $this;
    }

    /**
     * Get qbUsername
     *
     * @return string
     */
    public function getQbUsername()
    {
        return $this->qbUsername;
    }

    /**
     * Set qbAction
     *
     * @param string $qbAction
     *
     * @return QuickbooksRecur
     */
    public function setQbAction($qbAction)
    {
        $this->qbAction = $qbAction;

        return $this;
    }

    /**
     * Get qbAction
     *
     * @return string
     */
    public function getQbAction()
    {
        return $this->qbAction;
    }

    /**
     * Set ident
     *
     * @param string $ident
     *
     * @return QuickbooksRecur
     */
    public function setIdent($ident)
    {
        $this->ident = $ident;

        return $this;
    }

    /**
     * Get ident
     *
     * @return string
     */
    public function getIdent()
    {
        return $this->ident;
    }

    /**
     * Set extra
     *
     * @param string $extra
     *
     * @return QuickbooksRecur
     */
    public function setExtra($extra)
    {
        $this->extra = $extra;

        return $this;
    }

    /**
     * Get extra
     *
     * @return string
     */
    public function getExtra()
    {
        return $this->extra;
    }

    /**
     * Set qbxml
     *
     * @param string $qbxml
     *
     * @return QuickbooksRecur
     */
    public function setQbxml($qbxml)
    {
        $this->qbxml = $qbxml;

        return $this;
    }

    /**
     * Get qbxml
     *
     * @return string
     */
    public function getQbxml()
    {
        return $this->qbxml;
    }

    /**
     * Set priority
     *
     * @param integer $priority
     *
     * @return QuickbooksRecur
     */
    public function setPriority($priority)
    {
        $this->priority = $priority;

        return $this;
    }

    /**
     * Get priority
     *
     * @return integer
     */
    public function getPriority()
    {
        return $this->priority;
    }

    /**
     * Set runEvery
     *
     * @param integer $runEvery
     *
     * @return QuickbooksRecur
     */
    public function setRunEvery($runEvery)
    {
        $this->runEvery = $runEvery;

        return $this;
    }

    /**
     * Get runEvery
     *
     * @return integer
     */
    public function getRunEvery()
    {
        return $this->runEvery;
    }

    /**
     * Set recurLasttime
     *
     * @param integer $recurLasttime
     *
     * @return QuickbooksRecur
     */
    public function setRecurLasttime($recurLasttime)
    {
        $this->recurLasttime = $recurLasttime;

        return $this;
    }

    /**
     * Get recurLasttime
     *
     * @return integer
     */
    public function getRecurLasttime()
    {
        return $this->recurLasttime;
    }

    /**
     * Set enqueueDatetime
     *
     * @param \DateTime $enqueueDatetime
     *
     * @return QuickbooksRecur
     */
    public function setEnqueueDatetime($enqueueDatetime)
    {
        $this->enqueueDatetime = $enqueueDatetime;

        return $this;
    }

    /**
     * Get enqueueDatetime
     *
     * @return \DateTime
     */
    public function getEnqueueDatetime()
    {
        return $this->enqueueDatetime;
    }
}

