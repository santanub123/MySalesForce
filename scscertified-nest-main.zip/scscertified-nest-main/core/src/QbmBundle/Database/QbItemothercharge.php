<?php

namespace QbmBundle\Entity;

/**
 * QbItemothercharge
 */
class QbItemothercharge
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $listid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $fullname;

    /**
     * @var boolean
     */
    private $isactive = '0';

    /**
     * @var string
     */
    private $parentListid;

    /**
     * @var string
     */
    private $parentFullname;

    /**
     * @var integer
     */
    private $sublevel = '0';

    /**
     * @var string
     */
    private $salestaxcodeListid;

    /**
     * @var string
     */
    private $salestaxcodeFullname;

    /**
     * @var string
     */
    private $salesorpurchaseDesc;

    /**
     * @var string
     */
    private $salesorpurchasePrice;

    /**
     * @var string
     */
    private $salesorpurchasePricepercent;

    /**
     * @var string
     */
    private $salesorpurchaseAccountListid;

    /**
     * @var string
     */
    private $salesorpurchaseAccountFullname;

    /**
     * @var string
     */
    private $salesandpurchaseSalesdesc;

    /**
     * @var string
     */
    private $salesandpurchaseSalesprice;

    /**
     * @var string
     */
    private $salesandpurchaseIncomeaccountListid;

    /**
     * @var string
     */
    private $salesandpurchaseIncomeaccountFullname;

    /**
     * @var string
     */
    private $salesandpurchasePurchasedesc;

    /**
     * @var string
     */
    private $salesandpurchasePurchasecost;

    /**
     * @var string
     */
    private $salesandpurchaseExpenseaccountListid;

    /**
     * @var string
     */
    private $salesandpurchaseExpenseaccountFullname;

    /**
     * @var string
     */
    private $salesandpurchasePrefvendorListid;

    /**
     * @var string
     */
    private $salesandpurchasePrefvendorFullname;

    /**
     * @var string
     */
    private $specialitemtype;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbItemothercharge
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbItemothercharge
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set listid
     *
     * @param string $listid
     *
     * @return QbItemothercharge
     */
    public function setListid($listid)
    {
        $this->listid = $listid;

        return $this;
    }

    /**
     * Get listid
     *
     * @return string
     */
    public function getListid()
    {
        return $this->listid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbItemothercharge
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbItemothercharge
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbItemothercharge
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return QbItemothercharge
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set fullname
     *
     * @param string $fullname
     *
     * @return QbItemothercharge
     */
    public function setFullname($fullname)
    {
        $this->fullname = $fullname;

        return $this;
    }

    /**
     * Get fullname
     *
     * @return string
     */
    public function getFullname()
    {
        return $this->fullname;
    }

    /**
     * Set isactive
     *
     * @param boolean $isactive
     *
     * @return QbItemothercharge
     */
    public function setIsactive($isactive)
    {
        $this->isactive = $isactive;

        return $this;
    }

    /**
     * Get isactive
     *
     * @return boolean
     */
    public function getIsactive()
    {
        return $this->isactive;
    }

    /**
     * Set parentListid
     *
     * @param string $parentListid
     *
     * @return QbItemothercharge
     */
    public function setParentListid($parentListid)
    {
        $this->parentListid = $parentListid;

        return $this;
    }

    /**
     * Get parentListid
     *
     * @return string
     */
    public function getParentListid()
    {
        return $this->parentListid;
    }

    /**
     * Set parentFullname
     *
     * @param string $parentFullname
     *
     * @return QbItemothercharge
     */
    public function setParentFullname($parentFullname)
    {
        $this->parentFullname = $parentFullname;

        return $this;
    }

    /**
     * Get parentFullname
     *
     * @return string
     */
    public function getParentFullname()
    {
        return $this->parentFullname;
    }

    /**
     * Set sublevel
     *
     * @param integer $sublevel
     *
     * @return QbItemothercharge
     */
    public function setSublevel($sublevel)
    {
        $this->sublevel = $sublevel;

        return $this;
    }

    /**
     * Get sublevel
     *
     * @return integer
     */
    public function getSublevel()
    {
        return $this->sublevel;
    }

    /**
     * Set salestaxcodeListid
     *
     * @param string $salestaxcodeListid
     *
     * @return QbItemothercharge
     */
    public function setSalestaxcodeListid($salestaxcodeListid)
    {
        $this->salestaxcodeListid = $salestaxcodeListid;

        return $this;
    }

    /**
     * Get salestaxcodeListid
     *
     * @return string
     */
    public function getSalestaxcodeListid()
    {
        return $this->salestaxcodeListid;
    }

    /**
     * Set salestaxcodeFullname
     *
     * @param string $salestaxcodeFullname
     *
     * @return QbItemothercharge
     */
    public function setSalestaxcodeFullname($salestaxcodeFullname)
    {
        $this->salestaxcodeFullname = $salestaxcodeFullname;

        return $this;
    }

    /**
     * Get salestaxcodeFullname
     *
     * @return string
     */
    public function getSalestaxcodeFullname()
    {
        return $this->salestaxcodeFullname;
    }

    /**
     * Set salesorpurchaseDesc
     *
     * @param string $salesorpurchaseDesc
     *
     * @return QbItemothercharge
     */
    public function setSalesorpurchaseDesc($salesorpurchaseDesc)
    {
        $this->salesorpurchaseDesc = $salesorpurchaseDesc;

        return $this;
    }

    /**
     * Get salesorpurchaseDesc
     *
     * @return string
     */
    public function getSalesorpurchaseDesc()
    {
        return $this->salesorpurchaseDesc;
    }

    /**
     * Set salesorpurchasePrice
     *
     * @param string $salesorpurchasePrice
     *
     * @return QbItemothercharge
     */
    public function setSalesorpurchasePrice($salesorpurchasePrice)
    {
        $this->salesorpurchasePrice = $salesorpurchasePrice;

        return $this;
    }

    /**
     * Get salesorpurchasePrice
     *
     * @return string
     */
    public function getSalesorpurchasePrice()
    {
        return $this->salesorpurchasePrice;
    }

    /**
     * Set salesorpurchasePricepercent
     *
     * @param string $salesorpurchasePricepercent
     *
     * @return QbItemothercharge
     */
    public function setSalesorpurchasePricepercent($salesorpurchasePricepercent)
    {
        $this->salesorpurchasePricepercent = $salesorpurchasePricepercent;

        return $this;
    }

    /**
     * Get salesorpurchasePricepercent
     *
     * @return string
     */
    public function getSalesorpurchasePricepercent()
    {
        return $this->salesorpurchasePricepercent;
    }

    /**
     * Set salesorpurchaseAccountListid
     *
     * @param string $salesorpurchaseAccountListid
     *
     * @return QbItemothercharge
     */
    public function setSalesorpurchaseAccountListid($salesorpurchaseAccountListid)
    {
        $this->salesorpurchaseAccountListid = $salesorpurchaseAccountListid;

        return $this;
    }

    /**
     * Get salesorpurchaseAccountListid
     *
     * @return string
     */
    public function getSalesorpurchaseAccountListid()
    {
        return $this->salesorpurchaseAccountListid;
    }

    /**
     * Set salesorpurchaseAccountFullname
     *
     * @param string $salesorpurchaseAccountFullname
     *
     * @return QbItemothercharge
     */
    public function setSalesorpurchaseAccountFullname($salesorpurchaseAccountFullname)
    {
        $this->salesorpurchaseAccountFullname = $salesorpurchaseAccountFullname;

        return $this;
    }

    /**
     * Get salesorpurchaseAccountFullname
     *
     * @return string
     */
    public function getSalesorpurchaseAccountFullname()
    {
        return $this->salesorpurchaseAccountFullname;
    }

    /**
     * Set salesandpurchaseSalesdesc
     *
     * @param string $salesandpurchaseSalesdesc
     *
     * @return QbItemothercharge
     */
    public function setSalesandpurchaseSalesdesc($salesandpurchaseSalesdesc)
    {
        $this->salesandpurchaseSalesdesc = $salesandpurchaseSalesdesc;

        return $this;
    }

    /**
     * Get salesandpurchaseSalesdesc
     *
     * @return string
     */
    public function getSalesandpurchaseSalesdesc()
    {
        return $this->salesandpurchaseSalesdesc;
    }

    /**
     * Set salesandpurchaseSalesprice
     *
     * @param string $salesandpurchaseSalesprice
     *
     * @return QbItemothercharge
     */
    public function setSalesandpurchaseSalesprice($salesandpurchaseSalesprice)
    {
        $this->salesandpurchaseSalesprice = $salesandpurchaseSalesprice;

        return $this;
    }

    /**
     * Get salesandpurchaseSalesprice
     *
     * @return string
     */
    public function getSalesandpurchaseSalesprice()
    {
        return $this->salesandpurchaseSalesprice;
    }

    /**
     * Set salesandpurchaseIncomeaccountListid
     *
     * @param string $salesandpurchaseIncomeaccountListid
     *
     * @return QbItemothercharge
     */
    public function setSalesandpurchaseIncomeaccountListid($salesandpurchaseIncomeaccountListid)
    {
        $this->salesandpurchaseIncomeaccountListid = $salesandpurchaseIncomeaccountListid;

        return $this;
    }

    /**
     * Get salesandpurchaseIncomeaccountListid
     *
     * @return string
     */
    public function getSalesandpurchaseIncomeaccountListid()
    {
        return $this->salesandpurchaseIncomeaccountListid;
    }

    /**
     * Set salesandpurchaseIncomeaccountFullname
     *
     * @param string $salesandpurchaseIncomeaccountFullname
     *
     * @return QbItemothercharge
     */
    public function setSalesandpurchaseIncomeaccountFullname($salesandpurchaseIncomeaccountFullname)
    {
        $this->salesandpurchaseIncomeaccountFullname = $salesandpurchaseIncomeaccountFullname;

        return $this;
    }

    /**
     * Get salesandpurchaseIncomeaccountFullname
     *
     * @return string
     */
    public function getSalesandpurchaseIncomeaccountFullname()
    {
        return $this->salesandpurchaseIncomeaccountFullname;
    }

    /**
     * Set salesandpurchasePurchasedesc
     *
     * @param string $salesandpurchasePurchasedesc
     *
     * @return QbItemothercharge
     */
    public function setSalesandpurchasePurchasedesc($salesandpurchasePurchasedesc)
    {
        $this->salesandpurchasePurchasedesc = $salesandpurchasePurchasedesc;

        return $this;
    }

    /**
     * Get salesandpurchasePurchasedesc
     *
     * @return string
     */
    public function getSalesandpurchasePurchasedesc()
    {
        return $this->salesandpurchasePurchasedesc;
    }

    /**
     * Set salesandpurchasePurchasecost
     *
     * @param string $salesandpurchasePurchasecost
     *
     * @return QbItemothercharge
     */
    public function setSalesandpurchasePurchasecost($salesandpurchasePurchasecost)
    {
        $this->salesandpurchasePurchasecost = $salesandpurchasePurchasecost;

        return $this;
    }

    /**
     * Get salesandpurchasePurchasecost
     *
     * @return string
     */
    public function getSalesandpurchasePurchasecost()
    {
        return $this->salesandpurchasePurchasecost;
    }

    /**
     * Set salesandpurchaseExpenseaccountListid
     *
     * @param string $salesandpurchaseExpenseaccountListid
     *
     * @return QbItemothercharge
     */
    public function setSalesandpurchaseExpenseaccountListid($salesandpurchaseExpenseaccountListid)
    {
        $this->salesandpurchaseExpenseaccountListid = $salesandpurchaseExpenseaccountListid;

        return $this;
    }

    /**
     * Get salesandpurchaseExpenseaccountListid
     *
     * @return string
     */
    public function getSalesandpurchaseExpenseaccountListid()
    {
        return $this->salesandpurchaseExpenseaccountListid;
    }

    /**
     * Set salesandpurchaseExpenseaccountFullname
     *
     * @param string $salesandpurchaseExpenseaccountFullname
     *
     * @return QbItemothercharge
     */
    public function setSalesandpurchaseExpenseaccountFullname($salesandpurchaseExpenseaccountFullname)
    {
        $this->salesandpurchaseExpenseaccountFullname = $salesandpurchaseExpenseaccountFullname;

        return $this;
    }

    /**
     * Get salesandpurchaseExpenseaccountFullname
     *
     * @return string
     */
    public function getSalesandpurchaseExpenseaccountFullname()
    {
        return $this->salesandpurchaseExpenseaccountFullname;
    }

    /**
     * Set salesandpurchasePrefvendorListid
     *
     * @param string $salesandpurchasePrefvendorListid
     *
     * @return QbItemothercharge
     */
    public function setSalesandpurchasePrefvendorListid($salesandpurchasePrefvendorListid)
    {
        $this->salesandpurchasePrefvendorListid = $salesandpurchasePrefvendorListid;

        return $this;
    }

    /**
     * Get salesandpurchasePrefvendorListid
     *
     * @return string
     */
    public function getSalesandpurchasePrefvendorListid()
    {
        return $this->salesandpurchasePrefvendorListid;
    }

    /**
     * Set salesandpurchasePrefvendorFullname
     *
     * @param string $salesandpurchasePrefvendorFullname
     *
     * @return QbItemothercharge
     */
    public function setSalesandpurchasePrefvendorFullname($salesandpurchasePrefvendorFullname)
    {
        $this->salesandpurchasePrefvendorFullname = $salesandpurchasePrefvendorFullname;

        return $this;
    }

    /**
     * Get salesandpurchasePrefvendorFullname
     *
     * @return string
     */
    public function getSalesandpurchasePrefvendorFullname()
    {
        return $this->salesandpurchasePrefvendorFullname;
    }

    /**
     * Set specialitemtype
     *
     * @param string $specialitemtype
     *
     * @return QbItemothercharge
     */
    public function setSpecialitemtype($specialitemtype)
    {
        $this->specialitemtype = $specialitemtype;

        return $this;
    }

    /**
     * Get specialitemtype
     *
     * @return string
     */
    public function getSpecialitemtype()
    {
        return $this->specialitemtype;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbItemothercharge
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbItemothercharge
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbItemothercharge
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbItemothercharge
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbItemothercharge
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbItemothercharge
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbItemothercharge
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbItemothercharge
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbItemothercharge
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbItemothercharge
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbItemothercharge
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbItemothercharge
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbItemothercharge
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbItemothercharge
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbItemothercharge
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbItemothercharge
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbItemothercharge
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbItemothercharge
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

