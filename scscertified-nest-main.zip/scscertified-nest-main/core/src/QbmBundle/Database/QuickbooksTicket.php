<?php

namespace QbmBundle\Entity;

/**
 * QuickbooksTicket
 */
class QuickbooksTicket
{
    /**
     * @var integer
     */
    private $quickbooksTicketId;

    /**
     * @var string
     */
    private $qbUsername;

    /**
     * @var string
     */
    private $ticket;

    /**
     * @var integer
     */
    private $processed = '0';

    /**
     * @var string
     */
    private $lasterrorNum;

    /**
     * @var string
     */
    private $lasterrorMsg;

    /**
     * @var string
     */
    private $ipaddr;

    /**
     * @var \DateTime
     */
    private $writeDatetime;

    /**
     * @var \DateTime
     */
    private $touchDatetime;


    /**
     * Get quickbooksTicketId
     *
     * @return integer
     */
    public function getQuickbooksTicketId()
    {
        return $this->quickbooksTicketId;
    }

    /**
     * Set qbUsername
     *
     * @param string $qbUsername
     *
     * @return QuickbooksTicket
     */
    public function setQbUsername($qbUsername)
    {
        $this->qbUsername = $qbUsername;

        return $this;
    }

    /**
     * Get qbUsername
     *
     * @return string
     */
    public function getQbUsername()
    {
        return $this->qbUsername;
    }

    /**
     * Set ticket
     *
     * @param string $ticket
     *
     * @return QuickbooksTicket
     */
    public function setTicket($ticket)
    {
        $this->ticket = $ticket;

        return $this;
    }

    /**
     * Get ticket
     *
     * @return string
     */
    public function getTicket()
    {
        return $this->ticket;
    }

    /**
     * Set processed
     *
     * @param integer $processed
     *
     * @return QuickbooksTicket
     */
    public function setProcessed($processed)
    {
        $this->processed = $processed;

        return $this;
    }

    /**
     * Get processed
     *
     * @return integer
     */
    public function getProcessed()
    {
        return $this->processed;
    }

    /**
     * Set lasterrorNum
     *
     * @param string $lasterrorNum
     *
     * @return QuickbooksTicket
     */
    public function setLasterrorNum($lasterrorNum)
    {
        $this->lasterrorNum = $lasterrorNum;

        return $this;
    }

    /**
     * Get lasterrorNum
     *
     * @return string
     */
    public function getLasterrorNum()
    {
        return $this->lasterrorNum;
    }

    /**
     * Set lasterrorMsg
     *
     * @param string $lasterrorMsg
     *
     * @return QuickbooksTicket
     */
    public function setLasterrorMsg($lasterrorMsg)
    {
        $this->lasterrorMsg = $lasterrorMsg;

        return $this;
    }

    /**
     * Get lasterrorMsg
     *
     * @return string
     */
    public function getLasterrorMsg()
    {
        return $this->lasterrorMsg;
    }

    /**
     * Set ipaddr
     *
     * @param string $ipaddr
     *
     * @return QuickbooksTicket
     */
    public function setIpaddr($ipaddr)
    {
        $this->ipaddr = $ipaddr;

        return $this;
    }

    /**
     * Get ipaddr
     *
     * @return string
     */
    public function getIpaddr()
    {
        return $this->ipaddr;
    }

    /**
     * Set writeDatetime
     *
     * @param \DateTime $writeDatetime
     *
     * @return QuickbooksTicket
     */
    public function setWriteDatetime($writeDatetime)
    {
        $this->writeDatetime = $writeDatetime;

        return $this;
    }

    /**
     * Get writeDatetime
     *
     * @return \DateTime
     */
    public function getWriteDatetime()
    {
        return $this->writeDatetime;
    }

    /**
     * Set touchDatetime
     *
     * @param \DateTime $touchDatetime
     *
     * @return QuickbooksTicket
     */
    public function setTouchDatetime($touchDatetime)
    {
        $this->touchDatetime = $touchDatetime;

        return $this;
    }

    /**
     * Get touchDatetime
     *
     * @return \DateTime
     */
    public function getTouchDatetime()
    {
        return $this->touchDatetime;
    }
}

