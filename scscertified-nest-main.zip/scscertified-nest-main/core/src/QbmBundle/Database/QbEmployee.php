<?php

namespace QbmBundle\Entity;

/**
 * QbEmployee
 */
class QbEmployee
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $listid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var string
     */
    private $name;

    /**
     * @var boolean
     */
    private $isactive = '0';

    /**
     * @var string
     */
    private $salutation;

    /**
     * @var string
     */
    private $firstname;

    /**
     * @var string
     */
    private $middlename;

    /**
     * @var string
     */
    private $lastname;

    /**
     * @var string
     */
    private $employeeaddressAddr1;

    /**
     * @var string
     */
    private $employeeaddressAddr2;

    /**
     * @var string
     */
    private $employeeaddressCity;

    /**
     * @var string
     */
    private $employeeaddressState;

    /**
     * @var string
     */
    private $employeeaddressPostalcode;

    /**
     * @var string
     */
    private $printas;

    /**
     * @var string
     */
    private $phone;

    /**
     * @var string
     */
    private $mobile;

    /**
     * @var string
     */
    private $pager;

    /**
     * @var string
     */
    private $pagerpin;

    /**
     * @var string
     */
    private $altphone;

    /**
     * @var string
     */
    private $fax;

    /**
     * @var string
     */
    private $ssn;

    /**
     * @var string
     */
    private $email;

    /**
     * @var string
     */
    private $employeetype;

    /**
     * @var string
     */
    private $gender;

    /**
     * @var \DateTime
     */
    private $hireddate;

    /**
     * @var \DateTime
     */
    private $releaseddate;

    /**
     * @var \DateTime
     */
    private $birthdate;

    /**
     * @var string
     */
    private $accountnumber;

    /**
     * @var string
     */
    private $notes;

    /**
     * @var string
     */
    private $billingrateListid;

    /**
     * @var string
     */
    private $billingrateFullname;

    /**
     * @var string
     */
    private $employeepayrollinfoPayperiod;

    /**
     * @var string
     */
    private $employeepayrollinfoClassListid;

    /**
     * @var string
     */
    private $employeepayrollinfoClassFullname;

    /**
     * @var boolean
     */
    private $employeepayrollinfoClearearnings;

    /**
     * @var boolean
     */
    private $employeepayrollinfoIsusingtimedatatocreatepaychecks;

    /**
     * @var string
     */
    private $employeepayrollinfoUsetimedatatocreatepaychecks;

    /**
     * @var string
     */
    private $employeepayrollinfoSickhoursHoursavailable;

    /**
     * @var string
     */
    private $employeepayrollinfoSickhoursAccrualperiod;

    /**
     * @var string
     */
    private $employeepayrollinfoSickhoursHoursaccrued;

    /**
     * @var string
     */
    private $employeepayrollinfoSickhoursMaximumhours;

    /**
     * @var boolean
     */
    private $employeepayrollinfoSickhoursIsresettinghourseachnewyear;

    /**
     * @var string
     */
    private $employeepayrollinfoSickhoursHoursused;

    /**
     * @var \DateTime
     */
    private $employeepayrollinfoSickhoursAccrualstartdate;

    /**
     * @var string
     */
    private $employeepayrollinfoVacationhoursHoursavailable;

    /**
     * @var string
     */
    private $employeepayrollinfoVacationhoursAccrualperiod;

    /**
     * @var string
     */
    private $employeepayrollinfoVacationhoursHoursaccrued;

    /**
     * @var string
     */
    private $employeepayrollinfoVacationhoursMaximumhours;

    /**
     * @var boolean
     */
    private $employeepayrollinfoVacationhoursIsresettinghourseachnewyear;

    /**
     * @var string
     */
    private $employeepayrollinfoVacationhoursHoursused;

    /**
     * @var \DateTime
     */
    private $employeepayrollinfoVacationhoursAccrualstartdate;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbEmployee
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbEmployee
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set listid
     *
     * @param string $listid
     *
     * @return QbEmployee
     */
    public function setListid($listid)
    {
        $this->listid = $listid;

        return $this;
    }

    /**
     * Get listid
     *
     * @return string
     */
    public function getListid()
    {
        return $this->listid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbEmployee
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbEmployee
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbEmployee
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return QbEmployee
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set isactive
     *
     * @param boolean $isactive
     *
     * @return QbEmployee
     */
    public function setIsactive($isactive)
    {
        $this->isactive = $isactive;

        return $this;
    }

    /**
     * Get isactive
     *
     * @return boolean
     */
    public function getIsactive()
    {
        return $this->isactive;
    }

    /**
     * Set salutation
     *
     * @param string $salutation
     *
     * @return QbEmployee
     */
    public function setSalutation($salutation)
    {
        $this->salutation = $salutation;

        return $this;
    }

    /**
     * Get salutation
     *
     * @return string
     */
    public function getSalutation()
    {
        return $this->salutation;
    }

    /**
     * Set firstname
     *
     * @param string $firstname
     *
     * @return QbEmployee
     */
    public function setFirstname($firstname)
    {
        $this->firstname = $firstname;

        return $this;
    }

    /**
     * Get firstname
     *
     * @return string
     */
    public function getFirstname()
    {
        return $this->firstname;
    }

    /**
     * Set middlename
     *
     * @param string $middlename
     *
     * @return QbEmployee
     */
    public function setMiddlename($middlename)
    {
        $this->middlename = $middlename;

        return $this;
    }

    /**
     * Get middlename
     *
     * @return string
     */
    public function getMiddlename()
    {
        return $this->middlename;
    }

    /**
     * Set lastname
     *
     * @param string $lastname
     *
     * @return QbEmployee
     */
    public function setLastname($lastname)
    {
        $this->lastname = $lastname;

        return $this;
    }

    /**
     * Get lastname
     *
     * @return string
     */
    public function getLastname()
    {
        return $this->lastname;
    }

    /**
     * Set employeeaddressAddr1
     *
     * @param string $employeeaddressAddr1
     *
     * @return QbEmployee
     */
    public function setEmployeeaddressAddr1($employeeaddressAddr1)
    {
        $this->employeeaddressAddr1 = $employeeaddressAddr1;

        return $this;
    }

    /**
     * Get employeeaddressAddr1
     *
     * @return string
     */
    public function getEmployeeaddressAddr1()
    {
        return $this->employeeaddressAddr1;
    }

    /**
     * Set employeeaddressAddr2
     *
     * @param string $employeeaddressAddr2
     *
     * @return QbEmployee
     */
    public function setEmployeeaddressAddr2($employeeaddressAddr2)
    {
        $this->employeeaddressAddr2 = $employeeaddressAddr2;

        return $this;
    }

    /**
     * Get employeeaddressAddr2
     *
     * @return string
     */
    public function getEmployeeaddressAddr2()
    {
        return $this->employeeaddressAddr2;
    }

    /**
     * Set employeeaddressCity
     *
     * @param string $employeeaddressCity
     *
     * @return QbEmployee
     */
    public function setEmployeeaddressCity($employeeaddressCity)
    {
        $this->employeeaddressCity = $employeeaddressCity;

        return $this;
    }

    /**
     * Get employeeaddressCity
     *
     * @return string
     */
    public function getEmployeeaddressCity()
    {
        return $this->employeeaddressCity;
    }

    /**
     * Set employeeaddressState
     *
     * @param string $employeeaddressState
     *
     * @return QbEmployee
     */
    public function setEmployeeaddressState($employeeaddressState)
    {
        $this->employeeaddressState = $employeeaddressState;

        return $this;
    }

    /**
     * Get employeeaddressState
     *
     * @return string
     */
    public function getEmployeeaddressState()
    {
        return $this->employeeaddressState;
    }

    /**
     * Set employeeaddressPostalcode
     *
     * @param string $employeeaddressPostalcode
     *
     * @return QbEmployee
     */
    public function setEmployeeaddressPostalcode($employeeaddressPostalcode)
    {
        $this->employeeaddressPostalcode = $employeeaddressPostalcode;

        return $this;
    }

    /**
     * Get employeeaddressPostalcode
     *
     * @return string
     */
    public function getEmployeeaddressPostalcode()
    {
        return $this->employeeaddressPostalcode;
    }

    /**
     * Set printas
     *
     * @param string $printas
     *
     * @return QbEmployee
     */
    public function setPrintas($printas)
    {
        $this->printas = $printas;

        return $this;
    }

    /**
     * Get printas
     *
     * @return string
     */
    public function getPrintas()
    {
        return $this->printas;
    }

    /**
     * Set phone
     *
     * @param string $phone
     *
     * @return QbEmployee
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set mobile
     *
     * @param string $mobile
     *
     * @return QbEmployee
     */
    public function setMobile($mobile)
    {
        $this->mobile = $mobile;

        return $this;
    }

    /**
     * Get mobile
     *
     * @return string
     */
    public function getMobile()
    {
        return $this->mobile;
    }

    /**
     * Set pager
     *
     * @param string $pager
     *
     * @return QbEmployee
     */
    public function setPager($pager)
    {
        $this->pager = $pager;

        return $this;
    }

    /**
     * Get pager
     *
     * @return string
     */
    public function getPager()
    {
        return $this->pager;
    }

    /**
     * Set pagerpin
     *
     * @param string $pagerpin
     *
     * @return QbEmployee
     */
    public function setPagerpin($pagerpin)
    {
        $this->pagerpin = $pagerpin;

        return $this;
    }

    /**
     * Get pagerpin
     *
     * @return string
     */
    public function getPagerpin()
    {
        return $this->pagerpin;
    }

    /**
     * Set altphone
     *
     * @param string $altphone
     *
     * @return QbEmployee
     */
    public function setAltphone($altphone)
    {
        $this->altphone = $altphone;

        return $this;
    }

    /**
     * Get altphone
     *
     * @return string
     */
    public function getAltphone()
    {
        return $this->altphone;
    }

    /**
     * Set fax
     *
     * @param string $fax
     *
     * @return QbEmployee
     */
    public function setFax($fax)
    {
        $this->fax = $fax;

        return $this;
    }

    /**
     * Get fax
     *
     * @return string
     */
    public function getFax()
    {
        return $this->fax;
    }

    /**
     * Set ssn
     *
     * @param string $ssn
     *
     * @return QbEmployee
     */
    public function setSsn($ssn)
    {
        $this->ssn = $ssn;

        return $this;
    }

    /**
     * Get ssn
     *
     * @return string
     */
    public function getSsn()
    {
        return $this->ssn;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return QbEmployee
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set employeetype
     *
     * @param string $employeetype
     *
     * @return QbEmployee
     */
    public function setEmployeetype($employeetype)
    {
        $this->employeetype = $employeetype;

        return $this;
    }

    /**
     * Get employeetype
     *
     * @return string
     */
    public function getEmployeetype()
    {
        return $this->employeetype;
    }

    /**
     * Set gender
     *
     * @param string $gender
     *
     * @return QbEmployee
     */
    public function setGender($gender)
    {
        $this->gender = $gender;

        return $this;
    }

    /**
     * Get gender
     *
     * @return string
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     * Set hireddate
     *
     * @param \DateTime $hireddate
     *
     * @return QbEmployee
     */
    public function setHireddate($hireddate)
    {
        $this->hireddate = $hireddate;

        return $this;
    }

    /**
     * Get hireddate
     *
     * @return \DateTime
     */
    public function getHireddate()
    {
        return $this->hireddate;
    }

    /**
     * Set releaseddate
     *
     * @param \DateTime $releaseddate
     *
     * @return QbEmployee
     */
    public function setReleaseddate($releaseddate)
    {
        $this->releaseddate = $releaseddate;

        return $this;
    }

    /**
     * Get releaseddate
     *
     * @return \DateTime
     */
    public function getReleaseddate()
    {
        return $this->releaseddate;
    }

    /**
     * Set birthdate
     *
     * @param \DateTime $birthdate
     *
     * @return QbEmployee
     */
    public function setBirthdate($birthdate)
    {
        $this->birthdate = $birthdate;

        return $this;
    }

    /**
     * Get birthdate
     *
     * @return \DateTime
     */
    public function getBirthdate()
    {
        return $this->birthdate;
    }

    /**
     * Set accountnumber
     *
     * @param string $accountnumber
     *
     * @return QbEmployee
     */
    public function setAccountnumber($accountnumber)
    {
        $this->accountnumber = $accountnumber;

        return $this;
    }

    /**
     * Get accountnumber
     *
     * @return string
     */
    public function getAccountnumber()
    {
        return $this->accountnumber;
    }

    /**
     * Set notes
     *
     * @param string $notes
     *
     * @return QbEmployee
     */
    public function setNotes($notes)
    {
        $this->notes = $notes;

        return $this;
    }

    /**
     * Get notes
     *
     * @return string
     */
    public function getNotes()
    {
        return $this->notes;
    }

    /**
     * Set billingrateListid
     *
     * @param string $billingrateListid
     *
     * @return QbEmployee
     */
    public function setBillingrateListid($billingrateListid)
    {
        $this->billingrateListid = $billingrateListid;

        return $this;
    }

    /**
     * Get billingrateListid
     *
     * @return string
     */
    public function getBillingrateListid()
    {
        return $this->billingrateListid;
    }

    /**
     * Set billingrateFullname
     *
     * @param string $billingrateFullname
     *
     * @return QbEmployee
     */
    public function setBillingrateFullname($billingrateFullname)
    {
        $this->billingrateFullname = $billingrateFullname;

        return $this;
    }

    /**
     * Get billingrateFullname
     *
     * @return string
     */
    public function getBillingrateFullname()
    {
        return $this->billingrateFullname;
    }

    /**
     * Set employeepayrollinfoPayperiod
     *
     * @param string $employeepayrollinfoPayperiod
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoPayperiod($employeepayrollinfoPayperiod)
    {
        $this->employeepayrollinfoPayperiod = $employeepayrollinfoPayperiod;

        return $this;
    }

    /**
     * Get employeepayrollinfoPayperiod
     *
     * @return string
     */
    public function getEmployeepayrollinfoPayperiod()
    {
        return $this->employeepayrollinfoPayperiod;
    }

    /**
     * Set employeepayrollinfoClassListid
     *
     * @param string $employeepayrollinfoClassListid
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoClassListid($employeepayrollinfoClassListid)
    {
        $this->employeepayrollinfoClassListid = $employeepayrollinfoClassListid;

        return $this;
    }

    /**
     * Get employeepayrollinfoClassListid
     *
     * @return string
     */
    public function getEmployeepayrollinfoClassListid()
    {
        return $this->employeepayrollinfoClassListid;
    }

    /**
     * Set employeepayrollinfoClassFullname
     *
     * @param string $employeepayrollinfoClassFullname
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoClassFullname($employeepayrollinfoClassFullname)
    {
        $this->employeepayrollinfoClassFullname = $employeepayrollinfoClassFullname;

        return $this;
    }

    /**
     * Get employeepayrollinfoClassFullname
     *
     * @return string
     */
    public function getEmployeepayrollinfoClassFullname()
    {
        return $this->employeepayrollinfoClassFullname;
    }

    /**
     * Set employeepayrollinfoClearearnings
     *
     * @param boolean $employeepayrollinfoClearearnings
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoClearearnings($employeepayrollinfoClearearnings)
    {
        $this->employeepayrollinfoClearearnings = $employeepayrollinfoClearearnings;

        return $this;
    }

    /**
     * Get employeepayrollinfoClearearnings
     *
     * @return boolean
     */
    public function getEmployeepayrollinfoClearearnings()
    {
        return $this->employeepayrollinfoClearearnings;
    }

    /**
     * Set employeepayrollinfoIsusingtimedatatocreatepaychecks
     *
     * @param boolean $employeepayrollinfoIsusingtimedatatocreatepaychecks
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoIsusingtimedatatocreatepaychecks($employeepayrollinfoIsusingtimedatatocreatepaychecks)
    {
        $this->employeepayrollinfoIsusingtimedatatocreatepaychecks = $employeepayrollinfoIsusingtimedatatocreatepaychecks;

        return $this;
    }

    /**
     * Get employeepayrollinfoIsusingtimedatatocreatepaychecks
     *
     * @return boolean
     */
    public function getEmployeepayrollinfoIsusingtimedatatocreatepaychecks()
    {
        return $this->employeepayrollinfoIsusingtimedatatocreatepaychecks;
    }

    /**
     * Set employeepayrollinfoUsetimedatatocreatepaychecks
     *
     * @param string $employeepayrollinfoUsetimedatatocreatepaychecks
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoUsetimedatatocreatepaychecks($employeepayrollinfoUsetimedatatocreatepaychecks)
    {
        $this->employeepayrollinfoUsetimedatatocreatepaychecks = $employeepayrollinfoUsetimedatatocreatepaychecks;

        return $this;
    }

    /**
     * Get employeepayrollinfoUsetimedatatocreatepaychecks
     *
     * @return string
     */
    public function getEmployeepayrollinfoUsetimedatatocreatepaychecks()
    {
        return $this->employeepayrollinfoUsetimedatatocreatepaychecks;
    }

    /**
     * Set employeepayrollinfoSickhoursHoursavailable
     *
     * @param string $employeepayrollinfoSickhoursHoursavailable
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoSickhoursHoursavailable($employeepayrollinfoSickhoursHoursavailable)
    {
        $this->employeepayrollinfoSickhoursHoursavailable = $employeepayrollinfoSickhoursHoursavailable;

        return $this;
    }

    /**
     * Get employeepayrollinfoSickhoursHoursavailable
     *
     * @return string
     */
    public function getEmployeepayrollinfoSickhoursHoursavailable()
    {
        return $this->employeepayrollinfoSickhoursHoursavailable;
    }

    /**
     * Set employeepayrollinfoSickhoursAccrualperiod
     *
     * @param string $employeepayrollinfoSickhoursAccrualperiod
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoSickhoursAccrualperiod($employeepayrollinfoSickhoursAccrualperiod)
    {
        $this->employeepayrollinfoSickhoursAccrualperiod = $employeepayrollinfoSickhoursAccrualperiod;

        return $this;
    }

    /**
     * Get employeepayrollinfoSickhoursAccrualperiod
     *
     * @return string
     */
    public function getEmployeepayrollinfoSickhoursAccrualperiod()
    {
        return $this->employeepayrollinfoSickhoursAccrualperiod;
    }

    /**
     * Set employeepayrollinfoSickhoursHoursaccrued
     *
     * @param string $employeepayrollinfoSickhoursHoursaccrued
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoSickhoursHoursaccrued($employeepayrollinfoSickhoursHoursaccrued)
    {
        $this->employeepayrollinfoSickhoursHoursaccrued = $employeepayrollinfoSickhoursHoursaccrued;

        return $this;
    }

    /**
     * Get employeepayrollinfoSickhoursHoursaccrued
     *
     * @return string
     */
    public function getEmployeepayrollinfoSickhoursHoursaccrued()
    {
        return $this->employeepayrollinfoSickhoursHoursaccrued;
    }

    /**
     * Set employeepayrollinfoSickhoursMaximumhours
     *
     * @param string $employeepayrollinfoSickhoursMaximumhours
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoSickhoursMaximumhours($employeepayrollinfoSickhoursMaximumhours)
    {
        $this->employeepayrollinfoSickhoursMaximumhours = $employeepayrollinfoSickhoursMaximumhours;

        return $this;
    }

    /**
     * Get employeepayrollinfoSickhoursMaximumhours
     *
     * @return string
     */
    public function getEmployeepayrollinfoSickhoursMaximumhours()
    {
        return $this->employeepayrollinfoSickhoursMaximumhours;
    }

    /**
     * Set employeepayrollinfoSickhoursIsresettinghourseachnewyear
     *
     * @param boolean $employeepayrollinfoSickhoursIsresettinghourseachnewyear
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoSickhoursIsresettinghourseachnewyear($employeepayrollinfoSickhoursIsresettinghourseachnewyear)
    {
        $this->employeepayrollinfoSickhoursIsresettinghourseachnewyear = $employeepayrollinfoSickhoursIsresettinghourseachnewyear;

        return $this;
    }

    /**
     * Get employeepayrollinfoSickhoursIsresettinghourseachnewyear
     *
     * @return boolean
     */
    public function getEmployeepayrollinfoSickhoursIsresettinghourseachnewyear()
    {
        return $this->employeepayrollinfoSickhoursIsresettinghourseachnewyear;
    }

    /**
     * Set employeepayrollinfoSickhoursHoursused
     *
     * @param string $employeepayrollinfoSickhoursHoursused
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoSickhoursHoursused($employeepayrollinfoSickhoursHoursused)
    {
        $this->employeepayrollinfoSickhoursHoursused = $employeepayrollinfoSickhoursHoursused;

        return $this;
    }

    /**
     * Get employeepayrollinfoSickhoursHoursused
     *
     * @return string
     */
    public function getEmployeepayrollinfoSickhoursHoursused()
    {
        return $this->employeepayrollinfoSickhoursHoursused;
    }

    /**
     * Set employeepayrollinfoSickhoursAccrualstartdate
     *
     * @param \DateTime $employeepayrollinfoSickhoursAccrualstartdate
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoSickhoursAccrualstartdate($employeepayrollinfoSickhoursAccrualstartdate)
    {
        $this->employeepayrollinfoSickhoursAccrualstartdate = $employeepayrollinfoSickhoursAccrualstartdate;

        return $this;
    }

    /**
     * Get employeepayrollinfoSickhoursAccrualstartdate
     *
     * @return \DateTime
     */
    public function getEmployeepayrollinfoSickhoursAccrualstartdate()
    {
        return $this->employeepayrollinfoSickhoursAccrualstartdate;
    }

    /**
     * Set employeepayrollinfoVacationhoursHoursavailable
     *
     * @param string $employeepayrollinfoVacationhoursHoursavailable
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoVacationhoursHoursavailable($employeepayrollinfoVacationhoursHoursavailable)
    {
        $this->employeepayrollinfoVacationhoursHoursavailable = $employeepayrollinfoVacationhoursHoursavailable;

        return $this;
    }

    /**
     * Get employeepayrollinfoVacationhoursHoursavailable
     *
     * @return string
     */
    public function getEmployeepayrollinfoVacationhoursHoursavailable()
    {
        return $this->employeepayrollinfoVacationhoursHoursavailable;
    }

    /**
     * Set employeepayrollinfoVacationhoursAccrualperiod
     *
     * @param string $employeepayrollinfoVacationhoursAccrualperiod
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoVacationhoursAccrualperiod($employeepayrollinfoVacationhoursAccrualperiod)
    {
        $this->employeepayrollinfoVacationhoursAccrualperiod = $employeepayrollinfoVacationhoursAccrualperiod;

        return $this;
    }

    /**
     * Get employeepayrollinfoVacationhoursAccrualperiod
     *
     * @return string
     */
    public function getEmployeepayrollinfoVacationhoursAccrualperiod()
    {
        return $this->employeepayrollinfoVacationhoursAccrualperiod;
    }

    /**
     * Set employeepayrollinfoVacationhoursHoursaccrued
     *
     * @param string $employeepayrollinfoVacationhoursHoursaccrued
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoVacationhoursHoursaccrued($employeepayrollinfoVacationhoursHoursaccrued)
    {
        $this->employeepayrollinfoVacationhoursHoursaccrued = $employeepayrollinfoVacationhoursHoursaccrued;

        return $this;
    }

    /**
     * Get employeepayrollinfoVacationhoursHoursaccrued
     *
     * @return string
     */
    public function getEmployeepayrollinfoVacationhoursHoursaccrued()
    {
        return $this->employeepayrollinfoVacationhoursHoursaccrued;
    }

    /**
     * Set employeepayrollinfoVacationhoursMaximumhours
     *
     * @param string $employeepayrollinfoVacationhoursMaximumhours
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoVacationhoursMaximumhours($employeepayrollinfoVacationhoursMaximumhours)
    {
        $this->employeepayrollinfoVacationhoursMaximumhours = $employeepayrollinfoVacationhoursMaximumhours;

        return $this;
    }

    /**
     * Get employeepayrollinfoVacationhoursMaximumhours
     *
     * @return string
     */
    public function getEmployeepayrollinfoVacationhoursMaximumhours()
    {
        return $this->employeepayrollinfoVacationhoursMaximumhours;
    }

    /**
     * Set employeepayrollinfoVacationhoursIsresettinghourseachnewyear
     *
     * @param boolean $employeepayrollinfoVacationhoursIsresettinghourseachnewyear
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoVacationhoursIsresettinghourseachnewyear($employeepayrollinfoVacationhoursIsresettinghourseachnewyear)
    {
        $this->employeepayrollinfoVacationhoursIsresettinghourseachnewyear = $employeepayrollinfoVacationhoursIsresettinghourseachnewyear;

        return $this;
    }

    /**
     * Get employeepayrollinfoVacationhoursIsresettinghourseachnewyear
     *
     * @return boolean
     */
    public function getEmployeepayrollinfoVacationhoursIsresettinghourseachnewyear()
    {
        return $this->employeepayrollinfoVacationhoursIsresettinghourseachnewyear;
    }

    /**
     * Set employeepayrollinfoVacationhoursHoursused
     *
     * @param string $employeepayrollinfoVacationhoursHoursused
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoVacationhoursHoursused($employeepayrollinfoVacationhoursHoursused)
    {
        $this->employeepayrollinfoVacationhoursHoursused = $employeepayrollinfoVacationhoursHoursused;

        return $this;
    }

    /**
     * Get employeepayrollinfoVacationhoursHoursused
     *
     * @return string
     */
    public function getEmployeepayrollinfoVacationhoursHoursused()
    {
        return $this->employeepayrollinfoVacationhoursHoursused;
    }

    /**
     * Set employeepayrollinfoVacationhoursAccrualstartdate
     *
     * @param \DateTime $employeepayrollinfoVacationhoursAccrualstartdate
     *
     * @return QbEmployee
     */
    public function setEmployeepayrollinfoVacationhoursAccrualstartdate($employeepayrollinfoVacationhoursAccrualstartdate)
    {
        $this->employeepayrollinfoVacationhoursAccrualstartdate = $employeepayrollinfoVacationhoursAccrualstartdate;

        return $this;
    }

    /**
     * Get employeepayrollinfoVacationhoursAccrualstartdate
     *
     * @return \DateTime
     */
    public function getEmployeepayrollinfoVacationhoursAccrualstartdate()
    {
        return $this->employeepayrollinfoVacationhoursAccrualstartdate;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbEmployee
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbEmployee
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbEmployee
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbEmployee
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbEmployee
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbEmployee
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbEmployee
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbEmployee
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbEmployee
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbEmployee
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbEmployee
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbEmployee
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbEmployee
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbEmployee
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbEmployee
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbEmployee
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbEmployee
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbEmployee
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

