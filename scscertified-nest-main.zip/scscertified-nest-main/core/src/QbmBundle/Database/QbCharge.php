<?php

namespace QbmBundle\Entity;

/**
 * QbCharge
 */
class QbCharge
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $ispaid;

    /**
     * @var string
     */
    private $txnid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var integer
     */
    private $txnnumber = '0';

    /**
     * @var string
     */
    private $customerListid;

    /**
     * @var string
     */
    private $customerFullname;

    /**
     * @var \DateTime
     */
    private $txndate;

    /**
     * @var string
     */
    private $refnumber;

    /**
     * @var string
     */
    private $itemListid;

    /**
     * @var string
     */
    private $itemFullname;

    /**
     * @var string
     */
    private $quantity = '0.00000';

    /**
     * @var string
     */
    private $rate;

    /**
     * @var string
     */
    private $amount;

    /**
     * @var string
     */
    private $balanceremaining;

    /**
     * @var string
     */
    private $descrip;

    /**
     * @var string
     */
    private $araccountListid;

    /**
     * @var string
     */
    private $araccountFullname;

    /**
     * @var string
     */
    private $classListid;

    /**
     * @var string
     */
    private $classFullname;

    /**
     * @var \DateTime
     */
    private $billeddate;

    /**
     * @var \DateTime
     */
    private $duedate;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbCharge
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbCharge
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set ispaid
     *
     * @param string $ispaid
     *
     * @return QbCharge
     */
    public function setIspaid($ispaid)
    {
        $this->ispaid = $ispaid;

        return $this;
    }

    /**
     * Get ispaid
     *
     * @return string
     */
    public function getIspaid()
    {
        return $this->ispaid;
    }

    /**
     * Set txnid
     *
     * @param string $txnid
     *
     * @return QbCharge
     */
    public function setTxnid($txnid)
    {
        $this->txnid = $txnid;

        return $this;
    }

    /**
     * Get txnid
     *
     * @return string
     */
    public function getTxnid()
    {
        return $this->txnid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbCharge
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbCharge
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbCharge
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set txnnumber
     *
     * @param integer $txnnumber
     *
     * @return QbCharge
     */
    public function setTxnnumber($txnnumber)
    {
        $this->txnnumber = $txnnumber;

        return $this;
    }

    /**
     * Get txnnumber
     *
     * @return integer
     */
    public function getTxnnumber()
    {
        return $this->txnnumber;
    }

    /**
     * Set customerListid
     *
     * @param string $customerListid
     *
     * @return QbCharge
     */
    public function setCustomerListid($customerListid)
    {
        $this->customerListid = $customerListid;

        return $this;
    }

    /**
     * Get customerListid
     *
     * @return string
     */
    public function getCustomerListid()
    {
        return $this->customerListid;
    }

    /**
     * Set customerFullname
     *
     * @param string $customerFullname
     *
     * @return QbCharge
     */
    public function setCustomerFullname($customerFullname)
    {
        $this->customerFullname = $customerFullname;

        return $this;
    }

    /**
     * Get customerFullname
     *
     * @return string
     */
    public function getCustomerFullname()
    {
        return $this->customerFullname;
    }

    /**
     * Set txndate
     *
     * @param \DateTime $txndate
     *
     * @return QbCharge
     */
    public function setTxndate($txndate)
    {
        $this->txndate = $txndate;

        return $this;
    }

    /**
     * Get txndate
     *
     * @return \DateTime
     */
    public function getTxndate()
    {
        return $this->txndate;
    }

    /**
     * Set refnumber
     *
     * @param string $refnumber
     *
     * @return QbCharge
     */
    public function setRefnumber($refnumber)
    {
        $this->refnumber = $refnumber;

        return $this;
    }

    /**
     * Get refnumber
     *
     * @return string
     */
    public function getRefnumber()
    {
        return $this->refnumber;
    }

    /**
     * Set itemListid
     *
     * @param string $itemListid
     *
     * @return QbCharge
     */
    public function setItemListid($itemListid)
    {
        $this->itemListid = $itemListid;

        return $this;
    }

    /**
     * Get itemListid
     *
     * @return string
     */
    public function getItemListid()
    {
        return $this->itemListid;
    }

    /**
     * Set itemFullname
     *
     * @param string $itemFullname
     *
     * @return QbCharge
     */
    public function setItemFullname($itemFullname)
    {
        $this->itemFullname = $itemFullname;

        return $this;
    }

    /**
     * Get itemFullname
     *
     * @return string
     */
    public function getItemFullname()
    {
        return $this->itemFullname;
    }

    /**
     * Set quantity
     *
     * @param string $quantity
     *
     * @return QbCharge
     */
    public function setQuantity($quantity)
    {
        $this->quantity = $quantity;

        return $this;
    }

    /**
     * Get quantity
     *
     * @return string
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * Set rate
     *
     * @param string $rate
     *
     * @return QbCharge
     */
    public function setRate($rate)
    {
        $this->rate = $rate;

        return $this;
    }

    /**
     * Get rate
     *
     * @return string
     */
    public function getRate()
    {
        return $this->rate;
    }

    /**
     * Set amount
     *
     * @param string $amount
     *
     * @return QbCharge
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return string
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set balanceremaining
     *
     * @param string $balanceremaining
     *
     * @return QbCharge
     */
    public function setBalanceremaining($balanceremaining)
    {
        $this->balanceremaining = $balanceremaining;

        return $this;
    }

    /**
     * Get balanceremaining
     *
     * @return string
     */
    public function getBalanceremaining()
    {
        return $this->balanceremaining;
    }

    /**
     * Set descrip
     *
     * @param string $descrip
     *
     * @return QbCharge
     */
    public function setDescrip($descrip)
    {
        $this->descrip = $descrip;

        return $this;
    }

    /**
     * Get descrip
     *
     * @return string
     */
    public function getDescrip()
    {
        return $this->descrip;
    }

    /**
     * Set araccountListid
     *
     * @param string $araccountListid
     *
     * @return QbCharge
     */
    public function setAraccountListid($araccountListid)
    {
        $this->araccountListid = $araccountListid;

        return $this;
    }

    /**
     * Get araccountListid
     *
     * @return string
     */
    public function getAraccountListid()
    {
        return $this->araccountListid;
    }

    /**
     * Set araccountFullname
     *
     * @param string $araccountFullname
     *
     * @return QbCharge
     */
    public function setAraccountFullname($araccountFullname)
    {
        $this->araccountFullname = $araccountFullname;

        return $this;
    }

    /**
     * Get araccountFullname
     *
     * @return string
     */
    public function getAraccountFullname()
    {
        return $this->araccountFullname;
    }

    /**
     * Set classListid
     *
     * @param string $classListid
     *
     * @return QbCharge
     */
    public function setClassListid($classListid)
    {
        $this->classListid = $classListid;

        return $this;
    }

    /**
     * Get classListid
     *
     * @return string
     */
    public function getClassListid()
    {
        return $this->classListid;
    }

    /**
     * Set classFullname
     *
     * @param string $classFullname
     *
     * @return QbCharge
     */
    public function setClassFullname($classFullname)
    {
        $this->classFullname = $classFullname;

        return $this;
    }

    /**
     * Get classFullname
     *
     * @return string
     */
    public function getClassFullname()
    {
        return $this->classFullname;
    }

    /**
     * Set billeddate
     *
     * @param \DateTime $billeddate
     *
     * @return QbCharge
     */
    public function setBilleddate($billeddate)
    {
        $this->billeddate = $billeddate;

        return $this;
    }

    /**
     * Get billeddate
     *
     * @return \DateTime
     */
    public function getBilleddate()
    {
        return $this->billeddate;
    }

    /**
     * Set duedate
     *
     * @param \DateTime $duedate
     *
     * @return QbCharge
     */
    public function setDuedate($duedate)
    {
        $this->duedate = $duedate;

        return $this;
    }

    /**
     * Get duedate
     *
     * @return \DateTime
     */
    public function getDuedate()
    {
        return $this->duedate;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbCharge
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbCharge
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbCharge
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbCharge
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbCharge
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbCharge
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbCharge
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbCharge
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbCharge
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbCharge
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbCharge
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbCharge
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbCharge
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbCharge
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbCharge
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbCharge
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbCharge
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbCharge
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

