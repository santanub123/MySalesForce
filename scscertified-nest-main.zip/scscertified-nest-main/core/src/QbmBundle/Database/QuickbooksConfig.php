<?php

namespace QbmBundle\Entity;

/**
 * QuickbooksConfig
 */
class QuickbooksConfig
{
    /**
     * @var integer
     */
    private $quickbooksConfigId;

    /**
     * @var string
     */
    private $qbUsername;

    /**
     * @var string
     */
    private $module;

    /**
     * @var string
     */
    private $cfgkey;

    /**
     * @var string
     */
    private $cfgval;

    /**
     * @var string
     */
    private $cfgtype;

    /**
     * @var string
     */
    private $cfgopts;

    /**
     * @var \DateTime
     */
    private $writeDatetime;

    /**
     * @var \DateTime
     */
    private $modDatetime;


    /**
     * Get quickbooksConfigId
     *
     * @return integer
     */
    public function getQuickbooksConfigId()
    {
        return $this->quickbooksConfigId;
    }

    /**
     * Set qbUsername
     *
     * @param string $qbUsername
     *
     * @return QuickbooksConfig
     */
    public function setQbUsername($qbUsername)
    {
        $this->qbUsername = $qbUsername;

        return $this;
    }

    /**
     * Get qbUsername
     *
     * @return string
     */
    public function getQbUsername()
    {
        return $this->qbUsername;
    }

    /**
     * Set module
     *
     * @param string $module
     *
     * @return QuickbooksConfig
     */
    public function setModule($module)
    {
        $this->module = $module;

        return $this;
    }

    /**
     * Get module
     *
     * @return string
     */
    public function getModule()
    {
        return $this->module;
    }

    /**
     * Set cfgkey
     *
     * @param string $cfgkey
     *
     * @return QuickbooksConfig
     */
    public function setCfgkey($cfgkey)
    {
        $this->cfgkey = $cfgkey;

        return $this;
    }

    /**
     * Get cfgkey
     *
     * @return string
     */
    public function getCfgkey()
    {
        return $this->cfgkey;
    }

    /**
     * Set cfgval
     *
     * @param string $cfgval
     *
     * @return QuickbooksConfig
     */
    public function setCfgval($cfgval)
    {
        $this->cfgval = $cfgval;

        return $this;
    }

    /**
     * Get cfgval
     *
     * @return string
     */
    public function getCfgval()
    {
        return $this->cfgval;
    }

    /**
     * Set cfgtype
     *
     * @param string $cfgtype
     *
     * @return QuickbooksConfig
     */
    public function setCfgtype($cfgtype)
    {
        $this->cfgtype = $cfgtype;

        return $this;
    }

    /**
     * Get cfgtype
     *
     * @return string
     */
    public function getCfgtype()
    {
        return $this->cfgtype;
    }

    /**
     * Set cfgopts
     *
     * @param string $cfgopts
     *
     * @return QuickbooksConfig
     */
    public function setCfgopts($cfgopts)
    {
        $this->cfgopts = $cfgopts;

        return $this;
    }

    /**
     * Get cfgopts
     *
     * @return string
     */
    public function getCfgopts()
    {
        return $this->cfgopts;
    }

    /**
     * Set writeDatetime
     *
     * @param \DateTime $writeDatetime
     *
     * @return QuickbooksConfig
     */
    public function setWriteDatetime($writeDatetime)
    {
        $this->writeDatetime = $writeDatetime;

        return $this;
    }

    /**
     * Get writeDatetime
     *
     * @return \DateTime
     */
    public function getWriteDatetime()
    {
        return $this->writeDatetime;
    }

    /**
     * Set modDatetime
     *
     * @param \DateTime $modDatetime
     *
     * @return QuickbooksConfig
     */
    public function setModDatetime($modDatetime)
    {
        $this->modDatetime = $modDatetime;

        return $this;
    }

    /**
     * Get modDatetime
     *
     * @return \DateTime
     */
    public function getModDatetime()
    {
        return $this->modDatetime;
    }
}

