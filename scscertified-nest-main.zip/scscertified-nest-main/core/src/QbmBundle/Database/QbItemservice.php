<?php

namespace QbmBundle\Entity;

/**
 * QbItemservice
 */
class QbItemservice
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $listid;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $fullname;

    /**
     * @var boolean
     */
    private $isactive = '0';

    /**
     * @var string
     */
    private $parentListid;

    /**
     * @var string
     */
    private $parentFullname;

    /**
     * @var integer
     */
    private $sublevel = '0';

    /**
     * @var string
     */
    private $unitofmeasuresetListid;

    /**
     * @var string
     */
    private $unitofmeasuresetFullname;

    /**
     * @var string
     */
    private $salestaxcodeListid;

    /**
     * @var string
     */
    private $salestaxcodeFullname;

    /**
     * @var string
     */
    private $salesorpurchaseDesc;

    /**
     * @var string
     */
    private $salesorpurchasePrice;

    /**
     * @var string
     */
    private $salesorpurchasePricepercent;

    /**
     * @var string
     */
    private $salesorpurchaseAccountListid;

    /**
     * @var string
     */
    private $salesorpurchaseAccountFullname;

    /**
     * @var string
     */
    private $salesandpurchaseSalesdesc;

    /**
     * @var string
     */
    private $salesandpurchaseSalesprice;

    /**
     * @var string
     */
    private $salesandpurchaseIncomeaccountListid;

    /**
     * @var string
     */
    private $salesandpurchaseIncomeaccountFullname;

    /**
     * @var string
     */
    private $salesandpurchasePurchasedesc;

    /**
     * @var string
     */
    private $salesandpurchasePurchasecost;

    /**
     * @var string
     */
    private $salesandpurchaseExpenseaccountListid;

    /**
     * @var string
     */
    private $salesandpurchaseExpenseaccountFullname;

    /**
     * @var string
     */
    private $salesandpurchasePrefvendorListid;

    /**
     * @var string
     */
    private $salesandpurchasePrefvendorFullname;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbItemservice
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbItemservice
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set listid
     *
     * @param string $listid
     *
     * @return QbItemservice
     */
    public function setListid($listid)
    {
        $this->listid = $listid;

        return $this;
    }

    /**
     * Get listid
     *
     * @return string
     */
    public function getListid()
    {
        return $this->listid;
    }

    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbItemservice
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbItemservice
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbItemservice
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return QbItemservice
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set fullname
     *
     * @param string $fullname
     *
     * @return QbItemservice
     */
    public function setFullname($fullname)
    {
        $this->fullname = $fullname;

        return $this;
    }

    /**
     * Get fullname
     *
     * @return string
     */
    public function getFullname()
    {
        return $this->fullname;
    }

    /**
     * Set isactive
     *
     * @param boolean $isactive
     *
     * @return QbItemservice
     */
    public function setIsactive($isactive)
    {
        $this->isactive = $isactive;

        return $this;
    }

    /**
     * Get isactive
     *
     * @return boolean
     */
    public function getIsactive()
    {
        return $this->isactive;
    }

    /**
     * Set parentListid
     *
     * @param string $parentListid
     *
     * @return QbItemservice
     */
    public function setParentListid($parentListid)
    {
        $this->parentListid = $parentListid;

        return $this;
    }

    /**
     * Get parentListid
     *
     * @return string
     */
    public function getParentListid()
    {
        return $this->parentListid;
    }

    /**
     * Set parentFullname
     *
     * @param string $parentFullname
     *
     * @return QbItemservice
     */
    public function setParentFullname($parentFullname)
    {
        $this->parentFullname = $parentFullname;

        return $this;
    }

    /**
     * Get parentFullname
     *
     * @return string
     */
    public function getParentFullname()
    {
        return $this->parentFullname;
    }

    /**
     * Set sublevel
     *
     * @param integer $sublevel
     *
     * @return QbItemservice
     */
    public function setSublevel($sublevel)
    {
        $this->sublevel = $sublevel;

        return $this;
    }

    /**
     * Get sublevel
     *
     * @return integer
     */
    public function getSublevel()
    {
        return $this->sublevel;
    }

    /**
     * Set unitofmeasuresetListid
     *
     * @param string $unitofmeasuresetListid
     *
     * @return QbItemservice
     */
    public function setUnitofmeasuresetListid($unitofmeasuresetListid)
    {
        $this->unitofmeasuresetListid = $unitofmeasuresetListid;

        return $this;
    }

    /**
     * Get unitofmeasuresetListid
     *
     * @return string
     */
    public function getUnitofmeasuresetListid()
    {
        return $this->unitofmeasuresetListid;
    }

    /**
     * Set unitofmeasuresetFullname
     *
     * @param string $unitofmeasuresetFullname
     *
     * @return QbItemservice
     */
    public function setUnitofmeasuresetFullname($unitofmeasuresetFullname)
    {
        $this->unitofmeasuresetFullname = $unitofmeasuresetFullname;

        return $this;
    }

    /**
     * Get unitofmeasuresetFullname
     *
     * @return string
     */
    public function getUnitofmeasuresetFullname()
    {
        return $this->unitofmeasuresetFullname;
    }

    /**
     * Set salestaxcodeListid
     *
     * @param string $salestaxcodeListid
     *
     * @return QbItemservice
     */
    public function setSalestaxcodeListid($salestaxcodeListid)
    {
        $this->salestaxcodeListid = $salestaxcodeListid;

        return $this;
    }

    /**
     * Get salestaxcodeListid
     *
     * @return string
     */
    public function getSalestaxcodeListid()
    {
        return $this->salestaxcodeListid;
    }

    /**
     * Set salestaxcodeFullname
     *
     * @param string $salestaxcodeFullname
     *
     * @return QbItemservice
     */
    public function setSalestaxcodeFullname($salestaxcodeFullname)
    {
        $this->salestaxcodeFullname = $salestaxcodeFullname;

        return $this;
    }

    /**
     * Get salestaxcodeFullname
     *
     * @return string
     */
    public function getSalestaxcodeFullname()
    {
        return $this->salestaxcodeFullname;
    }

    /**
     * Set salesorpurchaseDesc
     *
     * @param string $salesorpurchaseDesc
     *
     * @return QbItemservice
     */
    public function setSalesorpurchaseDesc($salesorpurchaseDesc)
    {
        $this->salesorpurchaseDesc = $salesorpurchaseDesc;

        return $this;
    }

    /**
     * Get salesorpurchaseDesc
     *
     * @return string
     */
    public function getSalesorpurchaseDesc()
    {
        return $this->salesorpurchaseDesc;
    }

    /**
     * Set salesorpurchasePrice
     *
     * @param string $salesorpurchasePrice
     *
     * @return QbItemservice
     */
    public function setSalesorpurchasePrice($salesorpurchasePrice)
    {
        $this->salesorpurchasePrice = $salesorpurchasePrice;

        return $this;
    }

    /**
     * Get salesorpurchasePrice
     *
     * @return string
     */
    public function getSalesorpurchasePrice()
    {
        return $this->salesorpurchasePrice;
    }

    /**
     * Set salesorpurchasePricepercent
     *
     * @param string $salesorpurchasePricepercent
     *
     * @return QbItemservice
     */
    public function setSalesorpurchasePricepercent($salesorpurchasePricepercent)
    {
        $this->salesorpurchasePricepercent = $salesorpurchasePricepercent;

        return $this;
    }

    /**
     * Get salesorpurchasePricepercent
     *
     * @return string
     */
    public function getSalesorpurchasePricepercent()
    {
        return $this->salesorpurchasePricepercent;
    }

    /**
     * Set salesorpurchaseAccountListid
     *
     * @param string $salesorpurchaseAccountListid
     *
     * @return QbItemservice
     */
    public function setSalesorpurchaseAccountListid($salesorpurchaseAccountListid)
    {
        $this->salesorpurchaseAccountListid = $salesorpurchaseAccountListid;

        return $this;
    }

    /**
     * Get salesorpurchaseAccountListid
     *
     * @return string
     */
    public function getSalesorpurchaseAccountListid()
    {
        return $this->salesorpurchaseAccountListid;
    }

    /**
     * Set salesorpurchaseAccountFullname
     *
     * @param string $salesorpurchaseAccountFullname
     *
     * @return QbItemservice
     */
    public function setSalesorpurchaseAccountFullname($salesorpurchaseAccountFullname)
    {
        $this->salesorpurchaseAccountFullname = $salesorpurchaseAccountFullname;

        return $this;
    }

    /**
     * Get salesorpurchaseAccountFullname
     *
     * @return string
     */
    public function getSalesorpurchaseAccountFullname()
    {
        return $this->salesorpurchaseAccountFullname;
    }

    /**
     * Set salesandpurchaseSalesdesc
     *
     * @param string $salesandpurchaseSalesdesc
     *
     * @return QbItemservice
     */
    public function setSalesandpurchaseSalesdesc($salesandpurchaseSalesdesc)
    {
        $this->salesandpurchaseSalesdesc = $salesandpurchaseSalesdesc;

        return $this;
    }

    /**
     * Get salesandpurchaseSalesdesc
     *
     * @return string
     */
    public function getSalesandpurchaseSalesdesc()
    {
        return $this->salesandpurchaseSalesdesc;
    }

    /**
     * Set salesandpurchaseSalesprice
     *
     * @param string $salesandpurchaseSalesprice
     *
     * @return QbItemservice
     */
    public function setSalesandpurchaseSalesprice($salesandpurchaseSalesprice)
    {
        $this->salesandpurchaseSalesprice = $salesandpurchaseSalesprice;

        return $this;
    }

    /**
     * Get salesandpurchaseSalesprice
     *
     * @return string
     */
    public function getSalesandpurchaseSalesprice()
    {
        return $this->salesandpurchaseSalesprice;
    }

    /**
     * Set salesandpurchaseIncomeaccountListid
     *
     * @param string $salesandpurchaseIncomeaccountListid
     *
     * @return QbItemservice
     */
    public function setSalesandpurchaseIncomeaccountListid($salesandpurchaseIncomeaccountListid)
    {
        $this->salesandpurchaseIncomeaccountListid = $salesandpurchaseIncomeaccountListid;

        return $this;
    }

    /**
     * Get salesandpurchaseIncomeaccountListid
     *
     * @return string
     */
    public function getSalesandpurchaseIncomeaccountListid()
    {
        return $this->salesandpurchaseIncomeaccountListid;
    }

    /**
     * Set salesandpurchaseIncomeaccountFullname
     *
     * @param string $salesandpurchaseIncomeaccountFullname
     *
     * @return QbItemservice
     */
    public function setSalesandpurchaseIncomeaccountFullname($salesandpurchaseIncomeaccountFullname)
    {
        $this->salesandpurchaseIncomeaccountFullname = $salesandpurchaseIncomeaccountFullname;

        return $this;
    }

    /**
     * Get salesandpurchaseIncomeaccountFullname
     *
     * @return string
     */
    public function getSalesandpurchaseIncomeaccountFullname()
    {
        return $this->salesandpurchaseIncomeaccountFullname;
    }

    /**
     * Set salesandpurchasePurchasedesc
     *
     * @param string $salesandpurchasePurchasedesc
     *
     * @return QbItemservice
     */
    public function setSalesandpurchasePurchasedesc($salesandpurchasePurchasedesc)
    {
        $this->salesandpurchasePurchasedesc = $salesandpurchasePurchasedesc;

        return $this;
    }

    /**
     * Get salesandpurchasePurchasedesc
     *
     * @return string
     */
    public function getSalesandpurchasePurchasedesc()
    {
        return $this->salesandpurchasePurchasedesc;
    }

    /**
     * Set salesandpurchasePurchasecost
     *
     * @param string $salesandpurchasePurchasecost
     *
     * @return QbItemservice
     */
    public function setSalesandpurchasePurchasecost($salesandpurchasePurchasecost)
    {
        $this->salesandpurchasePurchasecost = $salesandpurchasePurchasecost;

        return $this;
    }

    /**
     * Get salesandpurchasePurchasecost
     *
     * @return string
     */
    public function getSalesandpurchasePurchasecost()
    {
        return $this->salesandpurchasePurchasecost;
    }

    /**
     * Set salesandpurchaseExpenseaccountListid
     *
     * @param string $salesandpurchaseExpenseaccountListid
     *
     * @return QbItemservice
     */
    public function setSalesandpurchaseExpenseaccountListid($salesandpurchaseExpenseaccountListid)
    {
        $this->salesandpurchaseExpenseaccountListid = $salesandpurchaseExpenseaccountListid;

        return $this;
    }

    /**
     * Get salesandpurchaseExpenseaccountListid
     *
     * @return string
     */
    public function getSalesandpurchaseExpenseaccountListid()
    {
        return $this->salesandpurchaseExpenseaccountListid;
    }

    /**
     * Set salesandpurchaseExpenseaccountFullname
     *
     * @param string $salesandpurchaseExpenseaccountFullname
     *
     * @return QbItemservice
     */
    public function setSalesandpurchaseExpenseaccountFullname($salesandpurchaseExpenseaccountFullname)
    {
        $this->salesandpurchaseExpenseaccountFullname = $salesandpurchaseExpenseaccountFullname;

        return $this;
    }

    /**
     * Get salesandpurchaseExpenseaccountFullname
     *
     * @return string
     */
    public function getSalesandpurchaseExpenseaccountFullname()
    {
        return $this->salesandpurchaseExpenseaccountFullname;
    }

    /**
     * Set salesandpurchasePrefvendorListid
     *
     * @param string $salesandpurchasePrefvendorListid
     *
     * @return QbItemservice
     */
    public function setSalesandpurchasePrefvendorListid($salesandpurchasePrefvendorListid)
    {
        $this->salesandpurchasePrefvendorListid = $salesandpurchasePrefvendorListid;

        return $this;
    }

    /**
     * Get salesandpurchasePrefvendorListid
     *
     * @return string
     */
    public function getSalesandpurchasePrefvendorListid()
    {
        return $this->salesandpurchasePrefvendorListid;
    }

    /**
     * Set salesandpurchasePrefvendorFullname
     *
     * @param string $salesandpurchasePrefvendorFullname
     *
     * @return QbItemservice
     */
    public function setSalesandpurchasePrefvendorFullname($salesandpurchasePrefvendorFullname)
    {
        $this->salesandpurchasePrefvendorFullname = $salesandpurchasePrefvendorFullname;

        return $this;
    }

    /**
     * Get salesandpurchasePrefvendorFullname
     *
     * @return string
     */
    public function getSalesandpurchasePrefvendorFullname()
    {
        return $this->salesandpurchasePrefvendorFullname;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbItemservice
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbItemservice
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbItemservice
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbItemservice
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbItemservice
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbItemservice
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbItemservice
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbItemservice
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbItemservice
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbItemservice
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbItemservice
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbItemservice
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbItemservice
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbItemservice
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbItemservice
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbItemservice
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbItemservice
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbItemservice
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

