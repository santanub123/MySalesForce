<?php

namespace QbmBundle\Entity;

/**
 * QbCreditmemoCreditmemolinegroupCreditmemoline
 */
class QbCreditmemoCreditmemolinegroupCreditmemoline
{
    /**
     * @var integer
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     */
    private $creditmemoTxnid;

    /**
     * @var string
     */
    private $creditmemoCreditmemolinegroupTxnlineid;

    /**
     * @var integer
     */
    private $sortorder = '0';

    /**
     * @var string
     */
    private $txnlineid;

    /**
     * @var string
     */
    private $itemListid;

    /**
     * @var string
     */
    private $itemFullname;

    /**
     * @var string
     */
    private $descrip;

    /**
     * @var string
     */
    private $quantity = '0.00000';

    /**
     * @var string
     */
    private $unitofmeasure;

    /**
     * @var string
     */
    private $overrideuomsetListid;

    /**
     * @var string
     */
    private $overrideuomsetFullname;

    /**
     * @var string
     */
    private $rate;

    /**
     * @var string
     */
    private $ratepercent;

    /**
     * @var string
     */
    private $classListid;

    /**
     * @var string
     */
    private $classFullname;

    /**
     * @var string
     */
    private $amount;

    /**
     * @var \DateTime
     */
    private $servicedate;

    /**
     * @var string
     */
    private $salestaxcodeListid;

    /**
     * @var string
     */
    private $salestaxcodeFullname;

    /**
     * @var string
     */
    private $other1;

    /**
     * @var string
     */
    private $other2;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoCreditcardnumber;

    /**
     * @var integer
     */
    private $creditcardtxninfoCreditcardtxninputinfoExpirationmonth;

    /**
     * @var integer
     */
    private $creditcardtxninfoCreditcardtxninputinfoExpirationyear;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoNameoncard;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoCreditcardaddress;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoCommercialcardcode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoTransactionmode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype;

    /**
     * @var integer
     */
    private $creditcardtxninfoCreditcardtxnresultinfoResultcode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoResultmessage;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoAvsstreet;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoAvszip;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoReconbatchid;

    /**
     * @var integer
     */
    private $creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoPaymentstatus;

    /**
     * @var \DateTime
     */
    private $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime;

    /**
     * @var integer
     */
    private $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp;

    /**
     * @var string
     */
    private $creditcardtxninfoCreditcardtxnresultinfoClienttransid;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }

    /**
     * Set creditmemoTxnid
     *
     * @param string $creditmemoTxnid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditmemoTxnid($creditmemoTxnid)
    {
        $this->creditmemoTxnid = $creditmemoTxnid;

        return $this;
    }

    /**
     * Get creditmemoTxnid
     *
     * @return string
     */
    public function getCreditmemoTxnid()
    {
        return $this->creditmemoTxnid;
    }

    /**
     * Set creditmemoCreditmemolinegroupTxnlineid
     *
     * @param string $creditmemoCreditmemolinegroupTxnlineid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditmemoCreditmemolinegroupTxnlineid($creditmemoCreditmemolinegroupTxnlineid)
    {
        $this->creditmemoCreditmemolinegroupTxnlineid = $creditmemoCreditmemolinegroupTxnlineid;

        return $this;
    }

    /**
     * Get creditmemoCreditmemolinegroupTxnlineid
     *
     * @return string
     */
    public function getCreditmemoCreditmemolinegroupTxnlineid()
    {
        return $this->creditmemoCreditmemolinegroupTxnlineid;
    }

    /**
     * Set sortorder
     *
     * @param integer $sortorder
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setSortorder($sortorder)
    {
        $this->sortorder = $sortorder;

        return $this;
    }

    /**
     * Get sortorder
     *
     * @return integer
     */
    public function getSortorder()
    {
        return $this->sortorder;
    }

    /**
     * Set txnlineid
     *
     * @param string $txnlineid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setTxnlineid($txnlineid)
    {
        $this->txnlineid = $txnlineid;

        return $this;
    }

    /**
     * Get txnlineid
     *
     * @return string
     */
    public function getTxnlineid()
    {
        return $this->txnlineid;
    }

    /**
     * Set itemListid
     *
     * @param string $itemListid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setItemListid($itemListid)
    {
        $this->itemListid = $itemListid;

        return $this;
    }

    /**
     * Get itemListid
     *
     * @return string
     */
    public function getItemListid()
    {
        return $this->itemListid;
    }

    /**
     * Set itemFullname
     *
     * @param string $itemFullname
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setItemFullname($itemFullname)
    {
        $this->itemFullname = $itemFullname;

        return $this;
    }

    /**
     * Get itemFullname
     *
     * @return string
     */
    public function getItemFullname()
    {
        return $this->itemFullname;
    }

    /**
     * Set descrip
     *
     * @param string $descrip
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setDescrip($descrip)
    {
        $this->descrip = $descrip;

        return $this;
    }

    /**
     * Get descrip
     *
     * @return string
     */
    public function getDescrip()
    {
        return $this->descrip;
    }

    /**
     * Set quantity
     *
     * @param string $quantity
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQuantity($quantity)
    {
        $this->quantity = $quantity;

        return $this;
    }

    /**
     * Get quantity
     *
     * @return string
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * Set unitofmeasure
     *
     * @param string $unitofmeasure
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setUnitofmeasure($unitofmeasure)
    {
        $this->unitofmeasure = $unitofmeasure;

        return $this;
    }

    /**
     * Get unitofmeasure
     *
     * @return string
     */
    public function getUnitofmeasure()
    {
        return $this->unitofmeasure;
    }

    /**
     * Set overrideuomsetListid
     *
     * @param string $overrideuomsetListid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setOverrideuomsetListid($overrideuomsetListid)
    {
        $this->overrideuomsetListid = $overrideuomsetListid;

        return $this;
    }

    /**
     * Get overrideuomsetListid
     *
     * @return string
     */
    public function getOverrideuomsetListid()
    {
        return $this->overrideuomsetListid;
    }

    /**
     * Set overrideuomsetFullname
     *
     * @param string $overrideuomsetFullname
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setOverrideuomsetFullname($overrideuomsetFullname)
    {
        $this->overrideuomsetFullname = $overrideuomsetFullname;

        return $this;
    }

    /**
     * Get overrideuomsetFullname
     *
     * @return string
     */
    public function getOverrideuomsetFullname()
    {
        return $this->overrideuomsetFullname;
    }

    /**
     * Set rate
     *
     * @param string $rate
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setRate($rate)
    {
        $this->rate = $rate;

        return $this;
    }

    /**
     * Get rate
     *
     * @return string
     */
    public function getRate()
    {
        return $this->rate;
    }

    /**
     * Set ratepercent
     *
     * @param string $ratepercent
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setRatepercent($ratepercent)
    {
        $this->ratepercent = $ratepercent;

        return $this;
    }

    /**
     * Get ratepercent
     *
     * @return string
     */
    public function getRatepercent()
    {
        return $this->ratepercent;
    }

    /**
     * Set classListid
     *
     * @param string $classListid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setClassListid($classListid)
    {
        $this->classListid = $classListid;

        return $this;
    }

    /**
     * Get classListid
     *
     * @return string
     */
    public function getClassListid()
    {
        return $this->classListid;
    }

    /**
     * Set classFullname
     *
     * @param string $classFullname
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setClassFullname($classFullname)
    {
        $this->classFullname = $classFullname;

        return $this;
    }

    /**
     * Get classFullname
     *
     * @return string
     */
    public function getClassFullname()
    {
        return $this->classFullname;
    }

    /**
     * Set amount
     *
     * @param string $amount
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return string
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set servicedate
     *
     * @param \DateTime $servicedate
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setServicedate($servicedate)
    {
        $this->servicedate = $servicedate;

        return $this;
    }

    /**
     * Get servicedate
     *
     * @return \DateTime
     */
    public function getServicedate()
    {
        return $this->servicedate;
    }

    /**
     * Set salestaxcodeListid
     *
     * @param string $salestaxcodeListid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setSalestaxcodeListid($salestaxcodeListid)
    {
        $this->salestaxcodeListid = $salestaxcodeListid;

        return $this;
    }

    /**
     * Get salestaxcodeListid
     *
     * @return string
     */
    public function getSalestaxcodeListid()
    {
        return $this->salestaxcodeListid;
    }

    /**
     * Set salestaxcodeFullname
     *
     * @param string $salestaxcodeFullname
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setSalestaxcodeFullname($salestaxcodeFullname)
    {
        $this->salestaxcodeFullname = $salestaxcodeFullname;

        return $this;
    }

    /**
     * Get salestaxcodeFullname
     *
     * @return string
     */
    public function getSalestaxcodeFullname()
    {
        return $this->salestaxcodeFullname;
    }

    /**
     * Set other1
     *
     * @param string $other1
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setOther1($other1)
    {
        $this->other1 = $other1;

        return $this;
    }

    /**
     * Get other1
     *
     * @return string
     */
    public function getOther1()
    {
        return $this->other1;
    }

    /**
     * Set other2
     *
     * @param string $other2
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setOther2($other2)
    {
        $this->other2 = $other2;

        return $this;
    }

    /**
     * Get other2
     *
     * @return string
     */
    public function getOther2()
    {
        return $this->other2;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoCreditcardnumber
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoCreditcardnumber
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoCreditcardnumber($creditcardtxninfoCreditcardtxninputinfoCreditcardnumber)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoCreditcardnumber = $creditcardtxninfoCreditcardtxninputinfoCreditcardnumber;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoCreditcardnumber
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoCreditcardnumber()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoCreditcardnumber;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoExpirationmonth
     *
     * @param integer $creditcardtxninfoCreditcardtxninputinfoExpirationmonth
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoExpirationmonth($creditcardtxninfoCreditcardtxninputinfoExpirationmonth)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoExpirationmonth = $creditcardtxninfoCreditcardtxninputinfoExpirationmonth;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoExpirationmonth
     *
     * @return integer
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoExpirationmonth()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoExpirationmonth;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoExpirationyear
     *
     * @param integer $creditcardtxninfoCreditcardtxninputinfoExpirationyear
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoExpirationyear($creditcardtxninfoCreditcardtxninputinfoExpirationyear)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoExpirationyear = $creditcardtxninfoCreditcardtxninputinfoExpirationyear;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoExpirationyear
     *
     * @return integer
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoExpirationyear()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoExpirationyear;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoNameoncard
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoNameoncard
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoNameoncard($creditcardtxninfoCreditcardtxninputinfoNameoncard)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoNameoncard = $creditcardtxninfoCreditcardtxninputinfoNameoncard;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoNameoncard
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoNameoncard()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoNameoncard;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoCreditcardaddress
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoCreditcardaddress
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoCreditcardaddress($creditcardtxninfoCreditcardtxninputinfoCreditcardaddress)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoCreditcardaddress = $creditcardtxninfoCreditcardtxninputinfoCreditcardaddress;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoCreditcardaddress
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoCreditcardaddress()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoCreditcardaddress;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode($creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode = $creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoCreditcardpostalcode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoCommercialcardcode
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoCommercialcardcode
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoCommercialcardcode($creditcardtxninfoCreditcardtxninputinfoCommercialcardcode)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoCommercialcardcode = $creditcardtxninfoCreditcardtxninputinfoCommercialcardcode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoCommercialcardcode
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoCommercialcardcode()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoCommercialcardcode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoTransactionmode
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoTransactionmode
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoTransactionmode($creditcardtxninfoCreditcardtxninputinfoTransactionmode)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoTransactionmode = $creditcardtxninfoCreditcardtxninputinfoTransactionmode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoTransactionmode
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoTransactionmode()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoTransactionmode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype
     *
     * @param string $creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxninputinfoCreditcardtxntype($creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype)
    {
        $this->creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype = $creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxninputinfoCreditcardtxntype()
    {
        return $this->creditcardtxninfoCreditcardtxninputinfoCreditcardtxntype;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoResultcode
     *
     * @param integer $creditcardtxninfoCreditcardtxnresultinfoResultcode
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoResultcode($creditcardtxninfoCreditcardtxnresultinfoResultcode)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoResultcode = $creditcardtxninfoCreditcardtxnresultinfoResultcode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoResultcode
     *
     * @return integer
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoResultcode()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoResultcode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoResultmessage
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoResultmessage
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoResultmessage($creditcardtxninfoCreditcardtxnresultinfoResultmessage)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoResultmessage = $creditcardtxninfoCreditcardtxnresultinfoResultmessage;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoResultmessage
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoResultmessage()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoResultmessage;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoCreditcardtransid($creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid = $creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoCreditcardtransid()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoCreditcardtransid;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber($creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber = $creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoMerchantaccountnumber;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoAuthorizationcode($creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode = $creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoAuthorizationcode()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoAuthorizationcode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoAvsstreet
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoAvsstreet
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoAvsstreet($creditcardtxninfoCreditcardtxnresultinfoAvsstreet)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoAvsstreet = $creditcardtxninfoCreditcardtxnresultinfoAvsstreet;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoAvsstreet
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoAvsstreet()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoAvsstreet;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoAvszip
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoAvszip
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoAvszip($creditcardtxninfoCreditcardtxnresultinfoAvszip)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoAvszip = $creditcardtxninfoCreditcardtxnresultinfoAvszip;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoAvszip
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoAvszip()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoAvszip;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch($creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch = $creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoCardsecuritycodematch;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoReconbatchid
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoReconbatchid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoReconbatchid($creditcardtxninfoCreditcardtxnresultinfoReconbatchid)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoReconbatchid = $creditcardtxninfoCreditcardtxnresultinfoReconbatchid;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoReconbatchid
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoReconbatchid()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoReconbatchid;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode
     *
     * @param integer $creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode($creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode = $creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode
     *
     * @return integer
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoPaymentgroupingcode;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoPaymentstatus
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoPaymentstatus
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoPaymentstatus($creditcardtxninfoCreditcardtxnresultinfoPaymentstatus)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoPaymentstatus = $creditcardtxninfoCreditcardtxnresultinfoPaymentstatus;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoPaymentstatus
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoPaymentstatus()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoPaymentstatus;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime
     *
     * @param \DateTime $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime($creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime = $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime
     *
     * @return \DateTime
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationtime;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp
     *
     * @param integer $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp($creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp = $creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp
     *
     * @return integer
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoTxnauthorizationstamp;
    }

    /**
     * Set creditcardtxninfoCreditcardtxnresultinfoClienttransid
     *
     * @param string $creditcardtxninfoCreditcardtxnresultinfoClienttransid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setCreditcardtxninfoCreditcardtxnresultinfoClienttransid($creditcardtxninfoCreditcardtxnresultinfoClienttransid)
    {
        $this->creditcardtxninfoCreditcardtxnresultinfoClienttransid = $creditcardtxninfoCreditcardtxnresultinfoClienttransid;

        return $this;
    }

    /**
     * Get creditcardtxninfoCreditcardtxnresultinfoClienttransid
     *
     * @return string
     */
    public function getCreditcardtxninfoCreditcardtxnresultinfoClienttransid()
    {
        return $this->creditcardtxninfoCreditcardtxnresultinfoClienttransid;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbCreditmemoCreditmemolinegroupCreditmemoline
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }
}

