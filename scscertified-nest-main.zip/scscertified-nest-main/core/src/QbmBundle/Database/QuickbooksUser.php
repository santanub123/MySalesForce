<?php

namespace QbmBundle\Entity;

/**
 * QuickbooksUser
 */
class QuickbooksUser
{
    /**
     * @var string
     */
    private $qbUsername;

    /**
     * @var string
     */
    private $qbPassword;

    /**
     * @var string
     */
    private $qbCompanyFile;

    /**
     * @var integer
     */
    private $qbwcWaitBeforeNextUpdate = '0';

    /**
     * @var integer
     */
    private $qbwcMinRunEveryNSeconds = '0';

    /**
     * @var string
     */
    private $status;

    /**
     * @var \DateTime
     */
    private $writeDatetime;

    /**
     * @var \DateTime
     */
    private $touchDatetime;


    /**
     * Get qbUsername
     *
     * @return string
     */
    public function getQbUsername()
    {
        return $this->qbUsername;
    }

    /**
     * Set qbPassword
     *
     * @param string $qbPassword
     *
     * @return QuickbooksUser
     */
    public function setQbPassword($qbPassword)
    {
        $this->qbPassword = $qbPassword;

        return $this;
    }

    /**
     * Get qbPassword
     *
     * @return string
     */
    public function getQbPassword()
    {
        return $this->qbPassword;
    }

    /**
     * Set qbCompanyFile
     *
     * @param string $qbCompanyFile
     *
     * @return QuickbooksUser
     */
    public function setQbCompanyFile($qbCompanyFile)
    {
        $this->qbCompanyFile = $qbCompanyFile;

        return $this;
    }

    /**
     * Get qbCompanyFile
     *
     * @return string
     */
    public function getQbCompanyFile()
    {
        return $this->qbCompanyFile;
    }

    /**
     * Set qbwcWaitBeforeNextUpdate
     *
     * @param integer $qbwcWaitBeforeNextUpdate
     *
     * @return QuickbooksUser
     */
    public function setQbwcWaitBeforeNextUpdate($qbwcWaitBeforeNextUpdate)
    {
        $this->qbwcWaitBeforeNextUpdate = $qbwcWaitBeforeNextUpdate;

        return $this;
    }

    /**
     * Get qbwcWaitBeforeNextUpdate
     *
     * @return integer
     */
    public function getQbwcWaitBeforeNextUpdate()
    {
        return $this->qbwcWaitBeforeNextUpdate;
    }

    /**
     * Set qbwcMinRunEveryNSeconds
     *
     * @param integer $qbwcMinRunEveryNSeconds
     *
     * @return QuickbooksUser
     */
    public function setQbwcMinRunEveryNSeconds($qbwcMinRunEveryNSeconds)
    {
        $this->qbwcMinRunEveryNSeconds = $qbwcMinRunEveryNSeconds;

        return $this;
    }

    /**
     * Get qbwcMinRunEveryNSeconds
     *
     * @return integer
     */
    public function getQbwcMinRunEveryNSeconds()
    {
        return $this->qbwcMinRunEveryNSeconds;
    }

    /**
     * Set status
     *
     * @param string $status
     *
     * @return QuickbooksUser
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set writeDatetime
     *
     * @param \DateTime $writeDatetime
     *
     * @return QuickbooksUser
     */
    public function setWriteDatetime($writeDatetime)
    {
        $this->writeDatetime = $writeDatetime;

        return $this;
    }

    /**
     * Get writeDatetime
     *
     * @return \DateTime
     */
    public function getWriteDatetime()
    {
        return $this->writeDatetime;
    }

    /**
     * Set touchDatetime
     *
     * @param \DateTime $touchDatetime
     *
     * @return QuickbooksUser
     */
    public function setTouchDatetime($touchDatetime)
    {
        $this->touchDatetime = $touchDatetime;

        return $this;
    }

    /**
     * Get touchDatetime
     *
     * @return \DateTime
     */
    public function getTouchDatetime()
    {
        return $this->touchDatetime;
    }
}

