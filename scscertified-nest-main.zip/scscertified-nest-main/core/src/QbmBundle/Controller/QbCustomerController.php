<?php

namespace QbmBundle\Controller;

use QbmBundle\Entity\QbCustomer;
use QbmBundle\Form\QbCustomerType;

//use FOS\RestBundle\Controller\Annotations\RouteResource;
//use FOS\RestBundle\Controller\Annotations\Route; // to amend _format in requirements
use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

class QbCustomerController extends FOSRestController
{
    /**
     * @Route(path="/customer", name="qbm_customer")
     */
    public function indexAction()
    {
        $customerEm = $this->get('doctrine')->getManager('qbm');
        
        return $customerEm;
    }
    
    /**
     * Using 'Search' in method name avoids generating a duplicate route, since we're using the @Get annotation
     *
     * Generates the route: (GET) /customer/name/{name}
     *
     * @ApiDoc(
     *   views = { "qb-mirror" },
     *   section = "QbCustomer",
     *   resource = true,
     *   description = "Get QbCustomer with name string (uses LIKE %name%)",
     *   output = "QbmBundle\Entity\QbCustomer",
     *   statusCodes = {
     *     200 = "Returned when successful",
     *   },
     * )
     *
     * @param string $name the qbCustomer 'name'
     *
     * @Get("/customer/name/{name}", name="qbm_get_customer_name", options={"method_prefix" = false})
     *
     * @return QbCustomer
     */
    public function getCustomerNameSearch($name = null)
    {
        $qbCustomer = $this
            ->getDoctrine()
            ->getRepository('QbmBundle:QbCustomer', 'qbm') // note the reference to non-default entity manager (defined in config.yml)
            //->findByName("$name");
            /**/
            ->createQueryBuilder('c')
            ->where('c.name LIKE :name')
            ->setParameter('name', '%' . $name . '%')
            ->getQuery()
            ->getResult();
            
            
        if (is_null($qbCustomer)) {
            throw $this->createNotFoundException('No such qbCustomer');
        }
        
        // Response is same as default (w/out View), but makes it explicit and configurable
        //return $qbCustomer;
        return new View($qbCustomer, Response::HTTP_OK);
    }
    
}