<?php

namespace QbmBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class DefaultController extends Controller
{
    /**
     * #Route("/", name="qbm_default_index", options={"method_prefix"=false})
     */
    public function indexAction()
    {
        return $this->render('QbmBundle:Default:index.html.twig');
    }
}
