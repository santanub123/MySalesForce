<?php

namespace QbmBundle\Controller;

use QbmBundle\Entity\QbClass;
use QbmBundle\Form\QbClassType;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\View\View;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

use Doctrine\ORM\Query\ResultSetMapping;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

class QbClassController extends FOSRestController
{
    /**
     * @Route(path="/class", name="qbm_class")
     */
    public function indexAction()
    {
        $classEm = $this->get('doctrine')->getManager('qbm');

        return $classEm;
    }

    /**
     * @Get("/class_list/{corporate_entity}", name="qbm_class_list", defaults={"corporate_entity"="scs"})
     *
     * corporate_entity = 'scs' | 'scs_consulting'
     * Identifies the QB company file from which to get class information.
     *
     * Returns an array of objects describing each QB class:
     * [
     *     {
     *         'listid':        'xxxx',
     *         'name':          'xxxx',
     *         'fullname':      'xxxx',
     *         'invoice_count': 'n',
     *     },
     *     ...
     *  ]
     */
    public function getClassList($corporate_entity)
    {
        // Determine entity manager from corporate entity.
        $qb_mirrors = [
            'scs'       => 'qbm',
            'scs_consulting'    => 'qbcm',
        ];
        $em_name = $qb_mirrors[$corporate_entity];
        $em = $this->getDoctrine()->getManager($em_name);

        /* Construct a query to return QB classes with joined invoice count.
         * Use a native query to do this because of aggregate invoice_count
         * column and extra field returned.     */
        $sql = '
            SELECT
              ListID,
              Name,
              FullName,
              IFNULL(qbi.invoice_count, 0) AS InvoiceCount
            FROM
              qb_class
              LEFT JOIN
              (
                SELECT COUNT(*) AS invoice_count, Class_ListID
                FROM qb_invoice
                GROUP BY Class_ListID
                ORDER BY Class_FullName
              ) qbi ON qb_class.ListID = qbi.Class_ListID
              ORDER BY Name';
        $rsm = new ResultSetMapping();
        $rsm->addScalarResult('ListID', 'listid');
        $rsm->addScalarResult('Name', 'name');
        $rsm->addScalarResult('FullName', 'fullname');
        $rsm->addScalarResult('InvoiceCount', 'invoice_count');

        $result = $em->createNativeQuery($sql, $rsm)->getResult();

        if (is_array($result)) {
            $data = $this->filterProgramClasses($result);
            $count = count($data);
            $http_code = Response::HTTP_OK;                     // 200
            $message = '';
        } else {
            $data = [];
            $count = 0;
            $http_code = Response::HTTP_INTERNAL_SERVER_ERROR;      // 500
            $message = 'Error querying for QB class list';
        }

        return new View(
            [
                'data'      => $data,
                'count'     => $count,
                'code'      => $http_code,
                'message'   => $message,
            ],
            $http_code
        );
    }

    /**
     * Remove duplicate and non-numeric classes from an array of qb_class records
     *
     * @param array $input_qb_classes
     *     array of qb_class records as returned by native query with
     *     invoice_count
     *
     * @return array
     *     the filtered set of classes
     */
    private function filterProgramClasses($input_qb_classes)
    {
        $department_class_groups = [];
        $non_numeric_classes = [];
        $output_class_list = [];

        // Sort the QB classes into dept (starting with #) and non-numeric
        // groups.
        foreach ($input_qb_classes as $key => $qb_class) {
            $matches = [];
            $is_numeric = preg_match(
                '#^((\d{2,4})([A-Z] )?)(.+)?#i',
                $qb_class['name'],
                $matches
            );
            if ($is_numeric === 1) {
                // Sort department classes into groups of like dept codes.
                $dept_code = $matches[1];
                $numeric_code = (int) $matches[2];
                if (!isset($department_class_groups[$dept_code])) {
                    $department_class_groups[$dept_code] = [];
                }
                $department_class_groups[$dept_code][] = $qb_class;
            } else {
                // Collect non-numeric classes only if they have invoices.
                if (!empty($qb_class['invoice_count'])) {
                    $non_numeric_classes[] = $qb_class;
                }
            }
        }

        // Iterate through the dept class groups and remove obvious duplicates.
        foreach ($department_class_groups as $dept_code => $class_group) {
            if (count($class_group) === 1) {
                // Only one class for this dept. Add it.
                $output_class_list[] = $class_group[0];
            } else {
                // Multiple classes for this dept. Look at invoices.
                $invoiced_classes = [];
                foreach ($class_group as $qb_class) {
                    if (!empty($qb_class['invoice_count'])) {
                        $invoiced_classes[] = $qb_class;
                    }
                }
                $invoiced_class_count = count($invoiced_classes);
                if ($invoiced_class_count === 1) {
                    // Only one class for this dept has invoices. Add it and
                    // omit the rest.
                    $output_class_list[] = $invoiced_classes[0];
                } else {
                    if ($invoiced_class_count > 0) {
                        // Multiple classes for this dept have invoices. Add
                        // the invoiced ones and omit the rest.
                        foreach ($invoiced_classes as $qb_class) {
                            $output_class_list[] = $qb_class;
                        }
                    } else {
                        // No classes for this dept have invoices. Add them all
                        // because we can't determine the right one.
                        foreach ($class_group as $qb_class) {
                            $output_class_list[] = $qb_class;
                        }
                    }
                }
            }
        }

        // For non-numeric QB classes, only include them in output if they have
        // invoices.
        foreach ($non_numeric_classes as $qb_class) {
            if (!empty($qb_class['invoice_count'])) {
                $output_class_list[] = $qb_class;
            }
        }

        return $output_class_list;
    }
}
