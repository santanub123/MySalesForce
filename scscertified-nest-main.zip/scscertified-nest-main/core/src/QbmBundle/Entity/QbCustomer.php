<?php

namespace QbmBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;
use JMS\Serializer\Annotation\SerializedName;

/**
 * QbCustomer
 *
 * {@inheritdoc}
 * @ORM\Table(name="qb_customer")
 * @ORM\Entity
 *
 * @ExclusionPolicy("all")
 */
class QbCustomer
{
    /**
     * Note: ORM annotations for this property strictly to satisfy Doctrine's requirement for an Id per Entity
     *
     * @var integer
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * #ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @Expose
     * @SerializedName("qbsql_id")
     */
    private $qbsqlId;

    /**
     * @var integer
     */
    private $qbsqlUsernameId;

    /**
     * @var integer
     */
    private $qbsqlExternalId;

    /**
     * @var string
     *
     * @ORM\Column(name="ListId", type="string", length=40, nullable=true)
     *
     * @Expose
     * @SerializedName("ListID")
     */
    public $ListID;

    /**
     * @var \DateTime
     */
    private $timecreated;

    /**
     * @var \DateTime
     */
    private $timemodified;

    /**
     * @var string
     */
    private $editsequence;

    /**
     * @var string
     *
     * @ORM\Column(name="Name", type="string", length=41, nullable=true)
     *
     * @Expose
     * @SerializedName("Name")
     */
    public $Name;

    /**
     * @var string
     *
     * @ORM\Column(name="FullName", type="string", length=255, nullable=true)
     *
     * @Expose
     * @SerializedName("FullName")
     */
    public $FullName;

    /**
     * @var boolean
     *
     * @ORM\Column(name="IsActive", type="boolean", length=1)
     *
     * @Expose
     * @SerializedName("IsActive")
     */
    private $isactive = '0';

    /**
     * @var string
     */
    private $parentListid;

    /**
     * @var string
     */
    private $parentFullname;

    /**
     * @var integer
     * @ORM\Column(name="Sublevel", type="integer", length=10)
     *
     * @Expose
     * @SerializedName("Sublevel")
     */
    private $sublevel = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="CompanyName", type="string", length=41, nullable=true)
     *
     * @Expose
     * @SerializedName("CompanyName")
     */
    public $CompanyName;

    /**
     * @var string
     */
    private $salutation;

    /**
     * @var string
     *
     * @ORM\Column(name="FirstName", type="string", length=25, nullable=true)
     *
     * @Expose
     * @SerializedName("FirstName")
     */
    public $FirstName;

    /**
     * @var string
     */
    private $middlename;

    /**
     * @var string
     *
     * @ORM\Column(name="LastName", type="string", length=25, nullable=true)
     *
     * @Expose
     * @SerializedName("LastName")
     */
    public $LastName;

    /**
     * @var string
     *
     * @ORM\Column(name="BillAddress_Addr1", type="string", length=41, nullable=true)
     *
     * @Expose
     * @SerializedName("BillAddress_Addr1")
     */
    public $BillAddress_Addr1;

    /**
     * @var string
     *
     * @ORM\Column(name="BillAddress_Addr2", type="string", length=41, nullable=true)
     *
     * @Expose
     * @SerializedName("BillAddress_Addr2")
     */
    public $BillAddress_Addr2;

    /**
     * @var string
     *
     * Note: this may contain multi-line data, as inserted from DMS
     *
     * @ORM\Column(name="BillAddress_Addr3", type="string", length=41, nullable=true)
     *
     * @Expose
     * @SerializedName("BillAddress_Addr3")
     */
    public $BillAddress_Addr3;

    /**
     * @var string
     */
    private $billaddressAddr4;

    /**
     * @var string
     */
    private $billaddressAddr5;

    /**
     * @var string
     *
     * @ORM\Column(name="BillAddress_City", type="string", length=31, nullable=true)
     *
     * @Expose
     * @SerializedName("BillAddress_City")
     */
    public $BillAddress_City;

    /**
     * @var string
     *
     * @ORM\Column(name="BillAddress_State", type="string", length=21, nullable=true)
     *
     * @Expose
     * @SerializedName("BillAddress_State")
     */
    public $BillAddress_State;

    /**
     * @var string
     *
     * @ORM\Column(name="BillAddress_PostalCode", type="string", length=13, nullable=true)
     *
     * @Expose
     * @SerializedName("BillAddress_PostalCode")
     */
    public $BillAddress_PostalCode;

    /**
     * @var string
     *
     * @ORM\Column(name="BillAddress_Country", type="string", length=31, nullable=true)
     *
     * @Expose
     * @SerializedName("BillAddress_Country")
     */
    public $BillAddress_Country;

    /**
     * @var string
     */
    private $billaddressNote;

    /**
     * @var string
     */
    private $billaddressblockAddr1;

    /**
     * @var string
     */
    private $billaddressblockAddr2;

    /**
     * @var string
     */
    private $billaddressblockAddr3;

    /**
     * @var string
     */
    private $billaddressblockAddr4;

    /**
     * @var string
     */
    private $billaddressblockAddr5;

    /**
     * @var string
     */
    private $shipaddressAddr1;

    /**
     * @var string
     */
    private $shipaddressAddr2;

    /**
     * @var string
     */
    private $shipaddressAddr3;

    /**
     * @var string
     */
    private $shipaddressAddr4;

    /**
     * @var string
     */
    private $shipaddressAddr5;

    /**
     * @var string
     */
    private $shipaddressCity;

    /**
     * @var string
     */
    private $shipaddressState;

    /**
     * @var string
     */
    private $shipaddressPostalcode;

    /**
     * @var string
     */
    private $shipaddressCountry;

    /**
     * @var string
     */
    private $shipaddressNote;

    /**
     * @var string
     */
    private $shipaddressblockAddr1;

    /**
     * @var string
     */
    private $shipaddressblockAddr2;

    /**
     * @var string
     */
    private $shipaddressblockAddr3;

    /**
     * @var string
     */
    private $shipaddressblockAddr4;

    /**
     * @var string
     */
    private $shipaddressblockAddr5;

    /**
     * @var string
     *
     * @ORM\Column(name="Phone", type="string", length=21, nullable=true)
     *
     * @Expose
     * @SerializedName("Phone")
     */
    public $Phone;

    /**
     * @var string
     */
    private $altphone;

    /**
     * @var string
     */
    private $fax;

    /**
     * @var string
     *
     * @ORM\Column(name="Email", type="text", nullable=true)
     *
     * @Expose
     * @SerializedName("Email")
     */
    public $Email;

    /**
     * @var string
     */
    private $altemail;

    /**
     * @var string
     */
    private $contact;

    /**
     * @var string
     */
    private $altcontact;

    /**
     * @var string
     */
    private $customertypeListid;

    /**
     * @var string
     */
    private $customertypeFullname;

    /**
     * @var string
     */
    private $termsListid;

    /**
     * @var string
     */
    private $termsFullname;

    /**
     * @var string
     */
    private $salesrepListid;

    /**
     * @var string
     */
    private $salesrepFullname;

    /**
     * @var string
     */
    private $balance;

    /**
     * @var string
     */
    private $totalbalance;

    /**
     * @var string
     */
    private $salestaxcodeListid;

    /**
     * @var string
     */
    private $salestaxcodeFullname;

    /**
     * @var string
     */
    private $itemsalestaxListid;

    /**
     * @var string
     */
    private $itemsalestaxFullname;

    /**
     * @var string
     */
    private $resalenumber;

    /**
     * @var string
     */
    private $accountnumber;

    /**
     * @var string
     */
    private $creditlimit;

    /**
     * @var string
     */
    private $preferredpaymentmethodListid;

    /**
     * @var string
     */
    private $preferredpaymentmethodFullname;

    /**
     * @var string
     */
    private $creditcardinfoCreditcardnumber;

    /**
     * @var integer
     */
    private $creditcardinfoExpirationmonth;

    /**
     * @var integer
     */
    private $creditcardinfoExpirationyear;

    /**
     * @var string
     */
    private $creditcardinfoNameoncard;

    /**
     * @var string
     */
    private $creditcardinfoCreditcardaddress;

    /**
     * @var string
     */
    private $creditcardinfoCreditcardpostalcode;

    /**
     * @var string
     */
    private $jobstatus;

    /**
     * @var \DateTime
     */
    private $jobstartdate;

    /**
     * @var \DateTime
     */
    private $jobprojectedenddate;

    /**
     * @var \DateTime
     */
    private $jobenddate;

    /**
     * @var string
     */
    private $jobdesc;

    /**
     * @var string
     */
    private $jobtypeListid;

    /**
     * @var string
     */
    private $jobtypeFullname;

    /**
     * @var string
     */
    private $notes;

    /**
     * @var string
     */
    private $pricelevelListid;

    /**
     * @var string
     */
    private $pricelevelFullname;

    /**
     * @var \DateTime
     */
    private $qbsqlDiscovDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlResyncDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlModifyTimestamp = 'CURRENT_TIMESTAMP';

    /**
     * @var string
     */
    private $qbsqlLastHash;

    /**
     * @var string
     */
    private $qbsqlLastQbxml;

    /**
     * @var string
     */
    private $qbsqlLastErrnum;

    /**
     * @var string
     */
    private $qbsqlLastErrmsg;

    /**
     * @var \DateTime
     */
    private $qbsqlEnqueueDatetime;

    /**
     * @var \DateTime
     */
    private $qbsqlDequeueDatetime;

    /**
     * @var string
     */
    private $qbsqlAuditAmount;

    /**
     * @var \DateTime
     */
    private $qbsqlAuditModified;

    /**
     * @var boolean
     */
    private $qbsqlToSync = '0';

    /**
     * @var boolean
     */
    private $qbsqlToDelete = '0';

    /**
     * @var boolean
     */
    private $qbsqlToSkip = '0';

    /**
     * @var boolean
     */
    private $qbsqlToVoid = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagDeleted = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagSkipped = '0';

    /**
     * @var boolean
     */
    private $qbsqlFlagVoided = '0';


    /**
     * Get qbsqlId
     *
     * @return integer
     */
    public function getQbsqlId()
    {
        return $this->qbsqlId;
    }

    /**
     * Set qbsqlUsernameId
     *
     * @param integer $qbsqlUsernameId
     *
     * @return QbCustomer
     */
    public function setQbsqlUsernameId($qbsqlUsernameId)
    {
        $this->qbsqlUsernameId = $qbsqlUsernameId;

        return $this;
    }

    /**
     * Get qbsqlUsernameId
     *
     * @return integer
     */
    public function getQbsqlUsernameId()
    {
        return $this->qbsqlUsernameId;
    }

    /**
     * Set qbsqlExternalId
     *
     * @param integer $qbsqlExternalId
     *
     * @return QbCustomer
     */
    public function setQbsqlExternalId($qbsqlExternalId)
    {
        $this->qbsqlExternalId = $qbsqlExternalId;

        return $this;
    }

    /**
     * Get qbsqlExternalId
     *
     * @return integer
     */
    public function getQbsqlExternalId()
    {
        return $this->qbsqlExternalId;
    }


    /**
     * Set timecreated
     *
     * @param \DateTime $timecreated
     *
     * @return QbCustomer
     */
    public function setTimecreated($timecreated)
    {
        $this->timecreated = $timecreated;

        return $this;
    }

    /**
     * Get timecreated
     *
     * @return \DateTime
     */
    public function getTimecreated()
    {
        return $this->timecreated;
    }

    /**
     * Set timemodified
     *
     * @param \DateTime $timemodified
     *
     * @return QbCustomer
     */
    public function setTimemodified($timemodified)
    {
        $this->timemodified = $timemodified;

        return $this;
    }

    /**
     * Get timemodified
     *
     * @return \DateTime
     */
    public function getTimemodified()
    {
        return $this->timemodified;
    }

    /**
     * Set editsequence
     *
     * @param string $editsequence
     *
     * @return QbCustomer
     */
    public function setEditsequence($editsequence)
    {
        $this->editsequence = $editsequence;

        return $this;
    }

    /**
     * Get editsequence
     *
     * @return string
     */
    public function getEditsequence()
    {
        return $this->editsequence;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return QbCustomer
     */
    public function setName($name)
    {
        $this->Name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->Name;
    }

    /**
     * Set fullname
     *
     * @param string $fullname
     *
     * @return QbCustomer
     */
    public function setFullname($fullname)
    {
        $this->FullName = $fullname;

        return $this;
    }

    /**
     * Get fullname
     *
     * @return string
     */
    public function getFullname()
    {
        return $this->FullName;
    }

    /**
     * Set isactive
     *
     * @param boolean $isactive
     *
     * @return QbCustomer
     */
    public function setIsactive($isactive)
    {
        $this->isactive = $isactive;

        return $this;
    }

    /**
     * Get isactive
     *
     * @return boolean
     */
    public function getIsactive()
    {
        return $this->isactive;
    }

    /**
     * Set parentListid
     *
     * @param string $parentListid
     *
     * @return QbCustomer
     */
    public function setParentListid($parentListid)
    {
        $this->parentListid = $parentListid;

        return $this;
    }

    /**
     * Get parentListid
     *
     * @return string
     */
    public function getParentListid()
    {
        return $this->parentListid;
    }

    /**
     * Set parentFullname
     *
     * @param string $parentFullname
     *
     * @return QbCustomer
     */
    public function setParentFullname($parentFullname)
    {
        $this->parentFullname = $parentFullname;

        return $this;
    }

    /**
     * Get parentFullname
     *
     * @return string
     */
    public function getParentFullname()
    {
        return $this->parentFullname;
    }

    /**
     * Set sublevel
     *
     * @param integer $sublevel
     *
     * @return QbCustomer
     */
    public function setSublevel($sublevel)
    {
        $this->sublevel = $sublevel;

        return $this;
    }

    /**
     * Get sublevel
     *
     * @return integer
     */
    public function getSublevel()
    {
        return $this->sublevel;
    }

    /**
     * Set companyname
     *
     * @param string $companyname
     *
     * @return QbCustomer
     */
    public function setCompanyname($companyname)
    {
        $this->CompanyName = $companyname;

        return $this;
    }

    /**
     * Get companyname
     *
     * @return string
     */
    public function getCompanyname()
    {
        return $this->CompanyName;
    }

    /**
     * Set salutation
     *
     * @param string $salutation
     *
     * @return QbCustomer
     */
    public function setSalutation($salutation)
    {
        $this->salutation = $salutation;

        return $this;
    }

    /**
     * Get salutation
     *
     * @return string
     */
    public function getSalutation()
    {
        return $this->salutation;
    }

    /**
     * Set firstname
     *
     * @param string $firstname
     *
     * @return QbCustomer
     */
    public function setFirstname($firstname)
    {
        $this->FirstName = $firstname;

        return $this;
    }

    /**
     * Get firstname
     *
     * @return string
     */
    public function getFirstname()
    {
        return $this->FirstName;
    }

    /**
     * Set middlename
     *
     * @param string $middlename
     *
     * @return QbCustomer
     */
    public function setMiddlename($middlename)
    {
        $this->middlename = $middlename;

        return $this;
    }

    /**
     * Get middlename
     *
     * @return string
     */
    public function getMiddlename()
    {
        return $this->middlename;
    }

    /**
     * Set lastname
     *
     * @param string $lastname
     *
     * @return QbCustomer
     */
    public function setLastname($lastname)
    {
        $this->LastName = $lastname;

        return $this;
    }

    /**
     * Get lastname
     *
     * @return string
     */
    public function getLastname()
    {
        return $this->LastName;
    }

    /**
     * Set billaddressAddr1
     *
     * @param string $billaddressAddr1
     *
     * @return QbCustomer
     */
    public function setBilladdressAddr1($billaddressAddr1)
    {
        $this->BillAddress_Addr1 = $billaddressAddr1;

        return $this;
    }

    /**
     * Get billaddressAddr1
     *
     * @return string
     */
    public function getBilladdressAddr1()
    {
        return $this->BillAddress_Addr1;
    }

    /**
     * Set billaddressAddr2
     *
     * @param string $billaddressAddr2
     *
     * @return QbCustomer
     */
    public function setBilladdressAddr2($billaddressAddr2)
    {
        $this->BillAddress_Addr2 = $billaddressAddr2;

        return $this;
    }

    /**
     * Get billaddressAddr2
     *
     * @return string
     */
    public function getBilladdressAddr2()
    {
        return $this->BillAddress_Addr2;
    }

    /**
     * Set billaddressAddr3
     *
     * @param string $billaddressAddr3
     *
     * @return QbCustomer
     */
    public function setBilladdressAddr3($billaddressAddr3)
    {
        $this->BillAddress_Addr3 = $billaddressAddr3;

        return $this;
    }

    /**
     * Get billaddressAddr3
     *
     * @return string
     */
    public function getBilladdressAddr3()
    {
        return $this->BillAddress_Addr3;
    }

    /**
     * Set billaddressAddr4
     *
     * @param string $billaddressAddr4
     *
     * @return QbCustomer
     */
    public function setBilladdressAddr4($billaddressAddr4)
    {
        $this->billaddressAddr4 = $billaddressAddr4;

        return $this;
    }

    /**
     * Get billaddressAddr4
     *
     * @return string
     */
    public function getBilladdressAddr4()
    {
        return $this->billaddressAddr4;
    }

    /**
     * Set billaddressAddr5
     *
     * @param string $billaddressAddr5
     *
     * @return QbCustomer
     */
    public function setBilladdressAddr5($billaddressAddr5)
    {
        $this->billaddressAddr5 = $billaddressAddr5;

        return $this;
    }

    /**
     * Get billaddressAddr5
     *
     * @return string
     */
    public function getBilladdressAddr5()
    {
        return $this->billaddressAddr5;
    }

    /**
     * Set billaddressCity
     *
     * @param string $billaddressCity
     *
     * @return QbCustomer
     */
    public function setBilladdressCity($billaddressCity)
    {
        $this->BillAddress_City = $billaddressCity;

        return $this;
    }

    /**
     * Get billaddressCity
     *
     * @return string
     */
    public function getBilladdressCity()
    {
        return $this->BillAddress_City;
    }

    /**
     * Set billaddressState
     *
     * @param string $billaddressState
     *
     * @return QbCustomer
     */
    public function setBilladdressState($billaddressState)
    {
        $this->BillAddress_State = $billaddressState;

        return $this;
    }

    /**
     * Get billaddressState
     *
     * @return string
     */
    public function getBilladdressState()
    {
        return $this->BillAddress_State;
    }

    /**
     * Set billaddressPostalcode
     *
     * @param string $billaddressPostalcode
     *
     * @return QbCustomer
     */
    public function setBilladdressPostalcode($billaddressPostalcode)
    {
        $this->BillAddress_PostalCode = $billaddressPostalcode;

        return $this;
    }

    /**
     * Get billaddressPostalcode
     *
     * @return string
     */
    public function getBilladdressPostalcode()
    {
        return $this->BillAddress_PostalCode;
    }

    /**
     * Set billaddressCountry
     *
     * @param string $billaddressCountry
     *
     * @return QbCustomer
     */
    public function setBilladdressCountry($billaddressCountry)
    {
        $this->BillAddress_Country = $billaddressCountry;

        return $this;
    }

    /**
     * Get billaddressCountry
     *
     * @return string
     */
    public function getBilladdressCountry()
    {
        return $this->BillAddress_Country;
    }

    /**
     * Set billaddressNote
     *
     * @param string $billaddressNote
     *
     * @return QbCustomer
     */
    public function setBilladdressNote($billaddressNote)
    {
        $this->billaddressNote = $billaddressNote;

        return $this;
    }

    /**
     * Get billaddressNote
     *
     * @return string
     */
    public function getBilladdressNote()
    {
        return $this->billaddressNote;
    }

    /**
     * Set billaddressblockAddr1
     *
     * @param string $billaddressblockAddr1
     *
     * @return QbCustomer
     */
    public function setBilladdressblockAddr1($billaddressblockAddr1)
    {
        $this->billaddressblockAddr1 = $billaddressblockAddr1;

        return $this;
    }

    /**
     * Get billaddressblockAddr1
     *
     * @return string
     */
    public function getBilladdressblockAddr1()
    {
        return $this->billaddressblockAddr1;
    }

    /**
     * Set billaddressblockAddr2
     *
     * @param string $billaddressblockAddr2
     *
     * @return QbCustomer
     */
    public function setBilladdressblockAddr2($billaddressblockAddr2)
    {
        $this->billaddressblockAddr2 = $billaddressblockAddr2;

        return $this;
    }

    /**
     * Get billaddressblockAddr2
     *
     * @return string
     */
    public function getBilladdressblockAddr2()
    {
        return $this->billaddressblockAddr2;
    }

    /**
     * Set billaddressblockAddr3
     *
     * @param string $billaddressblockAddr3
     *
     * @return QbCustomer
     */
    public function setBilladdressblockAddr3($billaddressblockAddr3)
    {
        $this->billaddressblockAddr3 = $billaddressblockAddr3;

        return $this;
    }

    /**
     * Get billaddressblockAddr3
     *
     * @return string
     */
    public function getBilladdressblockAddr3()
    {
        return $this->billaddressblockAddr3;
    }

    /**
     * Set billaddressblockAddr4
     *
     * @param string $billaddressblockAddr4
     *
     * @return QbCustomer
     */
    public function setBilladdressblockAddr4($billaddressblockAddr4)
    {
        $this->billaddressblockAddr4 = $billaddressblockAddr4;

        return $this;
    }

    /**
     * Get billaddressblockAddr4
     *
     * @return string
     */
    public function getBilladdressblockAddr4()
    {
        return $this->billaddressblockAddr4;
    }

    /**
     * Set billaddressblockAddr5
     *
     * @param string $billaddressblockAddr5
     *
     * @return QbCustomer
     */
    public function setBilladdressblockAddr5($billaddressblockAddr5)
    {
        $this->billaddressblockAddr5 = $billaddressblockAddr5;

        return $this;
    }

    /**
     * Get billaddressblockAddr5
     *
     * @return string
     */
    public function getBilladdressblockAddr5()
    {
        return $this->billaddressblockAddr5;
    }

    /**
     * Set shipaddressAddr1
     *
     * @param string $shipaddressAddr1
     *
     * @return QbCustomer
     */
    public function setShipaddressAddr1($shipaddressAddr1)
    {
        $this->shipaddressAddr1 = $shipaddressAddr1;

        return $this;
    }

    /**
     * Get shipaddressAddr1
     *
     * @return string
     */
    public function getShipaddressAddr1()
    {
        return $this->shipaddressAddr1;
    }

    /**
     * Set shipaddressAddr2
     *
     * @param string $shipaddressAddr2
     *
     * @return QbCustomer
     */
    public function setShipaddressAddr2($shipaddressAddr2)
    {
        $this->shipaddressAddr2 = $shipaddressAddr2;

        return $this;
    }

    /**
     * Get shipaddressAddr2
     *
     * @return string
     */
    public function getShipaddressAddr2()
    {
        return $this->shipaddressAddr2;
    }

    /**
     * Set shipaddressAddr3
     *
     * @param string $shipaddressAddr3
     *
     * @return QbCustomer
     */
    public function setShipaddressAddr3($shipaddressAddr3)
    {
        $this->shipaddressAddr3 = $shipaddressAddr3;

        return $this;
    }

    /**
     * Get shipaddressAddr3
     *
     * @return string
     */
    public function getShipaddressAddr3()
    {
        return $this->shipaddressAddr3;
    }

    /**
     * Set shipaddressAddr4
     *
     * @param string $shipaddressAddr4
     *
     * @return QbCustomer
     */
    public function setShipaddressAddr4($shipaddressAddr4)
    {
        $this->shipaddressAddr4 = $shipaddressAddr4;

        return $this;
    }

    /**
     * Get shipaddressAddr4
     *
     * @return string
     */
    public function getShipaddressAddr4()
    {
        return $this->shipaddressAddr4;
    }

    /**
     * Set shipaddressAddr5
     *
     * @param string $shipaddressAddr5
     *
     * @return QbCustomer
     */
    public function setShipaddressAddr5($shipaddressAddr5)
    {
        $this->shipaddressAddr5 = $shipaddressAddr5;

        return $this;
    }

    /**
     * Get shipaddressAddr5
     *
     * @return string
     */
    public function getShipaddressAddr5()
    {
        return $this->shipaddressAddr5;
    }

    /**
     * Set shipaddressCity
     *
     * @param string $shipaddressCity
     *
     * @return QbCustomer
     */
    public function setShipaddressCity($shipaddressCity)
    {
        $this->shipaddressCity = $shipaddressCity;

        return $this;
    }

    /**
     * Get shipaddressCity
     *
     * @return string
     */
    public function getShipaddressCity()
    {
        return $this->shipaddressCity;
    }

    /**
     * Set shipaddressState
     *
     * @param string $shipaddressState
     *
     * @return QbCustomer
     */
    public function setShipaddressState($shipaddressState)
    {
        $this->shipaddressState = $shipaddressState;

        return $this;
    }

    /**
     * Get shipaddressState
     *
     * @return string
     */
    public function getShipaddressState()
    {
        return $this->shipaddressState;
    }

    /**
     * Set shipaddressPostalcode
     *
     * @param string $shipaddressPostalcode
     *
     * @return QbCustomer
     */
    public function setShipaddressPostalcode($shipaddressPostalcode)
    {
        $this->shipaddressPostalcode = $shipaddressPostalcode;

        return $this;
    }

    /**
     * Get shipaddressPostalcode
     *
     * @return string
     */
    public function getShipaddressPostalcode()
    {
        return $this->shipaddressPostalcode;
    }

    /**
     * Set shipaddressCountry
     *
     * @param string $shipaddressCountry
     *
     * @return QbCustomer
     */
    public function setShipaddressCountry($shipaddressCountry)
    {
        $this->shipaddressCountry = $shipaddressCountry;

        return $this;
    }

    /**
     * Get shipaddressCountry
     *
     * @return string
     */
    public function getShipaddressCountry()
    {
        return $this->shipaddressCountry;
    }

    /**
     * Set shipaddressNote
     *
     * @param string $shipaddressNote
     *
     * @return QbCustomer
     */
    public function setShipaddressNote($shipaddressNote)
    {
        $this->shipaddressNote = $shipaddressNote;

        return $this;
    }

    /**
     * Get shipaddressNote
     *
     * @return string
     */
    public function getShipaddressNote()
    {
        return $this->shipaddressNote;
    }

    /**
     * Set shipaddressblockAddr1
     *
     * @param string $shipaddressblockAddr1
     *
     * @return QbCustomer
     */
    public function setShipaddressblockAddr1($shipaddressblockAddr1)
    {
        $this->shipaddressblockAddr1 = $shipaddressblockAddr1;

        return $this;
    }

    /**
     * Get shipaddressblockAddr1
     *
     * @return string
     */
    public function getShipaddressblockAddr1()
    {
        return $this->shipaddressblockAddr1;
    }

    /**
     * Set shipaddressblockAddr2
     *
     * @param string $shipaddressblockAddr2
     *
     * @return QbCustomer
     */
    public function setShipaddressblockAddr2($shipaddressblockAddr2)
    {
        $this->shipaddressblockAddr2 = $shipaddressblockAddr2;

        return $this;
    }

    /**
     * Get shipaddressblockAddr2
     *
     * @return string
     */
    public function getShipaddressblockAddr2()
    {
        return $this->shipaddressblockAddr2;
    }

    /**
     * Set shipaddressblockAddr3
     *
     * @param string $shipaddressblockAddr3
     *
     * @return QbCustomer
     */
    public function setShipaddressblockAddr3($shipaddressblockAddr3)
    {
        $this->shipaddressblockAddr3 = $shipaddressblockAddr3;

        return $this;
    }

    /**
     * Get shipaddressblockAddr3
     *
     * @return string
     */
    public function getShipaddressblockAddr3()
    {
        return $this->shipaddressblockAddr3;
    }

    /**
     * Set shipaddressblockAddr4
     *
     * @param string $shipaddressblockAddr4
     *
     * @return QbCustomer
     */
    public function setShipaddressblockAddr4($shipaddressblockAddr4)
    {
        $this->shipaddressblockAddr4 = $shipaddressblockAddr4;

        return $this;
    }

    /**
     * Get shipaddressblockAddr4
     *
     * @return string
     */
    public function getShipaddressblockAddr4()
    {
        return $this->shipaddressblockAddr4;
    }

    /**
     * Set shipaddressblockAddr5
     *
     * @param string $shipaddressblockAddr5
     *
     * @return QbCustomer
     */
    public function setShipaddressblockAddr5($shipaddressblockAddr5)
    {
        $this->shipaddressblockAddr5 = $shipaddressblockAddr5;

        return $this;
    }

    /**
     * Get shipaddressblockAddr5
     *
     * @return string
     */
    public function getShipaddressblockAddr5()
    {
        return $this->shipaddressblockAddr5;
    }

    /**
     * Set phone
     *
     * @param string $phone
     *
     * @return QbCustomer
     */
    public function setPhone($phone)
    {
        $this->Phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->Phone;
    }

    /**
     * Set altphone
     *
     * @param string $altphone
     *
     * @return QbCustomer
     */
    public function setAltphone($altphone)
    {
        $this->altphone = $altphone;

        return $this;
    }

    /**
     * Get altphone
     *
     * @return string
     */
    public function getAltphone()
    {
        return $this->altphone;
    }

    /**
     * Set fax
     *
     * @param string $fax
     *
     * @return QbCustomer
     */
    public function setFax($fax)
    {
        $this->fax = $fax;

        return $this;
    }

    /**
     * Get fax
     *
     * @return string
     */
    public function getFax()
    {
        return $this->fax;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return QbCustomer
     */
    public function setEmail($email)
    {
        $this->Email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->Email;
    }

    /**
     * Set altemail
     *
     * @param string $altemail
     *
     * @return QbCustomer
     */
    public function setAltemail($altemail)
    {
        $this->altemail = $altemail;

        return $this;
    }

    /**
     * Get altemail
     *
     * @return string
     */
    public function getAltemail()
    {
        return $this->altemail;
    }

    /**
     * Set contact
     *
     * @param string $contact
     *
     * @return QbCustomer
     */
    public function setContact($contact)
    {
        $this->contact = $contact;

        return $this;
    }

    /**
     * Get contact
     *
     * @return string
     */
    public function getContact()
    {
        return $this->contact;
    }

    /**
     * Set altcontact
     *
     * @param string $altcontact
     *
     * @return QbCustomer
     */
    public function setAltcontact($altcontact)
    {
        $this->altcontact = $altcontact;

        return $this;
    }

    /**
     * Get altcontact
     *
     * @return string
     */
    public function getAltcontact()
    {
        return $this->altcontact;
    }

    /**
     * Set customertypeListid
     *
     * @param string $customertypeListid
     *
     * @return QbCustomer
     */
    public function setCustomertypeListid($customertypeListid)
    {
        $this->customertypeListid = $customertypeListid;

        return $this;
    }

    /**
     * Get customertypeListid
     *
     * @return string
     */
    public function getCustomertypeListid()
    {
        return $this->customertypeListid;
    }

    /**
     * Set customertypeFullname
     *
     * @param string $customertypeFullname
     *
     * @return QbCustomer
     */
    public function setCustomertypeFullname($customertypeFullname)
    {
        $this->customertypeFullname = $customertypeFullname;

        return $this;
    }

    /**
     * Get customertypeFullname
     *
     * @return string
     */
    public function getCustomertypeFullname()
    {
        return $this->customertypeFullname;
    }

    /**
     * Set termsListid
     *
     * @param string $termsListid
     *
     * @return QbCustomer
     */
    public function setTermsListid($termsListid)
    {
        $this->termsListid = $termsListid;

        return $this;
    }

    /**
     * Get termsListid
     *
     * @return string
     */
    public function getTermsListid()
    {
        return $this->termsListid;
    }

    /**
     * Set termsFullname
     *
     * @param string $termsFullname
     *
     * @return QbCustomer
     */
    public function setTermsFullname($termsFullname)
    {
        $this->termsFullname = $termsFullname;

        return $this;
    }

    /**
     * Get termsFullname
     *
     * @return string
     */
    public function getTermsFullname()
    {
        return $this->termsFullname;
    }

    /**
     * Set salesrepListid
     *
     * @param string $salesrepListid
     *
     * @return QbCustomer
     */
    public function setSalesrepListid($salesrepListid)
    {
        $this->salesrepListid = $salesrepListid;

        return $this;
    }

    /**
     * Get salesrepListid
     *
     * @return string
     */
    public function getSalesrepListid()
    {
        return $this->salesrepListid;
    }

    /**
     * Set salesrepFullname
     *
     * @param string $salesrepFullname
     *
     * @return QbCustomer
     */
    public function setSalesrepFullname($salesrepFullname)
    {
        $this->salesrepFullname = $salesrepFullname;

        return $this;
    }

    /**
     * Get salesrepFullname
     *
     * @return string
     */
    public function getSalesrepFullname()
    {
        return $this->salesrepFullname;
    }

    /**
     * Set balance
     *
     * @param string $balance
     *
     * @return QbCustomer
     */
    public function setBalance($balance)
    {
        $this->balance = $balance;

        return $this;
    }

    /**
     * Get balance
     *
     * @return string
     */
    public function getBalance()
    {
        return $this->balance;
    }

    /**
     * Set totalbalance
     *
     * @param string $totalbalance
     *
     * @return QbCustomer
     */
    public function setTotalbalance($totalbalance)
    {
        $this->totalbalance = $totalbalance;

        return $this;
    }

    /**
     * Get totalbalance
     *
     * @return string
     */
    public function getTotalbalance()
    {
        return $this->totalbalance;
    }

    /**
     * Set salestaxcodeListid
     *
     * @param string $salestaxcodeListid
     *
     * @return QbCustomer
     */
    public function setSalestaxcodeListid($salestaxcodeListid)
    {
        $this->salestaxcodeListid = $salestaxcodeListid;

        return $this;
    }

    /**
     * Get salestaxcodeListid
     *
     * @return string
     */
    public function getSalestaxcodeListid()
    {
        return $this->salestaxcodeListid;
    }

    /**
     * Set salestaxcodeFullname
     *
     * @param string $salestaxcodeFullname
     *
     * @return QbCustomer
     */
    public function setSalestaxcodeFullname($salestaxcodeFullname)
    {
        $this->salestaxcodeFullname = $salestaxcodeFullname;

        return $this;
    }

    /**
     * Get salestaxcodeFullname
     *
     * @return string
     */
    public function getSalestaxcodeFullname()
    {
        return $this->salestaxcodeFullname;
    }

    /**
     * Set itemsalestaxListid
     *
     * @param string $itemsalestaxListid
     *
     * @return QbCustomer
     */
    public function setItemsalestaxListid($itemsalestaxListid)
    {
        $this->itemsalestaxListid = $itemsalestaxListid;

        return $this;
    }

    /**
     * Get itemsalestaxListid
     *
     * @return string
     */
    public function getItemsalestaxListid()
    {
        return $this->itemsalestaxListid;
    }

    /**
     * Set itemsalestaxFullname
     *
     * @param string $itemsalestaxFullname
     *
     * @return QbCustomer
     */
    public function setItemsalestaxFullname($itemsalestaxFullname)
    {
        $this->itemsalestaxFullname = $itemsalestaxFullname;

        return $this;
    }

    /**
     * Get itemsalestaxFullname
     *
     * @return string
     */
    public function getItemsalestaxFullname()
    {
        return $this->itemsalestaxFullname;
    }

    /**
     * Set resalenumber
     *
     * @param string $resalenumber
     *
     * @return QbCustomer
     */
    public function setResalenumber($resalenumber)
    {
        $this->resalenumber = $resalenumber;

        return $this;
    }

    /**
     * Get resalenumber
     *
     * @return string
     */
    public function getResalenumber()
    {
        return $this->resalenumber;
    }

    /**
     * Set accountnumber
     *
     * @param string $accountnumber
     *
     * @return QbCustomer
     */
    public function setAccountnumber($accountnumber)
    {
        $this->accountnumber = $accountnumber;

        return $this;
    }

    /**
     * Get accountnumber
     *
     * @return string
     */
    public function getAccountnumber()
    {
        return $this->accountnumber;
    }

    /**
     * Set creditlimit
     *
     * @param string $creditlimit
     *
     * @return QbCustomer
     */
    public function setCreditlimit($creditlimit)
    {
        $this->creditlimit = $creditlimit;

        return $this;
    }

    /**
     * Get creditlimit
     *
     * @return string
     */
    public function getCreditlimit()
    {
        return $this->creditlimit;
    }

    /**
     * Set preferredpaymentmethodListid
     *
     * @param string $preferredpaymentmethodListid
     *
     * @return QbCustomer
     */
    public function setPreferredpaymentmethodListid($preferredpaymentmethodListid)
    {
        $this->preferredpaymentmethodListid = $preferredpaymentmethodListid;

        return $this;
    }

    /**
     * Get preferredpaymentmethodListid
     *
     * @return string
     */
    public function getPreferredpaymentmethodListid()
    {
        return $this->preferredpaymentmethodListid;
    }

    /**
     * Set preferredpaymentmethodFullname
     *
     * @param string $preferredpaymentmethodFullname
     *
     * @return QbCustomer
     */
    public function setPreferredpaymentmethodFullname($preferredpaymentmethodFullname)
    {
        $this->preferredpaymentmethodFullname = $preferredpaymentmethodFullname;

        return $this;
    }

    /**
     * Get preferredpaymentmethodFullname
     *
     * @return string
     */
    public function getPreferredpaymentmethodFullname()
    {
        return $this->preferredpaymentmethodFullname;
    }

    /**
     * Set creditcardinfoCreditcardnumber
     *
     * @param string $creditcardinfoCreditcardnumber
     *
     * @return QbCustomer
     */
    public function setCreditcardinfoCreditcardnumber($creditcardinfoCreditcardnumber)
    {
        $this->creditcardinfoCreditcardnumber = $creditcardinfoCreditcardnumber;

        return $this;
    }

    /**
     * Get creditcardinfoCreditcardnumber
     *
     * @return string
     */
    public function getCreditcardinfoCreditcardnumber()
    {
        return $this->creditcardinfoCreditcardnumber;
    }

    /**
     * Set creditcardinfoExpirationmonth
     *
     * @param integer $creditcardinfoExpirationmonth
     *
     * @return QbCustomer
     */
    public function setCreditcardinfoExpirationmonth($creditcardinfoExpirationmonth)
    {
        $this->creditcardinfoExpirationmonth = $creditcardinfoExpirationmonth;

        return $this;
    }

    /**
     * Get creditcardinfoExpirationmonth
     *
     * @return integer
     */
    public function getCreditcardinfoExpirationmonth()
    {
        return $this->creditcardinfoExpirationmonth;
    }

    /**
     * Set creditcardinfoExpirationyear
     *
     * @param integer $creditcardinfoExpirationyear
     *
     * @return QbCustomer
     */
    public function setCreditcardinfoExpirationyear($creditcardinfoExpirationyear)
    {
        $this->creditcardinfoExpirationyear = $creditcardinfoExpirationyear;

        return $this;
    }

    /**
     * Get creditcardinfoExpirationyear
     *
     * @return integer
     */
    public function getCreditcardinfoExpirationyear()
    {
        return $this->creditcardinfoExpirationyear;
    }

    /**
     * Set creditcardinfoNameoncard
     *
     * @param string $creditcardinfoNameoncard
     *
     * @return QbCustomer
     */
    public function setCreditcardinfoNameoncard($creditcardinfoNameoncard)
    {
        $this->creditcardinfoNameoncard = $creditcardinfoNameoncard;

        return $this;
    }

    /**
     * Get creditcardinfoNameoncard
     *
     * @return string
     */
    public function getCreditcardinfoNameoncard()
    {
        return $this->creditcardinfoNameoncard;
    }

    /**
     * Set creditcardinfoCreditcardaddress
     *
     * @param string $creditcardinfoCreditcardaddress
     *
     * @return QbCustomer
     */
    public function setCreditcardinfoCreditcardaddress($creditcardinfoCreditcardaddress)
    {
        $this->creditcardinfoCreditcardaddress = $creditcardinfoCreditcardaddress;

        return $this;
    }

    /**
     * Get creditcardinfoCreditcardaddress
     *
     * @return string
     */
    public function getCreditcardinfoCreditcardaddress()
    {
        return $this->creditcardinfoCreditcardaddress;
    }

    /**
     * Set creditcardinfoCreditcardpostalcode
     *
     * @param string $creditcardinfoCreditcardpostalcode
     *
     * @return QbCustomer
     */
    public function setCreditcardinfoCreditcardpostalcode($creditcardinfoCreditcardpostalcode)
    {
        $this->creditcardinfoCreditcardpostalcode = $creditcardinfoCreditcardpostalcode;

        return $this;
    }

    /**
     * Get creditcardinfoCreditcardpostalcode
     *
     * @return string
     */
    public function getCreditcardinfoCreditcardpostalcode()
    {
        return $this->creditcardinfoCreditcardpostalcode;
    }

    /**
     * Set jobstatus
     *
     * @param string $jobstatus
     *
     * @return QbCustomer
     */
    public function setJobstatus($jobstatus)
    {
        $this->jobstatus = $jobstatus;

        return $this;
    }

    /**
     * Get jobstatus
     *
     * @return string
     */
    public function getJobstatus()
    {
        return $this->jobstatus;
    }

    /**
     * Set jobstartdate
     *
     * @param \DateTime $jobstartdate
     *
     * @return QbCustomer
     */
    public function setJobstartdate($jobstartdate)
    {
        $this->jobstartdate = $jobstartdate;

        return $this;
    }

    /**
     * Get jobstartdate
     *
     * @return \DateTime
     */
    public function getJobstartdate()
    {
        return $this->jobstartdate;
    }

    /**
     * Set jobprojectedenddate
     *
     * @param \DateTime $jobprojectedenddate
     *
     * @return QbCustomer
     */
    public function setJobprojectedenddate($jobprojectedenddate)
    {
        $this->jobprojectedenddate = $jobprojectedenddate;

        return $this;
    }

    /**
     * Get jobprojectedenddate
     *
     * @return \DateTime
     */
    public function getJobprojectedenddate()
    {
        return $this->jobprojectedenddate;
    }

    /**
     * Set jobenddate
     *
     * @param \DateTime $jobenddate
     *
     * @return QbCustomer
     */
    public function setJobenddate($jobenddate)
    {
        $this->jobenddate = $jobenddate;

        return $this;
    }

    /**
     * Get jobenddate
     *
     * @return \DateTime
     */
    public function getJobenddate()
    {
        return $this->jobenddate;
    }

    /**
     * Set jobdesc
     *
     * @param string $jobdesc
     *
     * @return QbCustomer
     */
    public function setJobdesc($jobdesc)
    {
        $this->jobdesc = $jobdesc;

        return $this;
    }

    /**
     * Get jobdesc
     *
     * @return string
     */
    public function getJobdesc()
    {
        return $this->jobdesc;
    }

    /**
     * Set jobtypeListid
     *
     * @param string $jobtypeListid
     *
     * @return QbCustomer
     */
    public function setJobtypeListid($jobtypeListid)
    {
        $this->jobtypeListid = $jobtypeListid;

        return $this;
    }

    /**
     * Get jobtypeListid
     *
     * @return string
     */
    public function getJobtypeListid()
    {
        return $this->jobtypeListid;
    }

    /**
     * Set jobtypeFullname
     *
     * @param string $jobtypeFullname
     *
     * @return QbCustomer
     */
    public function setJobtypeFullname($jobtypeFullname)
    {
        $this->jobtypeFullname = $jobtypeFullname;

        return $this;
    }

    /**
     * Get jobtypeFullname
     *
     * @return string
     */
    public function getJobtypeFullname()
    {
        return $this->jobtypeFullname;
    }

    /**
     * Set notes
     *
     * @param string $notes
     *
     * @return QbCustomer
     */
    public function setNotes($notes)
    {
        $this->notes = $notes;

        return $this;
    }

    /**
     * Get notes
     *
     * @return string
     */
    public function getNotes()
    {
        return $this->notes;
    }

    /**
     * Set pricelevelListid
     *
     * @param string $pricelevelListid
     *
     * @return QbCustomer
     */
    public function setPricelevelListid($pricelevelListid)
    {
        $this->pricelevelListid = $pricelevelListid;

        return $this;
    }

    /**
     * Get pricelevelListid
     *
     * @return string
     */
    public function getPricelevelListid()
    {
        return $this->pricelevelListid;
    }

    /**
     * Set pricelevelFullname
     *
     * @param string $pricelevelFullname
     *
     * @return QbCustomer
     */
    public function setPricelevelFullname($pricelevelFullname)
    {
        $this->pricelevelFullname = $pricelevelFullname;

        return $this;
    }

    /**
     * Get pricelevelFullname
     *
     * @return string
     */
    public function getPricelevelFullname()
    {
        return $this->pricelevelFullname;
    }

    /**
     * Set qbsqlDiscovDatetime
     *
     * @param \DateTime $qbsqlDiscovDatetime
     *
     * @return QbCustomer
     */
    public function setQbsqlDiscovDatetime($qbsqlDiscovDatetime)
    {
        $this->qbsqlDiscovDatetime = $qbsqlDiscovDatetime;

        return $this;
    }

    /**
     * Get qbsqlDiscovDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDiscovDatetime()
    {
        return $this->qbsqlDiscovDatetime;
    }

    /**
     * Set qbsqlResyncDatetime
     *
     * @param \DateTime $qbsqlResyncDatetime
     *
     * @return QbCustomer
     */
    public function setQbsqlResyncDatetime($qbsqlResyncDatetime)
    {
        $this->qbsqlResyncDatetime = $qbsqlResyncDatetime;

        return $this;
    }

    /**
     * Get qbsqlResyncDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlResyncDatetime()
    {
        return $this->qbsqlResyncDatetime;
    }

    /**
     * Set qbsqlModifyTimestamp
     *
     * @param \DateTime $qbsqlModifyTimestamp
     *
     * @return QbCustomer
     */
    public function setQbsqlModifyTimestamp($qbsqlModifyTimestamp)
    {
        $this->qbsqlModifyTimestamp = $qbsqlModifyTimestamp;

        return $this;
    }

    /**
     * Get qbsqlModifyTimestamp
     *
     * @return \DateTime
     */
    public function getQbsqlModifyTimestamp()
    {
        return $this->qbsqlModifyTimestamp;
    }

    /**
     * Set qbsqlLastHash
     *
     * @param string $qbsqlLastHash
     *
     * @return QbCustomer
     */
    public function setQbsqlLastHash($qbsqlLastHash)
    {
        $this->qbsqlLastHash = $qbsqlLastHash;

        return $this;
    }

    /**
     * Get qbsqlLastHash
     *
     * @return string
     */
    public function getQbsqlLastHash()
    {
        return $this->qbsqlLastHash;
    }

    /**
     * Set qbsqlLastQbxml
     *
     * @param string $qbsqlLastQbxml
     *
     * @return QbCustomer
     */
    public function setQbsqlLastQbxml($qbsqlLastQbxml)
    {
        $this->qbsqlLastQbxml = $qbsqlLastQbxml;

        return $this;
    }

    /**
     * Get qbsqlLastQbxml
     *
     * @return string
     */
    public function getQbsqlLastQbxml()
    {
        return $this->qbsqlLastQbxml;
    }

    /**
     * Set qbsqlLastErrnum
     *
     * @param string $qbsqlLastErrnum
     *
     * @return QbCustomer
     */
    public function setQbsqlLastErrnum($qbsqlLastErrnum)
    {
        $this->qbsqlLastErrnum = $qbsqlLastErrnum;

        return $this;
    }

    /**
     * Get qbsqlLastErrnum
     *
     * @return string
     */
    public function getQbsqlLastErrnum()
    {
        return $this->qbsqlLastErrnum;
    }

    /**
     * Set qbsqlLastErrmsg
     *
     * @param string $qbsqlLastErrmsg
     *
     * @return QbCustomer
     */
    public function setQbsqlLastErrmsg($qbsqlLastErrmsg)
    {
        $this->qbsqlLastErrmsg = $qbsqlLastErrmsg;

        return $this;
    }

    /**
     * Get qbsqlLastErrmsg
     *
     * @return string
     */
    public function getQbsqlLastErrmsg()
    {
        return $this->qbsqlLastErrmsg;
    }

    /**
     * Set qbsqlEnqueueDatetime
     *
     * @param \DateTime $qbsqlEnqueueDatetime
     *
     * @return QbCustomer
     */
    public function setQbsqlEnqueueDatetime($qbsqlEnqueueDatetime)
    {
        $this->qbsqlEnqueueDatetime = $qbsqlEnqueueDatetime;

        return $this;
    }

    /**
     * Get qbsqlEnqueueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlEnqueueDatetime()
    {
        return $this->qbsqlEnqueueDatetime;
    }

    /**
     * Set qbsqlDequeueDatetime
     *
     * @param \DateTime $qbsqlDequeueDatetime
     *
     * @return QbCustomer
     */
    public function setQbsqlDequeueDatetime($qbsqlDequeueDatetime)
    {
        $this->qbsqlDequeueDatetime = $qbsqlDequeueDatetime;

        return $this;
    }

    /**
     * Get qbsqlDequeueDatetime
     *
     * @return \DateTime
     */
    public function getQbsqlDequeueDatetime()
    {
        return $this->qbsqlDequeueDatetime;
    }

    /**
     * Set qbsqlAuditAmount
     *
     * @param string $qbsqlAuditAmount
     *
     * @return QbCustomer
     */
    public function setQbsqlAuditAmount($qbsqlAuditAmount)
    {
        $this->qbsqlAuditAmount = $qbsqlAuditAmount;

        return $this;
    }

    /**
     * Get qbsqlAuditAmount
     *
     * @return string
     */
    public function getQbsqlAuditAmount()
    {
        return $this->qbsqlAuditAmount;
    }

    /**
     * Set qbsqlAuditModified
     *
     * @param \DateTime $qbsqlAuditModified
     *
     * @return QbCustomer
     */
    public function setQbsqlAuditModified($qbsqlAuditModified)
    {
        $this->qbsqlAuditModified = $qbsqlAuditModified;

        return $this;
    }

    /**
     * Get qbsqlAuditModified
     *
     * @return \DateTime
     */
    public function getQbsqlAuditModified()
    {
        return $this->qbsqlAuditModified;
    }

    /**
     * Set qbsqlToSync
     *
     * @param boolean $qbsqlToSync
     *
     * @return QbCustomer
     */
    public function setQbsqlToSync($qbsqlToSync)
    {
        $this->qbsqlToSync = $qbsqlToSync;

        return $this;
    }

    /**
     * Get qbsqlToSync
     *
     * @return boolean
     */
    public function getQbsqlToSync()
    {
        return $this->qbsqlToSync;
    }

    /**
     * Set qbsqlToDelete
     *
     * @param boolean $qbsqlToDelete
     *
     * @return QbCustomer
     */
    public function setQbsqlToDelete($qbsqlToDelete)
    {
        $this->qbsqlToDelete = $qbsqlToDelete;

        return $this;
    }

    /**
     * Get qbsqlToDelete
     *
     * @return boolean
     */
    public function getQbsqlToDelete()
    {
        return $this->qbsqlToDelete;
    }

    /**
     * Set qbsqlToSkip
     *
     * @param boolean $qbsqlToSkip
     *
     * @return QbCustomer
     */
    public function setQbsqlToSkip($qbsqlToSkip)
    {
        $this->qbsqlToSkip = $qbsqlToSkip;

        return $this;
    }

    /**
     * Get qbsqlToSkip
     *
     * @return boolean
     */
    public function getQbsqlToSkip()
    {
        return $this->qbsqlToSkip;
    }

    /**
     * Set qbsqlToVoid
     *
     * @param boolean $qbsqlToVoid
     *
     * @return QbCustomer
     */
    public function setQbsqlToVoid($qbsqlToVoid)
    {
        $this->qbsqlToVoid = $qbsqlToVoid;

        return $this;
    }

    /**
     * Get qbsqlToVoid
     *
     * @return boolean
     */
    public function getQbsqlToVoid()
    {
        return $this->qbsqlToVoid;
    }

    /**
     * Set qbsqlFlagDeleted
     *
     * @param boolean $qbsqlFlagDeleted
     *
     * @return QbCustomer
     */
    public function setQbsqlFlagDeleted($qbsqlFlagDeleted)
    {
        $this->qbsqlFlagDeleted = $qbsqlFlagDeleted;

        return $this;
    }

    /**
     * Get qbsqlFlagDeleted
     *
     * @return boolean
     */
    public function getQbsqlFlagDeleted()
    {
        return $this->qbsqlFlagDeleted;
    }

    /**
     * Set qbsqlFlagSkipped
     *
     * @param boolean $qbsqlFlagSkipped
     *
     * @return QbCustomer
     */
    public function setQbsqlFlagSkipped($qbsqlFlagSkipped)
    {
        $this->qbsqlFlagSkipped = $qbsqlFlagSkipped;

        return $this;
    }

    /**
     * Get qbsqlFlagSkipped
     *
     * @return boolean
     */
    public function getQbsqlFlagSkipped()
    {
        return $this->qbsqlFlagSkipped;
    }

    /**
     * Set qbsqlFlagVoided
     *
     * @param boolean $qbsqlFlagVoided
     *
     * @return QbCustomer
     */
    public function setQbsqlFlagVoided($qbsqlFlagVoided)
    {
        $this->qbsqlFlagVoided = $qbsqlFlagVoided;

        return $this;
    }

    /**
     * Get qbsqlFlagVoided
     *
     * @return boolean
     */
    public function getQbsqlFlagVoided()
    {
        return $this->qbsqlFlagVoided;
    }

    /**
     * Set qbsqlId
     *
     * @param integer $qbsqlId
     *
     * @return QbCustomer
     */
    public function setQbsqlId($qbsqlId)
    {
        $this->qbsqlId = $qbsqlId;

        return $this;
    }

    /**
     * Set listID
     *
     * @param string $listID
     *
     * @return QbCustomer
     */
    public function setListID($listID)
    {
        $this->ListID = $listID;

        return $this;
    }

    /**
     * Get listID
     *
     * @return string
     */
    public function getListID()
    {
        return $this->ListID;
    }
}
