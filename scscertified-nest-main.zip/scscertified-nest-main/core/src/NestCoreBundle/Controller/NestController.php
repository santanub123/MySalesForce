<?php

namespace NestCoreBundle\Controller;

// use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use FOS\RestBundle\Controller\FOSRestController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use ApiBundle\Controller\PersonController;

use FOS\RestBundle\Controller\Annotations\Get; // to amend route for a particular method
use FOS\RestBundle\Controller\Annotations\Patch;
use FOS\RestBundle\View\View;
use Symfony\Component\Serializer\Serializer;

use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * @Route("/nest", name="nest_controller_")
 */
class NestController extends FOSRestController {

    /**
     * @ApiDoc(
     *   views = {"default", "nest-users"},
     *   section = "Nestcore/Nest",
     *   resource = true,
     *   description = "Get permissioned apps for logged-in user",
     *   output = "ApiBundle\Entity\App",
     *   statusCodes = {
     *     200 = "Returned when successful (empty or non-empty),"
     *   }
     * )
     * @Get("/my/apps", name="person_apps", options={"method_prefix" = false})
     */
    public function myAppsAction() {

        $person_id = $this->getUser()->getPerson()->getId();
        
        $response = $this->forward('\ApiBundle\Controller\PersonController::getPersonPrivilegerolesQuery', 
            ["id" => $person_id]
        );

        $apps = [];
        $privilegeroles = json_decode($response->getContent(), true)['data'];
        foreach($privilegeroles as $privilegerole) {

            // remove the id
            unset($privilegerole['privilege']['app']['id']);
            //only returning apps that are active
            if ($privilegerole['privilege']['app']['active']) {
                $apps[$privilegerole['privilege']['app']['appkey']] = $privilegerole['privilege']['app'];
            }

        }

        return new View(
            [
                'code'    => Response::HTTP_OK,
                'message' => '',
                'count'   => count($apps),
                'data'    => $apps,
            ],
            Response::HTTP_OK
        );

    }
}
