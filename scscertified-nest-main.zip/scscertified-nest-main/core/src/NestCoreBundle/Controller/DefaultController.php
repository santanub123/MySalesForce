<?php

namespace NestCoreBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        return $this->redirectToRoute('homepage');
        // return $this->render('NestCoreBundle:Default:index.html.twig');
    }
}
