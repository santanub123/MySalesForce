<?php

namespace NestCoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NestCoreBundle extends Bundle
{
}
