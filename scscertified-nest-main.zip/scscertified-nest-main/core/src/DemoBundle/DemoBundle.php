<?php

namespace DemoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DemoBundle extends Bundle
{
}
