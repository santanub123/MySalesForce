<?php

namespace DemoBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;

/**
 * #Route("/change-this")
 */
class DefaultController extends Controller
{
    /*
     * @Route("/")
     */
    /*
    public function indexAction()
    {
        return $this->render('DemoBundle:Default:index.html.twig');
    }
    */
    
    /*
     * @Route("/menu")
     */
    /*
    public function menuAction()
    {
        return $this->render('DemoBundle:Default:menu.html.twig');
    }
    */
    
    /*** Action methods for HTTP rendering (not API endpoints) ***/
    
    /**
     * @Route("/view/{path}", name="demo_default_index") // knocks out other API routes if evaluated early, but now at end of routing list (routing.yml)
     * @Method({"GET"})
     */
    public function indexAction($path='')
    {
        /*
        // allowed top-level directories (see ApiBundle/Resources/views/Api)
        $allowed = array(
            'backbone',
            'plain',
            'react',
            'vue',
        );
        
        $isValid = 0;
        foreach ($allowed as $v) {
            $test = explode($v, $path);
            if (empty($test[0])) {
                $isValid = 1;
            }
        }
        
        if (!$isValid) {
            $path = '';
        }
        */
        
        //$path='some/folder';
        
        if ($path) {
            return $this->render('DemoBundle:Default/' . $path . ':index.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
            'path' => $path,
            ));
        } else {
            return $this->render('DemoBundle:Default:index.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
            'path' => $path,
            ));
        }
    }
    
    /*
     * Additional routes below for demos (not a great routing method, but flexible enough per root)
     */
    
    /**
     * @Route("/backbone/{path}", name="demo_default_backbone_index", requirements={"path" = ".+"}) // 'path' must neither begin nor end with a "/"
     * @Method({"GET"})
     */
    public function backboneAction($path="")
    {
        $render = self::returnRender('backbone', $path);
        //return $this->render('ApiBundle:Api/backbone/' . $path . ':' . $last . '.html.twig', array(
        
        return $this->render($render, array(
            //'base_dir' => $base_dir,
            //'path'     => $path,
            //'last'     => $last,
            //'type'     => $type,
            ));
    }
    
    /**
     * @Route("/react/{path}", name="demo_default_react_index", requirements={"path" = ".+"}) // 'path' must neither begin nor end with a "/"
     * @Method({"GET"})
     */
    public function reactAction($path="")
    {
        $render = self::returnRender('react', $path);
        //return $this->render('ApiBundle:Api/react/' . $path . ':' . $last . '.html.twig', array(
        
        return $this->render($render, array(
            //'base_dir' => $base_dir,
            //'path'     => $path,
            //'last'     => $last,
            //'type'     => $type,
            ));
    }
    
    /**
     * @Route("/vue/{path}", name="demo_default_vue_index", requirements={"path" = ".+"}) // 'path' must neither begin nor end with a "/"
     * @Method({"GET"})
     */
    public function vueAction($path="")
    {
        $render = self::returnRender('vue', $path);
        //return $this->render('ApiBundle:Api/vue/' . $path . ':' . $last . '.html.twig', array(
        
        return $this->render($render, array(
            //'base_dir' => $base_dir,
            //'path'     => $path,
            //'last'     => $last,
            //'type'     => $type,
            ));
    }
    
    /**
     * @Route("/plain/{path}", name="demo_default_plain_index", requirements={"path" = ".+"}) // 'path' must neither begin nor end with a "/"
     * @Method({"GET"})
     */
    public function plainAction($path="")
    {
        $render = self::returnRender('plain', $path);
        //return $this->render('ApiBundle:Api/plain/' . $path . ':' . $last . '.html.twig', array(
        
        return $this->render($render, array(
            //'base_dir' => $base_dir,
            //'path'     => $path,
            //'last'     => $last,
            //'type'     => $type,
            ));
    }
    
    /**
     * @Route("/menu/{path}", name="demo_default_menu_index", requirements={"path" = ".+"}) // 'path' must neither begin nor end with a "/"
     * @Method({"GET"})
     */
    public function menuAction($path="")
    {
        $render = self::returnRender('menu', $path);
        //return $this->render('ApiBundle:Api/menu/' . $path . ':' . $last . '.html.twig', array(
        
        return $this->render($render, array(
            //'base_dir' => $base_dir,
            //'path'     => $path,
            //'last'     => $last,
            //'type'     => $type,
            ));
    }
    
    public function returnRender($root, $path) {
    
        $last = 'index';
        if ($path) {
            $parts = explode('/', $path);
            $last = array_pop($parts);
            if (count($parts) > 1) {
                $path = implode('/', $parts);
            } else { // 1 part only
                $path = '';
            }
        }
        
        $base_dir = realpath($this->container->getParameter('kernel.root_dir').'/..');

        $fs = new Filesystem();
        
        /*
        try {
            $fs->exists('ApiBundle:Api/' . $root . '/' . $path . ':' . $last . '.html.twig');
        } catch (IOExceptionInterface $e) {
            echo "An error occurred looking for " . $e->getPath();
        }
        */
        
        // Is last array element a dir or a page?
        $type = '';
        if ($fs->exists($base_dir . '/src/DemoBundle/Resources/views/Api/' . $root . '/' . $path . '/' . $last . '.html.twig')) {
            $render = 'DemoBundle:Default/' . $root . '/' . $path . ':' . $last . '.html.twig';
            $type = 'page';
        } elseif ($fs->exists($base_dir . '/src/DemoBundle/Resources/views/Api/' . $root . '/' . $path . '/' . $last . '/' . 'index' . '.html.twig')) {
            $render = 'DemoBundle:Default/' . $root . '/' . $path . '/' . $last . '/' . 'index' . '.html.twig';
            $type = 'dir';
        } else {
            $render = 'DemoBundle:Default/' . $root . ':' . 'index' . '.html.twig'; // default route; replace with error page? In former case, no longer matches browser's URL, which can be problematic
            $type = 'invalid';
        }
        
        return $render;
    
    }

    
}
