<?php

namespace ArsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ArsBundle extends Bundle
{
}
