<?php

namespace IntegrationBundle\Controller;

use IntegrationBundle\Service\AccountingConnector;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Monolog\Logger;
use Monolog\Handler\RotatingFileHandler;
use Monolog\Handler\StreamHandler;
use Monolog\Handler\NativeMailerHandler;

class AccountingController extends Controller
{
    private $log_dir = __DIR__ . '/../../../../log/nest/mac';
    private $logger = null;


    /**
     * @Route("/accounting", name="integration_accounting_index")
     */
    public function indexAction()
    {
        $this->initializeLogger();

        $this->logger->addDebug(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
            ' AccountingController::indexAction called',
            ['REMOTE_ADDR' => $_SERVER['REMOTE_ADDR']]
        );

        // Retrieve options from parameters.yml.
        $options = [];
        $option_keys = [
            'alert_email_address',
            'accounting_endpoint_enable',
            'allowed_salesforce_orgids',
        ];
        foreach ($option_keys as $option_key) {
            $options[$option_key] = $this->container->getParameter($option_key);
        }
        $this->logger->addDebug(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__,
            ['options' => var_export($options, true)]
        );

        // Check to make sure accounting endpoint is enabled.
        if (empty($options['accounting_endpoint_enable'])) {
            $this->logger->addError(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': Accounting endpoint is not enabled, aborting!'
            );
            return null;
        }

        // Check to make sure at least one org id is allowed.
        if (empty($options['allowed_salesforce_orgids'])) {
            $this->logger->addError(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': No org ids allowed, aborting!'
            );
            return null;
        }

        $accounting_connector = $this->get(AccountingConnector::class);
        $accounting_connector->setAlertEmailAddress($options['alert_email_address']);
        $accounting_connector->setAllowedSalesforceOrgIds($options['allowed_salesforce_orgids']);

        $soapServer = new \SoapServer(
            null,
            ['uri' => 'http://nest.scscertified.localhost/']
        );
        $soapServer->setObject($accounting_connector);

        $response = new Response();
        $response->headers->set('Content-Type', 'text/xml; charset=utf-8');

        ob_start();
        $soapServer->handle();
        $content = ob_get_clean();
        $this->logger->addDebug(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
            ' content = "' . var_export($content, true) . '"'
        );
        $response->setContent($content);

        $this->logger->addDebug(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
            ' response = "' . var_export($response, true) . '"'
        );
        return $response;
    }

    /**
     * Initialize Monolog logger.
     */
    private function initializeLogger()
    {
        // Set up Monolog logger.
        $logger = new Logger('AccountingController');

        // Debug log, stores all events.
        $logger->pushHandler(new RotatingFileHandler(
            $this->log_dir . '/debug.log',
            1095,
            Logger::DEBUG
        ));

        // Error log, stores events of level warning and above.
        $logger->pushHandler(new StreamHandler(
            $this->log_dir . '/error.log',
            Logger::WARNING
        ));

        $this->logger = $logger;
        $this->logger->debug('Logger initialized');
    }
}
