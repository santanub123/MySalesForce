<?php

namespace IntegrationBundle\Service;

use \Scs\Integration\Minnow\MinnowAccountingQueue;
use \Scs\Integration\Minnow\MinnowAccount;
use \Scs\Integration\Minnow\MinnowInvoice;
use \Scs\Integration\Minnow\MinnowPayment;
use \Scs\Integration\Minnow\MinnowCreditMemo;
use \Scs\Integration\Quickbooks\QbIntegration;
use Monolog\Logger;
use Monolog\Handler\RotatingFileHandler;
use Monolog\Handler\StreamHandler;
use Monolog\Handler\NativeMailerHandler;

/**
 * Class to act as a service and SOAP endpoint to receive notifications from
 * Minnow for accounting system
 */
class AccountingConnector
{
    // Properties.
    private $qbqueue_db = null;
    private $qbdevkit_db = null;
    private $logger = null;
    private $log_dir = __DIR__ . '/../../../../log/nest/mac';
    private $allowed_salesforce_orgids = [];


    // Methods.

    /**
     * Constructor
     */
    public function __construct()
    {
        // Set up Monolog logger.
        $logger = new Logger('AccountingConnector');

        // Debug log, stores all events.
        $logger->pushHandler(new RotatingFileHandler(
            $this->log_dir . '/debug.log',
            1095,
            Logger::DEBUG
        ));

        // Error log, stores events of level warning and above.
        $logger->pushHandler(new StreamHandler(
            $this->log_dir . '/error.log',
            Logger::WARNING
        ));

        $this->logger = $logger;
        $this->logger->debug('Logger initialized');
    }

    /**
     * Set alert email address
     *
     * Sets email address for error alerts and enables them.
     *
     * @param string $alert_email_address
     *     Email address to send error messages to. If "", no email will be
     *     sent. Configured in parameters.yml.
     */
    public function setAlertEmailAddress($alert_email_address)
    {
        $validated_email = filter_var(
            $alert_email_address,
            \FILTER_VALIDATE_EMAIL
        );
        if (!empty($validated_email)) {
            $to = $validated_email;
            $subject = 'Error alert: AccountingConnector';
            $from = 'donotreply@scscertified.com';
            $level = Logger::ERROR;
            $this->logger->pushHandler(new NativeMailerHandler(
                $to,
                $subject,
                $from,
                $level
            ));
        /* } else {
            $this->logger->error(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': Invalid alert email address: "' .
                $alert_email_address . '"'
            );  */
        }
    }

    /**
     * Set allowed Salesforce org ids
     *
     * Sets org ids allowed to send requests to the handler. If org id is blank
     *     or not in this array, the request is refused.
     *
     * @param array $allowed_salesforce_orgids
     */
    public function setAllowedSalesforceOrgIds($allowed_salesforce_orgids)
    {
        $this->allowed_salesforce_orgids = $allowed_salesforce_orgids;
    }

    /**
     * Receive Minnow outbound message notifications
     *
     * Parse XML and direct notification to appropriate object type handler
     *
     * @param string $id
     *     Has the Org id, we don't really need it
     *
     * @return string
     *     XML response to notification
     */
    public function notifications($id)
    {
        $qb_id = '';
        $session_id = '';
        $notification_id = '';

        try {
            // Read the XML data from the input stream.
            $fh = fopen('php://input', 'rb');
            $xml_str = fread($fh, 100000);
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': xml_str=' . $xml_str
            );

            // Disable DTDs.
            libxml_set_external_entity_loader(null);

            // Parse XML.
            $xml_doc = new \DOMDocument('1.0', 'utf-8');
            $parse_result = $xml_doc->loadXML($xml_str, \LIBXML_PARSEHUGE);
            if (!$parse_result) {
                $this->logger->addDebug(
                    basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                    ': Failed to parse XML, aborting request!'
                );
                return false;
            }

            // Extract org id and validate it.
            $elems = $xml_doc->getElementsByTagName('OrganizationId');
            if ($elems->length !== 1) {
                throw new \Exception('No OrganizationId');
            }
            $org_id = $elems->item(0)->nodeValue;
            if (
                empty($org_id) ||
                !in_array($org_id, $this->allowed_salesforce_orgids)
            ) {
                $this->logger->addDebug(
                    basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                    ': OrganizationId "' . $org_id . '" blank or incorrect, aborting request!'
                );
                return false;
            }

            // Extract session id.
            $elems = $xml_doc->getElementsByTagName('SessionId');
            if ($elems->length !== 1) {
                throw new \Exception('No SessionId');
            }
            $session_id = $elems->item(0)->nodeValue;

            // Extract notification id.
            $notification = $xml_doc->getElementsByTagName('Notification')->item(0);
            foreach ($notification->childNodes as $node) {
                if (($node->nodeType === 1) && ($node->nodeName === 'Id')) {
                    $notification_id = $node->nodeValue;
                    break;
                }
            }
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__,
                ['notification_id' => $notification_id]
            );
        } catch (\Exception $e) {
            $this->logger->addCritical(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': ' . $e->getMessage()
            );
            return false;
        }

        // Create temporary MinnowAccountingQueue object so we can access getMinnowModeFromOrgid
        $maq_temp = new MinnowAccountingQueue($this->logger, 'scs');
        $minnow_db_mode = $maq_temp->getMinnowModeFromOrgid($org_id);

        // Iterate through objects in this notification.
        $s_objects = $xml_doc->getElementsByTagName('sObject');
        foreach ($s_objects as $s_object) {
            // Determine object type.
            $object_type_ns = $s_object->attributes->getNamedItem('type')->nodeValue;
            $matches = [];
            preg_match('#^(.+:)?(\w+)$#', $object_type_ns, $matches);
            $object_type = $matches[2];
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__,
                ['object_type' => $object_type]
            );
            $object_type = str_replace(['fw1__', '__c', '_'], '', $object_type);
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__,
                ['object_type' => $object_type]
            );

            // Load Minnow object from incoming request.
            $minnow_obj_class = '\\Scs\\Integration\\Minnow\\Minnow' . $object_type;
            $minnow_object = new $minnow_obj_class(
                $this->logger,
                $minnow_db_mode
            );
            $minnow_object->organization_id = $org_id;
            $minnow_object->session_id = $session_id;
            $minnow_object->notification_id = $notification_id;
            $result = $minnow_object->loadFromXMLNotification(
                $xml_doc,
                $s_object
            );

            // Validate legal entity.
            $legal_entity_str = $minnow_object->retrieveLegalEntity();
            if (empty($legal_entity_str)) {
                $this->logger->addError(
                    basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                    ': Legal entity undefined! $data=' .
                    print_r($minnow_object->data, true)
                );
                return false;
            }

            $minnow_object->source_id = $notification_id . '_' .
                $minnow_object->data['Id'];
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': $minnow_object=' . print_r($minnow_object, true)
            );

            // Determine the action to perform.
            if (empty($minnow_object->data['Quickbooks_ID__c'])) {
                // No QB id: add.
                $action = 'add';
            } else {
                // Has QB id: modify.
                $action = 'modify';
            }

            // Send to accounting system.
            $method = $action . 'Entity';
            $this->$method($minnow_object);
        }

        return true;
    }

    /**
     * Convert an entity to Nest and send to the accounting system
     *
     * @param object $minnow_object
     *     MinnowObject-derived object instance
     */
    protected function addEntity($minnow_object)
    {
        $this->logger->addDebug(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
            ': $minnow_object=' . print_r($minnow_object, true)
        );

        if (!$minnow_object->hasValidData()) {
            $this->logger->addError(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': Invalid object, aborting!'
            );
            return;
        }

        $this->logger->addDebug(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
            ': Object is valid.'
        );

        // Set up MinnowAccountingQueue object.
        $legal_entity_str = $minnow_object->retrieveLegalEntity();
        $maq = new MinnowAccountingQueue($this->logger, $legal_entity_str);

        // Determine if object has been added before and is still in queue.
        if ($maq->stillInQbwcQueue($minnow_object->data['Id'])) {
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': Already in queue, SKIPPING.'
            );
            // $this->modifyEntity($minnow_object);
            return;
        }

        // Determine if object is ready to be added to QB now.
        $minnow_class = $minnow_object->object_type;
        if (($minnow_class !== 'MinnowAccount') && empty($minnow_object->data['Account_Quickbooks_ID__c'])) {
            $status = MinnowAccountingQueue::MAQ_STATUS_WAITING_FOR_ACCOUNT_QB_ID;
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': No Account QB id: ' . print_r($minnow_object, true)
            );
        } else {
            $status = MinnowAccountingQueue::MAQ_STATUS_QB_READY;
        }

        // If it's a cancelled payment, set status accordingly.
        if ($minnow_object->object_type === 'MinnowPayment') {
            $payment_status = $minnow_object->data['fw1__Status__c'];
            if ($payment_status === 'Cancelled') {
                $status = MinnowAccountingQueue::MAQ_STATUS_CANCELLED;
            }
        }

        // Add object to minnow accounting queue.
        $maq_id = $maq->add($minnow_object, $status);

        // If object is ready, send it to QB.
        if ($status === MinnowAccountingQueue::MAQ_STATUS_QB_READY) {
            // Create Nest object from Minnow object.
            $nest_object = $minnow_object->exportToNest();
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': $nest_object=' . print_r($nest_object, true)
            );

            // Enqueue the object for addition to QB.
            $qi = new QbIntegration($this->logger, $legal_entity_str);
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': QbIntegration object created.'
            );
            if ($qi->sendNestEntityToQuickbooks(
                $nest_object,
                'add',
                [
                    'integration_type' => 'Minnow_Qb',
                    'minnow_organization_id' => $minnow_object->organization_id,
                    'minnow_notification_id' => $minnow_object->notification_id,
                    'minnow_object_id' => $minnow_object->data['Id'],
                ],
                $minnow_object->source_id
            )) {
                $status = MinnowAccountingQueue::MAQ_STATUS_IN_QB_QUEUE;
            } else {
                $status = MinnowAccountingQueue::MAQ_STATUS_ERROR_SYNC;
            }
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__,
                ['maq_id' => $maq_id, 'status' => $status, 'object_type' => $minnow_object->object_type]
            );
            $maq->updateStatus(
                $maq_id,
                $status,
                $minnow_object->object_type,
                $minnow_object->data['Id'],
                ($minnow_object->object_type === 'MinnowAccount'),
                $minnow_object->organization_id
            );
        }
    }

    /**
     * Convert an entity to Nest and modify it in the accounting system
     *
     * @param object $minnow_object
     *     MinnowObject-derived object instance
     */
    protected function modifyEntity($minnow_object)
    {
        $this->logger->addDebug(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
            ': $minnow_object=' . print_r($minnow_object, true)
        );

        if (!$minnow_object->hasValidData()) {
            throw new \Exception(
                'Invalid submitted object: ' .
                print_r($minnow_object, true)
            );
        }

        // Set up MinnowAccountingQueue object.
        $legal_entity_str = $minnow_object->retrieveLegalEntity();
        $maq = new MinnowAccountingQueue($this->logger, $legal_entity_str);

        // If it's a cancelled payment, convert action to delete.
        if ($minnow_object->object_type === 'MinnowPayment') {
            $payment_status = $minnow_object->data['fw1__Status__c'];
            if ($payment_status === 'Cancelled') {
                $this->deleteEntity($minnow_object, $legal_entity_str);
                return;
            }
        }

        // Determine if object is ready to be sent to QB now.
        $minnow_class = $minnow_object->object_type;
        if (($minnow_class !== 'MinnowAccount') && empty($minnow_object->data['Account_Quickbooks_ID__c'])) {
            $status = MinnowAccountingQueue::MAQ_STATUS_WAITING_FOR_ACCOUNT_QB_ID;
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': No Account QB id: ' . print_r($minnow_object, true)
            );
        } else {
            // Determine if a prior operation is still in queue.
            if ($maq->stillInQbwcQueue($minnow_object->data['Id'])) {
                $status = MinnowAccountingQueue::MAQ_STATUS_WAITING_FOR_PRIOR_TXN;
                $this->logger->addDebug(
                    basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                    ': Waiting for prior txn: ' . print_r($minnow_object, true)
                );
            } else {
                $status = MinnowAccountingQueue::MAQ_STATUS_QB_READY;
            }
        }

        // Add object to minnow accounting queue.
        $maq_id = $maq->add($minnow_object, $status);

        // If object is ready, send it to QB.
        if ($status === MinnowAccountingQueue::MAQ_STATUS_QB_READY) {
            // Create Nest object from Minnow object.
            $nest_object = $minnow_object->exportToNest();
            $this->logger->addDebug(
                basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
                ': $nest_object=' . print_r($nest_object, true)
            );

            // Enqueue the object for modification in QB.
            $qi = new QbIntegration($this->logger, $legal_entity_str);
            if ($qi->sendNestEntityToQuickbooks(
                $nest_object,
                'modify',
                [
                    'integration_type' => 'Minnow_Qb',
                    'minnow_organization_id' => $minnow_object->organization_id,
                    'minnow_notification_id' => $minnow_object->notification_id,
                    'minnow_object_id' => $minnow_object->data['Id'],
                ],
                $minnow_object->source_id
            )) {
                $status = MinnowAccountingQueue::MAQ_STATUS_IN_QB_QUEUE;
            } else {
                $status = MinnowAccountingQueue::MAQ_STATUS_ERROR_SYNC;
            }
            $maq->updateStatus($maq_id, $status);
        }
    }

    /**
     * Delete an object in the accounting system
     *
     * @param object $minnow_object
     *     MinnowObject-derived object instance
     */
    protected function deleteEntity($minnow_object)
    {
        // Set up MinnowAccountingQueue object.
        $legal_entity_str = $minnow_object->retrieveLegalEntity();
        $maq = new MinnowAccountingQueue($this->logger, $legal_entity_str);

        // Add object to minnow accounting queue.
        $status = MinnowAccountingQueue::MAQ_STATUS_QB_READY;
        $maq_id = $maq->add($minnow_object, $status);

        // Create Nest object from Minnow object.
        $nest_object = $minnow_object->exportToNest();
        $this->logger->addDebug(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
            ': $nest_object=' . print_r($nest_object, true)
        );

        // Enqueue the object for deletion from QB.
        $qi = new QbIntegration($this->logger, $legal_entity_str);
        if ($qi->sendNestEntityToQuickbooks(
            $nest_object,
            'delete',
            [
                'integration_type' => 'Minnow_Qb',
                'minnow_organization_id' => $minnow_object->organization_id,
                'minnow_notification_id' => $minnow_object->notification_id,
                'minnow_object_id' => $minnow_object->data['Id'],
            ],
            $minnow_object->source_id
        )) {
            $status = MinnowAccountingQueue::MAQ_STATUS_IN_QB_QUEUE;
        } else {
            $status = MinnowAccountingQueue::MAQ_STATUS_ERROR_SYNC;
        }
        $maq->updateStatus($maq_id, $status);
    }
}
