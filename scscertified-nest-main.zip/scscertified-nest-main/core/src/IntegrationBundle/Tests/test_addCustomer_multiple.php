<?php

require_once __DIR__ . '/includes/integration_test_common.php';

$test_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <soapenv:Body>
  <notifications xmlns="http://soap.sforce.com/2005/09/outbound">
   <OrganizationId>00D0n0000001EfGEAU</OrganizationId>
   <ActionId>04k0n00000001kjAAA</ActionId>
   <SessionId>00D0n0000001EfG!AQgAQKDNdO_mRYQe_zC8F493meFbCvTPxkBbJjdWvn349aloZBCvamsjuLTcvgHzWifpVKCO2xkN1YgVMMl3zX_q9HvBo6Xv</SessionId>
   <EnterpriseUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/c/49.0/00D0n0000001EfG</EnterpriseUrl>
   <PartnerUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/u/49.0/00D0n0000001EfG</PartnerUrl>
    <Notification>
     <Id>04l6g00000E9SXhAAN</Id>
     <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
      <sf:Id>0016g000015V9MJAA0</sf:Id>
      <sf:BillingCity>Baltimore</sf:BillingCity>
      <sf:BillingCountry>United States</sf:BillingCountry>
      <sf:BillingCountryCode>US</sf:BillingCountryCode>
      <sf:BillingPostalCode>21220</sf:BillingPostalCode>
      <sf:BillingState>Maryland</sf:BillingState>
      <sf:BillingStateCode>MD</sf:BillingStateCode>
      <sf:BillingStreet>501 Chesapeake Park Plaza</sf:BillingStreet>
      <sf:Name>Tilley Chemical Company, Inc</sf:Name>
      <sf:Phone>410-574-4500</sf:Phone>
      <sf:Quickbooks_Account_Name__c>Tilley Chemical Company, Inc</sf:Quickbooks_Account_Name__c>
     </sObject>
    </Notification>
    <Notification>
     <Id>04l6g00000E9SXjAAN</Id>
     <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
      <sf:Id>0016g000015V9MKAA0</sf:Id>
      <sf:BillingCity>Ephrata</sf:BillingCity>
      <sf:BillingCountry>United States</sf:BillingCountry>
      <sf:BillingCountryCode>US</sf:BillingCountryCode>
      <sf:BillingPostalCode>17522</sf:BillingPostalCode>
      <sf:BillingState>Pennsylvania</sf:BillingState>
      <sf:BillingStateCode>PA</sf:BillingStateCode>
      <sf:BillingStreet>1925 West Main Street</sf:BillingStreet>
      <sf:Name>Weaver Nut Company, Inc.</sf:Name>
      <sf:Phone>717-738-3781</sf:Phone>
      <sf:Quickbooks_Account_Name__c>Weaver Nut Company, Inc.</sf:Quickbooks_Account_Name__c>
     </sObject>
    </Notification>
    <Notification>
     <Id>04l6g00000E9SXLAA3</Id>
     <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
      <sf:Id>0016g000015V9M8AAK</sf:Id>
      <sf:BillingCity>Newburyport</sf:BillingCity>
      <sf:BillingCountry>United States</sf:BillingCountry>
      <sf:BillingCountryCode>US</sf:BillingCountryCode>
      <sf:BillingPostalCode>01950</sf:BillingPostalCode>
      <sf:BillingState>Massachusetts</sf:BillingState>
      <sf:BillingStateCode>MA</sf:BillingStateCode>
      <sf:BillingStreet>4 Graf Road</sf:BillingStreet>
      <sf:Name>Dianne’s Fine Desserts, Inc</sf:Name>
      <sf:Phone>978-463-3852</sf:Phone>
      <sf:Quickbooks_Account_Name__c>Dianne’s Fine Desserts, Inc</sf:Quickbooks_Account_Name__c>
     </sObject>
    </Notification>
    <Notification>
     <Id>04l6g00000E9SXlAAN</Id>
     <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
      <sf:Id>0016g000015V9MLAA0</sf:Id>
      <sf:BillingCity>Ronkonkoma</sf:BillingCity>
      <sf:BillingCountry>United States</sf:BillingCountry>
      <sf:BillingCountryCode>US</sf:BillingCountryCode>
      <sf:BillingPostalCode>11779</sf:BillingPostalCode>
      <sf:BillingState>New York</sf:BillingState>
      <sf:BillingStateCode>NY</sf:BillingStateCode>
      <sf:BillingStreet>2001 Orville Dr. N.</sf:BillingStreet>
      <sf:Name>Wenner Bread Products</sf:Name>
      <sf:Phone>631-563-6262</sf:Phone>
      <sf:Quickbooks_Account_Name__c>Wenner Bread Products</sf:Quickbooks_Account_Name__c>
     </sObject>
    </Notification>
    <Notification>
     <Id>04l6g00000E9SXdAAN</Id>
     <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
      <sf:Id>0016g000015V9MHAA0</sf:Id>
      <sf:BillingCity>Kingsburg</sf:BillingCity>
      <sf:BillingCountry>United States</sf:BillingCountry>
      <sf:BillingCountryCode>US</sf:BillingCountryCode>
      <sf:BillingPostalCode>93631</sf:BillingPostalCode>
      <sf:BillingState>California</sf:BillingState>
      <sf:BillingStateCode>CA</sf:BillingStateCode>
      <sf:BillingStreet>13525 S. Bethel Ave</sf:BillingStreet>
      <sf:Name>Sun-Maid Growers of California</sf:Name>
      <sf:Phone>2094728440</sf:Phone>
      <sf:Quickbooks_Account_Name__c>Sun-Maid Growers of California</sf:Quickbooks_Account_Name__c>
     </sObject>
    </Notification>
    <Notification>
     <Id>04l6g00000E9SXDAA3</Id>
     <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
      <sf:Id>0016g000015V9M4AAK</sf:Id>
      <sf:BillingCity>Wondelgem</sf:BillingCity>
      <sf:BillingCountry>Belgium</sf:BillingCountry>
      <sf:BillingCountryCode>BE</sf:BillingCountryCode>
      <sf:BillingPostalCode>9032</sf:BillingPostalCode>
      <sf:BillingStreet>Kolegemstraat 179</sf:BillingStreet>
      <sf:Name>Certain bvba</sf:Name>
      <sf:Quickbooks_Account_Name__c>Certain bvba</sf:Quickbooks_Account_Name__c>
     </sObject>
    </Notification>
    <Notification>
     <Id>04l6g00000E9SXTAA3</Id>
     <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
      <sf:Id>0016g000015V9MCAA0</sf:Id>
      <sf:BillingCity>Foothill Ranch</sf:BillingCity>
      <sf:BillingCountry>United States</sf:BillingCountry>
      <sf:BillingCountryCode>US</sf:BillingCountryCode>
      <sf:BillingPostalCode>92610</sf:BillingPostalCode>
      <sf:BillingState>California</sf:BillingState>
      <sf:BillingStateCode>CA</sf:BillingStateCode>
      <sf:BillingStreet>25882 Wright Circle</sf:BillingStreet>
      <sf:Name>Mission Flavors &amp; Fragrances Inc.</sf:Name>
      <sf:Phone>+1 800-352-8677</sf:Phone>
      <sf:Quickbooks_Account_Name__c>Mission Flavors &amp; Fragrances Inc.</sf:Quickbooks_Account_Name__c>
     </sObject>
    </Notification>
    <Notification>
     <Id>04l6g00000E9SXfAAN</Id>
     <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
      <sf:Id>0016g000015V9MIAA0</sf:Id>
      <sf:BillingCity>Dickson</sf:BillingCity>
      <sf:BillingCountry>United States</sf:BillingCountry>
      <sf:BillingCountryCode>US</sf:BillingCountryCode>
      <sf:BillingPostalCode>37055</sf:BillingPostalCode>
      <sf:BillingState>Tennessee</sf:BillingState>
      <sf:BillingStateCode>TN</sf:BillingStateCode>
      <sf:BillingStreet>197 Printwood Dr.</sf:BillingStreet>
      <sf:Name>Tennessee Bun Company, LLC dba The Bakery Cos.</sf:Name>
      <sf:Quickbooks_Account_Name__c>Tennessee Bun Company, LLC dba The Bakery</sf:Quickbooks_Account_Name__c>
     </sObject>
    </Notification>
    <Notification>
     <Id>04l6g00000E9SXHAA3</Id>
     <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
      <sf:Id>0016g000015V9M6AAK</sf:Id>
      <sf:BillingCity>Tamaqua</sf:BillingCity>
      <sf:BillingCountry>United States</sf:BillingCountry>
      <sf:BillingCountryCode>US</sf:BillingCountryCode>
      <sf:BillingPostalCode>18252</sf:BillingPostalCode>
      <sf:BillingState>Pennsylvania</sf:BillingState>
      <sf:BillingStateCode>PA</sf:BillingStateCode>
      <sf:BillingStreet>120 River Road</sf:BillingStreet>
      <sf:Name>Copperhead Chemical Company, Inc.</sf:Name>
      <sf:Phone>570-386-6123</sf:Phone>
      <sf:Quickbooks_Account_Name__c>Copperhead Chemical Company, Inc.</sf:Quickbooks_Account_Name__c>
     </sObject>
    </Notification>
  </notifications>
 </soapenv:Body>
</soapenv:Envelope>';

sendXmlRequest($accounting_url, $test_xml);
