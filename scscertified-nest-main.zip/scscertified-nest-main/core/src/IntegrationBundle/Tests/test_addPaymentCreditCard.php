<?php

// Note: the Account_Quickbooks_ID__c value must be edited to match the actual
// QB id of the Customer record once it's been added to QB.

require_once __DIR__ . '/includes/integration_test_common.php';

$test_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <soapenv:Body>
  <notifications xmlns="http://soap.sforce.com/2005/09/outbound">
   <OrganizationId>00D0n0000001EfGEAU</OrganizationId>
   <ActionId>04k0n00000001koAAA</ActionId>
   <SessionId>00D0n0000001EfG!AQgAQL6cAjN26KK7VnFRE7JU_MZwSBDQh260bY8uu7MhsFRqQ98US.fCKWfvNgRxvenN6KTIL369G5408Jihcef5Es0840J8</SessionId>
   <EnterpriseUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/c/49.0/00D0n0000001EfG</EnterpriseUrl>
   <PartnerUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/u/49.0/00D0n0000001EfG</PartnerUrl>
   <Notification>
    <Id>' . $minnow_notification_id . '</Id>
    <sObject xsi:type="sf:fw1__Payment__c" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
     <sf:Id>a0L0n00000GrvUWEAZ</sf:Id>
     <sf:Account_Quickbooks_ID__c>80000032-1603384849</sf:Account_Quickbooks_ID__c>
     <sf:fw1__Account__c>0010n000017edSjAAI</sf:fw1__Account__c>
     <sf:fw1__Amount__c>21.0</sf:fw1__Amount__c>
     <sf:fw1__Authorization_Code__c>abcdef</sf:fw1__Authorization_Code__c>
     <sf:fw1__Credit_Card_Number__c>xxxxxxxxxxxx0002</sf:fw1__Credit_Card_Number__c>
     <sf:fw1__Credit_Card_Type__c>Visa</sf:fw1__Credit_Card_Type__c>
     <sf:fw1__Expiry_Month__c>05</sf:fw1__Expiry_Month__c>
     <sf:fw1__Expiry_Year__c>2021</sf:fw1__Expiry_Year__c>
     <sf:fw1__First_Name__c>Jenny</sf:fw1__First_Name__c>
     <sf:fw1__Invoice__c>a0P6g0000048jOXEAY</sf:fw1__Invoice__c>
     <sf:fw1__Last_Name__c>Ortiz</sf:fw1__Last_Name__c>
     <sf:fw1__Payment_Date__c>2020-09-17T18:51:44.000Z</sf:fw1__Payment_Date__c>
     <sf:fw1__Payment_Method__c>Credit Card</sf:fw1__Payment_Method__c>
     <sf:fw1__Payment_Result__c>Approved</sf:fw1__Payment_Result__c>
     <sf:fw1__Status__c>Captured</sf:fw1__Status__c>
     <sf:fw1__Total_Paid_Amount__c>21.0</sf:fw1__Total_Paid_Amount__c>
     <sf:fw1__Transaction_ID__c>170920AD4-217BE8C0-3E53-4879-B279-F2F35DAC4793</sf:fw1__Transaction_ID__c>
    </sObject>
   </Notification>
  </notifications>
 </soapenv:Body>
</soapenv:Envelope>';

sendXmlRequest($accounting_url, $test_xml);
