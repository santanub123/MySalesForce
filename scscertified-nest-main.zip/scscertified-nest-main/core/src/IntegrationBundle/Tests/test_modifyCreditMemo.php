<?php

// Note: the Account_Quickbooks_ID__c value must be edited to match the actual
// QB id of the Customer record once it's been added to QB.

require_once __DIR__ . '/includes/integration_test_common.php';

$test_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <soapenv:Body>
  <notifications xmlns="http://soap.sforce.com/2005/09/outbound">
   <OrganizationId>00D0n0000001EfGEAU</OrganizationId>
   <ActionId>04k0n00000001lrAAA</ActionId>
   <SessionId>00D0n0000001EfG!AQgAQLTdizKcmzW6hEB3EulJhYHJA.cEajdROJCI2OVG4wNEy5N4svaw994YuDj2KRRmZ33FoYFrPv5x.HvWeqCcYtY6YK2c</SessionId>
   <EnterpriseUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/c/49.0/00D0n0000001EfG</EnterpriseUrl>
   <PartnerUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/u/49.0/00D0n0000001EfG</PartnerUrl>
   <Notification>
    <Id>' . $minnow_notification_id . '</Id>
    <sObject xsi:type="sf:fw1__Credit_Memo__c" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
     <sf:Id>a090n0000038eOcAAI</sf:Id>
     <sf:Account_Quickbooks_ID__c>80000032-1603384849</sf:Account_Quickbooks_ID__c>
     <sf:Bad_Debt__c>0.0</sf:Bad_Debt__c>
     <sf:Bank_Charges__c>0.0</sf:Bank_Charges__c>
     <sf:Foreign_Currency_Exchange_Loss__c>0.0</sf:Foreign_Currency_Exchange_Loss__c>
     <sf:Invoice_Quickbooks_ID__c>8000002E-1601932012</sf:Invoice_Quickbooks_ID__c>
     <sf:Name>CM-0000000010</sf:Name>
     <sf:Quickbooks_ID__c>FD-1602805078</sf:Quickbooks_ID__c>
     <sf:REVENUE_Other_Revenue__c>2350.0</sf:REVENUE_Other_Revenue__c>
     <sf:TAXES_Foreign_Taxes__c>1000.0</sf:TAXES_Foreign_Taxes__c>
     <sf:fw1__Account__c>0010n000017edSjAAI</sf:fw1__Account__c>
     <sf:fw1__Date__c>2020-09-09</sf:fw1__Date__c>
     <sf:fw1__Description__c>rtyu</sf:fw1__Description__c>
     <sf:fw1__Total_Credit_Amount__c>3350.0</sf:fw1__Total_Credit_Amount__c>
     <sf:fw1__Total_Lines_Amount__c>3350.0</sf:fw1__Total_Lines_Amount__c>
    </sObject>
   </Notification>
  </notifications>
 </soapenv:Body>
</soapenv:Envelope>';

sendXmlRequest($accounting_url, $test_xml);
