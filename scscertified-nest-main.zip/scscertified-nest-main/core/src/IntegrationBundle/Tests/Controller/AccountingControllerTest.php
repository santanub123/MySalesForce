<?php

namespace IntegrationBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class AccountingControllerTest extends WebTestCase
{
}
