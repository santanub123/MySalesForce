<?php

require_once __DIR__ . '/../../../../sites/nest/includes/nest_top.php';

$endpoint_url = BASE_PROT . '://' . NEST_DOMAIN . NEST_API_RELATIVE_URL . '/accounting';
// $endpoint_url = 'https://nest-other.scscertified.com/core/accounting';

$test_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <soapenv:Body>
  <notifications xmlns="http://soap.sforce.com/2005/09/outbound">
   <OrganizationId>00D0n0000001EfGEAU</OrganizationId>
   <ActionId>04k0n00000001koAAA</ActionId>
   <SessionId>00D0n0000001EfG!AQgAQOxswLolAnxHXTNmdkeXdz6gDLTN4qdrx314ooXt7f3TGY05F_IeXdK.akYNpg6aRTQkeb8Ejxl8QqRBictDaYHIsMHW</SessionId>
   <EnterpriseUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/c/49.0/00D0n0000001EfG</EnterpriseUrl>
   <PartnerUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/u/49.0/00D0n0000001EfG</PartnerUrl>
   <Notification>
    <Id>04l0n000005kFOUAA2</Id>
    <sObject xsi:type="sf:fw1__Payment__c" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
     <sf:Id>a0L0n00000Grne8EAB</sf:Id>
     <sf:fw1__Account__c>0010n000017Aom1AAC</sf:fw1__Account__c>
     <sf:fw1__Amount__c>11.0</sf:fw1__Amount__c>
     <sf:fw1__Invoice__c>a0E0n000001Z49vEAC</sf:fw1__Invoice__c>
     <sf:fw1__Payment_Date__c>2020-08-28T22:48:00.000Z</sf:fw1__Payment_Date__c>
     <sf:fw1__Payment_Method__c>Check</sf:fw1__Payment_Method__c>
     <sf:fw1__Total_Paid_Amount__c>11.0</sf:fw1__Total_Paid_Amount__c>
    </sObject>
   </Notification>
  </notifications>
 </soapenv:Body>
</soapenv:Envelope>';

try {
    $header = [
        'Content-Type: text/xml',
        'Accept: text/xml',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
        'SOAPAction: "notifications"',
        'Content-length: ' . strlen($test_xml),
    ];
    $ch = curl_init($endpoint_url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $test_xml);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($ch);
    curl_close($ch);
    $x = 1;     // for debug
} catch (\Exception $e) {
    var_dump(
        $e->faultcode,
        $e->faultstring
    );
}
