<?php

require_once __DIR__ . '/includes/integration_test_common.php';

// BillingCity contains Latin-1 Supplement character "é" (U+00E9).
// Name contains single and double quotes, and Greek letters "ΑΩ" (U+0391 , U+03A9).
$test_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <soapenv:Body>
  <notifications xmlns="http://soap.sforce.com/2005/09/outbound">
   <OrganizationId>00D0n0000001EfGEAU</OrganizationId>
   <ActionId>04k0n00000001kjAAA</ActionId>
   <SessionId>00D0n0000001EfG!AQgAQKDNdO_mRYQe_zC8F493meFbCvTPxkBbJjdWvn349aloZBCvamsjuLTcvgHzWifpVKCO2xkN1YgVMMl3zX_q9HvBo6Xv</SessionId>
   <EnterpriseUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/c/49.0/00D0n0000001EfG</EnterpriseUrl>
   <PartnerUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/u/49.0/00D0n0000001EfG</PartnerUrl>
   <Notification>
    <Id>' . $minnow_notification_id . '</Id>
    <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
     <sf:Id>nax3in308xnjsk3nsj</sf:Id>
     <sf:BillingCity>Québec</sf:BillingCity>
     <sf:BillingCountry>Canada</sf:BillingCountry>
     <sf:BillingCountryCode>CA</sf:BillingCountryCode>
     <sf:BillingPostalCode>G1M 2K2</sf:BillingPostalCode>
     <sf:BillingState>Quebec</sf:BillingState>
     <sf:BillingStateCode>QC</sf:BillingStateCode>
     <sf:BillingStreet>550 Avenue Godin</sf:BillingStreet>
     <sf:Name>Nutriart\'s "Inc" ΑΩ</sf:Name>
     <sf:Phone>+1.418.687.3096 x5009</sf:Phone>
    </sObject>
   </Notification>
  </notifications>
 </soapenv:Body>
</soapenv:Envelope>';

sendXmlRequest($accounting_url, $test_xml);
