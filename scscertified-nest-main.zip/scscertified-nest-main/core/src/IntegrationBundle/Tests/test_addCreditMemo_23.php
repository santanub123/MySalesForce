<?php

// Note: the Account_Quickbooks_ID__c value must be edited to match the actual
// QB id of the Customer record once it's been added to QB.

require_once __DIR__ . '/includes/integration_test_common.php';

$test_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <soapenv:Body>
  <notifications xmlns="http://soap.sforce.com/2005/09/outbound">
   <OrganizationId>00D0n0000001EfGEAU</OrganizationId>
   <ActionId>04k0n00000001lrAAA</ActionId>
   <SessionId>00D0n0000001EfG!AQgAQGTOecPJhrS33Zo1d2eVQ4oX0TvRLfyK2sNGbXjB07AgvHB.jnYELAMuraKOGLI.rAHuEiTSQY29p2Ymn5TDaHbNNyTt</SessionId>
   <EnterpriseUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/c/49.0/00D0n0000001EfG</EnterpriseUrl>
   <PartnerUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/u/49.0/00D0n0000001EfG</PartnerUrl>
   <Notification>
    <Id>' . $minnow_notification_id . '</Id>
    <sObject xsi:type="sf:fw1__Credit_Memo__c" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
     <sf:Id>a090n0000039L5hAAE</sf:Id>
     <sf:Account_Quickbooks_ID__c>80000032-1603384849</sf:Account_Quickbooks_ID__c>
     <sf:Invoice_Number__c>INV-0000000046</sf:Invoice_Number__c>
     <sf:Name>CM-0000000023</sf:Name>
     <sf:Program_Nest_Unit_ID__c>39</sf:Program_Nest_Unit_ID__c>
     <sf:SCS_Total_Credit_Amount__c>0.0</sf:SCS_Total_Credit_Amount__c>
     <sf:fw1__Account__c>0010n000017edSjAAI</sf:fw1__Account__c>
     <sf:fw1__Date__c>2020-12-09</sf:fw1__Date__c>
     <sf:fw1__Description__c>erty</sf:fw1__Description__c>
     <sf:fw1__Generated_From__c>a0E0n000001QychEAC</sf:fw1__Generated_From__c>
     <sf:fw1__Total_Credit_Amount__c>455.0</sf:fw1__Total_Credit_Amount__c>
     <sf:fw1__Total_Lines_Amount__c>455.0</sf:fw1__Total_Lines_Amount__c>
    </sObject>
   </Notification>
  </notifications>
 </soapenv:Body>
</soapenv:Envelope>';

sendXmlRequest($accounting_url, $test_xml);
