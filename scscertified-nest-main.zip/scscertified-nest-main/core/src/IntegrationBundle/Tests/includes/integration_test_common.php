<?php

// require_once __DIR__ . '/../../../../../sites/nest/includes/nest_top.php';
require_once __DIR__ . '/../../../../../sites/nest/nest_config.php';

$accounting_url = BASE_PROT . '://' . NEST_DOMAIN . NEST_API_RELATIVE_URL . '/accounting';
// $accounting_url = 'https://nest-other.scscertified.com/core/accounting';

$minnow_notification_id = randomSalesforceId();


/**
 * Generate a random ID similar to those used in Salesforce
 *
 * Note: This function does not set the last three characters as a checksum so
 * the generated ID will not be usable by code that tests or uses that
 * characteristic.
 *
 * @return string
 *     18-character ID
 */
function randomSalesforceId()
{
    $chars = '01234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    $notification_id = '';
    for ($i = 0; $i < 18; $i++) {
        $pos = mt_rand(0, 61);
        $notification_id = $notification_id . substr($chars, $pos, 1);
    }
    return $notification_id;
}

/**
 * Send an XML request to an URL
 *
 * @param string $url
 *     URL to send the request to
 * @param string $xml
 *     XML request
 */
function sendXmlRequest($url, $xml)
{
    try {
        $header = [
            'Content-Type: text/xml',
            'Accept: text/xml',
            'Cache-Control: no-cache',
            'Pragma: no-cache',
            'SOAPAction: "notifications"',
            'Content-length: ' . strlen($xml),
        ];
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        curl_close($ch);
    } catch (\Exception $e) {
        var_dump(
            $e->faultcode,
            $e->faultstring
        );
    }
}
