<?php

// Note: the Account_Quickbooks_ID__c value must be edited to match the actual
// QB id of the Customer record once it's been added to QB.

require_once __DIR__ . '/includes/integration_test_common.php';

$test_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <soapenv:Body>
  <notifications xmlns="http://soap.sforce.com/2005/09/outbound">
   <OrganizationId>00D0n0000001EfGEAU</OrganizationId>
   <ActionId>04k0n00000001koAAA</ActionId>
   <SessionId>00D0n0000001EfG!AQgAQOxswLolAnxHXTNmdkeXdz6gDLTN4qdrx314ooXt7f3TGY05F_IeXdK.akYNpg6aRTQkeb8Ejxl8QqRBictDaYHIsMHW</SessionId>
   <EnterpriseUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/c/49.0/00D0n0000001EfG</EnterpriseUrl>
   <PartnerUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/u/49.0/00D0n0000001EfG</PartnerUrl>
   <Notification>
    <Id>' . $minnow_notification_id . '</Id>
    <sObject xsi:type="sf:fw1__Payment__c" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
     <sf:Account_Quickbooks_ID__c>80000032-1603384849</sf:Account_Quickbooks_ID__c>
     <sf:Id>a0L0n00000Grne8EAB</sf:Id>
     <sf:fw1__Account__c>0010n000017edSjAAI</sf:fw1__Account__c>
     <sf:fw1__Amount__c>11.0</sf:fw1__Amount__c>
     <sf:fw1__Check_Number__c>1234</sf:fw1__Check_Number__c>
     <sf:fw1__Invoice__c>a0E0n000001ZHQIEA4</sf:fw1__Invoice__c>
     <sf:fw1__Payment_Date__c>2020-08-28T22:48:00.000Z</sf:fw1__Payment_Date__c>
     <sf:fw1__Payment_Method__c>Check</sf:fw1__Payment_Method__c>
     <sf:fw1__Status__c>Ok</sf:fw1__Status__c>
     <sf:fw1__Total_Paid_Amount__c>11.0</sf:fw1__Total_Paid_Amount__c>
    </sObject>
   </Notification>
  </notifications>
 </soapenv:Body>
</soapenv:Envelope>';

sendXmlRequest($accounting_url, $test_xml);
