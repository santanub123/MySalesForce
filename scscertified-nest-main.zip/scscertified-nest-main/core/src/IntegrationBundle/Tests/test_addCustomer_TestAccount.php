<?php

require_once __DIR__ . '/includes/integration_test_common.php';

$test_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <soapenv:Body>
  <notifications xmlns="http://soap.sforce.com/2005/09/outbound">
   <OrganizationId>00D0n0000001EfGEAU</OrganizationId>
   <ActionId>04k0n00000001kjAAA</ActionId>
   <SessionId>00D0n0000001EfG!AQgAQL42Uzg943AqJziZEUEc.xaonlVmTr1sXodlnvU4Qfq57QHZan8_q5W7Fxsbm_UfWUnrP7GYZ21q32V8t2.KFmf2R99p</SessionId>
   <EnterpriseUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/c/49.0/00D0n0000001EfG</EnterpriseUrl>
   <PartnerUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/u/49.0/00D0n0000001EfG</PartnerUrl>
   <Notification>
    <Id>04l0n000005pQCPAA2</Id>
    <sObject xsi:type="sf:Account" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
     <sf:Id>0010n0000178INXAA2</sf:Id>
     <sf:BillingCity>San jose</sf:BillingCity>
     <sf:BillingCountry>United States</sf:BillingCountry>
     <sf:BillingCountryCode>US</sf:BillingCountryCode>
     <sf:BillingPostalCode>95134</sf:BillingPostalCode>
     <sf:BillingState>California</sf:BillingState>
     <sf:BillingStateCode>CA</sf:BillingStateCode>
     <sf:BillingStreet>77 Rio robles</sf:BillingStreet>
     <sf:Name>Test Account</sf:Name>
    </sObject>
   </Notification>
  </notifications>
 </soapenv:Body>
</soapenv:Envelope>';

sendXmlRequest($accounting_url, $test_xml);
