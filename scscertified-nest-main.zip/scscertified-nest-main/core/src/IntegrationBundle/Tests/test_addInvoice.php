<?php

// Note: the Account_Quickbooks_ID__c value must be edited to match the actual
// QB id of the Customer record once it's been added to QB.

require_once __DIR__ . '/includes/integration_test_common.php';

$test_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <soapenv:Body>
  <notifications xmlns="http://soap.sforce.com/2005/09/outbound">
   <OrganizationId>00D0n0000001EfGEAU</OrganizationId>
   <ActionId>04k0n00000001lNAAQ</ActionId>
   <SessionId>00D0n0000001EfG!AQgAQJMUQekHgCHWaLKrkrm1CZHp6906.U0kMBJt0WHAPZTQ6e92UsyDmFh3mhAdo2.Km6qLnS3aNwrgFaY09zYRIBojhFFs</SessionId>
   <EnterpriseUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/c/49.0/00D0n0000001EfG</EnterpriseUrl>
   <PartnerUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/u/49.0/00D0n0000001EfG</PartnerUrl>
   <Notification>
    <Id>' . $minnow_notification_id . '</Id>
    <sObject xsi:type="sf:fw1__Invoice__c" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
     <sf:Id>a0E0n000001ZHQIEA4</sf:Id>
     <sf:Account_Quickbooks_ID__c>80000032-1603384849</sf:Account_Quickbooks_ID__c>
     <sf:Name>INV-0000000030</sf:Name>
     <sf:Program__c>Seafood Chain of Custody</sf:Program__c>
     <sf:Total_C_Commission_Revenue__c>0.0</sf:Total_C_Commission_Revenue__c>
     <sf:Total_F_Fees_Accreditation__c>0.0</sf:Total_F_Fees_Accreditation__c>
     <sf:Total_L_Lab_Fees__c>0.0</sf:Total_L_Lab_Fees__c>
     <sf:Total_M_Misc_Other__c>1000.0</sf:Total_M_Misc_Other__c>
     <sf:Total_P_Professional_Fees__c>5000.0</sf:Total_P_Professional_Fees__c>
     <sf:Total_R_Reimbursable_Travel__c>1500.0</sf:Total_R_Reimbursable_Travel__c>
     <sf:fw1__Account__c>0010n000017edSjAAI</sf:fw1__Account__c>
     <sf:fw1__Description__c>Created from Quote9</sf:fw1__Description__c>
     <sf:fw1__Invoice_Date__c>2020-08-24</sf:fw1__Invoice_Date__c>
     <sf:fw1__Terms__c>30.0</sf:fw1__Terms__c>
     <sf:fw1__Total_Invoice_Amount__c>7500.0</sf:fw1__Total_Invoice_Amount__c>
    </sObject>
   </Notification>
  </notifications>
 </soapenv:Body>
</soapenv:Envelope>';

sendXmlRequest($accounting_url, $test_xml);
