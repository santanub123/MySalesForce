<?php

// Note: the Account_Quickbooks_ID__c value must be edited to match the actual
// QB id of the Customer record once it's been added to QB.

require_once __DIR__ . '/includes/integration_test_common.php';

$test_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <soapenv:Body>
  <notifications xmlns="http://soap.sforce.com/2005/09/outbound">
   <OrganizationId>00D0n0000001EfGEAU</OrganizationId>
   <ActionId>04k0n00000001lNAAQ</ActionId>
   <SessionId>00D0n0000001EfG!AQgAQIwKmC525bLj7KCVUNTemlyr7R5nV3CZaC4zlsrr2bR228IfOn2jZKxerxahpv6MBLNRVu6l4YzFNhq2PvVVnzFEej2e</SessionId>
   <EnterpriseUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/c/49.0/00D0n0000001EfG</EnterpriseUrl>
   <PartnerUrl>https://scsglobal--minnow.my.salesforce.com/services/Soap/u/49.0/00D0n0000001EfG</PartnerUrl>
   <Notification>
    <Id>04l0n000005pPdFAAU</Id>
    <sObject xsi:type="sf:fw1__Invoice__c" xmlns:sf="urn:sobject.enterprise.soap.sforce.com">
     <sf:Id>a0E0n000001ZSISEA4</sf:Id>
     <sf:Account_Quickbooks_ID__c>8000005C-1619477827</sf:Account_Quickbooks_ID__c>
     <sf:Name>INV-0000000036</sf:Name>
     <sf:Program_ID__c>38</sf:Program_ID__c>
     <sf:Program_Nest_Unit_ID__c>38</sf:Program_Nest_Unit_ID__c>
     <sf:Program__c>RSPO Supply Chain</sf:Program__c>
     <sf:Total_C_Commission_Revenue__c>0.0</sf:Total_C_Commission_Revenue__c>
     <sf:Total_F_Fees_Accreditation__c>0.0</sf:Total_F_Fees_Accreditation__c>
     <sf:Total_L_Lab_Fees__c>200.0</sf:Total_L_Lab_Fees__c>
     <sf:Total_M_Misc_Other__c>0.0</sf:Total_M_Misc_Other__c>
     <sf:Total_P_Professional_Fees__c>0.0</sf:Total_P_Professional_Fees__c>
     <sf:Total_R_Reimbursable_Travel__c>0.0</sf:Total_R_Reimbursable_Travel__c>
     <sf:fw1__Account__c>0010n0000178INXAA2</sf:fw1__Account__c>
     <sf:fw1__Description__c>Created from Test 9/2</sf:fw1__Description__c>
     <sf:fw1__Invoice_Date__c>2020-09-28</sf:fw1__Invoice_Date__c>
     <sf:fw1__Total_Invoice_Amount__c>200.0</sf:fw1__Total_Invoice_Amount__c>
    </sObject>
   </Notification>
  </notifications>
 </soapenv:Body>
</soapenv:Envelope>';

sendXmlRequest($accounting_url, $test_xml);
