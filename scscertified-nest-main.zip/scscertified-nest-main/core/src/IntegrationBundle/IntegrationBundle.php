<?php

namespace IntegrationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IntegrationBundle extends Bundle
{
}
