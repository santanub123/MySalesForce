<?php

/**
 * @file solr_status_check.php
 * @author T. Treadwell
 * @date 2022-05-12
 *
 * Solr status check script.
 *
 * Designed to run from the command line via a cron job. Checks Solr status by
 * checking response of Solr service and number of documents. If failure
 * detected, restarts Solr service, logs error and sends alert email.
 */

use \Scs\Monitor\NestMonitor;
use \Scs\Monitor\NestMonitorSolrStatus;

// Base values.
$nest_root_path = __DIR__ . '/../../..';

// Email address(es) to send error notifications to. If muliple, separate by commas.
const ERROR_NOTIFICATION_RECIPIENTS = 'webdev@scsglobalservices.com,6ddb94b5.scsglobalservices.com@amer.teams.ms';

// Configure PHP.
$error_log_dir = $nest_root_path . '/log/scscertified/gpg_update';
ini_set('error_log', $error_log_dir . '/solr_status_check.log');

// Load and initialize the autoloader.
require_once $nest_root_path . '/sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', $nest_root_path . '/sites/nest/includes/src');

// Verify that the request is from the command line.
$ssec = new Scs\ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

// Retrieve the status from the monitor.
$solr_monitor = new NestMonitorSolrStatus();
$solr_info = $solr_monitor->getInfo();

if (
    ($solr_info['status'] === NestMonitor::MONITOR_STATUS_FAIL) ||
    ($solr_info['status'] === NestMonitor::MONITOR_STATUS_UNKNOWN)
) {
    // Serious problem; restart Solr service.
    $error_output = shell_exec('/usr/sbin/service solr restart 2>&1');
    if (($error_output !== null) && (strlen($error_output) > 0)) {
        $restart_result_msg = 'Error executing service solr restart: ' .
            $error_output;
    } else {
        $restart_result_msg = 'Solr service restarted successfully.';
    }
    error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $restart_result_msg);

    // Send alert email.
    $to = ERROR_NOTIFICATION_RECIPIENTS;
    $from = 'donotreply@scscertified.com';
    $reply_to = $from;
    $subject = 'ALERT: Solr Status Check failure';
    $last_modified = $solr_info['synced'] ?: 'unknown';
    foreach ($solr_info['details'] as $detail) {
        $details[] = $detail['label'] . ': ' . $detail['value'];
    }
    $detail_list = implode('<br/>', $details);
    $message = 'Solr last modified: ' . $last_modified . '<br/>' .
        $detail_list . '<br/>';
    $message .= $restart_result_msg . '</br/>';
    $timenow = new \DateTime();
    $timenow->setTimezone(new \DateTimeZone('America/Los_Angeles'));
    $headers =  'Date: ' . $timenow->format('d M Y H:i:s O') . "\r\n"
              . 'From: ' . $from . "\r\n"
              . 'Reply-To: ' . $reply_to . "\r\n"
              . 'X-Mailer: PHP/' . phpversion() . "\r\n"
              . 'MIME-Version: 1.0' . "\r\n"
              . 'Content-Type: text/html; charset=UTF-8' . "\r\n";

    mail($to, $subject, $message, $headers);
}
