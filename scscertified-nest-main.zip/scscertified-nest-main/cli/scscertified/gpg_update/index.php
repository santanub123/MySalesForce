<?php

/**
 * @file gpg_update.php
 * @author T. Treadwell
 * @date 2014-04-15
 *
 * Green Products Guide update script.
 * Designed to run from the command line via a cron job.
 *
 * Command-line options
 *   -a
 *      Set Apple mode
 *
 *   -p
 *      Set production mode - allows writing to DMS and remote databases.
 *
 *   -s
 *      Solr only mode - skips MySQL update step.
 *
 * Examples:
 *    Test setting:
 *      php gpg_update.php
 *
 *    Test setting, run Solr update only:
 *      php gpg_update.php -s
 *
 *    Production setting:
 *      php gpg_update.php -p
 */

// base values
$path = '/../../../sites/nest';
require_once __DIR__ . "$path/nest_config.php";
require_once __DIR__ . "$path/includes/nest_functions.php";
$ERROR_NOTIFICATION_ADDRESS = 'webdev@scsglobalservices.com';


// configure PHP
//$error_log_dir = NEST_PATH_LOG . '/scscertified/gpg_update'; // because of how NEST_PATH_LOG is defined, it's incomplete here
$error_log_dir = __DIR__ . $path . '/../../log' . '/scscertified/gpg_update';
set_error_log($error_log_dir);
ini_set('max_execution_time', 7200);    // 2hrs; this script takes a long time

// Retrieve command-line options.
$options = getopt('aps');

// Check Apple mode option.
$use_apple = false;
if (array_key_exists('a', $options)) {
  $use_apple = true;
  echo 'In Apple mode...' . "\n";
}

// set test mode - if TRUE (default), only use localhost for MySQL and Solr databases, and don't update DMS
$test_mode = true;
if (array_key_exists('p', $options)) {
    $test_mode = false;
} else {
    echo 'In test mode...' . "\n";
}

// Check Solr only option.
$solr_only = false;
if (array_key_exists('s', $options)) {
  $solr_only = true;
  echo 'Skipping MySQL update, running Solr update only.' . "\n";
}


// load and initialize the autoloader
require_once __DIR__ . $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', __DIR__ . $path . '/includes/src');
$loader->addNamespace('Nest', __DIR__ . $path . '/src');

// Verify that the request is from the command line.
$ssec = new Scs\ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

// Load the DMS connection configuration.
require_once __DIR__ . $path . '/includes/dms/dms_config.php';

// initialize the MySQL database connection
if($use_apple)
  $mysql_db_new = Scs\ProductAppleDatabase::get_instance($test_mode);
else
  $mysql_db_new = Scs\ProductDatabase::get_instance($test_mode);

if ($mysql_db_new->connection)
{
  // Set connection timeout to a high value.
  $mysql_db_new->connection->setAttribute(\PDO::ATTR_TIMEOUT, 600);

  // run the DMS -> MySQL update
  $dms = new Scs\DmsDatabase;
  if (!$solr_only)
  {
    if($use_apple)
      $gmu = new Scs\GpgAppleMysqlUpdate($dms, $mysql_db_new, $test_mode);
    else
      $gmu = new Scs\GpgMysqlUpdate($dms, $mysql_db_new, $test_mode);
    $gmu->update_all($test_mode);
  }

  if ($solr_only || ($gmu->operational_status === Scs\GpgMysqlUpdate::OPERATION_COMPLETE))
  {
    if (!$use_apple && ($solr_only || ($gmu->total_records_updated > 0)))
    {
      // Run the MySQL -> Solr update
      $gpg_solr_index = new Scs\GpgSolrIndex($test_mode);
      $gsu = new Scs\GpgSolrUpdate($gpg_solr_index);
      // Clear the staging core.
      $gsu->delete_all('gpg_1');
      if (
        ($gsu->operational_status === Scs\GpgSolrUpdate::OPERATION_COMPLETE) &&
        ($gsu->error_status === Scs\GpgSolrUpdate::NO_ERROR)
      ) {
        // Run a full import on the staging core.
        $gsu->full_import('gpg_1');
        if (
          ($gsu->operational_status === Scs\GpgSolrUpdate::OPERATION_COMPLETE) &&
          ($gsu->error_status === Scs\GpgSolrUpdate::NO_ERROR)
        ) {
          // Swap the staging and production cores.
          $gsu->swapCores('gpg_0', 'gpg_1');
        } else {
          $err_msg = 'Solr update failed. Skipping swap of GPG Solr cores.';
          error_log(__FILE__ . ': ' . __LINE__ . ': ' . $err_msg);
        }
      } else {
        $err_msg = 'Solr delete command failed. Cannot run GPG Solr update.';
        error_log(__FILE__ . ': ' . __LINE__ . ': ' . $err_msg);
      }
    }
  }
  else
  {
    error_log(__FILE__ . ': ' . __LINE__ . ': Cannot complete GPG Solr update: GPG MySQL update failed.');
    mail($ERROR_NOTIFICATION_ADDRESS,'GPG Solr update failed','Please check the logs for the Solr import segment of the GPG Update script at https://nest.scscertified.com/dev/log_viewer');
  }
}
else
{
  error_log(__FILE__ . ': ' . __LINE__ . ': Cannot run GPG MySQL update: MySQL connection failed.');
  mail($ERROR_NOTIFICATION_ADDRESS,'GPG MySQL update failed','Please check the logs for the MySQL import segment of the GPG Update script at https://nest.scscertified.com/dev/log_viewer');
}
