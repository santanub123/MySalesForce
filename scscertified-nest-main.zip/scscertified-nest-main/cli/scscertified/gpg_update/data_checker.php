<?php

$path = '/../../../sites/nest';
require_once __DIR__ . "$path/nest_config.php";
require_once __DIR__ . "$path/includes/nest_functions.php";

$error_log_dir = __DIR__ . $path . '/../../log' . '/scscertified/gpg_update';
set_error_log($error_log_dir);

// Retrieve command-line options.
$options = getopt('apst:');
$test_mode = false;
// Check Apple mode option.
$use_apple = false;
if (array_key_exists('a', $options)) {
  $use_apple = true;
  echo 'In Apple mode...' . "\n";
}
// Check Table option
$table = -1; //Will test all tables
if(array_key_exists('t', $options)){
  $table = $options['t'];
  echo "Only testing table $table...\n";
}

// load and initialize the autoloader
require_once __DIR__ . $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', __DIR__ . $path . '/includes/src');
$loader->addNamespace('Nest', __DIR__ . $path . '/src');
$ERROR_NOTIFICATION_ADDRESS = 'webdev@scsglobalservices.com';


// Verify that the request is from the command line.
$ssec = new Scs\ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

// Load the DMS connection configuration.
require_once __DIR__ . $path . '/includes/dms/dms_config.php';

// initialize the MySQL database connection
if($use_apple)
  $mysql_db_new = Scs\ProductAppleDatabase::get_instance($test_mode);
else
  $mysql_db_new = Scs\ProductDatabase::get_instance($test_mode);

if ($mysql_db_new->connection)
{
  // Set connection timeout to a high value.
  $mysql_db_new->connection->setAttribute(\PDO::ATTR_TIMEOUT, 600);

  // run the DMS -> MySQL update
  $dms = new Scs\DmsDatabase;
  
  if($use_apple)
    $gmu = new Scs\GpgAppleMysqlUpdate($dms, $mysql_db_new, $test_mode);
  else
    $gmu = new Scs\GpgMysqlUpdate($dms, $mysql_db_new, $test_mode);
  $results = $gmu->check_all($table);
  $results = json_encode($results, JSON_PRETTY_PRINT);
  echo($results);
  if($use_apple)
    $mail_subject = 'Apple GPG check - Results';
  else
    $mail_subject = 'GPG check - Results';
  mail(
    $ERROR_NOTIFICATION_ADDRESS,
    $mail_subject, 
    $results
  );
}
else{
  echo 'Cannot run GPG MySQL update: MySQL connection failed.\n';
}
