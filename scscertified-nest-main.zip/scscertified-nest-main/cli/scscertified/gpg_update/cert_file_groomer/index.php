<?php

/*
 * Purpose: Move unreferenced cert PDF files from web directories, so no existing processes remove them when a certificate is removed from the GPG.
 *
 * Method: Analyze records in database and compare to list from directory in filesystem
 *     MySQL:      scs_website::clients_certificates::printable_certificate
 *     Filesystem: /web/com/scscertified/domain/www/products/cert_pdfs
 *
 *     search 1: look for expired certificates, considering grace period, then remove their PDF files
 *     search 2: look for PDF files with no (or outdated) reference in DB, then remove them
 *
 *     list of cert records will always be a subset of files list (but trap for errors)
 *
 * $all_cert_files   array list of files in /products/cert_pdfs -- these are the live certs, though not all have a record or are non-expired
 * $all_cert_records array list of records in products.certs table in MySQL -- these are the valid, non-expired certs to compare to
 */

// base values
$path = __DIR__ . '/../../../../sites/nest';
require_once "$path/nest_config.php";
require_once "$path/includes/nest_functions.php";
 
// Load and initialize the autoloader.
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');

// Setup
//$error_log_dir = NEST_PATH_LOG . '/scscertified/gpg_update/cert_file_groomer'; // because of how NEST_PATH_LOG is defined, it's incomplete here
$error_log_dir = $path . '/../../log' . '/scscertified/gpg_update/cert_file_groomer';
set_error_log($error_log_dir);
//error_log(__FILE__ . ': ' . __LINE__ . ': Start of script...');

// Grace period
$dbGrace   = 60; // for production (GPG Update should remove db records after 30 days, so we wait 30 days more)
                 // (However, once record is gone, we have only file mod date to do on, which is more likely to be 
                 // a year in the past)
                 // TODO: accommodate this idea.
$fileGrace = $grace + 365;
$mode      = 'hide';

// browser -- for testing
if (isset($_GET['dbgrace']) && $_GET['dbgrace']) {
  $dbGrace = intval($_GET['dbgrace']);
}
if (isset($_GET['filegrace']) && $_GET['filegrace']) {
  $fileGrace = intval($_GET['filegrace']);
}
if (isset($_GET['mode']) && $_GET['mode']) {
  $mode = $_GET['mode'];
}

// CLI setup
$arguments = [
  '--db-grace' => [
        'synonyms' => [],
        'values'   => [],
        'text'     => 'set delay in days until file is acted upon, relative to cert expiration modification date',
        'required' => '0',
        'type'     => 'integer',
    ],
    '--file-grace' => [
        'synonyms' => [],
        'values'   => [],
        'text'     => 'set delay in days until file is acted upon, relative to file modification date',
        'required' => '0',
        'type'     => 'integer',
    ],
  '--mode'=> [
        'synonyms' => ['-h', '-s'],
        'values'   => ['hide', 'show'],
        'text'     => '"hide" files that have no valid certificate record, or "show" files previously hidden which now have a valid record, and which would not overwrite anything newer with the same name.',
        'required' => '1',
        'type'     => 'string',
    ],
];

$req_arg_count = 0;
$help_text = '';
$values = [];
$synonyms = [];
foreach ($arguments as $k => $arg) {
  if ($arg['required']) $req_arg_count++;
  $help_text .= "    $k: " . $arg['text'] . PHP_EOL;
  $help_text .= "        synonyms: " . implode(', ', $arg['synonyms']) . PHP_EOL;
  $help_text .= "        values:   " . implode(', ', $arg['values']) . PHP_EOL;
  $values     = array_merge($values, $arg['values']);
  $synonyms   = array_merge($synonyms, $arg['synonyms']);
}

//echo implode(', ', $values) . PHP_EOL;
//echo implode(', ', $synonyms) . PHP_EOL;

$help = [
  'Help' => [
        'synonyms' => ['--help', '-h', '-?'],
        'text'     => 'This script requires ' . $req_arg_count . ' argument(s): ' . PHP_EOL,
    ],
];

// $argv[0] is always present (name of script), so $argc is always a minimum of 1
if ($req_arg_count > $argc - 1) {
  echo $argc . ': ' . $help['Help']['text'] . $help_text;
}
else {
  // validate submitted arguments (and values, if restricted)
  $i=0;
  foreach ($argv as $arg) {
    $arg = explode('=', $arg); // always either one or two elements
    if ($i) {
      $k = str_ireplace('-', '', $arg[0]);
      $error_allowed_values = 'Must use an allowed value: ' . implode(', ', $arguments["$arg[0]"]['values']) . '. (Or use short flag equivalent: ' . implode(', ', $arguments["$arg[0]"]['synonyms']) . '.)' . PHP_EOL;
      if (count($arg) == 2) { // long flag was submitted, like '--db-grace'
        $$k = $arg[1]; // e.g., $grace = 90
        // make sure values are in allowed set, if set is specified
        if (count($arguments["$arg[0]"]['values']) && !in_array($arg[1], $arguments["$arg[0]"]['values'])) {
          echo $error_allowed_values;
          exit;
        }
      }
      else {
        if (!empty($arguments["$arg[0]"])) {
          //echo $arg[0] . ': ' . 'value required (' . $arguments["$arg[0]"]['type'] . '). ' . 'Purpose: ' . $arguments["$arg[0]"]['text'] . PHP_EOL;
          if (count($arguments["$arg[0]"]['values'])) {
            echo $error_allowed_values;
            exit;
          }
        }
        elseif (!in_array($arg[0], $synonyms)) {
          //echo $help['Help']['text'] . $help_text;
          echo 'Must use a valid short flag: ' . implode(', ', $synonyms) . PHP_EOL;
          exit;
        }
      }
    }
    $i++;
  }
  //print_r($argv);
}

/*
Expected possible vars:

$mode
$dbGrace
$fileGrace

*/

echo '$mode: ' . $mode . PHP_EOL;
echo '$dbGrace: ' . $dbGrace . PHP_EOL;
echo '$fileGrace: ' . $fileGrace . PHP_EOL;



/*** BEGIN get database records ***/

/* Search 1 (filtered) */

// TODO: Grace may need to be 1 year + some buffer period, if certs are typically uploaded around the time of certification. This won't work for 'expired' evaluations, however.
$sql = <<<___SQL
SELECT id, expirationDate, pdfFile, expirationDate + INTERVAL {$dbGrace} day as dbGraceDate
FROM certs
WHERE pdfFile != ''
-- HAVING graceDate < curDate();
___SQL;

//error_log(__FILE__ . ': ' . __LINE__ . ': sql=' . $sql);

/* End */

$certs = array();

// TODO: this is not the only check based on $mode.
// TODO: accommodate an appropriate variation when run in Stage or other live server locations. A config file might work.
// this is a production path, but works in suitably set-up dev's
$cert_file_path =  $path . '/../../../scscertified/domain/www/products/cert_pdfs/'; // NOTE: cross-repo path
if ($mode == 'show') {
  $cert_file_path =  $path . '/../../../scscertified/domain/www/products/cert_pdfs/unreferenced/'; // NOTE: cross-repo path
}

$db_fns = new \Scs\DbFns;
//$db_fns->connect_db($db_config_scs_web); // works, but led to assumption it didn't
$db_fns->connect_db($db_config['gp']);     // populates $g_mysqli global, among others

$stmt = $g_mysqli->stmt_init(); // global var
if($stmt->prepare($sql)) {
  
  if(!$stmt->execute()) { // run the SQL statement
    $mysql_error = $stmt->errno . ':' . $stmt->error;
    // TODO: add date columnn for dev/log reader friendliness
    error_log(__FILE__ . ': ' . __LINE__ . ': MySQL error (' . $mysql_error . ')');
    exit;
  }

  $stmt->store_result();
  $stmt->bind_result($id, $expirationDate, $pdfFile, $dbGraceDate);
  
  while($stmt->fetch()) {
    // if !file_exists, omit record?
    $all_cert_records[$pdfFile] = array(
        'id'             => $id,
        'expirationDate' => $expirationDate,
        'dbGraceDate'    => $dbGraceDate,
        'fileGraceDate'  => ($dbGraceDate + $fileGrace),
        'fileExists'     => file_exists($cert_file_path . $pdfFile),
        'moved'          => false,
        'target'         => '',
        'result'         => [],
      );
  }
  //error_log(__FILE__ . ': ' . __LINE__ . ': Valid cert records found: ' . $stmt->num_rows);
  $stmt->free_result();
  $stmt->close();
} 
else {
  $mysql_error = $stmt->errno . ':' . $stmt->error;
  error_log(__FILE__ . ': ' . __LINE__ . ': MySQL error (' . $mysql_error . ')');
  exit;
}

// Sort array by expiration date

/*** END get database records ***/



// temp breakpoint
//echo 'breakpoint' . PHP_EOL;
//exit;



/*** BEGIN comparison ***/

$date_run          = date('Y-m-d_H:i:s');
$date_now_obj      = date_create(date('Y-m-d'));
$date_interval_obj = date_create(date('Y-m-d', time() - ($dbGrace * 24 * 60 * 60))); // e.g., 1 yr + 60 days (ago)

$all_cert_files              = array();
$all_unreferenced_cert_files = array();
$newly_expired_certs         = array();
$newly_unreferenced_certs    = array();
$newly_recertified_certs     = array();
$file_stat                   = array();

if ($mode == 'hide') {
  
  //$cert_file_path =  $path . '/../../../scscertified/domain/www/products/cert_pdfs/'; // NOTE: cross-repo path
  $expired_cert_placeholder = $cert_file_path . 'template/' . 'expired.pdf';
  $expired_cert_placeholder_info = stat($expired_cert_placeholder);
  $files_avoid = array('.', '..', 'expired', 'unreferenced', 'template');

  $all_cert_files = scandir($cert_file_path);
  $count_all_cert_files = count($all_cert_files);
  // TODO: add error trapping for pointing to invalid or wrong filepath
  //error_log(__FILE__ . ': ' . __LINE__ . ': Extant cert files found: ' . $count_all_cert_files);

  foreach ($all_cert_files as $k => $file_name) {
    
    if (!in_array($file_name, $files_avoid)) {
      
      if (isset($all_cert_records[$file_name])) { // name found in MySQL
      
        // Drop this section, since an expired cert should simply be removed from MySQL by update process, so we don't need to analyze or act on it here.
        
        /*
        $date_grace_obj = date_create(date($all_cert_records[$file_name]['dbGraceDate']));
    
        //if ($all_cert_records[$file_name]['dbGraceDate'] < $date ) {// newly expired
        if ($date_grace_obj < $date_now_obj ) {                     // newly expired
          
          // clean up from previous tests
          //if (file_exists($cert_file_path . 'expired/' . $file_name)) { // duplicate found in expired/ -- we assume expired one takes precedence;
          //  unlink($cert_file_path . $file_name);
          //  rename($cert_file_path . 'expired/' . $file_name, $cert_file_path . $file_name); // overwrites, though we've deleted the duplicate anyway;
          //}
          
          // now move the file and create a PDF placeholder where it's moved from
          $all_cert_records[$file_name]['target'] = 'expired';
          $all_cert_records[$file_name]['moved'] = rename($cert_file_path . $file_name, $cert_file_path . 'expired/' . $file_name); // overwrites;
          symlink($expired_cert_placeholder, $cert_file_path . $file_name); // overwrites;
          touch($cert_file_path . 'expired/' . $file_name . '_' . $date_run); // placeholder file;
          
          $newly_expired_certs[$file_name] = $all_cert_records[$file_name];
          //unset($all_cert_files[$k]); // reduce by this element
          
          // stat() returns an array, or false
          $file_stat = stat($cert_file_path . 'expired/' . $file_name);
          $file_stat += stat($cert_file_path . 'expired/' . $file_name . '_' . $date_run); // placeholder file;
          
        }
        */
        
      }
      else { // unreferenced file
        
        // clean up from previous tests
        //if (file_exists($cert_file_path . 'unreferenced/' . $file_name)) {
        //  if (file_exists($cert_file_path . $file_name)) unlink($cert_file_path . $file_name);
        //  rename($cert_file_path . 'unreferenced/' . $file_name, $cert_file_path . $file_name); // overwrites;
        //}
        
        $date_file = date('Y-m-d', filemtime($cert_file_path . $file_name));
        $date_file_obj = date_create($date_file);
        
        if ($date_file_obj < $date_interval_obj) { // do nothing unless file is older than <interval> -- 1 week at present
          $all_cert_records[$file_name]['target'] = 'unreferenced';
          
          /*** NOT moving files for now, just flagging them ***/
          ////$all_cert_records[$file_name]['moved'] = rename($cert_file_path . $file_name, $cert_file_path . 'unreferenced/' . $file_name); // overwrites;
          /*** End moving files ***/
          
          $all_cert_records[$file_name]['moved'] = 'held (but should be moved to /unreferenced when we have confidence)'; // just record that the file qualified, don't actually move it for now
          
          // TODO: though it creates a more infomative placeholder file, this will cause DMS file_upload.php to give a false positive about file being present
          //symlink($expired_cert_placeholder, $cert_file_path . $file_name); // overwrites;
          //touch($cert_file_path . 'expired/' . $file_name . '_' . $date_run); // placeholder file;
          
          $newly_unreferenced_certs[$file_name] = $all_cert_records[$file_name];
          //unset($all_cert_files[$k]); // reduce by this element
        }
        else {
          // TODO: add date column, for dev/log reader friendliness
          error_log(__FILE__ . ': ' . __LINE__ . ': File left in place, too recent (' . $date_file . '): ' . $file_name);
        }
        
      }
    
    }
    else {
      
      //unset($all_cert_files[$k]); // reduce by this element
      
    }
    
  }

}
elseif ($mode == 'show') {
  
  //cert_file_path =  $path . '/../../../scscertified/domain/www/products/cert_pdfs/unreferenced/'; // NOTE: cross-repo path
  $expired_cert_placeholder = $cert_file_path . '/../template/' . 'expired.pdf';
  $expired_cert_placeholder_info = stat($expired_cert_placeholder);
  $files_avoid = array('.', '..', 'expired', 'unreferenced', 'template'); // TODO: probably unnecessary in this context

  $all_unreferenced_cert_files = scandir($cert_file_path);
  $count_all_unreferenced_cert_files = count($all_unreferenced_cert_files);
  // TODO: add error trapping for pointing to invalid or wrong filepath
  //error_log(__FILE__ . ': ' . __LINE__ . ': Extant cert files in unreferenced: ' . $count_all_cert_files);
  
  foreach ($all_unreferenced_cert_files as $k => $file_name) {
    
    if (!in_array($file_name, $files_avoid)) {
      
      if (isset($all_cert_records[$file_name])) { // name found in MySQL
      
        $date_grace_obj = date_create(date($all_cert_records[$file_name]['dbGraceDate']));
    
        //if ($all_cert_records[$file_name]['graceDate'] < $date ) {// newly re-certified
        if ($date_grace_obj > $date_now_obj ) {                     // newly re-certified; note reversal of inequality
          
          /*
          // clean up from previous tests
          if (file_exists($cert_file_path . '../' . $file_name)) { // duplicate found in ../ -- we assume expired one takes precedence;
            unlink($cert_file_path . $file_name);
            rename($cert_file_path . '../' . $file_name, $cert_file_path . $file_name); // overwrites, though we've deleted the duplicate anyway;
          }
          */
          
          // now move the file and create a PDF placeholder where it's moved from
          $all_cert_records[$file_name]['target'] = 'parent';
          //$all_cert_records[$file_name]['moved'] = rename($cert_file_path . $file_name, $cert_file_path . '../' . $file_name); // overwrites;
          $all_cert_records[$file_name]['moved'] = 'held (not moved from /unreferenced)';
          //symlink($expired_cert_placeholder, $cert_file_path . $file_name); // overwrites;
          //touch($cert_file_path . '../' . $file_name . '_' . $date_run); // placeholder file;
          
          $newly_recertified_certs[$file_name] = $all_cert_records[$file_name];
          //unset($all_unreferenced_cert_files[$k]); // reduce by this element
          
          // stat() returns an array, or false
          //$file_stat = stat($cert_file_path . '../' . $file_name);
          //$file_stat += stat($cert_file_path . '../' . $file_name . '_' . $date_run); // placeholder file;
          
        }
        
      }
      // do nothing since, if record isn't in MySQL, we don't restore the file (or even report on it) anyway
      else { // unreferenced file
        
      }
    
    }
    else { // avoided files
      //unset($all_cert_files[$k]); // reduce by this element
    }
    
  }
  
}
else { // no mode specified
  // do nothing
  //echo 'No analyses or actions done';
}

/*** END comparison ***/



/*** BEGIN logging ***/

// log contents are mailed out as well, unless $show is true

$log_file = $error_log_dir . '/run_data/' . $date_run . '.log';

//echo $log_file;

$run_log = file_put_contents($log_file, 
    'Run date:                     ' . str_replace('_', ' ', $date_run) . "\n" . 
    '$mode:                        ' . $mode . "\n" . 
    '$dbGrace:                     ' . $dbGrace . "\n" . 
    '$fileGrace:                   ' . $fileGrace . "\n" . 
    '$all_cert_records:            ' . count($all_cert_records) . "\n" . 
    '$all_cert_files:              ' . count($all_cert_files) . "\n" . 
    '$all_unreferenced_cert_files: ' . count($all_unreferenced_cert_files) . "\n" . 
    "\n" . 
    '$newly_expired_certs:' . "\n" . 
    print_r($newly_expired_certs, true) . "\n" . 
    "\n" . 
    '$newly_unreferenced_certs:' . "\n" . 
    print_r($newly_unreferenced_certs, true) . "\n" . 
    "\n" . 
    '$newly_recertified_certs:' . "\n" . 
    print_r($newly_recertified_certs, true) . "\n" . 
    "\n" .
    '=====' . "\n" .
    "\n",
    FILE_APPEND
  );
if ($run_log) {
  $run_log = file_get_contents($log_file);
} else {
  $run_log = "Error occurred writing log file $log_file.";
}

/*** END logging ***/


/*** BEGIN Browser display ***/

if (isset($_GET['show'])) { // never true in CLI; note the current file location is inaccessible to a browser!
  
  $intersect = array();
  foreach ($file_stat as $k => $v) {
    if ($file_stat[$k] == $expired_cert_placeholder_info[$k]) $intersect[$k] = $v;
  }
  
  header('Content-Type: text/html');

  echo '
  <style>
  div {
    background-color: fed;
    margin-top:10px;
    padding:5px;
  }
  </style>';

  echo '<pre>';
  
  //echo $grace . "\n";

  /*
  //print_r($expired_cert_placeholder_info);
  echo '<div style="display: inline-block">';
  print_r( $intersect ) . "\n";
  echo '</div>';
  echo '<div style="display: inline-block">';
  print_r( $expired_cert_placeholder_info ) . "\n";
  echo '</div>';
  echo '<div style="display: inline-block">';
  print_r( $file_stat ) . "\n";
  echo '</div>';
  */

  /*
  echo '<div>';
  echo '$run_log (bytes): ' . $run_log . "\n";
  echo '</div>';
  */
  
  echo '<div>';
  echo '$mode: ' . $mode . "\n";
  echo '$dbGrace: ' . $dbGrace . "\n";
  echo '$fileGrace: ' . $fileGrace . "\n";
  echo '</div>';
  
  echo '<div>';
  echo '$newly_expired_certs: ' . count($newly_expired_certs) . "\n";
  echo "\n";
  print_r ( $newly_expired_certs );
  echo '</div>';
  
  echo '<div>';
  echo '$newly_unreferenced_certs: ' . count($newly_unreferenced_certs) . "\n";
  echo "\n";
  print_r ( $newly_unreferenced_certs );
  echo '</div>';
  
  echo '<div>';
  echo '$newly_recertified_certs: ' . count($newly_recertified_certs) . "\n";
  echo "\n";
  print_r ( $newly_recertified_certs );
  echo '</div>';
  
  echo '<div>';
  echo '$all_cert_files: ' . count($all_cert_files) . "\n";
  echo "\n";
  print_r ( $all_cert_files );
  echo '</div>';
  
  echo '<div>';
  echo '$all_cert_records: ' . count($all_cert_records) . "\n";
  echo "\n";
  print_r ( $all_cert_records );
  echo "\n";
  echo '</div>';

}

/*** END Browser display ***/

else { // $_GET['show'] is not set (which doesn't pertain to CLI)

    $default_domain = 'scscertified.com';
    $name = 'vrobinson';  // add/substitute your name if you're interested
    $host = gethostname();
    //$host = dns_get_record("$host");
    //$host = $host[0]['ip'];
    
    $to = "$name@$default_domain";
    $from = "www-data@$host.$default_domain";
    $subject = 'CFG Run Data';
    $message = $run_log;
    $headers = 
    'From: ' . $from . "\r\n" .
    'Reply-to: ' . $from . "\r\n"
    ;
    
    //HTML additions (using array rather than  . "\r\n" -- either method is fine, but don't combine)
    //$headers[] = 'MIME-Version: 1.0';
    //$headers[] = 'Content-type: text/html; charset=iso-8859-1';
    
    mail($to, $subject, $message, $headers);
  
}

//error_log(__FILE__ . ': ' . __LINE__ . ': ...End of script.');
