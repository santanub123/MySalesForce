<?php

/**
 * @file
 * 501 and 502 DMS -> FSC bulk export script.
 *
 * Designed to run from the command line. Searches the DMS for all 501 or 502
 * certified and suspended certificates, and exports/updates them to/in FSC db,
 * including child records.
 *
 * Logs results in MySQL database application_logs.bulk_fsc_export.
 *
 * Note, this script currently takes about 9 seconds per certificate, so the
 * full 502 certificate dataset of ~4700 certs takes almost 12 hours to process.
 *
 * @author T. Treadwell
 * @date 2022-06-29
 *
 * Options
 *   -c <certificate class>
 *      (required) Limit to one certificate class: 501 | 502
 *      Only that type of cert is processed.
 *
 *   -f <FSC database mode>
 *      Change the destination FSC database mode: none | mock | sandbox | prod
 *        none    = Don't export any data (default)
 *        mock    = MySQL mock of FSC db
 *        sandbox = FSC sandbox database
 *        prod    = FSC production database
 *
 *   -w
 *      DMS write enable: if set, allow writing of id values to DMS
 *      If not set, nothing is written to DMS.
 *
 *   -s <start skip value>
 *      (integer) Start skip value: offset in query results to start processing
 *      Useful if bulk export is interrupted and later resumed
 *
 * Examples:
 *   Test run for 502 certs on FSC mock database
 *     php bulk_export.php -c 502 -f mock
 *
 *   Bulk update on production FSC db, writing id values back to DMS
 *     php bulk_export.php -c 502 -f prod -w
 */

/* Configure PHP                        */

// This script takes a long time.
ini_set('max_execution_time', 7200);

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Log errors to custom error log.
require_once __DIR__ . '/../../../sites/nest/nest_config.php';
ini_set('log_errors', 1);
$log_dir = '/scscertified/fsc_export';
ini_set('error_log', NEST_PATH_LOG . $log_dir . '/bulk_export_errors.log');

// Load and initialize the autoloader.
require_once __DIR__ . '/../../../sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', __DIR__ . '/../../../sites/nest/includes/src');

// Load the database configurations.
require_once __DIR__ . '/../../../sites/nest/includes/db_config.php';

// Load the DMS connection configuration.
require_once __DIR__ . '/../../../sites/nest/includes/dms/dms_config.php';

// Load the FSC database configuration.
require_once __DIR__ . '/../../../sites/nest/includes/fsc/fsc_db_config.php';

// Load the FSC export script configuration.
include_once __DIR__ . '/fsc_export_config.php';

// Retrieve command-line options.
$options = getopt('c:f:ws:');

// Check for certificate class option..
$certificate_class = '';
if (array_key_exists('c', $options)) {
    if (!empty($options['c'])) {
        $certificate_class = $options['c'];
    } else {
        $msg = 'Missing -c option certificate_class value';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
} else {
    $msg = 'Missing -c option for certificate_class';
    error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
    echo $msg . PHP_EOL;
    exit;
}

// Check for FSC database mode option. Default to 'none'.
$fsc_db_mode = 'none';
if (array_key_exists('f', $options)) {
    if (!empty($options['f'])) {
        $fsc_db_mode = $options['f'];
    } else {
        $msg = 'Missing -f option fsc_db_mode value';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for DMS writeback option - if set, update DMS flags and ids.
$dms_write_enable = false;
if (array_key_exists('w', $options)) {
    $dms_write_enable = true;
    echo 'Writing data to DMS.' . PHP_EOL;
}

// Check for start skip value option. Default to 0.
$start_skip = 0;
if (array_key_exists('s', $options)) {
    if (!empty($options['s'])) {
        $start_skip = (int) $options['s'];
    } else {
        $msg = 'Missing -s option start_skip value';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Open FSC database connection based on $fsc_db_mode setting.
try {
    switch ($fsc_db_mode) {
        case 'none':
            echo 'No FSC database connection.' . PHP_EOL;
            break;

        case 'mock':
            echo 'Connecting to MySQL mock FSC database.' . PHP_EOL;
            $fsc_db = Scs\Integration\Test\FSC\FscDatabaseMock::getInstance(
                $fsc_db_config['mock']
            );
            break;

        case 'sandbox':
        case 'prod':
            echo 'Connecting to FSC ' . $fsc_db_mode . ' database.' . PHP_EOL;
            $fsc_db = Scs\Integration\FscDatabase::get_instance(
                $fsc_db_config[$fsc_db_mode]
            );
            break;

        default:
            $msg = 'Invalid mode value: "' . $fsc_db_mode . '"';
            error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
            echo $msg . PHP_EOL;
            exit;
    }

    // Create the DmsDatabase and DmsFscExport objects.
    $fm_db = new Scs\DmsDatabase();
    $dms_fsc_export = new Scs\Integration\DMS_FSC\DmsFscExport(
        $fm_db,
        $fsc_db,
        $dms_write_enable,
        true,
        $fsc_db_mode,
        false,
        $log_dir,
        'bulk_fsc_export'
    );

    // Run the bulk DMS -> FSC export.
    $dms_fsc_export->bulkProcessCertClass(
        $certificate_class,
        $fsc_export_config['error_notification_recipients'],
        $start_skip
    );

} catch (\Exception $e) {
    // Fatal error. Log to error log.
    error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $e->getMessage());
}

