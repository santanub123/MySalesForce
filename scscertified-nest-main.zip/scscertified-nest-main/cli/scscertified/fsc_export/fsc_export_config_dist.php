<?php

// Configuration file for FSC export.
$fsc_export_config = [

    // Recipients of fatal error notifications.
    'error_notification_recipients' => [
        'ralph@example.com',
    ],

    // Recipients of email reports.
    'email_report_recipients' => [
        'departments' => [
            '501' => [
                'mary@example.com',
            ],
            '502' => [
                'john@example.com',
            ],
        ],
        'always' => [
            'pat@example.com',
        ],
    ],

    // Certificate numbers to exclude from export processing.
    'certs_to_exclude' => [
        'SCS-XYZ-000001',
    ],
];
