<?php

/**
 * @file
 * Script to populate FSC database sandbox Species__c table.
 *
 * Designed to run from the command line. This is a one-time patch to the FSC db
 * to populate the sandbox species table. Uses a copy from the production FSC
 * site.
 *
 * 2020-04-16 Doesn't work because we don't have permission to write to the
 * Species__c table.
 *
 * @author T. Treadwell
 * @date 2020-04-13
 */

/* Configure PHP                        */

// This script takes a long time.
ini_set('max_execution_time', 7200);

// Report significant errors.
ini_set('error_reporting', E_ALL);

// Log errors to custom error log.
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/log/php_errors.log');

// Load and initialize the autoloader.
$path = __DIR__ . '/../../../sites/nest';
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');

// Load the FSC database configuration.
require_once $path . '/includes/fsc/fsc_db_config.php';

// Create object for the FSC sandbox database.
$fsc_db = Scs\Integration\FscDatabase::get_instance($fsc_db_config, true);

// Open the species list file.
$species_file = 'output/Species__c_2020-03-31_150354.csv';
if (($fh = fopen($species_file, 'r')) === false) {
    error_log(
        __FILE__ . ' line ' . __LINE__ .
        'Cannot open input file ' . $species_file
    );
    exit;
}
$first_record = true;
// Read each row of the file.
while (($row = fgetcsv($fh, 1000, ',')) !== false) {
    if ($first_record) {
        $col_names = $row;
        $first_record = false;
    } else {
        // Skip rows with invalid Id data.
        if (empty($row[0]) || (strpos($row[0], 'a') !== 0)) {
            continue;
        }
        // Load sObject with row data except for Id.
        $new_data = array_combine($col_names, $row);
        $sObject = new \SObject;
        $sObject->type = 'Species__c';
        foreach ($new_data as $field_name => $value) {
            if ($field_name !== 'Id') {
                $sObject->fields->{$field_name} = $value;
            }
        }
        // Save to FSC sandbox.
        $saveResults = $fsc_db->create(array($sObject));
        if (!$saveResults[0]->success) {
            error_log(
                __FILE__ . ' line ' . __LINE__ .
                'Error writing to FSC db: ' . $saveResults[0]->message
            );
            exit;
        }
    }
}

$a = 1;     // for debugging
