<?php

/**
 * @file
 * DMS connection test script.
 *
 * Designed to run from the command line. Establishes a connection to the DMS
 * and retrieves a layout similar to the FSC export script. Echoes results to
 * stdout.
 *
 *   -h <host id>
 *      Use a specific host for DMS: att | azure | comcast | fm | redbison1 | redbison2 | dev | default
 *      If not set or 'default', use default DMS host
 *
 *   -a
 *      Test all hosts (if set then -h option is ignored)
 *
 *      Note: This option doesn't really work yet because Filemaker apparently
 *      caches the previous connection and doesn't open a new one. Still needs
 *      work to close the connection on one host and open another.
 *
 * @author T. Treadwell
 * @date 2021-08-12
 */

$path = __DIR__ . '/../../../sites/nest';

// Load and initialize the autoloader.
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');

// Verify that it's a CLI request.
$scs_security = new Scs\ScsSecurity();
if (!$scs_security->verifyLocalRequest()) {
    echo 'Exiting...' . PHP_EOL;
}

// Load the DMS connection configuration.
require_once $path . '/includes/dms/dms_config.php';

// Retrieve command-line options.
$options = getopt('h:a');

// Check for DMS host id option. Default to null.
$dms_host_id = null;
if (array_key_exists('h', $options)) {
    if (!empty($options['h'])) {
        $dms_host_id = $options['h'];
    } else {
        $msg = 'Missing -h option DMS host id';
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for all hosts option.
if (array_key_exists('a', $options)) {
    foreach ($dms_config['hosts'] as $host_id => $domain) {
        echo '--------------------' . PHP_EOL;
        testHost($host_id);
    }
} else {
    testHost($dms_host_id);
}

/**
 * Run connection/performance test on one host
 *
 * @param string $dms_host_id
 *     identifier in $dms_config['hosts'] array
 */
function testHost($dms_host_id)
{
    global $dms_config;

    if (is_null($dms_host_id)) {
        $default_host_id = $dms_config['default_host_id'];
        echo 'Using default host \'' . $default_host_id . '\' connection ' .
            $dms_config['hosts'][$default_host_id] . PHP_EOL;
    } else {
        echo 'Using \'' . $dms_host_id . '\' connection ' .
            $dms_config['hosts'][$dms_host_id] . PHP_EOL;
    }

    // Create the DmsDatabase object.
    $fm_db = new Scs\DmsDatabase($dms_host_id);

    // Establish connection to file.
    $fm_db->connect('CERT_DATA_SCS');

    // Store start time.
    $time_start = new \DateTime(
        'now',
        new \DateTimeZone('America/Los_Angeles')
    );

    // Retrieve layout.
    $layout_object = $fm_db->connection->getLayout('web_upload_fsc_cert');
    if (\FileMaker::isError($layout_object)) {
        $message = __FILE__ . ' line ' . __LINE__ .
            ': Error getting layout: ' . $layout_object->getMessage() .
            ' (error ' . $layout_object->code . ')';
        echo $message . PHP_EOL;
    } else {
        echo 'Layout retrieved successfully.' . PHP_EOL;
    }

    // Store end time.
    $time_end = new \DateTime(
        'now',
        new \DateTimeZone('America/Los_Angeles')
    );

    // Calculate duration.
    $ext_duration = $time_start->diff($time_end);
    $mins = (int) $ext_duration->format('%i');
    $secs = (int) $ext_duration->format('%s');
    $microsecs = (int) $ext_duration->format('%f');
    $total_ms = ($mins * 60000) + ($secs * 1000) + (int) round($microsecs / 1000);
    echo 'Elapsed ' . $total_ms . 'ms' . PHP_EOL;

    // Destroy the FilemakerDatabase object.
    unset($fm_db);
}
