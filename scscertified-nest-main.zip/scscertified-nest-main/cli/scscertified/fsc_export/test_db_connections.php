<?php

/**
 * @file
 * Test of FSC integration MySQL and Azure SQL database connections
 *
 * Tests connections to:
 *   ApplicationDbLog MySQL application_logs
 *   Azure scs_reporting
 *
 * using settings in /sites/nest/includes/db_config_2.php
 *   and /sites/nest/quickbooks/qb_*_config.php files
 *
 * Run from command line
 *
 * @author T. Treadwell
 * @date 2023-08-17
 */

use \Scs\ApplicationlogsDatabase;
use \Scs\Integration\AzureSqlDatabase;

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);
ini_set('log_errors', 1);

// Set custom error log.
$log_dir = __DIR__ . '/../../../log/scscertified/fsc_export';
ini_set('error_log', $log_dir . '/test_db_connections_error.log');

// Load and initialize the autoloader.
require_once __DIR__ . '/../../../sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', __DIR__ . '/../../../sites/nest/includes/src');

// Verify that the request is from the command line.
$ssec = new Scs\ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

// Require the database configuration settings.
require_once __DIR__ . '/../../../sites/nest/includes/db_config.php';

// Test the Application Logs database.
$applog_db = ApplicationlogsDatabase::get_instance();
$db_name = $db_config['application_logs']['database'];
runConnectionTest($applog_db->connection, $db_name, 'dms_fsc_export');

// Test the Azure FSC Reporting Import database.
$afr_import_db = new AzureSqlDatabase($db_config['afr_import']);
$db_name = $db_config['afr_import']['database'];
runConnectionTest($afr_import_db->connection, $db_name, 'Landing.FSC_DMS_Comparison');

echo 'Test complete.' . PHP_EOL;

/**
 * Test connection to a single database.
 *
 * Output results to stdout.
 *
 * @param object $pdo
 *     PDO object with valid connection
 * @param string $database_name
 *     name of database to test
 * @param string $table_name
 *     name of table to query
 */
function runConnectionTest($pdo, $database_name, $table_name)
{
    // Add spaces to align results in a column.
    $db_table_name = $database_name . '.' . $table_name;
    $db_table_name_len = strlen($db_table_name);
    $padding = str_repeat(' ', 50 - $db_table_name_len);
    echo 'Testing query of ' . $db_table_name . '... ' . $padding;

    if (empty($database_name) || empty($table_name)) {
        echo 'FAIL - empty database name or table name' - PHP_EOL;
        return;
    }
    $sql = 'SELECT COUNT(*) AS cnt FROM ' . $table_name;
    $stmt = $pdo->query($sql, \PDO::FETCH_ASSOC);
    if ($stmt === false) {
        $error_info = $pdo->errorInfo();
        $error_msg = $error_info[2];
        echo 'FAIL - query failed: "' . $error_msg . '"' . PHP_EOL;
        return;
    }
    $row = $stmt->fetch(\PDO::FETCH_ASSOC);
    echo 'success - ' . $row['cnt'] . ' rows returned.' . PHP_EOL;
}
