<?php

/**
 * @file
 * 501 and 502 DMS -> FSC export script.
 *
 * Designed to run from the command line via a cron job. Finds all records in
 * the DMS checked for web export, and inserts or updates them in the FSC
 * Salesforce database. Records activity in database table.
 *
 * @author T. Treadwell
 * @date 2014-06-16
 *
 * Options
 *   -c <certificate class>
 *      Limit to one certificate class: 501 | 502
 *      If set, only that type of cert is exported.
 *      If not set, all cert types in export sequence are exported.
 *
 *   -f <FSC database mode>
 *      Change the destination FSC database mode: none | mock | sandbox | prod
 *        none    = Don't export any data (default)
 *        mock    = MySQL mock of FSC db
 *        sandbox = FSC sandbox database
 *        prod    = FSC production database
 *
 *   -w
 *      DMS write enable: if set, allow writing of flag and id values to DMS
 *      If not set, nothing is written to DMS
 *
 *   -s <certificate number>
 *      Processes a single certificate only, whether it's flagged or not
 *
 *   -h <host id>
 *      Use a specific host for DMS: att | comcast | redbison1 | redbison2 | dev | default
 *      If not set or 'default', use default DMS host
 *
 * Examples:
 *    Production setting:
 *      php fsc_export/index.php -f prod -w
 *
 *    Production setting, using Red Bison 2 host:
 *      php fsc_export/index.php -f prod -w -h redbison2
 *
 *    Development setting writing 502 certs to mock FSC db, not writing to DMS:
 *      php fsc_export/index.php -c 502 -f mock
 */

/* Configure PHP                        */

// base values
$path = __DIR__ . '/../../../sites/nest';
require_once "$path/nest_config.php";
require_once "$path/includes/nest_functions.php";

// This script takes a very long time.
ini_set('max_execution_time', 7200); // 2hrs

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Log errors to custom error log.
ini_set('log_errors', 1);
//$log_dir = NEST_PATH_LOG . '/scscertified/fsc_export'; // because of how NEST_PATH_LOG is defined, it's incomplete here
$log_dir = $path . '/../../log' . '/scscertified/fsc_export';
set_error_log($log_dir);

// Load and initialize the autoloader.
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');
$loader->addNamespace('Nest', $path . '/src');

// Load the database configurations.
require_once $path . '/includes/db_config.php';

// Load the DMS connection configuration.
require_once $path . '/includes/dms/dms_config.php';

// Load the FSC database configuration.
require_once $path . '/includes/fsc/fsc_db_config.php';

// Load the FSC export script configuration.
include_once __DIR__ . '/fsc_export_config.php';

// Load the Nest API config settings.
require_once $path . '/nest_config.php';

// Initialize the NestApi object and log in.
$nest_api = \Nest\Api::getInstance();
$nest_token_info = $nest_api->login(NEST_API_USER, NEST_API_PASS);
$nest_token = $nest_token_info->token;

// Retrieve command-line options.
$options = getopt('c:f:ws:h:');

// Check for certificate class option. Default to ''.
$certificate_class = '';
if (array_key_exists('c', $options)) {
    if (!empty($options['c'])) {
        $certificate_class = $options['c'];
    } else {
        $msg = 'Missing -c option certificate_class value';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for FSC database mode option. Default to 'none'.
$fsc_db_mode = 'none';
if (array_key_exists('f', $options)) {
    if (!empty($options['f'])) {
        $fsc_db_mode = $options['f'];
    } else {
        $msg = 'Missing -f option fsc_db_mode value';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for DMS writeback option - if set, update DMS flags and ids.
$dms_write_enable = false;
if (array_key_exists('w', $options)) {
    $dms_write_enable = true;
    echo 'Writing data to DMS.' . PHP_EOL;
}

// Check for single certificate option. Default to ''.
$single_certificate = '';
if (array_key_exists('s', $options)) {
    if (!empty($options['s'])) {
        $single_certificate = $options['s'];
    } else {
        $msg = 'Missing -s option certificate number value';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for DMS host id option. Default to null.
$dms_host_id = null;
if (array_key_exists('h', $options)) {
    if (!empty($options['h'])) {
        $dms_host_id = $options['h'];
        echo 'Using ' . $dms_host_id . ' connection.' . PHP_EOL;
    } else {
        $msg = 'Missing -h option DMS host id';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Open FSC database connection based on $fsc_db_mode setting.
try {
    switch ($fsc_db_mode) {
        case 'none':
            echo 'Not exporting data.' . PHP_EOL;
            break;

        case 'mock':
            echo 'Exporting data to MySQL mock FSC database.' . PHP_EOL;
            $fsc_db = Scs\Integration\Test\FSC\FscDatabaseMock::getInstance(
                $fsc_db_config['mock']
            );
            break;

        case 'sandbox':
            echo 'Exporting data to FSC test sandbox.' . PHP_EOL;
            $fsc_db = Scs\Integration\FscDatabase::get_instance($fsc_db_config['sandbox']);
            break;

        case 'prod':
            echo 'Exporting data to FSC live production database.' . PHP_EOL;
            $fsc_db = Scs\Integration\FscDatabase::get_instance($fsc_db_config['prod']);
            break;

        default:
            $msg = 'Invalid destination value: "' . $destination . '"';
            error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
            echo $msg . PHP_EOL;
            exit;
    }

    $omit_criteria = [];
    if (isset($fsc_export_config) &&
        !empty($fsc_export_config['certs_to_exclude'])
    ) {
        foreach ($fsc_export_config['certs_to_exclude'] as $cert_num) {
            $criterion = ['certificate' => $cert_num];
            $omit_criteria[] = $criterion;
        }
    }

    // Create the DmsDatabase and DmsFscExport objects.
    $fm_db = new Scs\DmsDatabase($dms_host_id);
    $dms_fsc_export = new Scs\Integration\DMS_FSC\DmsFscExport(
        $fm_db,
        $fsc_db,
        $dms_write_enable,
        true,
        $fsc_db_mode,
        false,
        $log_dir
    );

    // Run the DMS -> FSC export.
    $dms_fsc_export->processCertClasses(
        $certificate_class,
        $single_certificate,
        $omit_criteria,
        $fsc_export_config['error_notification_recipients']
    );
} catch (\Exception $e) {
    // Fatal error. Log to error log.
    error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $e->getMessage());

    // Set up email alert message.
    $error_recipients = implode(
        ',',
        $fsc_export_config['error_notification_recipients']
    );
    $subject = 'DMS - FSC Export Error Alert';
    $title = "<p align='left'><b>$subject</b></p>";
    $content = '<p style="text-align: left">' .
        '<span style="font-weight: bold; color: #f00">Fatal error:</span><br>' .
        $e->getMessage() . '</p>' .
        '<p style="text-align: left">See ' . $error_log_dir . '/errors.log</p>' .
        '<p> &nbsp; </p><p> &nbsp; </p>';

    // Send message.
    $email_templates = new \Scs\EmailTemplates();
    $headers = $email_templates->getHeaders();
    $options = ['url' => '', 'link_text' => ''];
    $message = $email_templates->generateTemplate($title, $content, $options);
    mail($error_recipients, $subject, $message, $headers);
}
