<?php

/**
 * @file
 * DMS - FSC email report script.
 *
 * Designed to run from the command line. Queries the application_logs database
 * dms_fsc_export table. Generates and sends email report for program staff.
 *
 * @author T. Treadwell
 * @date 2020-06-30
 *
 * Options
 *   -d <department>    (501 | 502)
 *     (optional) department # to report. If not set, report all available dept
 *     #s.
 *
 * Example report for 502:
 *    php dms_fsc_export.php -d 502
 */

/* Configuration                        */

// Nest configuration.
$path = __DIR__ . '/../../../sites/nest';
require_once "$path/nest_config.php";
require_once "$path/includes/nest_functions.php";

// This script takes a long time.
ini_set('max_execution_time', 3600);

// Report significant errors.
ini_set('error_reporting', E_ALL);

// Log errors to FSC export error log.
ini_set('log_errors', 1);
$error_log_dir = $path . '/../../log' . '/scscertified/fsc_export';
set_error_log($error_log_dir, 'dms_fsc_email_report.log');

// Set command line options.
$department = '';
$options = getopt('d:');

// Check for department option.
if (array_key_exists('d', $options)) {
    if (!empty($options['d'])) {
        $department = $options['d'];
    } else {
        $msg = 'Missing -d option department value';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Load and initialize the autoloader.
$path = __DIR__ . '/../../../sites/nest';
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');

// Load the database configurations.
require_once $path . '/includes/db_config.php';

// Load the FSC export script configuration and get the recipient array.
include_once __DIR__ . '/fsc_export_config.php';
$recipient_array = $fsc_export_config['email_report_recipients'];

// Instantiate the report class and send the reports.
$email_report = new Scs\Integration\DMS_FSC\DmsFscEmailReport();
$email_report->sendEmailReports($recipient_array, $department);
