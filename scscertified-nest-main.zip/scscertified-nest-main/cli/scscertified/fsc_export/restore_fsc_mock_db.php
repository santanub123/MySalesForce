<?php

/**
 * @file
 * Restore MySQL mock FSC database from CSV data dump files.
 *
 * Designed to run from the command line.
 * Note: requires FILE privilege which is a MySQL global privilege
 *
 * @author T. Treadwell
 * @date 2020-04-29
 */

/* Configure PHP                        */

// base values
$path = __DIR__ . '/../../../sites/nest';
require_once "$path/nest_config.php";
require_once "$path/includes/nest_functions.php";

// This script takes a long time.
ini_set('max_execution_time', 3600); // 1hr

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Log errors to custom error log.
ini_set('log_errors', 1);
$error_log_dir = $path . '/../../log/scscertified/fsc_export';
set_error_log($error_log_dir);

// Load and initialize the autoloader.
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');

// Load the database configurations.
// require_once $path . '/includes/db_config.php';

// Load the FSC database configuration.
require_once $path . '/includes/fsc/fsc_db_config.php';

// Open mock FSC database connection.
$fsc_db = Scs\Integration\Test\FscDatabaseMock::getInstance(
    $fsc_db_config['mock']
);

// Set directory for source CSV files.
// $csv_dir = __DIR__ . '/output';
$csv_dir = '/var/lib/mysql-files';

// Create the management utility for the mock db.
$fsc_db_util = new Scs\Integration\DMS_FSC\test\FscDatabaseMockUtil(
    $fsc_db,
    $csv_dir
);

// Clear the existing data from all the tables.
$result = $fsc_db_util->truncateTables();

if ($result) {
    // Load all the tables from latest CSV dump files.
    $fsc_db_util->loadTablesFromCsvFiles();
}
