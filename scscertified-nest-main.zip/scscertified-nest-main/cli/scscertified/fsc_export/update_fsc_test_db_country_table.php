<?php

/**
 * @file
 * Script to update FSC database sandbox Country__c table.
 *
 * Designed to run from the command line. This is a one-time patch to the FSC db
 * to update the sandbox country table.
 *
 * 2020-03-30 Doesn't work because we don't have permission to write to the
 * Country_Data__c table.
 *
 * @author T. Treadwell
 * @date 2020-03-30
 */

/* Configure PHP                        */

// This script takes a long time.
ini_set('max_execution_time', 7200);

// Report significant errors.
ini_set('error_reporting', E_ALL);

// Log errors to custom error log.
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/log/php_errors.log');

// Load and initialize the autoloader.
$path = __DIR__ . '/../../../sites/nest';
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');

// Load the FSC database configuration.
require_once $path . '/includes/fsc/fsc_db_config.php';

// Create object for the FSC sandbox database.
$fsc_db = Scs\Integration\FscDatabase::get_instance($fsc_db_config['sandbox']);

// Run query to get the current set of countries.
$update_sObjects = [];
$qr = $fsc_db->query(
  'SELECT Id, Name, ISO_Code__c FROM Country_Data__c ORDER BY Name'
);
if (!is_null($qr)) {
    if ($qr->size > 0) {
        // Update ISO codes for DE and US.
        foreach ($qr->records as $record) {
            $sObject = new \SObject($record);
            if (!is_null($sObject)) {
                if ($sObject->fields->Name === 'Germany') {
                    $sObject->fields->ISO_Code__c = 'DE';
                    $update_sObjects[] = $sObject;
                }
                if ($sObject->fields->Name === 'United States') {
                    $sObject->fields->ISO_Code__c = 'US';
                    $update_sObjects[] = $sObject;
                }
            }
        }
        $updateResults = $fsc_db->update($update_sObjects);
    }
}

// Create a new record for Switzerland.
$sObject = new \SObject;
$sObject->type = 'Country_Data__c';
$sObject->fields->Name = 'Switzerland';
$sObject->fields->ISO_Code__c = 'CH';
$saveResults = $fsc_db->create(array($sObject));

$a = 1;     // for debugging
