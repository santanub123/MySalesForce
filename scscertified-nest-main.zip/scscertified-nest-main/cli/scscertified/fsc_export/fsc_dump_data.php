<?php

/**
 * @file
 * FSC data dump script.
 *
 * Designed to run from the command line. Queries the Account, Certificate,
 * Product_Classification__c, Product_Species__c, and Species__c tables and
 * saves all the data to CSV files.
 *
 * @author T. Treadwell
 * @date 2020-02-26
 *
 * Options
 * -s <table name>       Single table export of <table name> only
 *
 * Example:
 *    php fsc_dump_data.php -s Species__c
 */

/* Configure PHP                        */

// This script takes a long time.
ini_set('max_execution_time', 7200);

// Report significant errors.
ini_set('error_reporting', E_ALL);

// Log errors to custom error log.
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/log/php_errors.log');

/* Set command line options             */
$single_table = '';
$options = getopt('s:');

// Check for single table option.
if (array_key_exists('s', $options)) {
    if (!empty($options['s'])) {
        $single_table = $options['s'];
    }
}

// Load and initialize the autoloader.
$path = __DIR__ . '/../../../sites/nest';
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');

// Load the FSC database configuration.
require_once $path . '/includes/fsc/fsc_db_config.php';

// Create objects for the databases and data dump process.
$fsc_db = Scs\Integration\FscDatabase::get_instance($fsc_db_config['prod']);
$output_dir = __DIR__ . '/output';
$fsc_migrate = new Scs\Integration\FscMigrate($fsc_db, $output_dir);

if (!empty($single_table)) {
    // Output one table to CSV file.
    $fsc_migrate->dumpFscTable($single_table);
} else {
    // Output all tables to CSV files.
    $fsc_migrate->dumpAllTables();
}
