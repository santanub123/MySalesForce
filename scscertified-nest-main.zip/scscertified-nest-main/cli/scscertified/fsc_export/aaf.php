<?php

/**
 * @file
 * 501 and 502 DMS -> FSC batch AAF update script.
 *
 * Designed to run from the command line. Searches the DMS for all 501 and 502
 * certified and suspended certificates, and updates the relevant AAF fields in
 * the FSC Salesforce database. Creates a detailed CSV log file.
 *
 * @author T. Treadwell
 * @date 2014-12-17
 *
 * Options
 *   -c <certificate class>
 *      Limit to one certificate class: 501 | 502
 *      If set, only that type of cert is processed.
 *      If not set, all cert types in export sequence are processed.
 *
 *   -f <FSC database mode>
 *      Change the destination FSC database mode: none | mock | sandbox | prod
 *        none    = Don't compare any data (default)
 *        mock    = MySQL mock of FSC db
 *        sandbox = FSC sandbox database
 *        prod    = FSC production database
 *
 *   -y
 *      FSC write enable: if set, allow writing of updates to FSC
 *      If not set, nothing is written to FSC
 *
 * Examples:
 *   Report 502 DMS/FSC differences only
 *     php aaf.php -c 502 -f prod
 *
 *   Update 502 certs in FSC db to match DMS
 *     php aaf.php -c 502 -f prod -y
 */

/* Configure PHP                        */

// This script takes a long time.
ini_set('max_execution_time', 7200);

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Log errors to custom error log.
require_once __DIR__ . '/../../../sites/nest/nest_config.php';
ini_set('log_errors', 1);
$log_dir = '/scscertified/fsc_export';
ini_set('error_log', NEST_PATH_LOG . $log_dir . '/aaf_errors.log');

// Load and initialize the autoloader.
require_once __DIR__ . '/../../../sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', __DIR__ . '/../../../sites/nest/includes/src');
$loader->addNamespace('Nest', __DIR__ . '/../../../sites/nest/src');

// Load the database configurations.
require_once __DIR__ . '/../../../sites/nest/includes/db_config.php';

// Load the DMS connection configuration.
require_once __DIR__ . '/../../../sites/nest/includes/dms/dms_config.php';

// Load the FSC database configuration.
require_once __DIR__ . '/../../../sites/nest/includes/fsc/fsc_db_config.php';

// Load the Nest API config settings.
require_once __DIR__ . '/../../../sites/nest/nest_config.php';

// Initialize the NestApi object and log in.
$nest_api = \Nest\Api::getInstance();
$nest_token_info = $nest_api->login(NEST_API_USER, NEST_API_PASS);
$nest_token = $nest_token_info->token;

// Retrieve command-line options.
$options = getopt('c:f:y');

// Check for certificate class option. Default to ''.
$certificate_class = '';
if (array_key_exists('c', $options)) {
    if (!empty($options['c'])) {
        $certificate_class = $options['c'];
    } else {
        $msg = 'Missing -c option certificate_class value';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for FSC database mode option. Default to 'none'.
$fsc_db_mode = 'none';
if (array_key_exists('f', $options)) {
    if (!empty($options['f'])) {
        $fsc_db_mode = $options['f'];
    } else {
        $msg = 'Missing -f option fsc_db_mode value';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for FSC write option - if set, update FSC data.
$fsc_write_enable = false;
if (array_key_exists('y', $options)) {
    $fsc_write_enable = true;
    echo 'Writing data to FSC.' . PHP_EOL;
}

// Open FSC database connection based on $fsc_db_mode setting.
try {
    switch ($fsc_db_mode) {
        case 'none':
            echo 'No FSC database connection.' . PHP_EOL;
            break;

        case 'mock':
            echo 'Connecting to MySQL mock FSC database.' . PHP_EOL;
            $fsc_db = Scs\Integration\Test\FscDatabaseMock::getInstance(
                $fsc_db_config['mock']
            );
            break;

        case 'sandbox':
            echo 'Connecting to FSC test sandbox.' . PHP_EOL;
            $fsc_db = Scs\Integration\FscDatabase::get_instance($fsc_db_config['sandbox']);
            break;

        case 'prod':
            echo 'Connecting to FSC live production database.' . PHP_EOL;
            $fsc_db = Scs\Integration\FscDatabase::get_instance($fsc_db_config['prod']);
            break;

        default:
            $msg = 'Invalid destination value: "' . $destination . '"';
            error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
            echo $msg . PHP_EOL;
            exit;
    }

    // Create the DmsDatabase and DmsFscExport objects.
    $fm_db = new Scs\DmsDatabase();
    $dms_fsc_export = new Scs\Integration\DMS_FSC\DmsFscExport(
        $fm_db,
        $fsc_db,
        false,
        $fsc_write_enable,
        $fsc_db_mode,
        true,
        $log_dir
    );

} catch (\Exception $e) {
    // Fatal error. Log to error log.
    error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $e->getMessage());
}

// Update AAF for 501 (certified or suspended).
if (($certificate_class === '') || ($certificate_class == '501')) {
  $dms_fsc_export->batchUpdate(
                                '501',
                                array(
                                  // 'forest_type',
                                  'forest_zone',
                                  'slimf_type',
                                  // 'tenure_ownership',
                                  'tenure_management',
                                  'nf_boreal',
                                  'nf_community_forestry',
                                  'nf_conservation_purposes',
                                  'nf_temperate',
                                  'nf_tropical',
                                  'nf_plantation',
                                  'slimf_boreal',
                                  'slimf_conservation_purposes',
                                  'slimf_temperate',
                                  'slimf_tropical',
                                  'slimf_plantation',
                                ),
                                array('status' => 'Certified')
                              );
  $dms_fsc_export->batchUpdate(
                                '501',
                                array(
                                  // 'forest_type',
                                  'forest_zone',
                                  'slimf_type',
                                  'tenure_ownership',
                                  // 'tenure_management',
                                  'nf_boreal',
                                  'nf_community_forestry',
                                  'nf_conservation_purposes',
                                  'nf_temperate',
                                  'nf_tropical',
                                  'nf_plantation',
                                  'slimf_boreal',
                                  'slimf_conservation_purposes',
                                  'slimf_temperate',
                                  'slimf_tropical',
                                  'slimf_plantation',
                                ),
                                array('status' => 'Suspended')
                              );
}

// Update AAF for 502 (certified or suspended).
if (($certificate_class === '') || ($certificate_class == '502')) {
  $dms_fsc_export->batchUpdate(
                                '502',
                                [
                                  'fsc_processor_turnover',
                                  'fsc_trader_turnover',
                                  'revenue',
                                ],
                                ['status' => 'Certified']
                              );
  $dms_fsc_export->batchUpdate(
                                '502',
                                [
                                  'fsc_processor_turnover',
                                  'fsc_trader_turnover',
                                  'revenue',
                                ],
                                ['status' => 'Suspended']
                              );
}
