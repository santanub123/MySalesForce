<?php

/**
 * @file
 * Create list of Nest units with their mapped QB class refs
 *
 * Run from command line
 *
 * @author T. Treadwell
 * @date 2023-04-18
 */

use \Nest\Api;
use \Scs\ApplicationLog;
use \Scs\ScsSecurity;

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Set custom error log.
$log_dir = __DIR__ . '/../../log/nest';
ini_set('error_log', $log_dir . '/nest_unit_list_error.log');

// Load and initialize the autoloader.
require_once __DIR__ . '/../../sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', __DIR__ . '/../../sites/nest/includes/src');
$loader->addNamespace('Nest', __DIR__ . '/../../sites/nest/src');

// Verify that the request is from the command line.
$ssec = new ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

// Log in to Nest.
$nest_api = Api::getInstance();
$login_response = $nest_api->login(NEST_API_USER, NEST_API_PASS);
if (empty($login_response->token)) {
    $msg = ': Nest login failed: ' . $login_response->code . ': ' .
        $login_response->message;
    error_log(__FILE__ . ': ' . __LINE__ . $msg);
    echo $msg . PHP_EOL;
    exit();
}

// Retrieve list of Nest units.
$api_path = '/units/';
$response = $nest_api->call(
    $login_response->token,
    $api_path
);
if ($response->code !== 200) {
    $msg = ': Nest API response: ' . $response->code . ': ' .
        $response->message;
    error_log(__FILE__ . ': ' . __LINE__ . $msg);
    echo $msg . PHP_EOL;
    exit();
}

// Create output CSV file.
$filename_root = 'nest_unit_list';
$app_log = new ApplicationLog(
    'nest',
    $filename_root
);
$arr_log_headings = [
    'Unit Id',
    'Dept Code',
    'Name',
    'Short Name',
    'QB Class ListID',
    'Parent Unit Id',
    'Use Parent Dept',
    'Effective QB Class ListID',
    'Effective QB Class Name',
];
$app_log->write($arr_log_headings);

foreach ($response->data as $unit) {
    // Retrieve QB class ref from Nest Unit table.
    $api_path2 = '/unit/' . $unit->id . '/qb_class';
    $response2 = $nest_api->call(
        $login_response->token,
        $api_path2
    );

    $parent_id = '';
    if (!empty($unit->parent)) {
        $parent_id = $unit->parent->id;
    }
    $qb_class_name = '';
    $qb_class_listid = '';
    if (!empty($response2->data)) {
        $qb_class_listid = $response2->data[0]->listid;
        $qb_class_name = $response2->data[0]->fullname;
    }

    // Write data to output CSV file.
    $arr_log_data = [
        $unit->id,
        $unit->deptCode ?? '',
        $unit->name ?? '',
        $unit->shortname ?? '',
        $unit->qbClassListid ?? '',
        $parent_id,
        $unit->useParentDept ? '1' : '0',
        $qb_class_listid,
        $qb_class_name,
    ];
    $app_log->write($arr_log_data);
}
