<?php

/**
 * @file check_unittree.php
 * @author T. Treadwell
 * @date 2019-08-12
 *
 * Unittree table maintenance script.
 * Designed to run from the command line via a cron job.
 */

// base values
$path = __DIR__ . '/../../../sites/nest';
require_once "$path/nest_config.php";

// Configure PHP.
ini_set('error_reporting', E_ALL);
ini_set('max_execution_time', 600);

// Initialize autoloader.
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();

// Add namespace for SCS general classes.
$loader->addNamespace('Scs', $path . '/includes/src');

// Add namespace for Nest classes.
$loader->addNamespace('Nest', $path . '/src');

// Set logging
$relative_error_log_dir = 'nest/check_unittree';
$error_log_dir = $path . '/../../log/' . $relative_error_log_dir;
$nestTop = new Scs\NestTop;
$nestTop->set_error_log($error_log_dir);

// Verify that the request is from the command line.
$ssec = new Scs\ScsSecurity;
$valid_sapi = $ssec->verifyLocalRequest();
if (!$valid_sapi) {
    error_log(__FILE__ . ' line ' . __LINE__ . ': Invalid request');
    exit;
}

// Load the database configurations.
require_once $path . '/includes/db_config.php';

// Set up the application log.
$app_log_db = Scs\ApplicationlogsDatabase::get_instance(false);
$app_log = new Scs\ApplicationDbLog($app_log_db, 'check_unittree');

try {
    // Log in to Nest API.
    $nest_api = Nest\Api::getInstance();
    $result = $nest_api->login(\NEST_API_USER, \NEST_API_PASS);
    if ($result) {
        if (is_object($result) && isset($result->token)) {
            $nest_token = $result->token;
            if (empty($nest_token)) {
                throw new Exception(
                    'Login to Nest API failed: empty token'
                );
            }
        }
        else {
            throw new Exception(
                'Login to Nest API failed: invalid return value'
            );
        }
    }
    else {
        throw new Exception('Error querying Nest API');
    }

    // API call to check Unittree.
    $result = $nest_api->call(
        $nest_token,
        '/unit/0/checktree',
        ['id' => 0],
        'PATCH'
    );

    // Validate and log result.
    if (!empty($result) && isset($result->code)) {
        // Valid response, log to application log.
        $app_log->log(['code' => $result->code, 'message' => $result->message]);
        //error_log(__FILE__ . ' line ' . __LINE__ . ': Execution completed. (code: ' . $result->code . ', message: ' . $result->message . ')');
        
        if (($result->code !== 200) && ($result->code !== 201)) {
            error_log(__FILE__ . ' line ' . __LINE__ . ': Execution completed with error. (code: ' . $result->code . ', message: ' . $result->message . ')');
            
            // TODO: notify on dashboard.
        }
    }
    else {
        // Invalid response, log error.
        error_log(
            __FILE__ . ' line ' . __LINE__ .
            ': Invalid response from Unit::checktreeUnitAction API call: ' .
            var_export($result, true)
        );

        // TODO: Notify on dashboard.
    }
}
catch (Exception $e) {
    error_log(
        __FILE__ . ' line ' . __LINE__ . ': Exception: ' .
        $e->getMessage()
    );
}
