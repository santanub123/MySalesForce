<?php
/**
 * @file gpg_update_summary.php
 * @author T. Treadwell
 * @date 2019-10-18
 *
 * Collects document update total from MysqlGpgUpdate log files.
 */

$path = __DIR__ . '/../../../sites/nest';

// Run security checks, connect to Nest, and initialize database objects.
// require_once "$path/dev/_includes/nest_key_dev_tools.php";
require_once "$path/includes/nest_top.php";

// Configure PHP.
ini_set('error_reporting', E_ALL);

// Set a custom error log.
ini_set(
    'error_log',
    NEST_PATH_LOG . '/nest/dev/monitor_errors.log'
);

// Verify that the request is from CLI.
$ssec = new Scs\ScsSecurity;
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(__FILE__ . ' line ' . __LINE__ . ': Invalid request');
    exit;
}

// Verify that user is logged into Nest.
$nest_authorize = new Nest\Authorize;
if (!$nest_authorize->isLoggedIn()) {
    error_log(__FILE__ . ' line ' . __LINE__ . ': Not logged in to Nest');
    exit;
}

// Check if current user is UMS Super Admin.
/* $is_superadmin = $nest_authorize->hasPrivilegerole('JaY8EwSv', 1);
if (!$is_superadmin) {
    error_log(
        __FILE__ . ' line ' . __LINE__ .
        ': User does not have UMS Super Admin privilege'
    );
    exit;
} */

// Load dev tools config file.
require_once $path . '/dev/_includes/config.php';

$now = new \DateTime(
    'now',
    new \DateTimeZone('America/Los_Angeles')
);
$year = $now->format('Y');

$monitor = new Scs\Monitor\NestMonitorGPGSync;
$monitor->setConfig($monitor_config);

$mysql_log_folder = $monitor_config['gpg_update_mysql_log_folder'];
$mysql_files = glob($mysql_log_folder . '/' . $year . '*');

$total_updates = 0;
$runs = 0;
foreach ($mysql_files as $mysql_file) {
    $mysql_update_result = $monitor->checkMysqlUpdateFile(
        $mysql_file
    );
    $total_updates += $mysql_update_result['total_updates'];
    $runs +=1;
}

echo $year . ' YTD num runs = ' . $runs . ', total updates = ' . $total_updates .
    ' avg updates/run = ' . $total_updates/$runs . "\n";
