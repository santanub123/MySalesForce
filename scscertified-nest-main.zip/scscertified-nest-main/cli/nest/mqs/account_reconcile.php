<?php

/**
 * @file
 * Minnow -> Quickbooks Account reconciliation script
 *
 * Designed to run from the command line. Reads MAQ for account requests that
 * have QB error for name already in use, checks the QB mirror qb_customer table
 * for a match on QB name of account, and if addresses don't conflict, sets the
 * QB ID in Minnow.
 *
 * @author T. Treadwell
 * @date 2023-02-13
 *
 * Options
 *   -t <start datetime> (required)
 *     Datetime in format YYYY-MM-DDTHH:MM, items in queue created before this
 *     time will not be processed.
 *
 * Example:
 *    php account_reconcile.php -t 2023-02-13T17:00
 */

use \Monolog\Handler\NativeMailerHandler;
use \Monolog\Handler\RotatingFileHandler;
use \Monolog\Handler\StreamHandler;
use \Monolog\Logger;
use \Scs\Integration\Minnow\MinnowAccount;
use \Scs\Integration\Minnow\MinnowAccountingQueue;
use \Scs\Integration\Minnow\MinnowDatabase2;
use \Scs\Integration\Nest\NestObject;
use \Scs\Integration\Quickbooks\QbMirrorDb;
use \Scs\ScsDataIntegrationDb;
use \Scs\ScsLogger;
use \Scs\ScsSecurity;

// Configure PHP.

// Allow up to 30 min for script execution.
ini_set('max_execution_time', 1800);

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Set custom error log.
$log_dir = __DIR__ . '/../../../log/nest/mqs';
ini_set('error_log', $log_dir . '/error.log');

// Load and initialize the autoloader.
require_once __DIR__ . '/../../../sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', __DIR__ . '/../../../sites/nest/includes/src');
$loader->addNamespace('Nest', __DIR__ . '/../../../sites/nest/src');
$loader->addNamespace(
    'Monolog',
    __DIR__ . '/../../../core/vendor/monolog/monolog/src/Monolog'
);
$loader->addNamespace('Psr', __DIR__ . '/../../../core/vendor/psr/log/Psr');

// Get an instance of the Monolog logger.
$logger = ScsLogger::getLogger(
    $log_dir,
    'Minnow Account Reconcile',
    'ttreadwell@scsglobalservices.com'
);

// Verify that the request is from the command line.
$ssec = new ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

// Require the database configuration settings.
require_once __DIR__ . '/../../../sites/nest/includes/db_config_2.php';

// Initialize the scs_data_integration MySQL database connection.
$sdi_db = ScsDataIntegrationDb::getInstance();

if (!$sdi_db->connection) {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Cannot run : MySQL connection failed.'
    );
    exit;
}

// Include Minnow configuration file.
require_once __DIR__ . '/../../../sites/nest/includes/minnow/minnow_db_config.php';

// Open Minnow connections.
$minnow_dbs = [];
foreach ($minnow_db_config as $key => $config) {
    if ($key === 'mode') {
        continue;
    }
    $minnow_dbs[$key] = new MinnowDatabase2($config);
}

// Retrieve command-line options.
$options = getopt('t:');

// Check for start time option.
$start_time_str  = '';
if (array_key_exists('t', $options)) {
    if (!empty($options['t'])) {
        $start_time_str = $options['t'];
        echo 'Reconciling accounts starting ' . $start_time_str . PHP_EOL;
    } else {
        $msg = 'Cannot run : missing -t option value.';
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        echo $msg . PHP_EOL;
        exit;
    }
} else {
    $msg = 'Cannot run : missing -t option.';
    $logger->addError(basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg);
    echo $msg . PHP_EOL;
    exit;
}

try {
    $start_time = new \DateTimeImmutable(
        $start_time_str,
        new \DateTimeZone('America/Los_Angeles')
    );
} catch (Exception $e) {
    $msg = $e->getMessage();
    $logger->addError(basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg);
    echo $msg . PHP_EOL;
    exit;
}

/* Array of SF objects that have been processed. This is used to prevent
 * duplicating work that has already been done. In form:
 * [
 *     <minnow_id> => <maq_status>,
 *     <minnow_id> => <maq_status>,
 *     ...
 * ]
 */
$processed = [];

$maq = new MinnowAccountingQueue($logger, 'scs');
$maq_rows = $maq->retrieveItems([
    'start_time' => $start_time->format('Y-m-d H:i:s'),
    'object_type' => 'MinnowAccount',
    'status' => MinnowAccountingQueue::MAQ_STATUS_ERROR_QB,
]);

$total_matched = 0;

foreach ($maq_rows as $maq_row) {
    // Check QB PDK queue, only process customer name duplicate errors.
    $qb_sync_info = $maq->getQbSyncInfo($maq_row);
    $msg = $qb_sync_info['pdk']['msg'];
    $pattern = '#^3100: The name \"(.+)\" of the list element is already in use\.$#';
    $matches = [];
    $match_result = preg_match($pattern, $msg, $matches);
    if ($match_result !== 1) {
        continue;
    }

    $organization_id = $maq_row['organization_id'];
    $minnow_mode = $maq->getMinnowModeFromOrgid($organization_id);
    if (empty($minnow_mode)) {
        $msg = 'Could not determine minnow mode for org id ' . $organization_id;
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        continue;
    }

    // Check to see if this object has already been processed, if so then update
    // its MAQ status.
    $minnow_id = $maq_row['object_id'];
    if (array_key_exists($minnow_id, $processed)) {
        $processed_status = $processed[$minnow_id];
        $maq->updateStatus($maq_row['id'], $processed_status);
        continue;
    }

    // Determine legal entity.
    $legal_entity_int = $maq_row['qb_legal_entity'];
    if ($legal_entity_int === null) {
        $legal_entity_int = 0;
    }
    $legal_entity = NestObject::legalEntityInfoFromStr(
        NestObject::legalEntityIntToStr($legal_entity_int)
    );

    // Retrieve account from Salesforce.
    $qb_id_field_name = $legal_entity['minnow_account_qb_id_field'];
    $fields = [
        'BillingCity',
        'BillingCountry',
        'BillingState',
        'BillingStreet',
        'Legal_Entity_Name__c',
        'Name',
        'Quickbooks_Account_Name__c',
        $qb_id_field_name
    ];
    $field_list = implode(',', $fields);
    $qr = $minnow_dbs[$minnow_mode]->retrieve(
        $field_list,
        'Account',
        [$minnow_id]
    );
    if (count($qr) === 0) {
        // Not found in Minnow, update status.
        $status = MinnowAccountingQueue::MAQ_STATUS_SF_OBJECT_DELETED;
        $maq->updateStatus($maq_row['id'], $status);
        $processed[$minnow_id] = $status;
        continue;
    }

    // Retrieve the record data.
    $sObject = new \SObject($qr[0]);
    if (is_null($sObject)) {
        $msg = 'Bad response on retrieval of ' . $minnow_id;
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        continue;
    }

    if (is_array($sObject)) {
        $obj = $sObject[0];
    } else {
        $obj = $sObject;
    }
    $properties = get_object_vars($obj->fields);

    // Load Minnow object from record.
    $minnow_account = new MinnowAccount($logger);
    $minnow_account->notification_id = $maq_row['notification_id'];
    $minnow_account->loadFromArray($properties);

    // Check to make sure QB ID is blank.
    if (!empty($minnow_account->data[$qb_id_field_name])) {
        // Account has a QB id.
        $status = MinnowAccountingQueue::MAQ_STATUS_HAS_QB_ID;
        $maq->updateStatus($maq_row['id'], $status);
        $processed[$minnow_id] = $status;
        continue;
    }

    // Search for account name in QB qb_customer table, and attempt to find
    // a single match.
    $qb_row = findQbCustomerMatch(
        $legal_entity['qb_config_file'],
        $minnow_account->data['Quickbooks_Account_Name__c']
    );
    if ($qb_row === false) {
        $msg = 'No match for "' .
            $minnow_account->data['Quickbooks_Account_Name__c'] . '" in ' .
            $legal_entity['minnow_option'] . ' QB mirror qb_customer table.';
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        continue;
    }

    // Map of fields to compare addresses.
    // compare_len is the minimum of the lengths of the minnow and QB fields.
    $address_compare_field_map = [
        [
            'minnow' => 'BillingStreet',
            'qb' => 'BillAddress_Addr1',
            'compare_len' => 10,    // set small because in SF it's a textarea.
        ],
        [
            'minnow' => 'BillingCity',
            'qb' => 'BillAddress_City',
            'compare_len' => 31,
        ],
        [
            'minnow' => 'BillingState',
            'qb' => 'BillAddress_State',
            'compare_len' => 21,
        ],
        [
            'minnow' => 'BillingCountry',
            'qb' => 'BillAddress_Country',
            'compare_len' => 31,
        ],
    ];

    // Summary array of address field comparison results.
    $address_field_match_totals = [
        'blank_no_conflict' => 0,
        'exact_matches' => 0,
        'mismatches' => 0,
    ];

    foreach ($address_compare_field_map as $af) {
        $minnow_value = $minnow_account->data[$af['minnow']];
        $qb_value = $qb_row[$af['qb']];
        if (empty($minnow_value) || empty($qb_value)) {
            $address_field_match_totals['blank_no_conflict'] += 1;
            continue;
        }
        $compare_result = strncasecmp(
            $minnow_value,
            $qb_value,
            $af['compare_len']
        );
        if ($compare_result === 0) {
            $address_field_match_totals['exact_matches'] += 1;
        } else {
            $address_field_match_totals['mismatches'] += 1;
        }
    }

    // If there is at least one mismatch, and no exact matches, then consider it
    // an address mismatch.
    if (
        ($address_field_match_totals['mismatches'] > 0) &&
        ($address_field_match_totals['exact_matches'] === 0)
    ) {
        $msg = 'Account ' . $minnow_id .
            ' matches QB customer name, but address does not match, skipping.';
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        continue;
    }

    // Check entity in Salesforce to make sure it's still the same as in MAQ.
    $maq_legal_entity = $legal_entity['nest_id'];
    $minnow_legal_entity = $minnow_account->retrieveLegalEntity();
    if ($minnow_legal_entity !== $maq_legal_entity) {
        $msg = 'Account ' . $minnow_id . ' legal entity ' . $minnow_legal_entity
            . ' does not match MAQ legal entity ' . $maq_legal_entity .
            ', skipping.';
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        continue;
    }

    // Update the Salesforce record with QB ID and QB result.
    $time_now = new \DateTimeImmutable(
        'now',
        new \DateTimeZone('America/Los_Angeles')
    );
    $minnow_account->data[$qb_id_field_name] = $qb_row['ListID'];
    $minnow_account->data['Quickbooks_Result__c'] =
        $time_now->format('Y-m-d H:i') . ' Matched QB customer.';
    $update_result = $minnow_account->updateSfRecord(
        [$qb_id_field_name, 'Quickbooks_Result__c']
    );
    if (!$update_result['success']) {
        $msg = 'Error updating account ' . $minnow_id;
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        continue;
    }

    $msg = 'Set QB ID on account ' . $minnow_id . ', ' .
        $minnow_account->data['Name'];
    $logger->addDebug(
        basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
    );
    $total_matched += 1;

    // Update MAQ status.
    $status = MinnowAccountingQueue::MAQ_STATUS_MATCHED_QB_RECORD;
    $maq->updateStatus($maq_row['id'], $status);

    // Add to processed array.
    $processed[$minnow_id] = $status;
}

$msg = 'Done, matched ' . $total_matched . ' accounts.';
$logger->addDebug(
    basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
);

echo $msg . PHP_EOL;

/**
 * Look up customer in QB mirror
 *
 * $param string $qb_config_file_name
 *     name of QB config file
 * @param string $customer_name
 *     account name from SF
 *
 * @return mixed
 *     row from QB mirror customer table, or false if not found
 */
function findQbCustomerMatch($qb_config_file_name, $customer_name)
{
    global $logger;

    // Require QuickBooks configuration settings.
    // TODO: find a more efficient way to do this.
    require __DIR__ . '/../../../sites/nest/quickbooks/' . $qb_config_file_name;
    $qb_mirror_db = new QbMirrorDb($scs_qb_mirror_db);

    // Minimum length of QB name to qualify for automatic match.
    $min_len = 10;

    // Maximum length of QB name.
    $max_len = 41;

    // Look up customers in QB mirror qb_customer table that match minimum
    // name match length.
    $name_root = substr($customer_name, 0, $min_len);
    $sql = 'SELECT
            ListID,
            Name,
            BillAddress_Addr1,
            BillAddress_City,
            BillAddress_State,
            BillAddress_Country
        FROM qb_customer
        WHERE Name LIKE \'' . $qb_mirror_db::sqlEscapeString($name_root)
            . '%\'';
    try {
        $stmt = $qb_mirror_db->connection->prepare($sql);
        $exec_result = $stmt->execute();
    } catch (Exception $e) {
        if (!$stmt) {
            $error_info = $qb_mirror_db->connection->errorInfo();
        } else {
            $error_info = $stmt->errorInfo();
        }
        $msg = $error_info[2];
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        return false;
    }
    if (!$exec_result) {
        $error_info = $stmt->errorInfo();
        $pdo_msg = $error_info[2];
        $msg = 'MySQL query failed on qb_customer: ' . $sql . '| ' . $pdo_msg;
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        return false;
    }
    $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);

    if (count($rows) === 0) {
        // No matches.
        return false;
    }

    if (count($rows) === 1) {
        // Exactly 1 match.
        return $rows[0];
    }

    if (count($rows) > 1) {
        // Multiple matches. Increase match length to find single match.
        for ($len = $min_len + 1; $len <= $max_len; $len += 1) {
            $match_count = 0;
            $match_index = null;
            foreach ($rows as $index => $row) {
                $result = strncasecmp($row['Name'], $customer_name, $len);
                if ($result === 0) {
                    $match_count += 1;
                    $match_index = $index;
                }
            }
            if ($match_count === 1) {
                break;
            }
        }
        if (!is_null($match_index)) {
            // Exactly 1 match.
            return $rows[$match_index];
        }
    }

    // Shouldn't usually get here.
    $msg = 'Could not find single name match for "' . $customer_name . '" in ' .
        $scs_qb_mirror_db['database'] . '.qb_customer';
    $logger->addError(
        basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
    );
    return false;
}
