<?php

/**
 * @file
 * Minnow -> Quickbooks Sync script
 *
 * Designed to run from the command line via a cron job. Finds objects in Minnow
 * eligible for export and adds them to database queues for addition to QB.
 *
 * @author T. Treadwell
 * @date 2021-06-04
 *
 * Options
 *   -m <minnow mode>
 *     (required)
 *     Set Salesforce host API config, index in minnow_db_config.php
 *     (currently sandbox | production | 2ndorgscsglobal | 2ndorgscsglobal--uat)
 *
 *   -w
 *      Set write mode - Write transactions to QB queue and send status and ids
 *      to Salesforce. Necessary for production operation.
 *
 *   -c <object class> (Account | Invoice | CreditMemo | Payment)
 *      Limit to one object class. If set, only that class of object is synced.
 *      If not set, all object classes in sequence are exported.
 *
 *   -e <legal entity> (scs | scs_consulting | scs_ivory)
 *      Limit to one legal entity
 *
 *   -s <id>
 *      Limit to single object with Salesforce id <id>
 *
 *   -a
 *      Add to QB even if entity has been processed before (useful if record has
 *      been deleted from QB).
 *
 * Examples:
 *    Test setting:
 *      php mqs.php -m sandbox
 *
 *    Production setting:
 *      php mqs.php -m production -w
 *
 *    Process account a1234bcde only
 *      php mqs.php -m production -w -c Account -s a1234bcde
 */

use \Scs\Integration\Minnow\MinnowAccountingQueue;
use \Scs\Integration\Minnow\MinnowDatabase2;
use \Scs\Integration\Minnow\MinnowInvoice;
use \Scs\Integration\Quickbooks\QbIntegration;
use \Scs\Integration\Nest\NestObject;
use \Monolog\Logger;
use \Monolog\Handler\RotatingFileHandler;
use \Monolog\Handler\StreamHandler;
use \Monolog\Handler\NativeMailerHandler;

// Configure PHP.

// Allow up to 30 min for script execution.
ini_set('max_execution_time', 1800);

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Set custom error log.
$log_dir = __DIR__ . '/../../../log/nest/mqs';
ini_set('error_log', $log_dir . '/error.log');

// Load and initialize the autoloader.
require_once __DIR__ . '/../../../sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', __DIR__ . '/../../../sites/nest/includes/src');
$loader->addNamespace('Nest', __DIR__ . '/../../../sites/nest/src');
$loader->addNamespace('Monolog', __DIR__ . '/../../../core/vendor/monolog/monolog/src/Monolog');
$loader->addNamespace('Psr', __DIR__ . '/../../../core/vendor/psr/log/Psr');

// Load local config file.
require_once __DIR__ . '/mqs_config.php';

// Get an instance of the Monolog logger.
$logger = getLogger($log_dir, 'MinnowQbSync', $alert_email_address);

// Verify that the request is from the command line.
$ssec = new Scs\ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

// Require the database configuration settings.
require_once __DIR__ . '/../../../sites/nest/includes/db_config_2.php';

// Initialize the scs_data_integration MySQL database connection.
$sdi_db = Scs\ScsDataIntegrationDb::getInstance();
// $qbqueue_db = new Scs\MysqlDatabase3($scs_qb_queue_db);
// $qbdevkit_db = new Scs\QbPhpdevkitDb($scs_qb_pdk_db);

if (!$sdi_db->connection) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Cannot run : MySQL connection failed.'
    );
    exit;
}

// Include Minnow configuration file.
require_once __DIR__ . '/../../../sites/nest/includes/minnow/minnow_db_config.php';

// Retrieve command-line options.
$options = getopt('m:wc:e:s:a');

// Check for minnow mode option.
$minnow_db_mode  = '';
if (array_key_exists('m', $options)) {
    if (!empty($options['m'])) {
        $minnow_db_mode = $options['m'];
        echo 'Retrieving records from ' . $minnow_db_mode . ' Minnow instance' . PHP_EOL;
    } else {
        $msg = 'Cannot run : missing -m option value.';
        $logger->addError(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
} else {
    $msg = 'Cannot run : missing -m option.';
    $logger->addError(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
    echo $msg . PHP_EOL;
    exit;
}

if (!array_key_exists($minnow_db_mode, $minnow_db_config)) {
    $msg = 'Cannot run : -m option \'' . $minnow_db_mode . '\' is not a key' .
        ' in $minnow_db_config.';
    $logger->addError(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
    echo $msg . PHP_EOL;
    exit;
}

// Check for write mode option.
$write_mode = false;
if (array_key_exists('w', $options)) {
    $write_mode = true;
    echo 'Running in write mode.' . PHP_EOL;
} else {
    echo 'Running in test mode - nothing will be written to QB or Salesforce.' . PHP_EOL;
}

// Check for object class filter option.
$object_class_filter  = '';
if (array_key_exists('c', $options)) {
    if (!empty($options['c'])) {
        $object_class_filter = $options['c'];
        echo 'Processing ' . $options['c'] . ' records only.' . PHP_EOL;
    } else {
        $msg = 'Missing -c option value (Account | Invoice | CreditMemo | Payment)';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for legal entity filter option.
$legal_entity_filter  = '';
if (array_key_exists('e', $options)) {
    if (!empty($options['e'])) {
        $legal_entity_filter = $options['e'];
        echo 'Processing ' . $options['e'] . ' records only.' . PHP_EOL;
    } else {
        $msg = 'Missing -e option value (scs | scs_consulting | scs_ivory)';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for single object filter option.
$object_id_filter  = '';
if (array_key_exists('s', $options)) {
    if (!empty($options['s'])) {
        $object_id_filter = $options['s'];
        echo 'Processing id ' . $options['s'] . ' only.' . PHP_EOL;
    } else {
        $msg = 'Missing -s option value (Salesforce id)';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for Always Add option - if set, ignore previous processing records.
$always_add = false;
if (array_key_exists('a', $options)) {
    $always_add = true;
    echo 'Adding to QB even if entity has previously been processed.' . PHP_EOL;
}

$output_csv = false;
$fp_output = null;

// If not writing to QB, output CSV for diagnostic purposes.
if (!$write_mode) {
    $output_csv = true;
}

if ($output_csv) {
    // Output CSV summary of objects synced to QB.

    // Construct the path to the output file.
    $time_now = new \DateTime(
        'now',
        new \DateTimeZone('America/Los_Angeles')
    );
    $filename = 'mqs_' . $time_now->format('Y-m-d_His') . '.csv';
    $full_file_path = __DIR__ . '/test_output/' . $filename;

    // Open the output file.
    $fp_output = fopen($full_file_path, 'w');
    if ($fp_output === false) {
        echo 'Could not open output file ' . $full_file_path . PHP_EOL;
        exit;
    }

    echo 'Output is in ' . $full_file_path . PHP_EOL;
}

// Open Minnow connection.
$minnow_db = new MinnowDatabase2($minnow_db_config[$minnow_db_mode]);

// Create list of valid legal entity names.
$legal_entity_names = [];
foreach (NestObject::$legal_entities as $legal_entity) {
    $legal_entity_names[] = $legal_entity['minnow_option'];
}
$legal_entity_name_list = "'" . implode("','", $legal_entity_names) . "'";

/* Define object types to sync:
 * [
 *     'object_class' => <name of object>,
 *     'api_name' => <SF api name of object>,
 *     'fields' => [<names of fields to select from SF>],
 *     'queries' => [
 *         'scs' => <where condition for SCS records>,
 *         'scs_consulting' => <where condition for SCS Consulting records>,
 *     ],
 *     'info_headings' => [<column headings to use in report>]
 *     'info_fields' => [<names of fields to use in report>]
 *     'info_query' => [    // optional extra query to add fields from related object
 *          'headings' => [<extra column headings>],
 *          'fields' => [<names of fields from related object>],
 *          'object' => <api name of related object>,
 *          'where_condition' => '<field name in related object> = <parameter marker>',
 *          'params' => [
 *              <parameter marker> => <field name in current object>,
 *           ],
 *     ],
 * ]
 */
$sync_objects = [
    0 => [
        'object_class' => 'Account',
        'api_name' => 'Account',
        'fields' => [
            'BillingCity',
            'BillingCountry',
            'BillingCountryCode',
            'BillingPostalCode',
            'BillingState',
            'BillingStateCode',
            'BillingStreet',
            'Id',
            'Legal_Entity_Name__c',
            'Name',
            'Phone',
            'QBConsulting_ID__c',
            'QBIvory_ID__c',
            //'QBLegalEntity__c',
            'Quickbooks_Account_Name__c',
            'Quickbooks_ID__c',
        ],
        'queries' => [
            "Type = 'Customer' AND RTName__c = 'Customer'",
        ],
    ],
    1 => [
        'object_class' => 'Invoice',
        'api_name' => 'fw1__Invoice__c',
        'fields' => [
            'Account_Quickbooks_ID__c',
            'Id',
            'Legal_Entity_Name__c',
            'Master_Invoice_Number__c',
            'Name',
            'Program_ID__c',
            'Program_Nest_Unit_ID__c',
            'Program__c',
            //'QBLegalEntity__c',
            'Quickbooks_ID__c',
            'fw1__Account__c',
            'fw1__Credit_Card_Failure_Reason__c',
            'fw1__Description__c',
            'fw1__Entity__c',
            'fw1__Invoice_Date__c',
            'fw1__Terms__c',
            'fw1__Total_Invoice_Amount__c',
        ],
        'queries' => [
            "Quickbooks_ID__c = null AND fw1__Email_Sent__c = true AND " .
                "(fw1__Status__c = 'Sent' OR fw1__Status__c = 'Paid' OR fw1__Status__c = 'Overdue') AND " .
                "Legal_Entity_Name__c IN (" . $legal_entity_name_list . ")",
        ],
    ],
    2 => [
        // TODO: support modification
        // if status changed to 'Approved' OR expense amounts changed
        'object_class' => 'CreditMemo',
        'api_name' => 'fw1__Credit_Memo__c',
        'fields' => [
            'Account_Quickbooks_ID__c',
            'Bad_Debt__c',
            'Bank_Charges__c',
            'Foreign_Currency_Exchange_Loss__c',
            'Id',
            'Invoice_Number__c',
            'Invoice_Quickbooks_ID__c',
            'Legal_Entity_Name__c',
            'Name',
            'Program_Nest_Unit_ID__c',
            'Program__c',
            //'QBLegalEntity__c',
            'Quickbooks_ID__c',
            'REVENUE_Other_Revenue__c',
            'SCS_Total_Credit_Amount__c',
            'TAXES_Foreign_Taxes__c',
            'fw1__Account__c',
            'fw1__Date__c',
            'fw1__Description__c',
            'fw1__Entity__c',
            'fw1__Total_Credit_Amount__c',
            'fw1__Total_Lines_Amount__c',
        ],
        'queries' => [
            "Quickbooks_ID__c = null AND Approval_Status__c = 'Approved' AND " .
                "Legal_Entity_Name__c IN (" . $legal_entity_name_list . ")",
        ],
    ],
    3 => [
        // TODO: support modification
        // if new, amount changed, OR status changed -> 'Cancelled'
        'object_class' => 'Payment',
        'api_name' => 'fw1__Payment__c',
        'fields' => [
            'Account_Quickbooks_ID__c',
            'Credit_Memo_QB_ID__c',
            'Id',
            'Legal_Entity_Name__c',
            'Quickbooks_ID__c',
            'fw1__Account__c',
            'fw1__Amount__c',
            'fw1__Authorization_Code__c',
            'fw1__Check_Number__c',
            'fw1__Connected_Account_Id__c',
            'fw1__Credit_Card_Number__c',
            'fw1__Credit_Card_Type__c',
            'fw1__Customer_ID_Number2__c',
            'fw1__Customer_ID_Type__c',
            'fw1__Entity__c',
            'fw1__Error_Code__c',
            'fw1__Error_Type__c',
            'fw1__Expiry_Month__c',
            'fw1__Expiry_Year__c',
            'fw1__First_Name__c',
            'fw1__Invoice__c',
            'fw1__Last_Name__c',
            'fw1__Name_On_Account__c',
            'fw1__Payment_Date__c',
            'fw1__Payment_Method_ID__c',
            'fw1__Payment_Method__c',
            'fw1__Payment_Result__c',
            'fw1__Reference__c',
            'fw1__Status__c',
            'fw1__Total_Paid_Amount__c',
            'fw1__Transaction_ID__c',
        ],
        'queries' => [
            "Quickbooks_ID__c = null AND ((fw1__Payment_Method__c != 'Credit Memo') OR (Credit_Memo_QB_ID__c != null)) AND " .
                "Legal_Entity_Name__c IN (" . $legal_entity_name_list . ")",
        ],
        'info_headings' => ['Payment Date'],
        'info_fields' => ['fw1__Payment_Date__c'],
        'info_query' => [
            'headings' => [
                'RefNum',
                'Account',
                'Invoice Date',
                'Amount',
                'Status'
            ],
            'fields' => [
                'Name',
                'fw1__Account_Name__c',
                'fw1__Invoice_Date__c',
                'fw1__Total_Invoice_Amount__c',
                'fw1__Status__c'
            ],
            'object' => 'fw1__Invoice__c',
            'where_condition' => 'Id = :invoice_id',
            'params' => [
                ':invoice_id' => 'fw1__Invoice__c',
            ],
        ],
    ],
];

// Add Account QB id field conditions to its query.
$account_qb_field_conditions = [];
foreach (NestObject::$legal_entities as $legal_entity) {
    $minnow_legal_entity = $legal_entity['minnow_option'];
    $minnow_account_qb_id_field = $legal_entity['minnow_account_qb_id_field'];
    $condition = "(Legal_Entity_Name__c = '$minnow_legal_entity' AND $minnow_account_qb_id_field = null)";
    $account_qb_field_conditions[] = $condition;
}
$account_qb_field_conditions_str = '(' . implode(' OR ', $account_qb_field_conditions) . ')';
$sync_objects[0]['queries'][0] .= ' AND ' . $account_qb_field_conditions_str;

foreach ($sync_objects as $object_sync) {
    if (
        empty($object_class_filter) ||
        ($object_sync['object_class'] === $object_class_filter)
    ) {
        syncObject($object_sync);
    }
}

/**
 * Run QB sync for one object type
 *
 * param array $object_sync
 *     array of object type parameters from $sync_objects array
 */
function syncObject($object_sync)
{
    global $output_csv, $fp_output, $minnow_db, $logger, $object_id_filter, $legal_entity_filter, $minnow_db_config, $minnow_db_mode, $always_add;

    if ($output_csv) {
        // Write headings.
        $base_headings = ['object_type', 'object_id', 'account_id', 'tag', 'status'];
        $extra_headings = [];
        if (!empty($object_sync['info_headings'])) {
            $extra_headings = array_merge(
                $extra_headings,
                $object_sync['info_headings']
            );
        };
        if (!empty($object_sync['info_query'])) {
            $extra_headings = array_merge(
                $extra_headings,
                $object_sync['info_query']['headings']
            );
        };
        $headings = array_merge($base_headings, $extra_headings);
        fputcsv($fp_output, $headings);
    }

    $notification_id = randomSalesforceId();
    $field_list = implode(',', $object_sync['fields']);
    foreach ($object_sync['queries'] as $condition_expr) {
        // If legal entity filter set, restrict results to that entity.
        $legal_entity_condition = '';
        if (!empty($legal_entity_filter)) {
            $legal_entity = NestObject::legalEntityInfoFromStr(
                $legal_entity_filter
            );
            $minnow_legal_entity = $legal_entity['minnow_option'];
            $legal_entity_condition = " AND (Legal_Entity_Name__c = '$minnow_legal_entity'";
            if ($legal_entity['nest_id'] === 'scs') {
                $legal_entity_condition .= ' OR Legal_Entity_Name__c = null';   // special case if Legal_Entity_Name__c is null = scs
            }
            $legal_entity_condition .= ')';
        }

        // If object id filter set, select that id only.
        if (empty($object_id_filter)) {
            $where_expr = $condition_expr . $legal_entity_condition;
        } else {
            $where_expr = "Id = '$object_id_filter'" . $legal_entity_condition;
        }
        $soql = 'SELECT ' . $field_list .
            ' FROM ' . $object_sync['api_name'] .
            ' WHERE ' . $where_expr;
        $qr = $minnow_db->query($soql);
        if ($qr->size > 0) {
            foreach ($qr->records as $record) {
            // Retrieve the record data.
                $sObject = new \SObject($record);
                if (!is_null($sObject)) {
                    if (is_array($sObject)) {
                        $obj = $sObject[0];
                    } else {
                        $obj = $sObject;
                    }
                    $properties = get_object_vars($obj->fields);

                    // Load Minnow object from record.
                    $minnow_obj_class = '\\Scs\\Integration\\Minnow\\Minnow' .
                        $object_sync['object_class'];
                    $minnow_object = new $minnow_obj_class(
                        $logger,
                        $minnow_db_mode
                    );
                    $minnow_object->organization_id = $minnow_db_config[$minnow_db_mode]['organization_id'];
                    $minnow_object->notification_id = $notification_id;
                    $minnow_object->loadFromArray($properties);
                    $minnow_object->source_id = $notification_id . '_' .
                        $minnow_object->data['Id'];

                    if (!$minnow_object->hasValidData()) {
                        $logger->addError(
                            __FILE__ . ' line ' . __LINE__ .
                            ': Invalid object: ' .
                            print_r($minnow_object->data, true)
                        );
                        continue;
                    }

                    // Set the legal entity string from object data.
                    $legal_entity_str = $minnow_object->retrieveLegalEntity();

                    // Initialize MinnowAccountingQueue connector.
                    $maq = new MinnowAccountingQueue($logger, $legal_entity_str);

                    // Look up object in minnow accounting queue to see if it's
                    // currently being processed.
                    $maq_record = $maq->getLatestQueueEntryById($obj->Id);
                    $prior_status = $maq::MAQ_STATUS_UNKNOWN;
                    if (!empty($maq_record)) {
                        $prior_status = (int) $maq_record['status'];
                    }
                    $add_eligible = false;
                    if (
                        $always_add ||
                        ($prior_status === $maq::MAQ_STATUS_UNKNOWN) ||
                        ($prior_status === $maq::MAQ_STATUS_CANCELLED) ||
                        ($prior_status === $maq::MAQ_STATUS_ERROR) ||
                        ($prior_status === $maq::MAQ_STATUS_ERROR_SYNC) ||
                        ($prior_status === $maq::MAQ_STATUS_ERROR_QB)
                    ) {
                        $add_eligible = true;
                    } else {
                        $logger->addDebug(
                            __FILE__ . ': ' . __LINE__ .
                            ': Object is currently being processed, skipping.',
                            [
                                'Id' => $obj->Id,
                                'prior_status' => $prior_status,
                            ]
                        );
                        continue;
                    }

                    if ($add_eligible) {
                        addEntity(
                            $legal_entity_str,
                            $object_sync,
                            $minnow_object
                        );
                    }

                    // TODO: handle modify

                }
            }
        }
    }
}

/**
 * Convert an entity to Nest and send to the accounting system
 *
 * @param string $legal_entity
 *     identifier for SCS corporate entity which determines QB company file
 *     'scs' | 'scs_consulting' | 'scs_ivory_coast'
 * @param array $object_sync
 *     array of object type parameters from $sync_objects array
 * @param object $minnow_object
 *     MinnowObject-derived object instance
 */
function addEntity($legal_entity, $object_sync, $minnow_object)
{
    global $output_csv, $fp_output, $minnow_db, $logger, $write_mode, $object_id_filter;

    // Determine if object is ready to be added to QB now.
    $minnow_class = $minnow_object->object_type;
    if (($minnow_class !== 'MinnowAccount') && empty($minnow_object->data['Account_Quickbooks_ID__c'])) {
        $status = MinnowAccountingQueue::MAQ_STATUS_WAITING_FOR_ACCOUNT_QB_ID;
        $logger->addDebug(
            __FILE__ . ' line ' . __LINE__ . ': ' . __METHOD__ .
            ': No Account QB id: ' . print_r($minnow_object, true)
        );
    } else {
        $status = MinnowAccountingQueue::MAQ_STATUS_QB_READY;
    }

    if ($output_csv) {
        $account_id = '';
        if (!empty($minnow_object->data['fw1__Account__c'])) {
            $account_id = $minnow_object->data['fw1__Account__c'];
        }

        $extra_log_data = [];

        // Optional info fields - add extra fields from this object to report.
        if (!empty($object_sync['info_fields'])) {
            foreach ($object_sync['info_fields'] as $field_name) {
                $extra_log_data[] = $minnow_object->data[$field_name];
            }
        }
        // Optional info query - to add fields to test output from supplemental
        // SOQL query.
        if (!empty($object_sync['info_query'])) {
            $info_query = $object_sync['info_query'];
            $where_condition = $info_query['where_condition'];
            $params = $info_query['params'];
            foreach ($params as $param_marker => $field_name) {
                $where_condition = str_replace(
                    $param_marker,
                    '\'' . $minnow_object->data[$field_name] . '\'',
                    $where_condition
                );
            }
            $soql = 'SELECT ' .
                implode(',', $info_query['fields']) . ' FROM ' .
                $info_query['object'] . ' WHERE ' . $where_condition;
            $qr = $minnow_db->query($soql);
            if ($qr->size > 0) {
                // Retrieve the record data.
                $record = $qr->records[0];
                $sObject = new \SObject($record);
                if (!is_null($sObject)) {
                    if (is_array($sObject)) {
                        $obj = $sObject[0];
                    } else {
                        $obj = $sObject;
                    }
                    $properties = get_object_vars($obj->fields);
                    foreach ($info_query['fields'] as $field_name) {
                        $extra_log_data[] = $properties[$field_name];
                    }
                }
            }
        }

        $tag = '';
        if ($minnow_object->object_type === 'MinnowPayment') {
            $tag = $minnow_object->data['fw1__Amount__c'];
        } else {
            $tag = $minnow_object->data['Name'];
        }
        $log_data = [
            'object_type' => $minnow_object->object_type,
            'object_id' => $minnow_object->data['Id'],
            'account_id' => $account_id,
            'tag' => $tag,
            'status' => $status,
        ];
        $log_data = array_merge($log_data, $extra_log_data);
        fputcsv($fp_output, $log_data);
    }

    if (!$write_mode) {
        return;
    }

    // Initialize MinnowAccountingQueue connector.
    $maq = new MinnowAccountingQueue($logger, $legal_entity);

    // Add object to MAQ and PDK queues.
    enqueueObject($maq, $minnow_object, $legal_entity, $status, $logger);
}

/**
 * Enqueue an object in minnow accounting queue and send to QB if ready
 *
 * @param object $maq
 *     MinnowAccountingQueue instance
 * @param object $minnow_object
 *     MinnowObject-derived object to enqueue
 * @param string $legal_entity
 *     identifier for SCS corporate entity which determines QB company file
 *     'scs' | 'scs_consulting' | 'scs_ivory_coast'
 * @param integer $status
 *     one of the MAQ_STATUS_* values
 * @param object $logger
 *     Monolog\Logger
 */
function enqueueObject($maq, $minnow_object, $legal_entity, $status, $logger)
{
    global $minnow_db_mode, $object_id_filter;

    // Add object to minnow accounting queue.
    $maq_id = $maq->add($minnow_object, $status);

    // If object is ready, send it to QB.
    if ($status === MinnowAccountingQueue::MAQ_STATUS_QB_READY) {
        // Create Nest object from Minnow object.
        $nest_object = $minnow_object->exportToNest();
        $logger->addDebug(
            __FILE__ . ' line ' . __LINE__ . ': ' . __METHOD__ .
            ': $nest_object=' . print_r($nest_object, true)
        );

        // Enqueue the object for addition to QB.
        $qi = new QbIntegration($logger, $legal_entity);
        if ($qi->sendNestEntityToQuickbooks(
            $nest_object,
            'add',
            [
                'integration_type' => 'Minnow_Qb',
                'minnow_organization_id' => $minnow_object->organization_id,
                'minnow_notification_id' => $minnow_object->notification_id,
                'minnow_object_id' => $minnow_object->data['Id'],
            ],
            $minnow_object->source_id,
            !empty($object_id_filter)
        )) {
            $status = MinnowAccountingQueue::MAQ_STATUS_IN_QB_QUEUE;
        } else {
            $status = MinnowAccountingQueue::MAQ_STATUS_ERROR_SYNC;
        }
        $logger->addDebug(
            __FILE__ . ' line ' . __LINE__ . ': ' . __METHOD__,
            [
                'maq_id' => $maq_id,
                'status' => $status,
                'object_type' => $minnow_object->object_type
            ]
        );
        $maq->updateStatus(
            $maq_id,
            $status,
            $minnow_object->object_type,
            $minnow_object->data['Id'],
            ($minnow_object->object_type === 'MinnowAccount'),
            $minnow_object->organization_id
        );
    }
}

/**
 * Generate a random ID similar to those used in Salesforce
 *
 * Note: This function does not set the last three characters as a checksum so
 * the generated ID will not be usable by code that tests or uses that
 * characteristic.
 *
 * @return string
 *     18-character ID
 */
function randomSalesforceId()
{
    $chars = '01234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    $notification_id = '';
    for ($i = 0; $i < 18; $i++) {
        $pos = mt_rand(0, 61);
        $notification_id = $notification_id . substr($chars, $pos, 1);
    }
    return $notification_id;
}

/**
 * Set up Monolog logger.
 *
 * @param string $log_dir
 *     folder for log files
 * @param string $channel
 *     identifier for this part of application
 * @param string $alert_email_address
 *     email address to send alerts to
 *
 * @return object
 *     Monolog\Logger instance
 */
function getLogger($log_dir, $channel, $alert_email_address)
{
    global $logger;

    if (is_a($logger, '\Monolog\Logger')) {
        return $logger;
    }

    // Set up Monolog logger.
    $logger = new Logger($channel);

    // Debug log, stores all events.
    $logger->pushHandler(new RotatingFileHandler(
        $log_dir . '/debug.log',
        1095,
        Logger::DEBUG
    ));

    // Error log, stores events of level warning and above.
    $logger->pushHandler(new StreamHandler(
        $log_dir . '/error.log',
        Logger::WARNING
    ));

    // Error alert, sends email for events of level error and above.
    $validated_email = filter_var(
        $alert_email_address,
        \FILTER_VALIDATE_EMAIL
    );
    if (!empty($validated_email)) {
        $to = $validated_email;
        $subject = 'Error alert: ' . $channel;
        $from = 'donotreply@scscertified.com';
        $level = Logger::ERROR;
        $logger->pushHandler(new NativeMailerHandler(
            $to,
            $subject,
            $from,
            $level
        ));
    } else {
        $logger->error(
            __FILE__ . ' line ' . __LINE__ . ': ' . __METHOD__ .
            ': Invalid alert email address: "' .
            $alert_email_address . '"'
        );
    }

    $logger->debug('Logger initialized');

    return $logger;
}
