<?php

// Configuration file for Minnow-QB sync script.
// Copy to mqs_config.php and edit values.

// Email address to send alerts to.
$alert_email_address = 'xxxxxx';
