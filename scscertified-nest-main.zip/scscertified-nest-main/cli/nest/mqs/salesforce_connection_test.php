<?php

/**
 * @file
 * Salesforce Connection Test
 *
 * Tests SOAP API connection to Salesforce using credentials in
 * minnow_db_config.php
 *
 * @author T. Treadwell
 * @date 2022-04-08
 *
 * Options
 *   -m <mode> ( minnow | partial | production )
 *      Forces use of a specific connection mode. If undefined, it uses the
 *      mode value in the config file.
 */

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Set custom error log.
$log_dir = __DIR__ . '/../../../log/nest/mqs';
ini_set('error_log', $log_dir . '/salesforce_connection_test_error.log');

// Load and initialize the autoloader.
require_once __DIR__ . '/../../../sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', __DIR__ . '/../../../sites/nest/includes/src');

// Verify that the request is from the command line.
$ssec = new Scs\ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

// Include Minnow configuration file.
require_once __DIR__ . '/../../../sites/nest/includes/minnow/minnow_db_config.php';

// Retrieve default Minnow database mode set in config file.
$minnow_db_mode = $minnow_db_config['mode'];

// Retrieve command-line options.
$options = getopt('m:');

// Check for Minnow database mode option.
if (array_key_exists('m', $options)) {
    if (!empty($options['m'])) {
        $minnow_db_mode = $options['m'];
    } else {
        $msg = 'Missing -m option value (sandbox | production)';
        error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

echo 'Testing connection to ' . $minnow_db_mode . ' Minnow instance' . PHP_EOL;

try {
    // Open Minnow connection.
    $minnow_db = new Scs\Integration\Minnow\MinnowDatabase2(
        $minnow_db_config[$minnow_db_mode]
    );

    // Perform a test query.
    $soql = 'SELECT Id, Name FROM Account';
    $qr = $minnow_db->query($soql);
    if ($qr->size > 0) {
        echo $qr->size . ' records retrieved successfully.' . PHP_EOL;
    } else {
        echo 'FAILED to retrieve records' . PHP_EOL;
    }
} catch (Exception $e) {
    $msg = $e->getMessage();
    error_log(basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg);
    echo $msg . PHP_EOL;
    exit;
}
