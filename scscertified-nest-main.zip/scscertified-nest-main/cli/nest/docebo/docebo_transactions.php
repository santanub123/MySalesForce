<?php

/**
 * @file
 * script to create summary of Docebo transactions sent to QB
 *
 * Designed to run from the command line. Reads Docebo invoice queue and outputs
 * CSV of all transactions including time, invoice #, registrant name,
 * company name, amount, QB status, and SF status.
 *
 * @author T. Treadwell
 * @date 2023-03-17
 *
 */

use \Monolog\Handler\NativeMailerHandler;
use \Monolog\Handler\RotatingFileHandler;
use \Monolog\Handler\StreamHandler;
use \Monolog\Logger;
use \Scs\ApplicationLog;
use \Scs\Integration\Docebo\DoceboQueue;
use \Scs\ScsDataIntegrationDb;
use \Scs\ScsLogger;
use \Scs\ScsSecurity;

// Configure PHP.

// Allow up to 30 min for script execution.
ini_set('max_execution_time', 1800);

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Set custom error log.
$log_dir = __DIR__ . '/../../../log/nest/docebo';
ini_set('error_log', $log_dir . '/docebo_transactions_errors.log');

// Load and initialize the autoloader.
require_once __DIR__ . '/../../../sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', __DIR__ . '/../../../sites/nest/includes/src');
$loader->addNamespace(
    'Monolog',
    __DIR__ . '/../../../core/vendor/monolog/monolog/src/Monolog'
);
$loader->addNamespace('Psr', __DIR__ . '/../../../core/vendor/psr/log/Psr');

// Get an instance of the Monolog logger.
$logger = ScsLogger::getLogger(
    $log_dir,
    'Docebo Transaction Reconcile',
    'ttreadwell@scsglobalservices.com'
);

// Verify that the request is from the command line.
$ssec = new ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

// Require the database configuration settings.
require_once __DIR__ . '/../../../sites/nest/includes/db_config_2.php';

// Initialize the scs_data_integration MySQL database connection.
$sdi_db = ScsDataIntegrationDb::getInstance();

if (!$sdi_db->connection) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Cannot run : MySQL connection failed.'
    );
    exit;
}

$sql = 'SELECT * ' .
    ' FROM docebo_invoice_queue ';
try {
    $stmt = $sdi_db->connection->prepare($sql);
    $exec_result = $stmt->execute();
} catch (Exception $e) {
    if (!$stmt) {
        $error_info = $sdi_db->connection->errorInfo();
    } else {
        $error_info = $stmt->errorInfo();
    }
    $msg = $error_info[2];
    $logger->addError(
        __FILE__ . ' line ' . __LINE__ . ': ' . $msg
    );
    exit($msg);
}
if (!$exec_result) {
    $error_info = $stmt->errorInfo();
    $pdo_msg = $error_info[2];
    $msg = 'MySQL query failed on qb_customer: ' . $sql . '| ' . $pdo_msg;
    $logger->addError(
        __FILE__ . ' line ' . __LINE__ . ': ' . $msg
    );
    exit($msg);
}
$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);

// Create the log file.
$filename_root = 'docebo_transactions';
$app_log = new ApplicationLog(
    'nest/docebo',
    $filename_root
);
$arr_log_headings = [
    'Time',
    'Docebo Invoice Id',
    'QB Invoice #',
    'Buyer Username',
    'Buyer Company Name',
    'Amount',
    'QB Status',
    'SF Status',
];
$app_log->write($arr_log_headings);

foreach ($rows as $row) {
    $data = \unserialize($row['data']);
    $arr_log_data = [
        $row['creation_time'],
        $row['invoice_id'],
        $row['invoice_number'],
        $data['buyer_data']['username'],
        $data['billing_data']['company_name'],
        (string) $data['total_amount'],
        DoceboQueue::$status_names[$row['status_qb']],
        DoceboQueue::$status_names[$row['status_sf']],
    ];
    $app_log->write($arr_log_data);
}
