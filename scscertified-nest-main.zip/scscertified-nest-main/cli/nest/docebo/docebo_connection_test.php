<?php

/**
 * @file docebo_connection_test.php
 * @author T. Treadwell
 * @date 2022-09-05
 *
 * Tests connection to ADP API. Meant to run from command line.
 */

use \Scs\ScsLogger;
use \Scs\ScsSecurity;
use \Scs\Integration\Docebo\DoceboApi;

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Set custom error log.
$log_dir = __DIR__ . '/../../../log/nest/docebo';
ini_set('error_log', $log_dir . '/error.log');

// Load and initialize the autoloader.
require_once __DIR__ . '/../../../sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', __DIR__ . '/../../../sites/nest/includes/src');
$loader->addNamespace(
    'Monolog',
    __DIR__ . '/../../../core/vendor/monolog/monolog/src/Monolog'
);
$loader->addNamespace(
    'Psr',
    __DIR__ . '/../../../core/vendor/psr/log/Psr'
);

// Load Docebo config file.
require_once __DIR__ . '/../../../sites/nest/includes/docebo/docebo_config.php';

// Get an instance of the Monolog logger.
$logger = ScsLogger::getLogger(
    $log_dir,
    'Docebo Connection Test',
    $docebo_config['alert_email_address']
);

// Verify that the request is from the command line.
$ssec = new Scs\ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

$docebo_api = new DoceboApi($logger, $docebo_config);
$success = $docebo_api->connect();

if ($success) {
    echo 'Successfully connected to Docebo API and retrieved token.' . PHP_EOL;
} else {
    echo 'Failed to connect to Docebo API - see ' . $log_dir . '/error.log' .
        PHP_EOL;
}
