<?php
/**
 * @file test_dms_invoice_number.php
 *
 * Tests DMS script get_INV_number_website that generates invoice numbers
 *
 * Options
 *   -d <dept #>
 *      Dept number to pass to script, e.g. "305" or "305a"
 *   -f
 *      Use fake numbers, don't use a real number from the pool
 */

use Scs\DmsDatabase;
use Scs\ScsSecurity;

// Path to nest root dir.
$nest_root = __DIR__ . '/../../..';

// Load and initialize the autoloader.
require_once $nest_root . '/sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $nest_root . '/sites/nest/includes/src');

// Verify that the request is locally requested.
$ssec = new ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    echo basename(__FILE__) . ' line ' . __LINE__ .
        ': Invalid request' . PHP_EOL;
    exit();
}

// Retrieve command-line options.
$options = getopt('d:f');

// Get dept number value.
$dept_num  = '';
if (array_key_exists('d', $options)) {
    if (!empty($options['d'])) {
        $dept_num = $options['d'];
        $msg = 'Processing department ' . $dept_num;
        echo $msg . PHP_EOL;
    } else {
        $msg = 'Missing -d option value (Dept number)';
        echo basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg . PHP_EOL;
        exit();
    }
} else {
    $msg = 'Missing required -d parameter (Dept number)';
    echo basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg . PHP_EOL;
        exit();
}

// Check for use fake numbers option.
$use_fake_numbers = false;
if (array_key_exists('f', $options)) {
    $use_fake_numbers = true;
    $msg = 'Using fake numbers.';
    echo $msg . PHP_EOL;
}

// Load the DMS connection configuration.
require_once $nest_root . '/sites/nest/includes/dms/dms_config.php';

$fm_db = new DmsDatabase();

// Retrieve the next invoice number from the DMS.
$fm_db->connect('WO_SCS.fmp12');
$layout_name = 'DEPT_INV_NUMS';
$script_name = 'get_INV_number_website';
$layout_object = $fm_db->connection->getLayout($layout_name);
if (\FileMaker::isError($layout_object)) {
    echo basename(__FILE__) . ' line ' . __LINE__ .
        ': Error getting to layout: ' .
        $layout_object->getMessage() .
        ' (error ' . $layout_object->code . ')' . PHP_EOL;
    exit();
}

$script_parameter = $dept_num;
if ($use_fake_numbers) {
    $script_parameter .= ';1';
}
$command = $fm_db->connection->newPerformScriptCommand(
    $layout_name,
    $script_name,
    $script_parameter
);

$result = $command->execute();
if (\FileMaker::isError($result)) {
    echo basename(__FILE__) . ' line ' . __LINE__ .
        ': Error retrieving invoice number: ' .
        $result->getMessage() .
        ' (error ' . $result->code . ')';
    exit();
}

$fm_records = $result->getRecords();
$fm_record = $fm_records[0];
$fm_g_script_run = $fm_record->getFieldUnencoded('g_script_run');
$fm_g_script_result = $fm_record->getFieldUnencoded('g_script_result');

echo 'fm_g_script_run = ' . $fm_g_script_run . PHP_EOL;
echo 'fm_g_script_result = ' . $fm_g_script_result . PHP_EOL;
