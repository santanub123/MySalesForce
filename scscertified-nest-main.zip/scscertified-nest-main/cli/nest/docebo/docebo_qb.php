<?php

/**
 * @file docebo_qb.php
 *
 * Docebo -> QuickBooks data integration script. Retrieves the most recent
 * registrations via the Docebo API and sends the customer and invoice data to
 * the QuickBooks queue.
 *
 * @author T. Treadwell
 * @date 2022-09-06
 *
 * Options
 *   -q
 *      Enable Quickbooks integration - send invoices to QB.
 *
 *   -s
 *      Enable Salesforce integration - create opportunities in Salesforce.
 *      (note: Minnow mode is set in docebo_config.php)
 *
 *   -i <invoice #>
 *      Process only one Docebo invoice number <invoice #> in form
 *      <Docebo transaction id>_<dept code>, e.g. "2_305". Used for testing.
 *
 *   -n
 *      Disable addition of invoices from Docebo to queue. Used in test
 *      environment to reduce execution time.
 *
 * Examples
 *   Test single invoice send to Salesforce only, no read of new invoices:
 *      php docebo_qb -s -i 2_305 -n
 *
 *   Production setting:
 *      php docebo_qb.php -q -s
 */

use \Scs\ScsDataIntegrationDb;
use \Scs\ScsLogger;
use \Scs\ScsSecurity;
use \Scs\Integration\Docebo\DoceboApi;
use \Scs\Integration\Docebo\DoceboInvoice;
use \Scs\Integration\Docebo\DoceboQbIntegration;
use \Scs\Integration\Docebo\DoceboQueue;
use \Scs\Integration\Docebo\DoceboSalesforceIntegration;

// Path to nest root dir.
$nest_root = __DIR__ . '/../../..';

// Allow up to 30 min for script execution.
ini_set('max_execution_time', 1800);

// Set PHP error log location.
$log_dir = $nest_root . '/log/nest/docebo/quickbooks';
ini_set('error_log', $log_dir . '/php_errors.log');

// Load and initialize the autoloader.
require_once $nest_root . '/sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $nest_root . '/sites/nest/includes/src');
$loader->addNamespace('Nest', $nest_root . '/sites/nest/src');
$loader->addNamespace(
    'Monolog',
    $nest_root . '/core/vendor/monolog/monolog/src/Monolog'
);
$loader->addNamespace('Psr', $nest_root . '/core/vendor/psr/log/Psr');

// Get an instance of the Monolog logger.
$logger = ScsLogger::getLogger(
    $log_dir,
    'DoceboQbSync',
    'jmatviak@scsglobalservices.com'
);

// Verify that the request is locally requested.
$ssec = new ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Invalid request'
    );
    exit();
}

// Retrieve command-line options.
$options = getopt('qsi:n');

// Check for Quickbooks integration option.
$qb_enable = false;
if (array_key_exists('q', $options)) {
    $qb_enable = true;
    $msg = 'Quickbooks integration enabled.';
    $logger->addDebug(basename(__FILE__) . ': ' . __LINE__ . ': ' . $msg);
}

// Check for Salesforce integration option.
$sf_enable = false;
if (array_key_exists('s', $options)) {
    $sf_enable = true;
    $msg = 'Salesforce integration enabled.';
    $logger->addDebug(basename(__FILE__) . ': ' . __LINE__ . ': ' . $msg);
}

// Check for single invoice option.
$single_invoice_filter  = '';
if (array_key_exists('i', $options)) {
    if (!empty($options['i'])) {
        $single_invoice_filter = $options['i'];
        $msg = 'Processing invoice ' . $options['i'] . ' only.';
        $logger->addDebug(basename(__FILE__) . ': ' . __LINE__ . ': ' . $msg);
    } else {
        $msg = 'Missing -i option value (Docebo invoice #)';
        echo $msg . PHP_EOL;
        $logger->addError(basename(__FILE__) . ': ' . __LINE__ . ': ' . $msg);
        exit;
    }
}

// Check for no addition of new invoices option.
$no_new_invoices = false;
if (array_key_exists('n', $options)) {
    $no_new_invoices = true;
    $msg = 'Addition of new Docebo invoices disabled.';
    echo $msg . PHP_EOL;
    $logger->addDebug(basename(__FILE__) . ': ' . __LINE__ . ': ' . $msg);
}

// Load the Nest API config settings.
require_once $nest_root . '/sites/nest/nest_config.php';

// Initialize the NestApi object and log in.
$nest_api = \Nest\Api::getInstance();
$nest_token_info = $nest_api->login(NEST_API_USER, NEST_API_PASS);
$nest_token = $nest_token_info->token;

// Load the queue MySQL database configuration settings.
require_once $nest_root . '/sites/nest/includes/db_config_2.php';

// Load the DMS connection configuration.
require_once $nest_root . '/sites/nest/includes/dms/dms_config.php';

// Load Docebo config file.
require_once $nest_root . '/sites/nest/includes/docebo/docebo_config.php';

// Require the QuickBooks PHP DevKit library.
require_once $nest_root . '/sites/nest/lib/QuickBooksPhpDevKit/quickbooks-php-master/QuickBooks.php';

// Initialize the MySQL database connections.
$sdi_db = ScsDataIntegrationDb::getInstance();
if (!$sdi_db->connection) {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Cannot run Docebo-QuickBooks integration script: MySQL connection failed.'
    );
    exit();
}

// Initialize and connect to Docebo.
$docebo_api = new DoceboApi($logger, $docebo_config);
$docebo_success = $docebo_api->connect();

if ($docebo_success) {
    $logger->addDebug(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Successfully connected to Docebo API and retrieved token.'
    );
} else {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Failed to connect to Docebo API - see ' . $log_dir .
        '/error.log, aborting!'
    );
    exit();
}

// Set up DoceboQueue object.
$dq = new DoceboQueue($logger, $docebo_config, $docebo_api);

// Add new invoices to Docebo queue.
if (!$no_new_invoices) {
    $dq->addNewInvoices();
}

// Placeholders for downstream code that expects these to be global. Set in
// DoceboQbIntegration::processInvoice when qb config file is loaded, can
// change if different legal entity invoice is processed.
$scs_docebo_info = [];
$scs_qb_queue_db = [];
$scs_qb_pdk_db = [];

if ($qb_enable) {
    $logger->addDebug(
        basename(__FILE__) . ' line ' . __LINE__ .
            ': Preparing to process invoices for QB.',
    );

    // Set up DoceboQuickbooksIntegration object.
    $dqi = new DoceboQbIntegration($logger, $dq, $docebo_config);

    // Retrieve invoices for QB from queue.
    $dqi->loadInvoicesFromQueue($single_invoice_filter);

    // Process the invoices for QB.
    $dqi->processInvoices();
}

if ($sf_enable) {
    $logger->addDebug(
        basename(__FILE__) . ' line ' . __LINE__ .
            ': Preparing to process invoices for SF.',
    );

    // Set up DoceboQuickbooksSalesforce object.
    $dsi = new DoceboSalesforceIntegration($logger, $dq, $docebo_config);

    // Retrieve invoices for SF from queue.
    $dsi->loadInvoicesFromQueue($single_invoice_filter);

    // Process the invoices for SF.
    $dsi->processInvoices();
}

$logger->addDebug(
    basename(__FILE__) . ' line ' . __LINE__ .
    ': Execution completed.'
);
