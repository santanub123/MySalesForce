#!/usr/bin/env python

# FSC Azure service bus event listener
# 2023-08-30

import os
import logging
import logging.config
import json
from azure.servicebus import ServiceBusClient, ServiceBusMessage
import mysql.connector
from mysql.connector import errorcode
from datetime import datetime

CONST_FSC_MSGQ_STATUS_NEW = 20
CONST_FSC_MSGQ_STATUS_INVALID = 52

# Load FSC Azure config file
config_folder = os.path.realpath(os.path.dirname(__file__))
with open(config_folder + "/../fsc_config.json") as config_file:
    fsc_azure_config = json.load(config_file)
logging_config = fsc_azure_config['logging_config']
scs_fsc_data_config = fsc_azure_config['scs_fsc_data_configs'][fsc_azure_config['mode']]
fsc_msg_queue_config = fsc_azure_config['fsc_msg_queue_configs'][fsc_azure_config['mode']]
peek_only = fsc_azure_config['peek_only']       # Process messages without removing them from queue, for testing

# Set up logger
logging.config.dictConfig(logging_config)
logger = logging.getLogger('fsc_azure_event_listener')
logger.debug('Azure service bus listener started')

# Define service bus connection string and queue name
connstr = 'Endpoint=sb://' + scs_fsc_data_config['endpoint'] + \
    ';SharedAccessKeyName=' + scs_fsc_data_config['shared_access_key_name'] + \
    ';SharedAccessKey=' + scs_fsc_data_config['shared_access_key'] + \
    ';EntityPath=' + scs_fsc_data_config['entity_path']
queue_name = scs_fsc_data_config['entity_path']

# Open MySQL connection
try:
    cnx = mysql.connector.connect(**fsc_msg_queue_config)
except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print("Something is wrong with your user name or password")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print("Database does not exist")
    else:
        print(err)
    quit()

def processMessage(msg):
    """
    Process a message from the FSC data service bus

    :param msg: JSON string containing one or more blocks of certificate data
    """

    logger.debug('Processing message from service bus')
    msg_data = json.loads(msg)
    cursor = cnx.cursor()
    for cert_data in msg_data:

        # Define SQL statement.
        now = datetime.now()
        time_str = now.strftime("%Y-%m-%d %H:%M:%S")
        status = CONST_FSC_MSGQ_STATUS_NEW
        sf_id = cert_data['SF_ID']
        sf_oc_id = cert_data['SF_OC_ID']
        cert_num = cert_data['certificate']
        logger.debug('Processing ' + sf_id + ': ' + cert_num)
        if not sf_id or not cert_num:
            status = CONST_FSC_MSGQ_STATUS_INVALID
        cert_json = json.dumps(cert_data)
        add_cert = ("INSERT INTO fsc_message_queue "
                    "(creation_time, sf_id, sf_oc_id, cert_num, data, status) "
                    "VALUES (%s, %s, %s, %s, %s, %s)")
        data_cert = (time_str, sf_id, sf_oc_id, cert_num, cert_json, status)

        # Execute insert.
        cursor.execute(add_cert, data_cert)
        cnx.commit()

    cursor.close()

# create a Service Bus client using the connection string
with ServiceBusClient.from_connection_string(connstr) as client:
    # max_wait_time specifies how long the receiver should wait with no incoming messages before stopping receipt.
    # Default is None; to receive forever.
    with client.get_queue_receiver(queue_name, max_wait_time=290) as receiver:
        if peek_only:
            received_msgs = receiver.peek_messages(max_message_count=20)
        else:
            received_msgs = receiver.receive_messages(max_message_count=20, max_wait_time=5)
        for msg in received_msgs:
            processMessage(str(msg))
            if not peek_only:
                receiver.complete_message(msg)
