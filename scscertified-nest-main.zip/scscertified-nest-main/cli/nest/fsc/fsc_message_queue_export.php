<?php

/**
 * @file
 * FSC MySQL message queue -> FSC Salesforce export script.
 *
 * Designed to run from the command line via a cron job. Finds all records in
 * the MySQL FSC message queue with new or error status, and inserts or updates
 * them in the FSC Salesforce database. Records activity in database table.
 *
 * @author T. Treadwell
 * @date 2023-08-31
 *
 * Options
 *   -f <FSC database mode>
 *      Change the destination FSC database mode: none | mock | sandbox | prod
 *        none    = Don't export any data (default)
 *        mock    = MySQL mock of FSC db
 *        sandbox = FSC sandbox database
 *        prod    = FSC production database
 *
 *   -c <SCS SF certificate id>
 *      Export the latest instance of this certificate id in queue db (sf_id),
 *      regardless of its status.
 *
 *   -o <SCS SF OC id>
 *      Export the latest instance of this opportunity certificate id in queue db
 *      (sf_oc_id), regardless of its status. If -c and -o parameters are both
 *      present, they must match the same queue entry.
 *
 * Examples:
 *    Test setting:
 *      php fsc_message_queue_export.php -f mock
 *
 *    Production setting:
 *      php fsc_message_queue_export.php -f prod
 *
 *    Sync only specific OC id abcd1234efgh5678ij in production:
 *      php fsc_message_queue_export.php -f prod -o abcd1234efgh5678ij
 */

use \Scs\MysqlDatabase3;
use \Scs\ScsDataIntegrationDb;
use \Scs\ScsLogger;
use \Scs\ScsSecurity;
use \Scs\Integration\SalesforceDatabase2;

// Path to nest root dir.
$nest_root = __DIR__ . '/../../..';

// Allow up to 30 min for script execution.
ini_set('max_execution_time', 1800);

// Set PHP error log location.
$log_dir = $nest_root . '/log/nest/fsc';
ini_set('error_log', $log_dir . '/php_errors.log');

// Load and initialize the autoloader.
require_once $nest_root . '/sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $nest_root . '/sites/nest/includes/src');
$loader->addNamespace('Nest', $nest_root . '/sites/nest/src');
$loader->addNamespace(
    'Monolog',
    $nest_root . '/core/vendor/monolog/monolog/src/Monolog'
);
$loader->addNamespace('Psr', $nest_root . '/core/vendor/psr/log/Psr');

// Get an instance of the Monolog logger.
$logger = ScsLogger::getLogger(
    $log_dir,
    'FSC Message Queue Export',
    'ttreadwell@scsglobalservices.com'
);

// Verify that the request is locally requested.
$ssec = new ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request'
    );
    exit();
}

// Retrieve command-line options.
$options = getopt('f:c:o:');

// Check for FSC database mode option. Default to 'none'.
$fsc_db_mode = 'none';
if (array_key_exists('f', $options)) {
    if (!empty($options['f'])) {
        $fsc_db_mode = $options['f'];
    } else {
        $msg = 'Missing -f option fsc_db_mode value';
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for cert retry id option. Default to ''.
$cert_retry_id = '';
if (array_key_exists('c', $options)) {
    if (!empty($options['c'])) {
        $cert_retry_id = $options['c'];
    } else {
        $msg = 'Missing -c option cert_retry_id value';
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for OC retry id option. Default to ''.
$oc_retry_id = '';
if (array_key_exists('o', $options)) {
    if (!empty($options['o'])) {
        $oc_retry_id = $options['o'];
    } else {
        $msg = 'Missing -o option oc_retry_id value';
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        echo $msg . PHP_EOL;
        exit;
    }
}

// Load the FSC queue config settings.
$fsc_config_file = __DIR__ . '/fsc_config.json';

if (file_exists($fsc_config_file)) {
    $json = file_get_contents($fsc_config_file);
    $fsc_config_data = json_decode($json, true);
} else {
    echo 'File ' . $fsc_config_file . ' not found.' . PHP_EOL;
    exit;
}

// Load the MySQL configuration for the app log database.
require_once $nest_root . '/sites/nest/includes/db_config.php';

// Load the SCS Salesforce configuration.
require_once $nest_root . '/sites/nest/includes/minnow/minnow_db_config.php';
$scs_sf_config = $minnow_db_config[$fsc_config_data['minnow_mode']];
$scs_sf_db = new SalesforceDatabase2($scs_sf_config);
if (empty($scs_sf_db)) {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Cannot run FSC message queue integration script: No connection to SCS Salesforce.'
    );
    exit();
}

// Load the FSC Salesforce database configuration.
require_once $nest_root . '/sites/nest/includes/fsc/fsc_db_config.php';

// Initialize the MySQL database connections.
$mode = $fsc_config_data['mode'];
$fsc_msg_queue_config = $fsc_config_data['fsc_msg_queue_configs'][$mode];
$fsc_msg_queue_config['pass'] = $fsc_msg_queue_config['password'];  // PHP adj.
$sdi_db = new MysqlDatabase3($fsc_msg_queue_config);
if (!$sdi_db->connection) {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Cannot run FSC message queue integration script: MySQL connection to FSC message queue db failed.'
    );
    exit();
}

$app_log_db = new MysqlDatabase3($db_config['application_logs']);
if (!$app_log_db->connection) {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Cannot run FSC message queue integration script: MySQL connection to app log db failed.'
    );
    exit();
}

// Open FSC database connection based on $fsc_db_mode setting.
try {
    switch ($fsc_db_mode) {
        case 'none':
            echo 'Not exporting data.' . PHP_EOL;
            break;

        case 'mock':
            echo 'Exporting data to MySQL mock FSC database.' . PHP_EOL;
            $fsc_db = Scs\Integration\Test\FSC\FscDatabaseMock::getInstance(
                $fsc_db_config['mock']
            );
            break;

        case 'sandbox':
            echo 'Exporting data to FSC test sandbox.' . PHP_EOL;
            $fsc_db = Scs\Integration\FscDatabase::get_instance($fsc_db_config['sandbox']);
            break;

        case 'prod':
            echo 'Exporting data to FSC live production database.' . PHP_EOL;
            $fsc_db = Scs\Integration\FscDatabase::get_instance($fsc_db_config['prod']);
            break;

        default:
            $msg = 'Invalid destination value: "' . $destination . '"';
            error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
            echo $msg . PHP_EOL;
            exit;
    }

    // SCS cert #s that should not be synced, from exclusions file.
    $exclusions = file(
        'exclusions.txt',
        FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
    );

    // Create the MqFscExport object.
    $mq_fsc_export = new Scs\Integration\DMS_FSC\MqFscExport(
        $logger,
        $app_log_db,
        $sdi_db,
        $scs_sf_db,
        $fsc_db,
        true,
        $fsc_db_mode,
        $exclusions
    );

    if (empty($cert_retry_id) && empty($oc_retry_id)) {
        // Run the Message queue -> FSC export.
        $mq_fsc_export->processMessageQueue();
    } else {
        // Sync a single certificate.
        $mq_fsc_export->retryCertificate($cert_retry_id, $oc_retry_id);
    }
} catch (\Exception $e) {
    // Fatal error.
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ . ': ' . $e->getMessage()
    );
}
