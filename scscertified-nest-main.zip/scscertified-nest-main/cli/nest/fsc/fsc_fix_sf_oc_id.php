<?php

/**
 * @file
 * Utility script to fix missing SF OC ID in message queue table.
 *
 * @author T. Treadwell
 * @date 2023-11-29
 *
 * One-time use script to populate SF OC ID column in queue
 */

use \Scs\MysqlDatabase3;
use \Scs\ScsDataIntegrationDb;
use \Scs\ScsLogger;
use \Scs\ScsSecurity;

// Path to nest root dir.
$nest_root = __DIR__ . '/../../..';

// Allow up to 30 min for script execution.
ini_set('max_execution_time', 1800);

// Set PHP error log location.
$log_dir = $nest_root . '/log/nest/fsc';
ini_set('error_log', $log_dir . '/php_errors.log');

// Load and initialize the autoloader.
require_once $nest_root . '/sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $nest_root . '/sites/nest/includes/src');
$loader->addNamespace('Nest', $nest_root . '/sites/nest/src');
$loader->addNamespace(
    'Monolog',
    $nest_root . '/core/vendor/monolog/monolog/src/Monolog'
);
$loader->addNamespace('Psr', $nest_root . '/core/vendor/psr/log/Psr');

// Get an instance of the Monolog logger.
$logger = ScsLogger::getLogger(
    $log_dir,
    'FSC Fix SF OC ID',
    'ttreadwell@scsglobalservices.com'
);

// Verify that the request is locally requested.
$ssec = new ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request'
    );
    exit();
}

// Load the FSC queue config settings.
$fsc_config_file = __DIR__ . '/fsc_config.json';

if (file_exists($fsc_config_file)) {
    $json = file_get_contents($fsc_config_file);
    $fsc_config_data = json_decode($json, true);
} else {
    echo 'File ' . $fsc_config_file . ' not found.' . PHP_EOL;
    exit;
}

// Initialize the MySQL database connection.
$mode = $fsc_config_data['mode'];
$fsc_msg_queue_config = $fsc_config_data['fsc_msg_queue_configs'][$mode];
$fsc_msg_queue_config['pass'] = $fsc_msg_queue_config['password'];  // PHP adj.
$sdi_db = new MysqlDatabase3($fsc_msg_queue_config);
if (!$sdi_db->connection) {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Cannot run FSC message queue integration script: MySQL connection to FSC message queue db failed.'
    );
    exit();
}

// Retrieve all the records that are missing SF OC ID
$sql = "SELECT
  id, data
FROM fsc_message_queue
WHERE creation_time > '2023-11-06 01:00' AND sf_oc_id = ''
ORDER BY id ASC";
$stmt = $sdi_db->connection->prepare($sql);
$result = $stmt->execute();
if (!$result) {
    $this->logger->addError(
        basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
            ': Error querying FSC message queue - ' .
            var_export($stmt->errorInfo(), true)
    );
    exit();
}
$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
$stmt->closeCursor();

// On each record, find the SF OC ID in the data block and insert it in the queue.
$sql2 = 'UPDATE fsc_message_queue
SET sf_oc_id = :sf_oc_id
WHERE id = :id';
$stmt2 = $sdi_db->connection->prepare($sql2);

foreach ($rows as $row) {
    $cert_json_data = $row['data'];
    $cert_data = json_decode($cert_json_data);
    $sf_oc_id = $cert_data->SF_OC_ID;
    $stmt2->bindValue(':sf_oc_id', $sf_oc_id, \PDO::PARAM_STR);
    $stmt2->bindValue(':id', (int) $row['id'], \PDO::PARAM_INT);
    $stmt2->execute();
}
