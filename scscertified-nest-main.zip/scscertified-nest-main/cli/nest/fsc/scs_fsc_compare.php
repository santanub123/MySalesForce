<?php

/**
 * @file
 * SCS - FSC comparison script
 *
 * Designed to run from the command line. Searches SCS Salesforce for all
 * 502 certified and suspended certificates, and reports the results in a SQL
 * database.
 *
 * @author T. Treadwell
 * @date 2023-11-03
 *
 * Options
 *   -m <salesforce mode>
 *     (required), index in minnow_db_config.php
 *     Set Salesforce host API config
 *     (currently sandbox | production | 2ndorgscsglobal | 2ndorgscsglobal--uat)
 *
 *   -f <FSC database mode>
 *      (required), FSC database mode: none | mock | sandbox | prod
 *        none    = Don't compare any data
 *        mock    = MySQL mock of FSC db
 *        sandbox = FSC sandbox database
 *        prod    = FSC production database
 *
 *   -r <reporting database>
 *      optional, index in sf_fsc_compare.config.json afr_db_configs array
 *      sets spec for SQL reporting db
 *      if not present, writes results to CSV files
 *
 * Examples:
 *    Test setting, writing to CSV:
 *      php -m 2ndorgscsglobal--uat -f mock
 *
 *    Test setting, using production data, writing to Azure reporting test db:
 *      php -m 2ndorgscsglobal -f prod -r test
 *
 *    Production setting, writing to Azure reporting db::
 *      php -m 2ndorgscsglobal -f prod -r prod
 */

use \Scs\ScsLogger;
use \Scs\ScsSecurity;
use \Scs\Integration\AzureSqlDatabase;
use \Scs\Integration\DMS_FSC\MqFscExport;
use \Scs\Integration\FscDatabase;
use \Scs\Integration\Minnow\MinnowDatabase2;
use \Scs\Integration\Test\FSC\FscDatabaseMock;

// Path to nest root dir.
$nest_root = __DIR__ . '/../../..';

// Allow up to 30 min for script execution.
ini_set('max_execution_time', 1800);

// Set PHP error log location.
$log_dir = $nest_root . '/log/nest/fsc';
ini_set('error_log', $log_dir . '/php_errors.log');

// Load and initialize the autoloader.
require_once $nest_root . '/sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $nest_root . '/sites/nest/includes/src');
$loader->addNamespace('Nest', $nest_root . '/sites/nest/src');
$loader->addNamespace(
    'Monolog',
    $nest_root . '/core/vendor/monolog/monolog/src/Monolog'
);
$loader->addNamespace('Psr', $nest_root . '/core/vendor/psr/log/Psr');

// Get an instance of the Monolog logger.
$logger = ScsLogger::getLogger(
    $log_dir,
    'SCS - FSC Certificate Comparison',
    'jmatviak@scsglobalservices.com'
);

// Verify that the request is locally requested.
$ssec = new ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Invalid request'
    );
    exit();
}

// Retrieve command-line options.
$options = getopt('m:f:r:');

// Check for SCS Salesforce mode option.
$minnow_db_mode  = '';
if (array_key_exists('m', $options)) {
    if (!empty($options['m'])) {
        $minnow_db_mode = $options['m'];
        echo 'Retrieving records from ' . $minnow_db_mode . ' SF instance' . PHP_EOL;
    } else {
        $msg = 'Cannot run : missing -m option value.';
        $logger->addError(basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
} else {
    $msg = 'Cannot run : missing -m option.';
    $logger->addError(basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg);
    echo $msg . PHP_EOL;
    exit;
}

// Check for FSC database mode option. Default to 'none'.
$fsc_db_mode = '';
if (array_key_exists('f', $options)) {
    if (!empty($options['f'])) {
        $fsc_db_mode = $options['f'];
        echo 'Comparing with ' . $fsc_db_mode . ' FSC instance' . PHP_EOL;
    } else {
        $msg = 'Missing -f option fsc_db_mode value';
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        echo $msg . PHP_EOL;
        exit;
    }
} else {
    $msg = 'Cannot run : missing -f option.';
    $logger->addError(basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg);
    echo $msg . PHP_EOL;
    exit;
}

// Check for reporting database mode option. Default to ''.
$afr_db_mode = '';
if (array_key_exists('r', $options)) {
    if (!empty($options['r'])) {
        $afr_db_mode = $options['r'];
        echo 'Sending to ' . $afr_db_mode . ' Azure FSC reporting db' . PHP_EOL;
    } else {
        $msg = 'Missing -r option afr_db_mode value';
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . $msg
        );
        echo $msg . PHP_EOL;
        exit;
    }
}

// Load Minnow configuration file.
require_once __DIR__ . '/../../../sites/nest/includes/minnow/minnow_db_config.php';

// Load FSC Salesforce database configuration.
require_once __DIR__ . '/../../../sites/nest/includes/fsc/fsc_db_config.php';

// Load the local config settings (includes Azure FSC Reporting db config).
$scs_fsc_compare_config_file = __DIR__ . '/scs_fsc_compare_config.json';
if (file_exists($scs_fsc_compare_config_file)) {
    $json = file_get_contents($scs_fsc_compare_config_file);
    $scs_fsc_compare_config_data = json_decode($json, true);
} else {
    echo 'File ' . $scs_fsc_compare_config_file . ' not found.' . PHP_EOL;
    exit;
}
if (empty($scs_fsc_compare_config_data)) {
    echo 'Problem decoding file ' . $scs_fsc_compare_config_file . ': ' .
        json_last_error_msg() . PHP_EOL;
    exit;
}

// Open Minnow connection.
$minnow_db = new MinnowDatabase2($minnow_db_config[$minnow_db_mode]);

// Retrieve FSC CoC program id.
$fsc_coc_program_ids = $minnow_db_config[$minnow_db_mode]['fsc_program_ids'];

// Loop through the entire config array
foreach ($fsc_coc_program_ids as $fsc_coc_program_id) {
    echo "Processing: $fsc_coc_program_id\n";

    // Open FSC database connection based on $fsc_db_mode setting.
    try {
        switch ($fsc_db_mode) {
            case 'none':
                echo 'Not comparing data.' . PHP_EOL;
                break;

            case 'mock':
                echo 'Comparing to MySQL mock FSC database.' . PHP_EOL;
                $fsc_db = FscDatabaseMock::getInstance(
                    $fsc_db_config['mock']
                );
                break;

            case 'sandbox':
                echo 'Comparing to FSC test sandbox.' . PHP_EOL;
                $fsc_db = FscDatabase::get_instance($fsc_db_config['sandbox']);
                break;

            case 'prod':
                echo 'Comparing to FSC live production database.' . PHP_EOL;
                $fsc_db = FscDatabase::get_instance($fsc_db_config['prod']);
                break;

            default:
                $msg = 'Invalid destination value: "' . $destination . '"';
                error_log(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
                echo $msg . PHP_EOL;
                exit;
        }
    } catch (\Exception $e) {
        // Fatal error.
        $logger->addError(
            basename(__FILE__) . ': ' . __LINE__ . $e->getMessage()
        );
        exit();
    }

    // Open connection to Azure FSC Reporting database.
    $afr_db = null;
    if (!empty($afr_db_mode)) {
        $afr_config = $scs_fsc_compare_config_data['afr_db'][$afr_db_mode];
        $afr_db = new AzureSqlDatabase($afr_config);
    }

    // Create MqFscExport object.
    $mq_fsc_export = new MqFscExport(
        $logger,
        null,
        null,
        $minnow_db,
        $fsc_db,
        false,
        $fsc_db_mode,
        [],
        '/nest/fsc_export'
    );

    // Run batch comparison report.
    $mq_fsc_export->batchCompare($afr_db, $fsc_coc_program_id);
}