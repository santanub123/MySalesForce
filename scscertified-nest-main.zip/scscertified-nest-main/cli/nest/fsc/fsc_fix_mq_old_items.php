<?php

/**
 * @file
 * Utility script to fix old unqueued items in message queue table. Useful if
 * the queue processing has been turned off for a period of time.
 *
 * @author T. Treadwell
 * @date 2024-03-29
 *
 * One-time use script to find items with NEW (20) status in fsc_message_queue
 * and check for later items in queue. If there are later items then the item
 * is set to status FSC_MSGQ_STATUS_ERROR_SUPERCEDED (53) to prevent sync.
 *
 * Creates log of its activity at Nest folder:
 * <nest root>/log/nest/fsc/fsc_fix_mq_old_items_YYYYMMDD_HHMMSS.csv.
 */

use \Scs\MysqlDatabase3;
use \Scs\ScsDataIntegrationDb;
use \Scs\ScsLogger;
use \Scs\ScsSecurity;
use \Scs\Integration\DMS_FSC\FscMessageQueue;

// Path to nest root dir.
$nest_root = __DIR__ . '/../../..';

// Allow up to 30 min for script execution.
ini_set('max_execution_time', 1800);

// Set PHP error log location.
$log_dir = $nest_root . '/log/nest/fsc';
ini_set('error_log', $log_dir . '/php_errors.log');

// Load and initialize the autoloader.
require_once $nest_root . '/sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', $nest_root . '/sites/nest/includes/src');
$loader->addNamespace('Nest', $nest_root . '/sites/nest/src');
$loader->addNamespace(
    'Monolog',
    $nest_root . '/core/vendor/monolog/monolog/src/Monolog'
);
$loader->addNamespace('Psr', $nest_root . '/core/vendor/psr/log/Psr');

// Get an instance of the Monolog logger.
$logger = ScsLogger::getLogger(
    $log_dir,
    'FSC Fix MQ Old Items',
    'ttreadwell@scsglobalservices.com'
);

// Verify that the request is locally requested.
$ssec = new ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request'
    );
    exit();
}

// Load the FSC queue config settings.
$fsc_config_file = __DIR__ . '/fsc_config.json';

if (file_exists($fsc_config_file)) {
    $json = file_get_contents($fsc_config_file);
    $fsc_config_data = json_decode($json, true);
} else {
    echo 'File ' . $fsc_config_file . ' not found.' . PHP_EOL;
    exit;
}

// Initialize the MySQL database connection.
$mode = $fsc_config_data['mode'];
$fsc_msg_queue_config = $fsc_config_data['fsc_msg_queue_configs'][$mode];
$fsc_msg_queue_config['pass'] = $fsc_msg_queue_config['password'];  // PHP adj.
$sdi_db = new MysqlDatabase3($fsc_msg_queue_config);
if (!$sdi_db->connection) {
    $logger->addError(
        basename(__FILE__) . ': ' . __LINE__ .
        ': Cannot run FSC message queue integration script: MySQL connection to FSC message queue db failed.'
    );
    exit();
}

// Create log file and write heading.
$app_log = new \Scs\ApplicationLog('/nest/fsc', 'fsc_fix_mq_old_items');
$arr_log_values = [
    'Time',
    'FSC MQ Id',
    'sf_id',
    'sf_oc_id',
    'cert_num',
    'action',
];
$app_log->write($arr_log_values);

// Create the FscMessageQueue object.
$fmq = new FscMessageQueue($logger, $sdi_db);

// Retrieve all the records with status = NEW
$new_items = $fmq->getNewItems();

// Process each item.
foreach ($new_items as $new_item) {
    processMqItem($new_item);
}


/**
 * Process an item from the FSC message queue
 *
 * @param array $mq_item
 *     row from fsc_message_queue database
 */
function processMqItem($mq_item)
{
    global $sdi_db, $fmq, $logger;

    // Find all MQ items for this certificate.
    $rows = [];
    $mq_item_id = (int) $mq_item['id'];
    $sql = "SELECT * " .
        "FROM fsc_message_queue " .
        "WHERE sf_id = :sf_id AND creation_time > :creation_time";
    $stmt = $sdi_db->connection->prepare($sql);
    $stmt->bindValue(':sf_id', $mq_item['sf_id']);
    $stmt->bindValue(':creation_time', $mq_item['creation_time']);
    $result = $stmt->execute();
    if ($result) {
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
    } else {
        $error_info = $stmt->errorInfo();
        $logger->addError(
            basename(__FILE__) . ' line ' . __LINE__ . ': ' . __FUNCTION__ .
            ': MySQL Error: ' . var_export($error_info, true)
        );
        logAction($mq_item, 'SQL error');
        return;
    }

    if (count($rows) > 0) {
        // There are more recent queue items for this certificate, set status to
        // FSC_MSGQ_STATUS_ERROR_SUPERCEDED to prevent sync.
        $fmq->updateStatus(
            $mq_item_id,
            FscMessageQueue::FSC_MSGQ_STATUS_ERROR_SUPERCEDED
        );
        logAction($mq_item, 'old, set to ERR');
    } else {
        logAction($mq_item, 'most recent');
    }
}

/**
 * Log action taken on MQ item
 *
 * @param array $mq_item
 *     FSC MQ item being processed
 * @param string $action
 *     action taken
 */
function logAction($mq_item, $action)
{
    global $app_log;

    $time_now = new \DateTimeImmutable();
    $time_iso = $time_now->format('Y-m-d H:i:s');
    unset($time_now);

    $arr_log_values = [
        'time_iso' => $time_iso,
        'fsc_mq_id' => $mq_item['id'],
        'sf_id' => $mq_item['sf_id'],
        'sf_oc_id' => $mq_item['sf_oc_id'],
        'cert_number' => $mq_item['cert_num'],
        'action' => $action,
    ];
    $app_log->write($arr_log_values);
}
