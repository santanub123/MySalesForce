<?php

/**
 * @file cvent_quickbooks.php
 * @author T. Treadwell
 * @date 2016-12-12
 *
 * Cvent -> QuickBooks data integration script.
 * Retrieves the most recent registrations via the Cvent API and sends the
 * customer and invoice data to QuickBooks.
 */

use \Monolog\Logger;
use \Monolog\Handler\RotatingFileHandler;
use \Monolog\Handler\StreamHandler;
use \Monolog\Handler\NativeMailerHandler;

// base values
$path = '/../../../../sites/nest';
require_once __DIR__ . "$path/nest_config.php";

// Allow up to 60 min for script execution.
ini_set('max_execution_time', 3600);

// Load and initialize the autoloader.
require_once __DIR__ . $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', __DIR__ . $path . '/includes/src');
$loader->addNamespace('Nest', __DIR__ . $path . '/src');
$loader->addNamespace('Monolog', __DIR__ . '/../../../../core/vendor/monolog/monolog/src/Monolog');
$loader->addNamespace('Psr', __DIR__ . '/../../../../core/vendor/psr/log/Psr');

// Get an instance of the Monolog logger.
$log_dir = __DIR__ . $path . '/../../log/nest/cvent/quickbooks';
$logger = getLogger($log_dir, 'CventQbSync', 'ttreadwell@scsglobalservices.com');

// Verify that the request is locally requested.
$ssec = new Scs\ScsSecurity;
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request'
    );
    exit();
}

// Set logging
$nestTop = new Scs\NestTop;
$nestTop->set_error_log($log_dir);


/* Set test mode. If true:
 *   Read from cvent_registration_mock table instead of live Cvent.
 *   Use test versions of queue databases.    */
$test_mode = false;
$options = getopt('t');
if (array_key_exists('t', $options)) {
    $test_mode = true;
}

if ($test_mode) {
    // Require the test database configuration settings.
    require_once __DIR__ . $path . '/includes/db_config_2_test.php';
} else {
    // Require the normal database configuration settings.
    require_once __DIR__ . $path . '/includes/db_config_2.php';
}

// Load the DMS connection configuration.
require_once __DIR__ . $path . '/includes/dms/dms_config.php';

// Require the Cvent configuration settings.
require_once __DIR__ . $path . '/cvent/cvent_config.php';

// Require QuickBooks configuration settings.
require_once __DIR__ . $path . '/quickbooks/qb_consulting_config.php';

// Require the Cvent PHP library.
require_once __DIR__ . $path . '/lib/CventClient/php-cvent-master/CventClient.class.php';

// Require the QuickBooks PHP DevKit library.
require_once __DIR__ . $path . '/lib/QuickBooksPhpDevKit/quickbooks-php-master/QuickBooks.php';

// Initialize the MySQL database connections.
$sdi_db      = Scs\ScsDataIntegrationDb::getInstance();
$qbqueue_db = new Scs\MysqlDatabase3($scs_qb_queue_db);
$qbdevkit_db = new Scs\Integration\Quickbooks\QbPhpdevkitDb($scs_qb_pdk_db);

if ((!$sdi_db->connection) ||
    (!$qbqueue_db->connection) ||
    (!$qbdevkit_db->connection)) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Cannot run Cvent-QuickBooks integration script: MySQL connection failed.'
    );
    exit();
}

// Initialize and log in to Cvent.
$cvent = Scs\CventAccess::getInstance($test_mode);
$cvent->login();

// Set up CventQuickbooksIntegration object.
$cqi = new Scs\CventQuickbooksIntegration($logger, 'scs_consulting');
$cqi->setDatabases($sdi_db, $qbqueue_db, $qbdevkit_db);

// Log in to Nest API.
$nest_token = '';
$nest_api = Nest\Api::getInstance();
if ($result = $nest_api->login(NEST_CVENT_USER, NEST_CVENT_PASS)) {
    if (is_object($result) && !empty($result->token)) {
        $nest_token = $result->token;
    }
}
else {
    $logger->addError(
        __FILE__ . ' - ' . __LINE__ . ': Error querying Nest API, terminating'
    );
    exit();
}

// Verify login succeeded.
if (empty($nest_token)) {
    $logger->addError(
        __FILE__ . ' - ' . __LINE__ . ': Login to Nest API failed: empty token'
    );
    exit;
}

// for testing
//$logger->addDebug( __FILE__ . ' - ' . __LINE__ . ': Breakpoint: end execution for testing.');
//exit;

// Retrieve new registrations from Cvent.
$registrations = $cvent->getNewRegistrations();

foreach ($registrations as $key => $cvent_reg) {
    $cvent_status = $cvent_reg->getCventQueueStatus();
    if ($cvent_status === false) {
        $logger->addError(
            __FILE__ . ' - ' . __LINE__ .
            ': Error checking cvent registration status, terminating'
        );
        exit();
    }
    if ($cvent_status !== Scs\CventObject::CVENT_STATUS_NOT_IN_QUEUE) {
        // Registration is already in Cvent queue.
        continue;
    }

    // TODO: eliminate problem characters (CTRL)

    // Add registration to Cvent queue.
    $cvent_reg->addToCventQueue();
}

// Retrieve all open registrations from queue.
$cqi->loadRegistrationsFromQueue();

// Mark some registrations as primary for the purpose of aggregation.
$cqi->aggregateInvoices();

// Process the registrations.
$cqi->processNewRegistrations($nest_token);

$logger->addDebug(
    __FILE__ . ' - ' . __LINE__ .
    ': Execution completed.'
);

/**
 * Set up Monolog logger.
 *
 * @param string $log_dir
 *     folder for log files
 * @param string $channel
 *     identifier for this part of application
 * @param string $alert_email_address
 *     email address to send alerts to
 *
 * @return object
 *     Monolog\Logger instance
 */
function getLogger($log_dir, $channel, $alert_email_address)
{
    global $logger;

    if (is_a($logger, '\Monolog\Logger')) {
        return $logger;
    }

    // Set up Monolog logger.
    $logger = new Logger($channel);

    // Debug log, stores all events.
    $logger->pushHandler(new RotatingFileHandler(
        $log_dir . '/debug.log',
        1095,
        Logger::DEBUG
    ));

    // Error log, stores events of level warning and above.
    $logger->pushHandler(new StreamHandler(
        $log_dir . '/error.log',
        Logger::WARNING
    ));

    // Error alert, sends email for events of level error and above.
    $validated_email = filter_var(
        $alert_email_address,
        \FILTER_VALIDATE_EMAIL
    );
    if (!empty($validated_email)) {
        $to = $validated_email;
        $subject = 'Error alert: ' . $channel;
        $from = 'donotreply@scscertified.com';
        $level = Logger::ERROR;
        $logger->pushHandler(new NativeMailerHandler(
            $to,
            $subject,
            $from,
            $level
        ));
    } else {
        $logger->error(
            __FILE__ . ' line ' . __LINE__ . ': ' . __METHOD__ .
            ': Invalid alert email address: "' .
            $alert_email_address . '"'
        );
    }

    $logger->debug('Logger initialized');

    return $logger;
}
