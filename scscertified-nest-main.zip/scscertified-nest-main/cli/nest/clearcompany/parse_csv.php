<?php
/**
 * Including below required libraries 
 * -SimpleXLSX.php It is a library for reading the xlsx file parse into the PHP variables.
 * -phpseclib It is a Library for reading files from the remote computer.
 */
require_once 'includes/SimpleXLSX/SimpleXLSX.php';
require_once 'includes/phpseclib/vendor/autoload.php';
require_once 'includes/cc_config.php';
require_once 'ccapi/clear-company.php';
use Shuchkin\SimpleXLSX;
use phpseclib3\Net\SFTP;
use ClearCompany\ClearCompany;

/**
 * Parse XLSX file from Remote and Send File Date Via API.
 */
class ParseCsv 
{
    /**
     * Constructor Function that executes automatically on initialized.
     */
    /**
     * API Required fields
     * JobTitle - In sheet
     * JobDescription - In sheet
     * DepartmentGuid - Not given in the sheet (Check i department API, and get guid by name value from sheet, if dept not exist create new using dept API)
     * OfficeGuid - Not given in the sheet (No column found in the sheet for the value)
     * HiringManagerGuid - Not given in the sheet (No column found in the sheet for the value)
     * RecruiterGuid - Not given in the sheet (No column found in the sheet for the value)
     * 
     * Mapped fields (Left is of sheet column name and right is of API parameters)
     * Job Code - 
     * Job Description Name - JobTitle
     * Company: OfficeGuid (b0eca7d8-ab22-fbb8-06ed-462c2573ad63)
     * Division: HiringManagerGuid (d02f3ada-07ea-b57d-4dd2-875bebec905c)
     * Department: DepartmentName/DepartmentGuid (941c8dc3-4eab-02f7-e204-4c9f9439e7e0)
     * EEO Code: EEOCode
     * FLSA Code: SalaryType
     * Salary Min : SalaryLow
     * Salary Midpoint : SalaryHigh + SalaryLow) / 2
     * Job Posting - JobDescription
     * 
     */
    public function __construct()
    {  
        $this->cc_api = new ClearCompany();
        /** This will get the xlsx file from the directory and make it useful so that we can use it in the PHP variables. */   
        $this->save_values_to_cc();
          
        /**
         * Below is the API which I found useful and the column names we have in the XLSX file.
         * Requisition API
         * JobCode 
         * Job Description Name
         * Title
         * Company:
         * Division:
         * Department:
         * EEO Code:
         * FLSA Code:
         * Salary Min
         * Salary Midpoint
         * Job Posting
         */
    }

    /**     
     * The function for copying the XLSX file from the remote address (SFTP).
     * It will get the File from remote computer and save it locally with the name (SCS_Global_Job_Description.xlsx) to use it later for parsing it in the PHP variables.
     */
    public function get_remote_file()
    {
        /*Initialize the SFTP library to read the file from the given login details. it will copy the file from given path aka '/Staging/Outbound/SCS_Global_Job_Description.xlsx' into the root folder as the file name
        SCS_Global_Job_Description.xlsx.
        */
        $sftp = new SFTP(SFTP_HOST);
        if( $sftp ) {
            $sftp->login(SFTP_USER, SFTP_PASSWORD);
            $sftp->get('/Staging/Outbound/SCS_Global_Job_Description.xlsx', 'SCS_Global_Job_Description.xlsx');
        } else {
            $this->add_log(__FILE__ . ' line ' . __LINE__ . ': ' . $sftp);
        }
        
    }

    /**
     * Add Errors / Debug Message To The Log File.
     * @param string $log_msg Message / Error to be logged.
     */
    public function add_log( $log_msg )
    {
        $log_filename = "log";
        if (!file_exists($log_filename))  {
            // create directory/folder uploads.
            mkdir($log_filename, 0777, true);
        }
        $log_file_data = $log_filename.'/log_' . date('d-M-Y') . '.log';

        //Add error messages / logs to the file.
        file_put_contents($log_file_data, print_r($log_msg,true). "\n", FILE_APPEND);
    }

    /**
     * To read a single row from the file 'SCS_Global_Job_Description.xlsx' and save the row values into the PHP array variable, we can use that variable to map with the API parameters.
     * The array variable is $rows. and to get the values we need to use the column header values, aka to get the Title we need to use $row_values['title'], to get the "Company" we need to use $row_values['Company'], and so on.
     */
    public function parse_file()
    {
        //$this->get_remote_file();
        $inputFileName = 'SCS_Global_Job_Description.xlsx';
        // Produce array keys from the array values of 1st array element
        $header_values = $rows = [];
        
        if ($xls = SimpleXLSX::parse($inputFileName)) {
            $row_values = $xls->rows();
            foreach ( $xls->rows() as $k => $r ) {
                if ( $k === 0 ) {
                    $header_values = $r;
                    foreach ($header_values as &$value) {
                        $temp_value = strtolower(str_replace(' ', '_', $value));
                        $value = str_replace(":",'',$temp_value);
                     }
                    continue;
                }
                $rows[] = array_combine( $header_values, $r );
                //$this->add_log(__FILE__ . ' line ' . __LINE__ . ': ' . $k );
            }          
        } else {
            $this->add_log(__FILE__ . ' line ' . __LINE__ . ': ' . SimpleXLSX::parseError());   
        }
        return $rows;
    }

    public function save_values_to_cc() {
        $jdx_values = $this->parse_file();
        $api_params = [];
        foreach( $jdx_values as $column_header => $row_value ) {
            $dept_guid = $this->get_department_guid( $row_value['department'] );
            $api_params['JobTitle'] = $row_value['job_description_name'];
            $api_params['JobDescription'] = $row_value['job_posting'];
            $api_params['OfficeGuid'] = 'b0eca7d8-ab22-fbb8-06ed-462c2573ad63';
            $api_params['DepartmentGuid'] = $dept_guid;
            $api_params['HiringManagerGuid'] = 'd02f3ada-07ea-b57d-4dd2-875bebec905c';
            $api_params['RecruiterGuid'] = '4f8f2936-2422-a261-c8b7-121408ceb1c3';
            $api_params['EEOCode'] = $row_value['eeo_code'];
            $api_params['SalaryType'] = "Per" . $row_value['flsa_code'];
            $api_params['SalaryLow'] = $row_value['salary_min'];
            $this->add_log($api_params);
            print_r($api_params);
            break;
        }
    }

    public function get_department_guid( $name ) {
        $name = str_replace(' ','%20',$name);       
        $url = 'https://api.clearcompany.com/v1/departments/active?$filter=substringof(Name,\''.$name.'\')';
        /*$api_request_parameters = array('filter'=>"substringof\(Name,".$name."\)");
        $url .= "?".http_build_query($api_request_parameters);*/
        $guid = $this->cc_api->get_dept_details_by_name($url);
        return $guid;
    }
}
 
//Initilize the Class variable to begin the exexution of the script.
$ParseCsvObj = new ParseCsv();

