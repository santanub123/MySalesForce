<?php
/**
 * The base configuration.
 */

define( 'SFTP_HOST', 'clientftp.hrtms.com' );
define( 'SFTP_USER', 'ftp_scsglobalservices' );
define( 'SFTP_PASSWORD', 'aNjs5&rTu9Aj13' );
define( 'CC_API_USERNAME', 'SCSGlobalServices' );
define( 'CC_API_PWD', 'Scientific@CC1' );