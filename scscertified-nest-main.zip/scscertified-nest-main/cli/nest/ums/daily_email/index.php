<?php 

/**
 * @file daily_email.php
 * @author D. Llose
 * @date 2018-09-13
 *
 * Runs the daily e-mail for users that will run on their start date.
 */

// base values
$path = __DIR__ . '/../../../../sites/nest';
require_once "$path/nest_config.php";

require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');
$loader->addNamespace('Nest', $path . '/src');

// Set logging
$relative_error_log_dir = '/nest/ums/daily_email';
$error_log_dir = $path . '/../../log/' . $relative_error_log_dir;
$nestTop = new Scs\NestTop;
$nestTop->set_error_log($error_log_dir);

$nest_token = '';
$nest_api = \Nest\Api::getInstance();
$result;
if ($result = $nest_api->login(\NEST_API_USER, \NEST_API_PASS)) {
    if (is_object($result) && !empty($result->token)) {
        $nest_token = $result->token;
    }
}
else {
    error_log(
        __FILE__ . ' - ' . __LINE__ . ': Error querying Nest API, terminating'
    );
    exit();
}

$api_endpoint = '/person/dailyEmail/'; // ApiBundle::EmailController

// diagnostic
/*
$fq_endpoint = NEST_DOMAIN . (BASE_PORT ? ':' . BASE_PORT : '') . NEST_API_RELATIVE_URL . $api_endpoint;
echo "\n";
echo $nest_token . "\n";
echo $fq_endpoint . "\n";
*/

$result = $nest_api->call($nest_token, $api_endpoint);

$persons = $result->data;

$column_names = array(
    array("App ID", "ID", "First Name", "Last Name", "E-mail", "Start Date", "End Date", "Sent Activation Date", "Comment")
);

$ums_id = 1;

if (count($persons) > 0) {
      
    foreach ($persons as $person) {
        $start_date = !empty($person->startDate) ? (new DateTime($person->startDate))->format('Y-m-d H:i:s') : ""; 
        $end_date   = !empty($person->endDate)   ? (new DateTime($person->endDate))->format('Y-m-d H:i:s') : "";
        $now = date("Y-m-d H:i:s");
        Scs\ApplicationLog::logToCSV(
            NEST_PATH_LOG . '/nest/ums/daily_email/', // file directory 
            'daily_email',                            // file name (+ .csv)
            array(
                array(
                    $ums_id, 
                    $person->id,
                    $person->nameFirst,
                    $person->nameLast,
                    $person->email1,
                    $start_date, //The Date should be like this if I use the $person->startDate->date like on the NEST_PATH_LOG/nest/ums/deactivate_user/index.php, but it outputs an empty String. This is weird because they're both returned from a View instance;
                    $end_date,
                    $now
                )
            ),
            $column_names
        );
    }
}

if ($result->code > 299 || $result->code < 0) {
    error_log(__FILE__ . ': Api.php error: ' . $result->code . ' - message: ' . $result->message);
    // TODO: record output if count > 0
    //error_log(__FILE__ . ': Api.php count: ' . $result->count . ' - data: ' . print_r($result->data, true));
}
    
Scs\ApplicationLog::logToCSV(
    NEST_PATH_LOG . '/nest/ums/daily_email/', // file directory 
    'daily_email',                            // file name (+ .csv)
    array(
        array(
            $ums_id, 
            '', //$person->id,
            '', //$person->nameFirst,
            '', //$person->nameLast,
            '', //$person->email1,
            '', //$start_date,
            '', //$end_date,
            date("Y-m-d H:i:s"),
            'Execution finished.'
        )
    ),
    $column_names
);

// deprecated -- use Api.php instead (above)
/*
$curl = curl_init($end_point);
$header[] = 'Authorization: Bearer ' . $nest_token;
$curl_opts = array(
          \CURLOPT_URL            => $end_point,
          \CURLOPT_HTTPHEADER     => $header,
          \CURLOPT_CUSTOMREQUEST  => 'GET',
          \CURLOPT_SSL_VERIFYPEER => false,
          \CURLOPT_SSL_VERIFYHOST => false,
          \CURLOPT_MAXREDIRS      => 5, // any limit at all will prevent endless redirects
          \CURLOPT_FOLLOWLOCATION => true,
);

curl_setopt_array($curl, $curl_opts);

$result = curl_exec($curl);
$errno = curl_errno($curl);
$errmsg = curl_error ($curl);

curl_close($curl);

if ($errno) {
    error_log(__FILE__ . ': cURL error ' . $errno . ' - ' . $errmsg);
}
*/
