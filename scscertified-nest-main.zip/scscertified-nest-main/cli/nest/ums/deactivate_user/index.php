<?php 

/**
 * @file deactivate_user.php
 * @author D. Llose
 * @date 2018-09-13
 *
 * Runs the daily cron for deactivating persons based on their end date.
 */

// base values
$path = __DIR__ . '/../../../../sites/nest';
require_once "$path/nest_config.php";

// load and initialize the autoloader
require_once "/$path/includes/Psr4Autoloader.php";
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', "/$path/includes/src");
$loader->addNamespace('Nest', "/$path/src");

// Set logging
$relative_error_log_dir = 'nest/ums/deactivate_user';
$error_log_dir = $path . '/../../log/' . $relative_error_log_dir;
$nestTop = new Scs\NestTop;
$nestTop->set_error_log($error_log_dir);

$nest_token = '';
$nest_api = \Nest\Api::getInstance();
$result = $nest_api->login(\NEST_API_USER, \NEST_API_PASS);

if (is_object($result) && !empty($result->token)) {
    $nest_token = $result->token;
}
else {
    error_log(
        __FILE__ . ' - ' . __LINE__ . ': Error while logging into Nest API, terminating'
    );
    exit();
}

$endpoint = '/person/cron/deactivateUserOnEndDate';
$result = $nest_api->call($nest_token, $endpoint);
$persons = $result->data;

/*
$deactivated_user_list_file = "$error_log_dir/actions.log";

// if the file doesn't exist, create it
if (!is_file($deactivated_user_list_file)) {
  file_put_contents($deactivated_user_list_file, '');
}
*/

$ums_id = 1;

$column_names = array(
  array("App ID", "ID" , "First Name", "Last Name", "E-mail", "Start Date", "End Date", "Deactivation Date", "Comment")
);

if (!empty($persons)) {
  
  foreach($persons as $person) {
    $start_date = !empty($person->startDate) ? (new DateTime($person->startDate->date))->format('Y-m-d H:i:s') : ""; 
    $end_date = !empty($person->endDate) ? (new DateTime($person->endDate->date))->format('Y-m-d H:i:s') : ""; 
    $now = date("Y-m-d H:i:s");
    
    Scs\ApplicationLog::logToCSV(
      NEST_PATH_LOG . '/nest/ums/deactivate_user/', // file path
      'deactivated_users',                          // file name
      array(
        array(
          $ums_id,
          $person->id,
          $person->nameFirst,
          $person->nameLast,
          $person->email1,
          $start_date,
          $end_date,
          $now
        )
      ),
      $column_names
    );
  
  }
  
  exit();

}

Scs\ApplicationLog::logToCSV(
  NEST_PATH_LOG . '/nest/ums/deactivate_user/', // file path
  'deactivated_users',                          // file name
  array(
    array(
      $ums_id,
      '', //$person->id,
      '', //$person->nameFirst,
      '', //$person->nameLast,
      '', //$person->email1,
      '', //$start_date,
      '', //$end_date,
      date("Y-m-d H:i:s"),
      'Execution finished.'
    )
  ),
  $column_names
);