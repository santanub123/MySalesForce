<?php

/**
 * Internal Audit Portal daily processing
 * This file is executed once per day via a cron job
 */

// base values
$path = __DIR__ . '/../../../sites/nest';
require_once "$path/nest_config.php";
require_once "$path/includes/nest_functions.php";

// configure PHP
set_error_log(NEST_PATH_LOG . '/nest/iap/');
ini_set('error_reporting', E_ALL);

// Load and initialize the autoloader.
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');
$loader->addNamespace('Nest', $path . '/src');


// Initialize $g_nest_app_key.
require_once $path . '/iap/inc/nest_key_iap.php';

// Load data and initialize autoloader for \Scs\, \Iap, \EmailTemplate, \Logger
require_once $path . '/iap/inc/iap_top.php';

// Verify that the request is locally requested.
$ssec = new Scs\ScsSecurity;
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request'
    );
    exit();
}

// Initialize IAP database connection.
$g_iap_db = Iap\IapNestDb::getInstance($iap_nest_db_config);

// Log in to Nest API.
$nest_token = '';
$nestApi = Nest\Api::getInstance();

if ($result = $nestApi->login(NEST_API_USER, NEST_API_PASS)) {
    if (is_object($result) && !empty($result->token)) {
        $nest_token = $result->token;
    }
} else {
    error_log(
        __FILE__ . ' - ' . __LINE__ . ': Error querying Nest API, terminating'
    );
    exit();
}

// Verify that login succeeded.
if (empty($nest_token)) {
    error_log(
        __FILE__ . ' - ' . __LINE__ . ': Login to Nest API failed: empty token'
    );
    exit;
}

// This provokes an non-fatal error in line 57 of Authorize.php due to headers already having been sent.
// However, this object is required in Iap.php class as a global variable.
// The error does not seem to be a problem for this script, but would be nice to fix. (VR)
$nestAuthorize = new Nest\Authorize();

/**
 * Provide Nest token to the person manager, and populate lists of
 * users that have specific IAP privileges.
 */
Nest\PersonManager::setNestToken($nest_token);
//Nest\PersonManager::loadPrivilegeList($g_nest_app_key, PRIVILEGE_IAP_MUTE);
Nest\PersonManager::loadPrivilegeList($g_nest_app_key, PRIVILEGE_IAP_DELETE);
$person_list = Nest\PersonManager::getStaffNamesArray();

$iap = new Iap\Iap;

$url = BASE_PROT . '://'.$NEST_DOMAIN."/iap/";
$link_text = 'View My Dashboard';

$users = array();
//API Query to retrieve all users who should receive Weekly Email ~ 200 persons
$path = '/assignedroles/{"privilegeroles.privilegeId":[7,8,11,49]}/{"dql_flat_result":"1","dql_include_entities":["privilegeroles"],"dql_operators":{"privilegeroles.privilegeId":"IN"}}';
$arguments = [];
$method = 'GET';
$result = $nestApi->call($nest_token, $path, $arguments, $method);

$users_array = array();
foreach($result->data as $r) {
  //print $person_list[$r->personId]['name'] . ' ' . $person_list[$r->personId]['user_status'] . "\n";
  if (!empty($person_list[$r->personId]['user_status'])) $users_array[] = $r->personId;
}
$users = array_unique($users_array);

if (!empty($users)) {
    $emailTemplates = new \Scs\EmailTemplates();
    $headers = $emailTemplates->getHeaders();
    $finding_text = 'Finding';
    $findings_text = 'Findings';

    $i = 0;

    //Run Stats query and send email to each user
    foreach($users as $user_id) {
        $send_to = '';
        $query = "
        SELECT 
        SUM(case WHEN status = 'Overdue' then 1 else 0 end) AS overdue,
        SUM(case WHEN status = 'Open' AND date_due >= DATE(NOW()) AND date_due < DATE(DATE_ADD(NOW(), INTERVAL 7 DAY)) then 1 else 0 end) AS this_week,
        SUM(case WHEN status = 'Open' AND date_due >= DATE(NOW()) AND date_due < DATE(DATE_ADD(NOW(), INTERVAL 3 MONTH)) then 1 else 0 end) AS three_months,
        SUM(case WHEN status = 'Open' then 1 else 0 end) AS open,
        SUM(case WHEN status = 'Pending-Evidence' then 1 else 0 end) AS evidence
        FROM (SELECT DISTINCT f.id, f.status, f.date_due FROM finding f
        LEFT OUTER JOIN assigned_auditors aa ON f.id = aa.finding_id
        LEFT OUTER JOIN assigned_persons ap ON f.id = ap.record_id
        WHERE ((aa.user_id = $user_id AND aa.owner = 1) OR ap.user_id = $user_id OR f.responsible_person = $user_id)) fa;";

        $records = array();
        $content = '';
        $stmt = Iap\Iap::$database->connection->prepare($query);
        $results = $stmt->execute();
        if ($results !== false) {
            $records = $stmt->fetchAll();
            $stats = $records[0];
            
            if (!empty($stats['overdue']) || !empty($stats['this_week']) || !empty($stats['three_months']) || !empty($stats['evidence'])) {
                $i++;
                
                $send_to = $person_list[$user_id]['user_email'];
                
                if (!empty(TEST_EMAILS)) $send_to = TEST_EMAILS;

                $subject = 'Weekly Summary of My Audit Findings';
                $title = 'Audit Findings - Weekly Summary for ' . $person_list[$user_id]['name'];
                $url_finding = $url . 'findings/?person=' . $user_id;

                $content .= 'Visit <a href="'. $url . '">My Dashboard</a> to view your overdue and upcoming findings:<br /><br />
                You have <a href="'. $url_finding . '&status=Overdue">' . $stats['overdue'] . ' ' . ngettext($finding_text, $findings_text, $stats['overdue']) . '</a> with status <span style="color: red;">Overdue</span><br />
                You have <a href="'. $url_finding . '&due_date_start=' . date('Y-m-d', time()) . '&due_date_end=' . date("Y-m-d", strtotime("+6 day")) . '">' . $stats['this_week'] . ' ' . ngettext($finding_text, $findings_text, $stats['this_week']) . '</a> due this week<br />
                You have <a href="'. $url_finding . '&status=Open&due_date_start=' . date('Y-m-d', time()) . '&due_date_end=' . date('Y-m-d', strtotime("+3 month")) . '">' . $stats['three_months'] . ' Findings</a> due within the next 3 months<br />
                You have <a href="'. $url_finding . '&status=Open">' . $stats['open'] . ' ' . ngettext($finding_text, $findings_text, $stats['open']) . '</a> with status Open<br />
                You have <a href="'. $url_finding . '&status=Pending-Evidence">' . $stats['evidence'] . ' ' . ngettext($finding_text, $findings_text, $stats['evidence']) . '</a> with status Pending Evidence</a><br />';
                
                $body = '
                <table frame="box" width="100%" style="background: #fff; border-collapse: collapse; padding: 0; font-family: Helvetica, garamond, Arial, sans-serif; font-size:16px; font-weight:normal; font-style:normal; table-layout: fixed; border: 1px solid #9d9d9d;">
                <tr valign="top" style="padding: 20px;">
                <td align="left">
                <p>' . $content . '</p>
                </td>
                </tr>
                </table><br />
                ';

                if (!empty($send_to)) {
                    $body = $emailTemplates->generateTemplate($title, $body, array("link_text" => $link_text, "url" => $url));
                    mail($send_to, $subject, $body, $headers);

                    $iap->logEmail(array($send_to), $user_id, '', '', 'weekly_summary', 'Report');
                }
            }
        }
    }
}  else {
  error_log(__FILE__ . ': ' . __LINE__ . ': No users found for Weekly Summaries : ' . Iap\Iap::$database->connection->errorInfo());
}

//Set up Log Folder
$now = date("Y-m-d H:i:s");
$app_id = 3;

\Scs\ApplicationLog::logToCSV(
    NEST_PATH_LOG . '/nest/iap/', //PHP 7. The path of file 
    'cron', //filename
    array(
        array($now, $app_id, 'weekly_summary', 'Weekly Summary run complete: ' . $i . ' emails sent'),
    ),
    $cron_log_columns
  );
exit;
