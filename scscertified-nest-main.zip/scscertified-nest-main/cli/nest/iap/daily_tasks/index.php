<?php

/**
 * Internal Audit Portal daily processing
 * This file is executed once per day via a cron job
 */

// base values
$path = __DIR__ . '/../../../../sites/nest';
require_once $path . '/nest_config.php';

// configure PHP
ini_set('error_reporting', E_ALL);

// Load and initialize the autoloader.
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');
$loader->addNamespace('Nest', $path . '/src');

// Set logging
$relative_error_log_dir = 'nest/iap/daily_tasks';
$error_log_dir = $path . '/../../log/' . $relative_error_log_dir;
$nestTop = new Scs\NestTop;
$nestTop->set_error_log($error_log_dir);

// Initialize $g_nest_app_key.
require_once $path . '/iap/inc/nest_key_iap.php';

// Load data and initialize autoloader for \Scs\, \Iap, \EmailTemplate, \Logger
require_once $path . '/iap/inc/iap_top.php';

// Verify the request is locally requested.
$ssec = new Scs\ScsSecurity;
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request'
    );
    exit();
}

// Set application log (vs. error log)
$app_log = new \Scs\ApplicationLog(
                              $relative_error_log_dir,
                              '',
                              FALSE); // remember -- that log location has to exist, as it stands!
$headings = array('Time', 'Result');
$app_log->write($headings);

// Initialize IAP database connection.
$g_iap_db = Iap\IapNestDb::getInstance($iap_nest_db_config);

// Log in to Nest API.
$nest_token = '';
$nestApi = Nest\Api::getInstance();
if ($result = $nestApi->login(NEST_API_USER, NEST_API_PASS)) {
    if (is_object($result) && !empty($result->token)) {
        $nest_token = $result->token;
    }
}
else {
    error_log(
        __FILE__ . ' - ' . __LINE__ . ': Error querying Nest API, terminating'
    );
    exit();
}

// Verify that login succeeded.
if (empty($nest_token)) {
    error_log(
        __FILE__ . ' - ' . __LINE__ . ': Login to Nest API failed: empty token, terminating'
    );
    exit;
}

// This provokes an non-fatal error in line 57 of Authorize.php due to headers already having been sent.
// However, this object is required in Iap.php class as a global variable.
// The error does not seem to be a problem for this script, but would be nice to fix. (VR)
$nestAuthorize = new Nest\Authorize();

/**
 * Provide Nest token to the person manager, and populate lists of
 * users that have specific IAP privileges.
 */
Nest\PersonManager::setNestToken($nest_token);
//Nest\PersonManager::loadPrivilegeList($g_nest_app_key, PRIVILEGE_IAP_MUTE);
Nest\PersonManager::loadPrivilegeList($g_nest_app_key, PRIVILEGE_IAP_DELETE);

$iap = new Iap\Iap;

/* Schedule of actions, each action specified by an associative array:
 *    action        = identifier recognized by this script and/or Iap::notify()
 *    interval      = interval specification for DateInterval::__construct()
 *    interval_dir  = 'future' | 'past'
 *    filter        = string to add to MySQL WHERE clause, to select records
 */
$actions = array(
    array('action' => 'due_90_days',
          'interval' => 'P90D',
          'interval_dir' => 'future',
          'filter' => "status = 'Open' AND (significance = 'Minor' OR significance = 'Observation')"),
    array('action' => 'due_30_days',
          'interval' => 'P30D',
          'interval_dir' => 'future',
          'filter' => "status = 'Open' AND significance = 'Major'"),
    array('action' => 'due_7_days',
          'interval' => 'P7D',
          'interval_dir' => 'future',
          'filter' => "status = 'Open'"),
    array('action' => 'due_today',
          'interval' => null,
          'interval_dir' => null,
          'filter' => "status = 'Open'"),
    array('action' => 'set_status_overdue',
          'interval' => 'P1D',
          'interval_dir' => 'past',
          'filter' => "status = 'Open' AND date_due != '0000-00-00'"),
    array('action' => 'overdue_30',
          'interval' => 'P30D',
          'interval_dir' => 'past',
          'filter' => "status = 'Overdue'"),
    array('action' => 'overdue_44',
          'interval' => 'P44D',
          'interval_dir' => 'past',
          'filter' => "status = 'Overdue'")
                );

// Send reminders based on due date
foreach ($actions as $a) {
  // select the due date
  $due_date = new DateTime('now', new DateTimeZone('America/Los_Angeles'));
  if ($a['interval']) {
    if ($a['interval_dir'] == 'future') {
      $due_date->add(new DateInterval($a['interval']));
    } else if ($a['interval_dir'] == 'past') {
      $due_date->sub(new DateInterval($a['interval']));
    }
  }

  $operator = '=';
  if ($a['action'] == 'set_status_overdue') $operator = '<=';
  // query for the relevant records
  $query = "SELECT id FROM finding WHERE date_due $operator '" .
            $due_date->format('Y-m-d') . "'";
  if ( $a['filter'] && ($a['filter'] <> '') ) {
    $query .= ' AND ' . $a['filter'];
  }
  $stmt = Iap\Iap::$database->connection->prepare($query);
  $results = $stmt->execute();
  if ($results !== false) {
    $record_ids = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

    // process the actions
    if ($a['action'] == 'set_status_overdue') {
      foreach ($record_ids as $id) {
        $iap->set_status($id, 'Overdue');
        // print_r("$id, set status 'Overdue'\n");   // for testing
        
        // Run log (vs. error log)
        $message = ' - Setting status Overdue for ' . $a['action'] . ' for finding id ' . $id;
        $time = date('Y-m-d H:i:s', time());
        $app_log->write([$time, $message]);
      }
    }
    else {
      foreach ($record_ids as $id) {
        $iap->notify($id, $a['action']);
        //print_r("$id, notify {$a['action']}\n");  // for testing
        
        // Run log (vs. error log)
        $message = ' - Notifying for ' . $a['action'] . ' for finding id ' . $id;
        $time = date('Y-m-d H:i:s', time());
        $app_log->write([$time, $message]);
        
        sleep(1);
      }
    }

    $stmt->closeCursor();
  }
  else {
    error_log(__FILE__ . ': ' . __LINE__ . ': No due date reminders for ' . $a['action'] . ': ' . $query .
              ': ' . Iap\Iap::$database->connection->errorInfo());
  }
  
  //error_log(__FILE__ . ': ' . __LINE__ . ': ' . $message);
  
  // Run log (vs. error log)
  $message = 'Action ' . $a['action'] . ' processed.';
  $time = date('Y-m-d H:i:s', time());
  $app_log->write([$time, $message]);
  
}

// Send bimonthly notifications for 'Pending' NCRs
$now = new DateTime('now', new DateTimeZone('America/Los_Angeles'));
$d = $now->format('d');
if ( ($d == '01') || ($d == '15') ) {
  $query = "SELECT id FROM finding WHERE status = 'Pending-Evidence'";
  $stmt = Iap\Iap::$database->connection->prepare($query);
  $results = $stmt->execute();
  if ($results !== false) {
    $record_ids = $stmt->fetchAll(\PDO::FETCH_COLUMN, 0);
    foreach ($record_ids as $id) {
      $iap->notify($id, 'pending');
      //print_r("$id, notify 'pending'\n");  // for testing
      
      // Run log (vs. error log)
      $message = ' - Notifying for pending evidence for finding id ' . $id;
      $time = date('Y-m-d H:i:s', time());
      $app_log->write([$time, $message]);
      
      sleep(1);
    }
  }
  else {
    error_log(__FILE__ . ': ' . __LINE__ . ': No bimonthly notifications for: ' . $query .
              ': ' . Iap\Iap::$database->connection->errorInfo());
  }
}

$message = 'Run complete.';
$time = date('Y-m-d H:i:s', time());
$app_log->write([$time, $message]);
