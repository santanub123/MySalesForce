<?php

/**
 * Internal Audit Portal daily processing
 * This file is executed once per day via a cron job
 */

// base values
$path = __DIR__ . '/../../../sites/nest';
require_once "$path/nest_config.php";
require_once "$path/includes/nest_functions.php";

// configure PHP
$error_log_path = NEST_PATH_LOG . '/nest/iap/';
set_error_log($error_log_path);
ini_set('error_reporting', E_ALL);

// Load and initialize the autoloader.
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');
$loader->addNamespace('Nest', $path . '/src');


// Require the Nest configuration settings.
require_once $path . '/nest_config.php';

// Initialize $g_nest_app_key.
require_once $path . '/iap/inc/nest_key_iap.php';

// Load data and initialize autoloader for \Scs\, \Iap, \EmailTemplate, \Logger
require_once $path . '/iap/inc/iap_top.php';

// Verify that the request is locally requested.
$ssec = new Scs\ScsSecurity;
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request'
    );
    exit();
}

// Initialize IAP database connection.
$g_iap_db = Iap\IapNestDb::getInstance($iap_nest_db_config);

// Log in to Nest API.
$nest_token = '';
$nestApi = Nest\Api::getInstance();
if ($result = $nestApi->login(NEST_API_USER, NEST_API_PASS)) {
    if (is_object($result) && !empty($result->token)) {
        $nest_token = $result->token;
    }
} else {
    error_log(
        __FILE__ . ' - ' . __LINE__ . ': Error querying Nest API, terminating'
    );
    exit();
}

// Verify that login succeeded.
if (empty($nest_token)) {
    error_log(
        __FILE__ . ' - ' . __LINE__ . ': Login to Nest API failed: empty token'
    );
    exit;
}

// This provokes an non-fatal error in line 57 of Authorize.php due to headers already having been sent.
// However, this object is required in Iap.php class as a global variable.
// The error does not seem to be a problem for this script, but would be nice to fix. (VR)
$nestAuthorize = new Nest\Authorize();

/**
 * Provide Nest token to the person manager, and populate lists of
 * users that have specific IAP privileges.
 */
Nest\PersonManager::setNestToken($nest_token);
//Nest\PersonManager::loadPrivilegeList($g_nest_app_key, PRIVILEGE_IAP_MUTE);
Nest\PersonManager::loadPrivilegeList($g_nest_app_key, PRIVILEGE_IAP_DELETE);

$iap = new Iap\Iap;

$due_date = new DateTime('now', new DateTimeZone('America/Los_Angeles'));
$closed_count = 0;
$overdue_count = 0;

$query = "UPDATE finding SET date_due = NULL WHERE date_due = '0000-00-00';";
$stmt = Iap\Iap::$database->connection->prepare($query);
$results = $stmt->execute();

// query for the relevant records
$query = "UPDATE finding SET status = 'Closed' WHERE record_type = 'OFI' AND date_due <= '" . $due_date->format('Y-m-d') . "' AND status = 'Open';";
$stmt = Iap\Iap::$database->connection->prepare($query);
$stmt->execute();

$closed_count = $stmt->rowCount();

// query for the relevant records
$query = "UPDATE finding SET status = 'Overdue' WHERE date_due <= '" . $due_date->format('Y-m-d') . "' AND status = 'Open';";
$stmt = Iap\Iap::$database->connection->prepare($query);
$stmt->execute();

$overdue_count = $stmt->rowCount();

//Set up Log Folder
\Scs\ApplicationLog::createLogFolder(NEST_PATH_LOG, '/nest/iap', '');
$now = date("Y-m-d H:i:s");
$app_id = 3;

\Scs\ApplicationLog::logToCSV(
    NEST_PATH_LOG . '/nest/iap/', //PHP 7. The path of file 
    'cron', //filename
    array(
        array($now, $app_id, 'set_closed', 'Set Closed run complete: ' . $closed_count . ' OFI findings set to "Closed"'),
    ),
    $cron_log_columns
);

\Scs\ApplicationLog::logToCSV(
    NEST_PATH_LOG . '/nest/iap/', //PHP 7. The path of file 
    'cron', //filename
    array(
        array($now, $app_id, 'set_overdue', 'Set Overdue run complete: ' . $overdue_count . ' findings set to "Overdue"'),
    ),
    $cron_log_columns
);