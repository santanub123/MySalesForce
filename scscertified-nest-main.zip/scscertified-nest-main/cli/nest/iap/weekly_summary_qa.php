<?php

/**
 * Internal Audit Portal daily processing
 * This file is executed once per day via a cron job
 */

// base values
$path = __DIR__ . '/../../../sites/nest';
require_once "$path/nest_config.php";
require_once "$path/includes/nest_functions.php";

// configure PHP
$error_log_path = NEST_PATH_LOG . '/nest/iap/';
set_error_log($error_log_path);
ini_set('error_reporting', E_ALL);

// Load and initialize the autoloader.
require_once $path . '/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader;
$loader->register();
$loader->addNamespace('Scs', $path . '/includes/src');
$loader->addNamespace('Nest', $path . '/src');

// Initialize $g_nest_app_key.
require_once $path . '/iap/inc/nest_key_iap.php';

// Load data and initialize autoloader for \Scs\, \Iap, \EmailTemplate, \Logger
require_once $path . '/iap/inc/iap_top.php';

// Verify that the request is locally requested.
$ssec = new Scs\ScsSecurity;
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    error_log(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request'
    );
    exit();
}

// Initialize IAP database connection.
$g_iap_db = Iap\IapNestDb::getInstance($iap_nest_db_config);

// Log in to Nest API.
$nest_token = '';
$nestApi = Nest\Api::getInstance();

if ($result = $nestApi->login(NEST_API_USER, NEST_API_PASS)) {
    if (is_object($result) && !empty($result->token)) {
        $nest_token = $result->token;
    }
} else {
    error_log(
        __FILE__ . ' - ' . __LINE__ . ': Error querying Nest API, terminating'
    );
    exit();
}

// Verify that login succeeded.
if (empty($nest_token)) {
    error_log(
        __FILE__ . ' - ' . __LINE__ . ': Login to Nest API failed: empty token'
    );
    exit;
}

// This provokes an non-fatal error in line 57 of Authorize.php due to headers already having been sent.
// However, this object is required in Iap.php class as a global variable.
// The error does not seem to be a problem for this script, but would be nice to fix. (VR)
$nestAuthorize = new Nest\Authorize();

/**
 * Provide Nest token to the person manager, and populate lists of
 * users that have specific IAP privileges.
 */
Nest\PersonManager::setNestToken($nest_token);
//Nest\PersonManager::loadPrivilegeList($g_nest_app_key, PRIVILEGE_IAP_MUTE);
Nest\PersonManager::loadPrivilegeList($g_nest_app_key, PRIVILEGE_IAP_DELETE);
$person_list = Nest\PersonManager::getStaffNamesArray();

$iap = new Iap\Iap;

$url = BASE_PROT . '://'.$NEST_DOMAIN."/iap/";
$link_text = 'View My Dashboard';


$send_to = 'qa@scsglobalservices.com';

//Build email to send to each user
$query = "
SELECT issuer,
SUM(case WHEN status = 'Overdue' AND DATE(deadline) <= DATE(NOW()) then 1 else 0 end) AS past_deadline,
SUM(case WHEN status = 'Overdue' AND DATE(deadline) >= DATE(NOW()) then 1 else 0 end) AS past_due_within_deadline,
SUM(case WHEN status = 'Overdue' AND deadline IS NULL then 1 else 0 end) AS past_due_no_deadline,
SUM(case WHEN (status = 'Open' OR status = 'Pending-Evidence') AND DATE(date_due) >= DATE(NOW()) AND DATE(date_due) < DATE(DATE_ADD(NOW(), INTERVAL 7 DAY)) then 1 else 0 end) AS this_week,
SUM(case WHEN (status = 'Open' OR status = 'Pending-Evidence') AND DATE(date_due) >= DATE(NOW()) AND DATE(date_due) < DATE(DATE_ADD(NOW(), INTERVAL 3 MONTH)) then 1 else 0 end) AS three_months,
SUM(case WHEN status = 'Pending-Evidence' then 1 else 0 end) AS evidence
FROM finding f 
LEFT JOIN audit a ON a.id = f.audit_id 
WHERE status IN ('Overdue','Open','Pending','Pending-Evidence') GROUP BY issuer";
    
$records = array();
$content = '';
$stmt = Iap\Iap::$database->connection->prepare($query);
$results = $stmt->execute();
$finding_text = 'Finding';
$findings_text = 'Findings';

if ($results !== false) {
    $records = $stmt->fetchAll();

    $url_finding = $url . 'findings/?';
    $content .= 'Visit <a href="'. $url . '">My Dashboard</a> to view your overdue and upcoming findings:<br /><br />';

    foreach($records as $stats) {
        if (!empty($stats['past_deadline']) || !empty($stats['past_due_within_deadline']) || !empty($stats['past_due_no_deadline']) || !empty($stats['this_week']) || !empty($stats['three_months']) || !empty($stats['evidence'])) {
            $content .= '<h3>' . $stats['issuer'] . '</h3>';
            if ($stats['issuer'] == 'SCS') {
                if (!empty($stats['past_deadline'])) $content .= '<a href="'. $url_finding . 'status=Overdue&mode=Internal&deadline_end=' . date('Y-m-d', time()) . '">' . $stats['past_deadline'] . ' ' . ngettext($finding_text, $findings_text, $stats['past_deadline']) . '</a> Past Deadline<br />';
                if (!empty($stats['past_due_within_deadline'])) $content .= '<a href="'. $url_finding . 'status=Overdue&mode=Internal&due_date_end=' . date('Y-m-d', time()) . '&deadline_start=' . date('Y-m-d', time()) . '">' . $stats['past_due_within_deadline'] . ' ' . ngettext($finding_text, $findings_text, $stats['past_due_within_deadline']) . '</a> Past Due within Deadline<br />';
                if (!empty($stats['past_due_no_deadline'])) $content .= '<a href="'. $url_finding . 'status=Overdue&mode=Internal&due_date_end=' . date('Y-m-d', time()) . '">' . $stats['past_due_no_deadline'] . ' ' . ngettext($finding_text, $findings_text, $stats['past_due_no_deadline']) . '</a> Past Due with no Deadline<br />';
                if (!empty($stats['this_week'])) $content .= '<a href="'. $url_finding . 'status=Open,Pending-Evidence&mode=Internal&due_date_start=' . date('Y-m-d', time()) . '&due_date_end=' . date('Y-m-d', strtotime("+6 day")) . '">' . $stats['this_week'] . ' ' . ngettext($finding_text, $findings_text, $stats['this_week']) . '</a> Due this week<br />';
                if (!empty($stats['three_months'])) $content .= '<a href="'. $url_finding . 'status=Open,Pending-Evidence&mode=Internal&due_date_start=' . date('Y-m-d', time()) . '&due_date_end=' . date('Y-m-d', strtotime("+3 month")) . '">' . $stats['three_months'] . ' ' . ngettext($finding_text, $findings_text, $stats['three_months']) . '</a> Due within the next 3 months<br />';
                if (!empty($stats['evidence'])) $content .= '<a href="'. $url_finding . 'mode=Internal&status=Pending-Evidence">' . $stats['evidence'] . ' ' . ngettext($finding_text, $findings_text, $stats['evidence']) . '</a> Pending Evidence<br />';
            } else {
                if (!empty($stats['past_deadline'])) $content .= $stats['past_deadline'] . ' ' . ngettext($finding_text, $findings_text, $stats['past_deadline']) . ' Past Deadline<br />';
                if (!empty($stats['past_due_within_deadline'])) $content .= $stats['past_due_within_deadline'] . ' ' . ngettext($finding_text, $findings_text, $stats['past_due_within_deadline']) . ' Past Due within Deadline<br />';
                if (!empty($stats['past_due_no_deadline'])) $content .= $stats['past_due_no_deadline'] . ' ' . ngettext($finding_text, $findings_text, $stats['past_due_no_deadline']) . ' Past Due with no Deadline<br />';
                if (!empty($stats['this_week'])) $content .= $stats['this_week'] . ' ' . ngettext($finding_text, $findings_text, $stats['this_week']) . ' Due this week<br />';
                if (!empty($stats['three_months'])) $content .= $stats['three_months'] . ' ' . ngettext($finding_text, $findings_text, $stats['three_months']) . ' Due within the next 3 months<br />';
                if (!empty($stats['evidence'])) $content .= $stats['evidence'] . ' ' . ngettext($finding_text, $findings_text, $stats['evidence']) . ' Pending Evidence<br />';
            }
            $content .= '<br />';
        }
    }

    $body = '<table frame="box" width="100%" style="background: #fff; border-collapse: collapse; padding: 0; font-family: Helvetica, garamond, Arial, sans-serif; font-size:16px; font-weight:normal; font-style:normal; table-layout: fixed; border: 1px solid #9d9d9d;">
    <tr valign="top" style="padding: 20px;">
    <td align="left">
    <p>' . $content . '</p>
    </td>
    </tr>
    </table><br />';

    $emailTemplates = new \Scs\EmailTemplates();
    $headers = $emailTemplates->getHeaders();

    //Send email to QA
    $title = 'Audit Findings - Weekly QA Summary';

    if (!empty(TEST_EMAILS)) {
        $send_to = TEST_EMAILS;
    }

    if (!empty($send_to)) {
        $body = $emailTemplates->generateTemplate($title, $body, array("link_text" => $link_text, "url" => $url));
        mail($send_to, $title, $body, $headers);

        $iap->logEmail(array($send_to), '', '', '', 'weekly_summary_qa', 'Report');
    }
}  else {
  error_log(__FILE__ . ': ' . __LINE__ . ': No findings found for Weekly Summaries : ' . Iap\Iap::$database->connection->errorInfo());
}

//Set up Log Folder
$now = date("Y-m-d H:i:s");
$app_id = 3;

\Scs\ApplicationLog::logToCSV(
    NEST_PATH_LOG . '/nest/iap/', //PHP 7. The path of file 
    'cron', //filename
    array(
        array($now, $app_id, 'weekly_summary_qa', 'Weekly QA Summary run complete'),
    ),
    $cron_log_columns
  );
exit;
?>