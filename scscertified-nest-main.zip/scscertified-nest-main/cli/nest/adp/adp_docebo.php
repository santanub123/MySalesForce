<?php

/**
 * @file adp_docebo.php
 * @author T. Treadwell
 * @date 2022-10-04
 *
 * ADP -> Docebo data integration script.
 * Retrieves set of workers from ADP and syncs them to Docebo.
 *
 * Options
 *   -w
 *       Set write mode - Write data to Docebo. If not set, no data is
 *       written.
 *
 *   -s <email>
 *       Process a single user in ADP with email <email>. If set, batch of ADP
 *       users is not processed.
 *
 *   -p
 *       Process pilot set of users set in config file. If set, batch of ADP
 *       users is not processed.
 *
 * Examples:
 *   Test setting for one user:
 *     php adp_docebo.php -s ted@example.com
 *
 *   Process pilot users in write mode:
 *     php adp_docebo.php -w -p
 *
 *   Production setting:
 *     php adp_docebo.php -w
 */

use \Monolog\Logger;
use \Monolog\Handler\RotatingFileHandler;
use \Monolog\Handler\StreamHandler;
use \Monolog\Handler\NativeMailerHandler;
use \Scs\Integration\ADP_Docebo\AdpDoceboIntegration;

// Report significant errors.
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Set custom error log.
$log_dir = __DIR__ . '/../../../log/nest/adp';
ini_set('error_log', $log_dir . '/error.log');

// Load and initialize the autoloader.
require_once __DIR__ . '/../../../sites/nest/includes/Psr4Autoloader.php';
$loader = new Psr4Autoloader();
$loader->register();
$loader->addNamespace('Scs', __DIR__ . '/../../../sites/nest/includes/src');
$loader->addNamespace(
    'Monolog',
    __DIR__ . '/../../../core/vendor/monolog/monolog/src/Monolog'
);
$loader->addNamespace('Psr', __DIR__ . '/../../../core/vendor/psr/log/Psr');

// Load ADP config file.
require_once __DIR__ . '/../../../sites/nest/includes/adp/adp_config.php';

// Get an instance of the Monolog logger.
$logger = getLogger(
    $log_dir,
    'ADP-Docebo Sync',
    $adp_config['alert_email_address']
);

// Verify that the request is from the command line.
$ssec = new Scs\ScsSecurity();
$valid_request = $ssec->verifyLocalRequest();
if (!$valid_request) {
    $logger->addError(
        __FILE__ . ': ' . __LINE__ .
        ': Invalid request from ' . $_SERVER['REMOTE_ADDR']
    );
    exit();
}

// Retrieve command-line options.
$options = getopt('ws:p');

// Check for write mode option.
$write_mode = false;
if (array_key_exists('w', $options)) {
    $write_mode = true;
    echo 'Running in write mode.' . PHP_EOL;
} else {
    echo 'Running in test mode - nothing will be written to Docebo.' . PHP_EOL;
}

// Check for single user option.
$single_user  = '';
if (array_key_exists('s', $options)) {
    if (!empty($options['s'])) {
        $single_user = $options['s'];
        echo 'Processing single user ' . $options['s'] . PHP_EOL;
    } else {
        $msg = 'Missing -s option value (email address)';
        $logger->addError(__FILE__ . ' line ' . __LINE__ . ': ' . $msg);
        echo $msg . PHP_EOL;
        exit;
    }
}

// Check for pilot mode option.
$pilot_mode = false;
if (array_key_exists('p', $options)) {
    $pilot_mode = true;
    echo 'Processing pilot users.' . PHP_EOL;
}

$adi_options = [
    'write_mode' => $write_mode,
    'single_user' => $single_user,
    'pilot_mode' => $pilot_mode,
];

// Load Docebo config file.
require_once __DIR__ . '/../../../sites/nest/includes/docebo/docebo_config.php';

// Set up AdpDoceboIntegration object.
$adi = new AdpDoceboIntegration(
    $logger,
    $adp_config,
    $docebo_configs[$docebo_mode],
    $adi_options
);

// Sync single user to Docebo if option specified on command line.
if (!empty($single_user)) {
    $adi->syncAdpWorkerToDocebo($single_user);
}

// Sync pilot users to Docebo if option specified on command line.
if ($pilot_mode) {
    foreach ($adp_config['pilot_users'] as $email) {
        $adi->syncAdpWorkerToDocebo($email);
    }
}

// Sync the set of workers to Docebo if -s and -p options not specified.
if (empty($single_user) && !$pilot_mode) {
    $adi->syncAllAdpWorkersToDocebo();
}

/**
 * Set up Monolog logger.
 * TODO: move this to a static method in a class
 *
 * @param string $log_dir
 *     folder for log files
 * @param string $channel
 *     identifier for this part of application
 * @param string $alert_email_address
 *     email address to send alerts to
 *
 * @return object
 *     Monolog\Logger instance
 */
function getLogger($log_dir, $channel, $alert_email_address)
{
    global $logger;
    if (is_a($logger, '\Monolog\Logger')) {
        return $logger;
    }

    // Set up Monolog logger.
    $logger = new Logger($channel);

    // Debug log, stores all events.
    $logger->pushHandler(new RotatingFileHandler(
        $log_dir . '/debug.log',
        1095,
        Logger::DEBUG
    ));

    // Error log, stores events of level warning and above.
    $logger->pushHandler(new StreamHandler(
        $log_dir . '/error.log',
        Logger::WARNING
    ));

    // Error alert, sends email for events of level error and above.
    $validated_email = filter_var(
        $alert_email_address,
        \FILTER_VALIDATE_EMAIL
    );
    if (!empty($validated_email)) {
        $to = $validated_email;
        $subject = 'Error alert: ' . $channel;
        $from = 'donotreply@scscertified.com';
        $level = Logger::ERROR;
        $logger->pushHandler(new NativeMailerHandler(
            $to,
            $subject,
            $from,
            $level
        ));
    } else {
        $logger->addError(
            __FILE__ . ' line ' . __LINE__ . ': ' . __METHOD__ .
            ': Invalid alert email address: "' .
            $alert_email_address . '"'
        );
    }
    $logger->debug('Logger initialized');
    return $logger;
}
