# Nest

### About this Repo

---

This repo is two main projects -- one Symfony project folder representing both the API and the "core" controllers & 
entities used by Nest or any other web application using the same instance of Symfony, and a second representing the 
actual web root and non-Symfony production code. (Since these are not native Symfony apps, and instead interact via 
the Nest API, they avoid some kinds of interference from Symfony -- such as templating delimiter collisions with 
Symfony's Twig engine, for example).

These began as separate repos -- Symfony and the Nest web root, under the Nest repo, and the [www.scscertified.com](https://www.scscertified.com) 
repo. The have been combined under this parent folder. The existing .gitignore files have been left in place, in their 
respective subdirectories. This turns out to work just fine, and avoids having to combine them and prefix their constituent 
paths.

Note there is an alias in the 'web-root' repo, at the root level, that points to the 'web' folder in the 'core' project. 
This alias may appear to be broken in a dev environment, if the same folder structure is not used (.e.g, /web/com/
scscertified-nest...), but should work in the production web environment. The alias is ignored by git to avoid duplicating 
content in the parent repo.
